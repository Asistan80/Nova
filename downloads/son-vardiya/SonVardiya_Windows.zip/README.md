# SON VARDİYA
Godot 4.3 ile yapılmış 3B korku oyunu. Terk edilmiş Kuzey Kanat'ta gece bekçisisin.

Kontroller: WASD yürü · Shift koş · C çömel · E etkileşim · F el feneri · J defter · Esc duraklat.
Güvenlik masasındaki monitörden kameraları izle (A/D kamera değiştirir).
Dört final: Kaçış, Gerçek, Vardiya Devri, Tedavi (gizli).

Kaynaktan çalıştırma: Godot 4.3 ile proje klasörünü aç, F5.
