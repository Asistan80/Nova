# Masaüstü Arkadaşı

Masaüstünde yaşayan sanal arkadaş: yürür, uyur, duvara tırmanır, top oynar, yemek yer, sohbet eder.
Godot 4.3 / GDScript. Görsellerin tamamı kodla çizilir, dış dosya gerekmez.

## Çalıştırma (Windows)
`MasaustuArkadasi.exe` dosyasına çift tıkla. Kurulum yok. Tepsi (saat yanı) simgesinden Göster/Gizle, Sohbet, Ayarlar, Çıkış.
Saydam pencere sorun çıkarırsa `PencereModu.bat` ile ya da `--pencere` argümanıyla başlat (normal pencerede çalışır).

## Kullanım
- Sol tık: sev. Basılı tutup sürükle: tut ve fırlat. Çift tık: sohbet. Sağ tık: menü.
- Top ve yemekleri sürükleyip fırlatabilirsin. Yemeği doğrudan arkadaşının üstüne bırakırsan yer.
- Fareyi hızlı sallarsan imleci kovalar. Gece boştayken uyur.
- Sohbette: "10 dakika sonra çayı hatırlat", "pomodoro başlat", "adım Murat", "bunu hatırla: ...", "top oynayalım", "uyu", "dans et".
- Menüden: besle, sev, top, uyku, gardırop (seviye atladıkça aksesuar), durum ve 16 başarım, pomodoro ve hatırlatıcılar, ayarlar.
- 8 karakter: Börü (kurt), Minnoş (kedi), Kızıl (tilki), Pamuk (tavşan), Bulut (ruh), Pofuduk (köpek yavrusu), Bambu (panda), Fındık (hamster). Yeni yiyecekler: bambu, çekirdek.

## Yeni özellikler (v3)
- Numaralar: her karakterin kendine özgü hareketi var (kurt uluma, kedi yalanma, tilki atlayış, tavşan zıplama, ruh erime, köpek kuyruk kovalama, panda yuvarlanma, hamster çark). Menü > "Numara yap" ya da kendiliğinden yapar.
- Mevsim aksesuarları: kış beresi, çiçek tacı, hasır şapka, sonbahar yaprağı. Ayarlar > "Mevsime göre otomatik giyin" ile o mevsimin aksesuarını kendisi takar.
- Yıldız yakala (mini oyun): menüden başlat, 30 saniye düşen yıldızlara tıkla (altın yıldız 3 puan). Oyun sürerken fare ekranın tamamında yakalanır, süre bitince normale döner.
- Yoldaş: Ayarlar > "Yanında bir arkadaş" ile ikinci karakter ekle; birbirleriyle buluşur, top oynar, uyur. Ona tıklarsan sevinir.

## Yapay zekâ (Ayarlar > Yapay Zekâ)
- Çevrimdışı: internet gerekmez, kural tabanlı.
- Ollama: adres `http://localhost:11434`, "Modelleri Getir" ile model seç.
- Claude API: anahtarını gir (yalnızca bu bilgisayarda saklanır), model varsayılanı `claude-haiku-4-5-20251001`.
- Hata olursa otomatik çevrimdışı moda döner.

## Veri
`user://arkadas.json` (Windows: `%APPDATA%\Godot\app_userdata\Masaüstü Arkadaşı\`). Silersen sıfırlanır.

## Not
Saydamlık, fare geçirgenliği, tepsi simgesi ve Windows ile başlatma bu geliştirme ortamında denenemedi (sunucuda pencere sistemi yok). Mantık, çizim, arayüz ve yapay zekâ bağlantısı sanal ekranda ve sahte sunucularla test edildi.
