@echo off
rem Saydam pencere sorun cikarirsa normal pencerede calistirir.
start "" "%~dp0MasaustuArkadasi.exe" --pencere
