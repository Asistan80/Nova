EVRİM HAVUZU + MİKRO DÜNYA  (Godot 4.3)
=======================================
Sinir ağıyla evrilen yaratıklar ve canlı bir ekosistem.
Bitkiler -> Otoburlar -> Avcılar. Her yaratığın kendi beyni ve genleri var;
yiyecek bulup üreyenler beynini ve genlerini mutasyonla çocuklarına aktarır.

KONTROLLER
  Fare tekerleği: yakınlaştır | Sağ/orta tuş sürükle veya WASD/ok: kaydır
  Sol tık: seçili araç (Seç, Bitki, Otobur, Avcı, Süpürge, Gübre, Meteor)
  Boşluk: duraklat | 1-5: hız (1x,2x,4x,8x,16x) | F: seçileni takip et | Home: kamerayı sığdır
  G: grafikler | N: besin haritası | V: video modu | Tab: arayüzü gizle | M: ses
  F5 / F9: hızlı kaydet / yükle | F12: ekran görüntüsü | Esc: menü | H: yardım

ÖZELLİKLER
  - 7 gen: hız, boy, görüş mesafesi, görüş açısı, yalıtım(kürk), üreme eşiği, renk
  - Seçili yaratığın sinir ağı canlı görüntülenir (10 girdi, 10 gizli, 3 çıktı)
  - İklim: mevsimler, gece-gündüz, sıcaklık; besin haritası (ölenler toprağı besler)
  - Felaketler: meteor, kuraklık, buzul çağı, sıcak dalga, salgın, mutasyon fırtınası, bereket
  - Grafikler: nüfus, otobur/avcı gen ortalamaları, iklim, ölüm nedenleri
  - Şeref Salonu: en başarılı yaratıklar yeni dünyalarda kullanılabilir
  - 3 kayıt yuvası + otomatik kayıt
  - Video modu: arayüzsüz, otomatik kamera, istenirse otomatik felaket (Easy Life AI filigranı)
  - Ses: çalışma anında üretilen efektler ve ortam sesi

WEB SÜRÜMÜ
  index.html dosyasını doğrudan açmak çalışmaz (tarayıcı kısıtı). Web_Calistir.bat dosyasına çift tıkla
  (Python gerekir) ya da klasörde:  python -m http.server 8000  yazıp  http://localhost:8000  adresini aç.

VİDEO KAYDI İPUCU (Windows exe):
  EvrimHavuzu.exe --write-movie kayit.avi --fixed-fps 30   (Godot Movie Maker, kare kare kayıt)
