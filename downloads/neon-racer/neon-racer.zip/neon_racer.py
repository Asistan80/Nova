"""
NEON RACER - Synthwave Arcade Araba Yarisi (v3)
Tamamen Python (Pygame) ile, harici gorsel/ses dosyasi kullanilmadan yazilmistir.
Sesler numpy ile aninda uretilir. Skor tablosu + basarimlar + istatistikler
yaninda olusan bir JSON dosyasinda kalici olarak saklanir (neon_racer_data.json).

Kontroller:
  W/A/S/D veya Ok Tuslari - Hareket
  SPACE - Nitro
  P - Duraklat / Devam Et
  M - Sesi Ac/Kapat (sag ust hoparlor ikonu ile de degistirilebilir)
  ESC - Menuye don
"""

import pygame
import numpy as np
import random
import math
import sys
import os
import json
import time as time_module

# ------------------------------------------------------------------
# KURULUM
# ------------------------------------------------------------------
pygame.mixer.pre_init(44100, -16, 2, 256)
pygame.init()
pygame.mixer.set_num_channels(16)
pygame.mixer.init()

WIDTH, HEIGHT = 900, 650
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
IS_FULLSCREEN = False

def toggle_fullscreen():
    global screen, IS_FULLSCREEN
    IS_FULLSCREEN = not IS_FULLSCREEN
    if IS_FULLSCREEN:
        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    else:
        screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)

def blit_scaled(render_surf, ox, oy):
    """Internal sabit cozunurlugu (WIDTH x HEIGHT) ekrana en-boy oranini koruyarak
    (letterbox ile) cizer - boylece tam ekranda da bozulma olmaz."""
    sw, sh = screen.get_size()
    scale = min(sw / WIDTH, sh / HEIGHT)
    new_w, new_h = int(WIDTH * scale), int(HEIGHT * scale)
    off_x = (sw - new_w) // 2
    off_y = (sh - new_h) // 2
    screen.fill(BLACK)
    if scale != 1.0:
        scaled = pygame.transform.smoothscale(render_surf, (new_w, new_h))
    else:
        scaled = render_surf
    screen.blit(scaled, (off_x + ox * scale, off_y + oy * scale))
    return scale, off_x, off_y
pygame.display.set_caption("NEON RACER")
clock = pygame.time.Clock()
FPS = 60

BLACK = (5, 5, 12)
DARK = (12, 8, 28)
NEON_PINK = (255, 30, 180)
NEON_BLUE = (40, 220, 255)
NEON_GREEN = (60, 255, 140)
NEON_YELLOW = (255, 230, 60)
NEON_ORANGE = (255, 130, 40)
NEON_PURPLE = (170, 60, 255)
NEON_RED = (255, 70, 90)
WHITE = (240, 240, 255)
GREY = (90, 90, 110)

FONT_BIG = pygame.font.SysFont("consolas", 58, bold=True)
FONT_MED = pygame.font.SysFont("consolas", 30, bold=True)
FONT_SMALL = pygame.font.SysFont("consolas", 20, bold=True)
FONT_TINY = pygame.font.SysFont("consolas", 14)

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "neon_racer_data.json")

# ------------------------------------------------------------------
# KALICI VERI: SKORLAR + ISTATISTIKLER + BASARIMLAR
# ------------------------------------------------------------------
DEFAULT_DATA = {
    "scores": {"endless": [], "time": [], "survival": [], "fuel": [], "race": []},
    "stats": {
        "total_distance": 0, "total_coins": 0, "total_nitro_frames": 0,
        "runs_finished": 0, "themes_seen": [], "best_combo": 0,
        "survival_best_time": 0, "race_wins": 0, "crash_free_best": 0,
    },
    "achievements_unlocked": [],
}

def load_data():
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
            for k, v in DEFAULT_DATA.items():
                if k not in d:
                    d[k] = v
            for k in DEFAULT_DATA["scores"]:
                d["scores"].setdefault(k, [])
            for k, v in DEFAULT_DATA["stats"].items():
                d["stats"].setdefault(k, v)
            return d
        except Exception:
            return json.loads(json.dumps(DEFAULT_DATA))
    return json.loads(json.dumps(DEFAULT_DATA))

def save_data():
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(DATA, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

DATA = load_data()
SCORES = DATA["scores"]
STATS = DATA["stats"]

def fmt_time(seconds):
    seconds = max(0, int(seconds))
    m, s = divmod(seconds, 60)
    return f"{m:02d}:{s:02d}"

def qualifies_for_top(mode, score, limit=10):
    lst = SCORES.get(mode, [])
    if len(lst) < limit:
        return True
    return score > min(e["score"] for e in lst)

def add_score(mode, name, score, elapsed, limit=10):
    lst = SCORES.setdefault(mode, [])
    lst.append({"name": (name or "ANONIM")[:12], "score": int(score), "time": round(elapsed, 1)})
    lst.sort(key=lambda e: e["score"], reverse=True)
    del lst[limit:]
    save_data()

# ------------------------------------------------------------------
# BASARIMLAR (10+)
# ------------------------------------------------------------------
class Achievement:
    def __init__(self, key, name, desc, check):
        self.key = key
        self.name = name
        self.desc = desc
        self.check = check  # fonksiyon: (stats, run_ctx) -> bool

ACHIEVEMENTS = [
    Achievement("first_drive", "ILK SURUS", "Bir oyunu tamamla",
                lambda s, r: s["runs_finished"] >= 1),
    Achievement("dist_1000", "1000 METRE", "Tek seferde 1000m git",
                lambda s, r: r.get("distance", 0) >= 1000),
    Achievement("dist_5000", "5000 METRE", "Tek seferde 5000m git",
                lambda s, r: r.get("distance", 0) >= 5000),
    Achievement("dist_total_10000", "YOL TUTKUNU", "Toplamda 10.000m yol kat et",
                lambda s, r: s["total_distance"] >= 10000),
    Achievement("coins_50", "ALTIN AVCISI", "Toplamda 50 altin topla",
                lambda s, r: s["total_coins"] >= 50),
    Achievement("coins_200", "HAZINE AVCISI", "Toplamda 200 altin topla",
                lambda s, r: s["total_coins"] >= 200),
    Achievement("combo_10", "KOMBO USTASI", "x10 kombo yap",
                lambda s, r: s["best_combo"] >= 10),
    Achievement("crash_free_2000", "TEMIZ SURUS", "Carpismadan 2000m git",
                lambda s, r: s["crash_free_best"] >= 2000),
    Achievement("survival_180", "HAYATTA KALAN", "Hayatta Kalim modunda 3 dakika dayan",
                lambda s, r: s["survival_best_time"] >= 180),
    Achievement("time_attack_win", "ZAMAN USTASI", "Zamana Karsi modunu bitir",
                lambda s, r: r.get("mode") == "time" and r.get("win")),
    Achievement("nitro_60s", "NITRO BAGIMLISI", "Toplamda 60 saniye nitro kullan",
                lambda s, r: s["total_nitro_frames"] >= 60 * FPS),
    Achievement("fuel_master", "YAKIT USTASI", "Yakit modunda hic tukenmeden 3000m git",
                lambda s, r: r.get("mode") == "fuel" and r.get("distance", 0) >= 3000 and not r.get("fuel_ran_out")),
    Achievement("race_win", "YARIS GALIBI", "Yaris modunda 1. ol",
                lambda s, r: r.get("mode") == "race" and r.get("position") == 1),
    Achievement("all_themes", "GEZGIN", "Tum ortamlari gor (4 tema)",
                lambda s, r: len(set(s["themes_seen"])) >= 4),
    Achievement("runs_10", "KIDEMLI PILOT", "10 oyun tamamla",
                lambda s, r: s["runs_finished"] >= 10),
]

def check_achievements(run_ctx):
    """run_ctx: bu kosunun ozet bilgisi. Yeni acilan basarimlari dondurur."""
    newly = []
    unlocked = set(DATA["achievements_unlocked"])
    for ach in ACHIEVEMENTS:
        if ach.key in unlocked:
            continue
        try:
            if ach.check(STATS, run_ctx):
                unlocked.add(ach.key)
                newly.append(ach)
        except Exception:
            pass
    if newly:
        DATA["achievements_unlocked"] = list(unlocked)
        save_data()
    return newly

# ------------------------------------------------------------------
# SES URETIMI (harici dosya yok - numpy ile sentezleme)
# ------------------------------------------------------------------
SAMPLE_RATE = 44100

def to_sound(wave, volume=0.5):
    wave = np.clip(wave, -1, 1)
    wave = (wave * volume * 32767).astype(np.int16)
    stereo = np.column_stack([wave, wave])
    return pygame.sndarray.make_sound(np.ascontiguousarray(stereo))

def envelope(n, attack=0.05, release=0.25):
    env = np.ones(n)
    a = max(1, int(n * attack))
    r = max(1, int(n * release))
    env[:a] = np.linspace(0, 1, a)
    env[-r:] = np.linspace(1, 0, r)
    return env

def make_sound(freq=440, duration=0.15, volume=0.4, kind="sine", fade=True, detune=0.0):
    n = int(SAMPLE_RATE * duration)
    t = np.linspace(0, duration, n, False)
    f2 = freq * (1 + detune)
    def osc(f, k):
        if k == "sine":
            return np.sin(f * t * 2 * np.pi)
        elif k == "square":
            return np.sign(np.sin(f * t * 2 * np.pi))
        elif k == "saw":
            return 2 * (t * f - np.floor(t * f + 0.5))
        elif k == "tri":
            return 2 * np.abs(2 * (t * f - np.floor(t * f + 0.5))) - 1
        elif k == "noise":
            return np.random.uniform(-1, 1, n)
        return np.sin(f * t * 2 * np.pi)
    wave = osc(freq, kind)
    if detune:
        wave = 0.6 * wave + 0.4 * osc(f2, kind)
    if fade:
        wave = wave * envelope(n, 0.08, 0.3)
    return to_sound(wave, volume)

def make_sweep(f0, f1, duration=0.4, volume=0.4, kind="square"):
    n = int(SAMPLE_RATE * duration)
    t = np.linspace(0, duration, n, False)
    freq_t = np.linspace(f0, f1, n)
    phase = np.cumsum(freq_t) / SAMPLE_RATE * 2 * np.pi
    wave = np.sign(np.sin(phase)) if kind == "square" else np.sin(phase)
    wave *= np.linspace(1, 0.05, n)
    return to_sound(wave, volume)

def make_crash():
    n = int(SAMPLE_RATE * 0.35)
    noise = np.random.uniform(-1, 1, n)
    env = np.linspace(1, 0, n) ** 1.4
    wave = noise * env
    low = np.sin(np.linspace(0, 55, n) * 2 * np.pi) * env * 0.7
    crackle = (np.random.uniform(-1, 1, n) > 0.97).astype(float) * env
    wave = wave * 0.45 + low * 0.45 + crackle * 0.3
    return to_sound(wave, 0.7)

def make_wind(duration=0.5):
    n = int(SAMPLE_RATE * duration)
    noise = np.random.uniform(-1, 1, n)
    kernel = np.ones(50) / 50
    filtered = np.convolve(noise, kernel, mode="same")
    env = np.sin(np.linspace(0, np.pi, n))
    wave = filtered * env
    return to_sound(wave, 0.4)

def make_engine_loop(base_freq, duration=0.9, volume=0.18):
    n = int(SAMPLE_RATE * duration)
    t = np.linspace(0, duration, n, False)
    cycles = max(1, round(base_freq * duration))
    real_freq = cycles / duration
    wave = np.sign(np.sin(real_freq * t * 2 * np.pi)) * 0.5
    wave += np.sign(np.sin(real_freq * 2.01 * t * 2 * np.pi)) * 0.18
    wave += np.sin(real_freq * 0.5 * t * 2 * np.pi) * 0.25
    wave += np.random.uniform(-1, 1, n) * 0.04
    fl = max(2, int(n * 0.01))
    fadewin = np.ones(n)
    fadewin[:fl] = np.linspace(0, 1, fl)
    fadewin[-fl:] = np.linspace(1, 0, fl)
    wave *= fadewin
    return to_sound(wave, volume)

SND_CLICK = make_sound(700, 0.07, 0.3, "square")
SND_HOVER = make_sound(900, 0.05, 0.15, "sine")
SND_COUNT = make_sound(440, 0.18, 0.4, "square", detune=0.01)
SND_GO = make_sweep(300, 1000, 0.35, 0.5, "square")
SND_CRASH = make_crash()
SND_NITRO = make_wind(0.5)
SND_COIN = make_sound(1300, 0.1, 0.35, "sine", detune=0.005)
SND_COIN2 = make_sound(1700, 0.08, 0.28, "sine")
SND_CLOCK_PICKUP = make_sweep(600, 1300, 0.18, 0.4, "sine")
SND_GAMEOVER = make_sweep(500, 70, 0.7, 0.4, "saw")
SND_HIGHSCORE = make_sweep(440, 1400, 0.6, 0.45, "square")
SND_TYPE = make_sound(950, 0.04, 0.18, "square")
SND_PAUSE = make_sound(330, 0.12, 0.28, "tri")
SND_FUEL = make_sweep(500, 900, 0.2, 0.4, "sine")
SND_FUEL_LOW = make_sound(220, 0.3, 0.3, "square")
SND_BOOST = make_sweep(400, 1200, 0.3, 0.45, "saw")
SND_ACHIEVEMENT = make_sweep(660, 1760, 0.5, 0.5, "square")
SND_LAP = make_sweep(500, 1000, 0.25, 0.4, "tri")
SND_RACE_WIN = make_sweep(300, 1800, 1.0, 0.5, "square")

ENGINE_BANDS = [make_engine_loop(f, 0.9, 0.16) for f in (55, 70, 90, 115, 145, 180)]

def make_music_loop(mood="city", bars=8):
    presets = {
        "city":    {"bpm": 128, "bass": [110, 110, 146, 110, 130, 110, 164, 146], "wave": "square"},
        "desert":  {"bpm": 100, "bass": [98, 98, 110, 98, 87, 87, 98, 110],        "wave": "saw"},
        "cyber":   {"bpm": 150, "bass": [82, 123, 82, 110, 82, 123, 98, 110],      "wave": "square"},
        "space":   {"bpm": 90,  "bass": [73, 73, 65, 73, 87, 73, 98, 87],          "wave": "tri"},
    }
    p = presets.get(mood, presets["city"])
    beat = 60 / p["bpm"]
    n_total = int(SAMPLE_RATE * beat * bars)
    wave = np.zeros(n_total)
    step = n_total // bars
    for i, f in enumerate(p["bass"]):
        seg_t = np.linspace(0, beat, step, False)
        if p["wave"] == "square":
            seg = np.sign(np.sin(f * seg_t * 2 * np.pi))
        elif p["wave"] == "saw":
            seg = 2 * (seg_t * f - np.floor(seg_t * f + 0.5))
        else:
            seg = 2 * np.abs(2 * (seg_t * f - np.floor(seg_t * f + 0.5))) - 1
        seg = seg * 0.18
        arp = np.sign(np.sin(f * 2 * seg_t * 2 * np.pi)) * 0.06
        seg = seg + arp
        env = np.ones(step)
        fl = max(2, step // 6)
        env[-fl:] = np.linspace(1, 0, fl)
        seg *= env
        wave[i * step:i * step + step] += seg
    for i in range(bars * 2):
        pos = int(i * n_total / (bars * 2))
        click_len = min(250, n_total - pos)
        if click_len > 0:
            wave[pos:pos + click_len] += np.random.uniform(-1, 1, click_len) * 0.04
    return to_sound(wave, 0.4)

MUSIC_TRACKS = {
    "city": make_music_loop("city"),
    "desert": make_music_loop("desert"),
    "cyber": make_music_loop("cyber"),
    "space": make_music_loop("space"),
}

# ------------------------------------------------------------------
# SES YONETIMI
# ------------------------------------------------------------------
class AudioManager:
    def __init__(self):
        self.music_on = True
        self.sfx_on = True
        self.music_channel = pygame.mixer.Channel(0)
        self.engine_channel = pygame.mixer.Channel(1)
        self.nitro_channel = pygame.mixer.Channel(2)
        self._music_playing = False
        self._current_track = None
        self._engine_band = -1
        self.music_volume = 0.28   # daha kisik varsayilan
        self.sfx_volume = 0.65

    def play_music(self, track_key="city"):
        if not self.music_on:
            self._current_track = track_key
            return
        if self._current_track != track_key or not self._music_playing:
            self.music_channel.play(MUSIC_TRACKS[track_key], loops=-1)
            self.music_channel.set_volume(self.music_volume)
            self._music_playing = True
            self._current_track = track_key

    def stop_music(self):
        self.music_channel.stop()
        self._music_playing = False

    def toggle_master(self):
        new_state = not (self.music_on or self.sfx_on)
        self.music_on = new_state
        self.sfx_on = new_state
        if not new_state:
            self.stop_music()
            self.engine_channel.stop()
        else:
            self.play_music(self._current_track or "city")

    def play(self, snd, vol=1.0):
        if self.sfx_on:
            snd.set_volume(vol * self.sfx_volume)
            snd.play()

    def update_engine(self, speed_ratio):
        if not self.sfx_on:
            self.engine_channel.stop()
            self._engine_band = -1
            return
        band = min(len(ENGINE_BANDS) - 1, int(speed_ratio * len(ENGINE_BANDS)))
        if band != self._engine_band:
            self._engine_band = band
            self.engine_channel.play(ENGINE_BANDS[band], loops=-1, fade_ms=120)
        vol = (0.14 + min(0.18, speed_ratio * 0.14)) * self.sfx_volume
        self.engine_channel.set_volume(vol)

    def stop_engine(self):
        self.engine_channel.stop()
        self._engine_band = -1

    def is_any_on(self):
        return self.music_on or self.sfx_on

AUDIO = AudioManager()

# ------------------------------------------------------------------
# YARDIMCI FONKSIYONLAR
# ------------------------------------------------------------------
def lerp(a, b, t):
    return a + (b - a) * t

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def draw_glow_rect(surf, color, rect, glow=10, radius=8):
    x, y, w, h = rect
    glow_surf = pygame.Surface((w + glow * 2, h + glow * 2), pygame.SRCALPHA)
    for i in range(glow, 0, -2):
        alpha = int(60 * (1 - i / glow))
        pygame.draw.rect(glow_surf, (*color, alpha),
                          (glow - i, glow - i, w + i * 2, h + i * 2), border_radius=radius + i)
    surf.blit(glow_surf, (x - glow, y - glow))
    pygame.draw.rect(surf, color, rect, border_radius=radius)

def draw_glow_circle(surf, color, pos, radius, glow=14, alpha_mul=1.0):
    radius = max(1, int(radius))
    glow_surf = pygame.Surface((radius * 4, radius * 4), pygame.SRCALPHA)
    cx, cy = radius * 2, radius * 2
    for i in range(glow, 0, -2):
        alpha = int(50 * alpha_mul * (1 - i / glow))
        pygame.draw.circle(glow_surf, (*color, alpha), (cx, cy), radius + i)
    pygame.draw.circle(glow_surf, color, (cx, cy), radius)
    surf.blit(glow_surf, (pos[0] - cx, pos[1] - cy))

def draw_text_glow(surf, text, font, color, pos, center=True, glow_color=None):
    glow_color = glow_color or color
    base = font.render(text, True, color)
    glow = font.render(text, True, glow_color)
    rect = base.get_rect()
    if center:
        rect.center = pos
    else:
        rect.topleft = pos
    for dx, dy in [(-2, 0), (2, 0), (0, -2), (0, 2)]:
        gsurf = glow.copy()
        gsurf.set_alpha(60)
        surf.blit(gsurf, (rect.x + dx, rect.y + dy))
    surf.blit(base, rect)
    return rect

# ------------------------------------------------------------------
# PARCACIK SISTEMI
# ------------------------------------------------------------------
class Particle:
    def __init__(self, x, y, color, vx=None, vy=None, life=30, size=4, gravity=0.0):
        self.x, self.y = x, y
        self.vx = vx if vx is not None else random.uniform(-3, 3)
        self.vy = vy if vy is not None else random.uniform(-3, 3)
        self.color = color
        self.life = life
        self.max_life = life
        self.size = size
        self.gravity = gravity

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += self.gravity
        self.life -= 1

    def draw(self, surf):
        if self.life <= 0:
            return
        t = self.life / self.max_life
        alpha = clamp(int(255 * t), 0, 255)
        s = max(1, int(self.size * t))
        p_surf = pygame.Surface((s * 2, s * 2), pygame.SRCALPHA)
        pygame.draw.circle(p_surf, (*self.color, alpha), (s, s), s)
        surf.blit(p_surf, (self.x - s, self.y - s))

    @property
    def alive(self):
        return self.life > 0

particles = []

def spawn_exhaust(x, y, color, n=2):
    for _ in range(n):
        particles.append(Particle(
            x + random.uniform(-4, 4), y + random.uniform(-2, 2),
            color, vx=random.uniform(-0.5, 0.5), vy=random.uniform(2, 5),
            life=random.randint(14, 26), size=random.uniform(3, 6)))

def spawn_sparks(x, y, n=18):
    colors = [NEON_YELLOW, NEON_ORANGE, WHITE]
    for _ in range(n):
        angle = random.uniform(0, math.pi * 2)
        speed = random.uniform(2, 7)
        particles.append(Particle(
            x, y, random.choice(colors),
            vx=math.cos(angle) * speed, vy=math.sin(angle) * speed,
            life=random.randint(16, 30), size=random.uniform(2, 5), gravity=0.15))

def spawn_coin_burst(x, y):
    for _ in range(10):
        angle = random.uniform(0, math.pi * 2)
        speed = random.uniform(1, 4)
        particles.append(Particle(
            x, y, NEON_YELLOW, vx=math.cos(angle) * speed, vy=math.sin(angle) * speed,
            life=random.randint(10, 20), size=random.uniform(2, 4)))

# ------------------------------------------------------------------
# ORTAMLAR (TEMALAR)
# ------------------------------------------------------------------
class Theme:
    def __init__(self, key, name, sky_top, sky_bottom, sun_color, road_color,
                 line_color, accent, music_key, deco, show_sun=True):
        self.key = key
        self.name = name
        self.sky_top = sky_top
        self.sky_bottom = sky_bottom
        self.sun_color = sun_color
        self.road_color = road_color
        self.line_color = line_color
        self.accent = accent
        self.music_key = music_key
        self.deco = deco
        self.show_sun = show_sun

THEMES = [
    Theme("city", "NEON SEHIR", (40, 6, 40), (10, 8, 26), NEON_PINK, (20, 14, 36), NEON_PURPLE, NEON_BLUE, "city", "city", show_sun=False),
    Theme("desert", "GUNBATIMI COLU", (120, 40, 20), (40, 16, 30), NEON_ORANGE, (35, 18, 16), NEON_YELLOW, NEON_RED, "desert", "desert", show_sun=True),
    Theme("cyber", "SIBER IZGARA", (5, 20, 40), (4, 4, 14), NEON_BLUE, (8, 10, 22), NEON_GREEN, NEON_PURPLE, "cyber", "cyber", show_sun=False),
    Theme("space", "DERIN UZAY", (10, 5, 35), (2, 2, 10), NEON_PURPLE, (12, 8, 24), NEON_BLUE, NEON_PINK, "space", "space", show_sun=False),
]

def theme_for_distance(distance):
    idx = int(distance // 1400) % len(THEMES)
    return THEMES[idx]

class Star:
    def __init__(self):
        self.x = random.uniform(0, WIDTH)
        self.y = random.uniform(0, HEIGHT * 0.4)
        self.size = random.uniform(1, 3)
        self.speed = random.uniform(0.2, 0.8)
        self.tw = random.uniform(0, math.pi * 2)

    def update(self):
        self.y += self.speed
        self.tw += 0.05
        if self.y > HEIGHT * 0.45:
            self.y = 0
            self.x = random.uniform(0, WIDTH)

stars = [Star() for _ in range(80)]

class Planet:
    def __init__(self):
        self.x = random.uniform(60, WIDTH - 60)
        self.y = random.uniform(30, 180)
        self.r = random.uniform(10, 26)
        self.color = random.choice([NEON_ORANGE, NEON_GREEN, NEON_PURPLE])

planets = [Planet() for _ in range(3)]

class Building:
    def __init__(self, x):
        self.x = x
        self.w = random.uniform(30, 70)
        self.h = random.uniform(60, 220)
        self.color = random.choice([NEON_PINK, NEON_BLUE, NEON_PURPLE])
        self.lit = random.random() < 0.5

city_buildings_l = [Building(random.uniform(-40, 250)) for _ in range(7)]
city_buildings_r = [Building(random.uniform(WIDTH - 250, WIDTH + 40)) for _ in range(7)]

class Dune:
    def __init__(self, y, amp):
        self.y = y
        self.amp = amp

dunes = [Dune(HEIGHT * 0.42 + i * 14, 10 + i * 3) for i in range(5)]

class CyberPillar:
    def __init__(self, x, side):
        self.x = x
        self.side = side
        self.h = random.uniform(80, 260)
        self.flicker = random.uniform(0, math.pi * 2)

cyber_pillars_l = [CyberPillar(random.uniform(-30, 200), "L") for _ in range(6)]
cyber_pillars_r = [CyberPillar(random.uniform(WIDTH - 200, WIDTH + 30), "R") for _ in range(6)]

ROADSIDE_SPACING = 190
ROADSIDE_COUNT = 7

def pick_roadside_kind(deco):
    if deco == "city":
        return random.choices(["house", "tree", "lamppost"], weights=[3, 4, 2])[0]
    if deco == "desert":
        return random.choices(["cactus", "rock", "deadtree"], weights=[4, 3, 2])[0]
    if deco == "cyber":
        return random.choices(["crystal", "antenna", "rock"], weights=[4, 3, 2])[0]
    if deco == "space":
        return random.choices(["rock", "crystal", "crater"], weights=[3, 3, 3])[0]
    return "tree"

class RoadsideProp:
    def __init__(self, side, slot):
        self.side = side
        self.slot = slot
        self.y = slot * ROADSIDE_SPACING - 260
        self.kind = None
        self.scale = random.uniform(0.85, 1.2)
        self.jitter = random.uniform(0, 22)
        self.lit = random.random() < 0.6
        self.flicker = random.uniform(0, math.pi * 2)

    def update(self, world_speed, deco):
        self.y += world_speed
        total_span = ROADSIDE_SPACING * ROADSIDE_COUNT
        if self.y > HEIGHT + 160:
            self.y -= total_span
            self.kind = None
        if self.kind is None:
            self.kind = pick_roadside_kind(deco)
        self.flicker += 0.04

    def base_x(self):
        margin = 18 + self.jitter
        if self.side == "L":
            return ROAD_X - margin - 30
        return ROAD_X + ROAD_W + margin + 30

LEFT_PROPS = [RoadsideProp("L", i) for i in range(ROADSIDE_COUNT)]
RIGHT_PROPS = [RoadsideProp("R", i) for i in range(ROADSIDE_COUNT)]

def shade_tuple(c, amt):
    return (clamp(c[0] + amt, 0, 255), clamp(c[1] + amt, 0, 255), clamp(c[2] + amt, 0, 255))

def draw_tree(surf, x, y, scale):
    trunk_h = int(20 * scale)
    pygame.draw.rect(surf, (70, 45, 30), (x - 3 * scale, y - trunk_h, 6 * scale, trunk_h))
    for dy, r, c in [(-trunk_h - 10 * scale, 16 * scale, (30, 110, 60)),
                     (-trunk_h - 20 * scale, 12 * scale, (40, 140, 75)),
                     (-trunk_h - 28 * scale, 8 * scale, (55, 170, 95))]:
        pygame.draw.circle(surf, c, (int(x), int(y + dy)), int(r))

def draw_deadtree(surf, x, y, scale):
    pygame.draw.line(surf, (60, 40, 30), (x, y), (x, y - 30 * scale), max(2, int(3 * scale)))
    pygame.draw.line(surf, (60, 40, 30), (x, y - 18 * scale), (x - 12 * scale, y - 30 * scale), 2)
    pygame.draw.line(surf, (60, 40, 30), (x, y - 22 * scale), (x + 10 * scale, y - 34 * scale), 2)

def draw_house(surf, x, y, scale, lit, accent):
    w, h = 38 * scale, 26 * scale
    base = pygame.Rect(x - w / 2, y - h, w, h)
    pygame.draw.rect(surf, (45, 32, 40), base, border_radius=2)
    roof = [(base.left - 4, base.top), (base.centerx, base.top - 16 * scale), (base.right + 4, base.top)]
    pygame.draw.polygon(surf, (80, 30, 40), roof)
    win_color = accent if lit else (40, 40, 50)
    pygame.draw.rect(surf, win_color, (base.left + 5 * scale, base.top + 6 * scale, 8 * scale, 8 * scale))
    pygame.draw.rect(surf, win_color, (base.right - 13 * scale, base.top + 6 * scale, 8 * scale, 8 * scale))
    pygame.draw.rect(surf, (20, 14, 18), (base.centerx - 4 * scale, base.bottom - 14 * scale, 8 * scale, 14 * scale))
    if lit:
        draw_glow_circle(surf, win_color, (int(base.left + 9 * scale), int(base.top + 10 * scale)), 3, glow=6, alpha_mul=0.5)

def draw_lamppost(surf, x, y, scale, flicker):
    pygame.draw.line(surf, (40, 40, 48), (x, y), (x, y - 46 * scale), max(2, int(3 * scale)))
    glow_amt = 0.6 + 0.4 * math.sin(flicker)
    draw_glow_circle(surf, NEON_YELLOW, (int(x), int(y - 46 * scale)), int(5 * scale), glow=int(14 * glow_amt), alpha_mul=glow_amt)

def draw_cactus(surf, x, y, scale):
    pygame.draw.rect(surf, (40, 110, 60), (x - 4 * scale, y - 30 * scale, 8 * scale, 30 * scale), border_radius=4)
    pygame.draw.rect(surf, (40, 110, 60), (x - 12 * scale, y - 20 * scale, 8 * scale, 14 * scale), border_radius=4)
    pygame.draw.rect(surf, (40, 110, 60), (x + 4 * scale, y - 24 * scale, 8 * scale, 14 * scale), border_radius=4)

def draw_rock(surf, x, y, scale, color=(70, 60, 70)):
    pts = [(x - 14 * scale, y), (x - 8 * scale, y - 14 * scale), (x + 6 * scale, y - 16 * scale),
           (x + 14 * scale, y - 4 * scale), (x + 10 * scale, y), (x - 4 * scale, y + 2 * scale)]
    pygame.draw.polygon(surf, color, pts)
    pygame.draw.polygon(surf, shade_tuple(color, 25), pts, 2)

def draw_crystal(surf, x, y, scale, accent):
    pts = [(x, y - 34 * scale), (x + 10 * scale, y - 10 * scale), (x, y), (x - 10 * scale, y - 10 * scale)]
    glow_surf = pygame.Surface((80, 80), pygame.SRCALPHA)
    pygame.draw.polygon(glow_surf, (*accent, 70), [(p[0] - x + 40, p[1] - y + 40) for p in pts])
    surf.blit(glow_surf, (x - 40, y - 40))
    pygame.draw.polygon(surf, accent, pts)
    pygame.draw.polygon(surf, WHITE, pts, 1)

def draw_antenna(surf, x, y, scale, flicker, accent):
    pygame.draw.line(surf, (50, 50, 60), (x, y), (x, y - 50 * scale), max(2, int(3 * scale)))
    glow_amt = 0.5 + 0.5 * math.sin(flicker * 2)
    draw_glow_circle(surf, accent, (int(x), int(y - 50 * scale)), int(4 * scale), glow=int(10 * glow_amt), alpha_mul=glow_amt)
    pygame.draw.line(surf, accent, (x - 8 * scale, y - 40 * scale), (x + 8 * scale, y - 40 * scale), 2)

def draw_crater(surf, x, y, scale):
    pygame.draw.ellipse(surf, (40, 38, 50), (x - 16 * scale, y - 6 * scale, 32 * scale, 12 * scale))
    pygame.draw.ellipse(surf, (60, 56, 70), (x - 16 * scale, y - 6 * scale, 32 * scale, 12 * scale), 2)

def draw_roadside_props(surf, theme, world_speed, horizon_y):
    for prop in LEFT_PROPS + RIGHT_PROPS:
        prop.update(world_speed, theme.deco)
        if prop.y < horizon_y - 10 or prop.y > HEIGHT + 40:
            continue
        x = prop.base_x()
        y = prop.y
        s = prop.scale
        if prop.kind == "tree":
            draw_tree(surf, x, y, s)
        elif prop.kind == "deadtree":
            draw_deadtree(surf, x, y, s)
        elif prop.kind == "house":
            draw_house(surf, x, y, s, prop.lit, theme.accent)
        elif prop.kind == "lamppost":
            draw_lamppost(surf, x, y, s, prop.flicker)
        elif prop.kind == "cactus":
            draw_cactus(surf, x, y, s)
        elif prop.kind == "rock":
            draw_rock(surf, x, y, s)
        elif prop.kind == "crystal":
            draw_crystal(surf, x, y, s, theme.accent)
        elif prop.kind == "antenna":
            draw_antenna(surf, x, y, s, prop.flicker, theme.accent)
        elif prop.kind == "crater":
            draw_crater(surf, x, y, s)

ROAD_W = 460
ROAD_X = (WIDTH - ROAD_W) // 2
LANES = 4
LANE_W = ROAD_W // LANES

def draw_background(surf, theme, speed_factor=1.0, anim_t=0, world_speed=2.5):
    surf.fill(BLACK)
    horizon_y = int(HEIGHT * 0.42)
    for i in range(horizon_y):
        t = i / horizon_y
        c = (
            int(lerp(theme.sky_top[0], theme.sky_bottom[0], t)),
            int(lerp(theme.sky_top[1], theme.sky_bottom[1], t)),
            int(lerp(theme.sky_top[2], theme.sky_bottom[2], t)),
        )
        pygame.draw.line(surf, c, (0, i), (WIDTH, i))

    # Gunes/ay sadece bazi temalarda gosterilir (her bolumde olmasin istendi)
    if theme.show_sun:
        sun_pos = (WIDTH // 2, horizon_y - 6)
        draw_glow_circle(surf, theme.sun_color, sun_pos, 60, glow=42, alpha_mul=0.75)
        sun_surf = pygame.Surface((130, 130), pygame.SRCALPHA)
        for r in range(54, 0, -2):
            t = r / 54
            c = (
                int(lerp(255, theme.sun_color[0], t)),
                int(lerp(255, theme.sun_color[1], t)),
                int(lerp(220, theme.sun_color[2], t)),
            )
            pygame.draw.circle(sun_surf, c, (65, 65), r)
        surf.blit(sun_surf, (sun_pos[0] - 65, sun_pos[1] - 65))
        haze = pygame.Surface((WIDTH, 36), pygame.SRCALPHA)
        for i in range(36):
            a = int(60 * (1 - i / 36))
            pygame.draw.line(haze, (*theme.sun_color, a), (0, i), (WIDTH, i))
        surf.blit(haze, (0, horizon_y - 18))

    if theme.deco == "city":
        for b in city_buildings_l + city_buildings_r:
            top = horizon_y - b.h
            pygame.draw.rect(surf, (20, 14, 30), (b.x, top, b.w, b.h + 20))
            pygame.draw.rect(surf, b.color, (b.x, top, b.w, b.h + 20), 2)
            if b.lit:
                for wy in range(int(top) + 8, horizon_y, 14):
                    for wx in range(int(b.x) + 6, int(b.x + b.w) - 6, 12):
                        if random.random() < 0.4:
                            pygame.draw.rect(surf, theme.accent, (wx, wy, 4, 6))
    elif theme.deco == "desert":
        for i, d in enumerate(dunes):
            shade = 30 + i * 10
            pygame.draw.ellipse(surf, (shade + 50, shade + 10, shade),
                                 (-60, d.y - d.amp, WIDTH + 120, d.amp * 2.4))
    elif theme.deco == "cyber":
        for p in cyber_pillars_l + cyber_pillars_r:
            p.flicker += 0.03
            glow_amt = 0.5 + 0.5 * math.sin(p.flicker)
            top = horizon_y - p.h
            col = theme.accent
            pygame.draw.rect(surf, (8, 8, 18), (p.x, top, 14, p.h + 20))
            pygame.draw.rect(surf, col, (p.x, top, 14, p.h + 20), max(1, int(2 * glow_amt) + 1))
        for gy in range(0, horizon_y, 26):
            pygame.draw.line(surf, (20, 60, 60), (0, gy), (WIDTH, gy), 1)
    elif theme.deco == "space":
        for s in stars:
            s.update()
            tw = 150 + int(90 * math.sin(s.tw))
            pygame.draw.circle(surf, (tw, tw, 255), (int(s.x), int(s.y)), int(s.size))
        for p in planets:
            draw_glow_circle(surf, p.color, (int(p.x), int(p.y)), int(p.r), glow=16, alpha_mul=0.6)

    if theme.deco != "space":
        for s in stars[:30]:
            s.update()
            pygame.draw.circle(surf, WHITE, (int(s.x), int(min(s.y, horizon_y - 4))), int(s.size))

    for i in range(-10, 10):
        x1 = WIDTH // 2 + i * 40
        pygame.draw.line(surf, theme.line_color, (WIDTH // 2, horizon_y), (x1, HEIGHT), 1)

    pygame.draw.rect(surf, DARK, (0, horizon_y, WIDTH, HEIGHT - horizon_y))
    pygame.draw.rect(surf, theme.road_color, (ROAD_X, horizon_y, ROAD_W, HEIGHT - horizon_y))
    pygame.draw.line(surf, theme.accent, (ROAD_X, horizon_y), (ROAD_X, HEIGHT), 3)
    pygame.draw.line(surf, theme.accent, (ROAD_X + ROAD_W, horizon_y), (ROAD_X + ROAD_W, HEIGHT), 3)
    for lane in range(1, LANES):
        lx = ROAD_X + lane * LANE_W
        pygame.draw.line(surf, (90, 50, 130), (lx, horizon_y), (lx, HEIGHT), 1)

    draw_roadside_props(surf, theme, world_speed, horizon_y)
    return horizon_y

class LaneMarks:
    def __init__(self):
        self.offset = 0

    def update(self, speed):
        self.offset = (self.offset + speed) % 60

    def draw(self, surf, theme):
        for lane in range(1, LANES):
            lx = ROAD_X + lane * LANE_W
            y = -60 + self.offset
            while y < HEIGHT:
                pygame.draw.rect(surf, theme.line_color, (lx - 2, y, 4, 28))
                y += 60

# ------------------------------------------------------------------
# SOUND BUTTON
# ------------------------------------------------------------------
class SoundButton:
    def __init__(self):
        self.rect = pygame.Rect(WIDTH - 56, 16, 40, 40)
        self.hover = False

    def draw(self, surf):
        color = NEON_BLUE if AUDIO.is_any_on() else GREY
        cx, cy = self.rect.center
        scale = 1.15 if self.hover else 1.0
        draw_glow_circle(surf, color, (cx, cy), int(18 * scale), glow=12)
        body = [(cx - 10, cy - 4), (cx - 4, cy - 4), (cx + 4, cy - 11),
                (cx + 4, cy + 11), (cx - 4, cy + 4), (cx - 10, cy + 4)]
        pygame.draw.polygon(surf, BLACK, body)
        if AUDIO.is_any_on():
            pygame.draw.arc(surf, BLACK, (cx + 2, cy - 9, 16, 18), -0.8, 0.8, 2)
            pygame.draw.arc(surf, BLACK, (cx + 5, cy - 12, 22, 24), -0.7, 0.7, 2)
        else:
            pygame.draw.line(surf, (255, 60, 60), (cx + 6, cy - 8), (cx + 16, cy + 8), 3)
            pygame.draw.line(surf, (255, 60, 60), (cx + 16, cy - 8), (cx + 6, cy + 8), 3)

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos):
            AUDIO.toggle_master()
            return True
        return False

SOUND_BTN = SoundButton()

# ------------------------------------------------------------------
# BUTON
# ------------------------------------------------------------------
class Button:
    def __init__(self, text, x, y, w, h, color=NEON_PINK):
        self.text = text
        self.rect = pygame.Rect(x, y, w, h)
        self.color = color
        self.scale = 1.0
        self.target_scale = 1.0
        self.hover = False
        self._was_hover = False

    def update(self, mouse_pos):
        self.hover = self.rect.collidepoint(mouse_pos)
        self.target_scale = 1.08 if self.hover else 1.0
        self.scale = lerp(self.scale, self.target_scale, 0.2)
        if self.hover and not self._was_hover:
            AUDIO.play(SND_HOVER, 0.5)
        self._was_hover = self.hover

    def draw(self, surf):
        w = int(self.rect.w * self.scale)
        h = int(self.rect.h * self.scale)
        cx, cy = self.rect.center
        rect = pygame.Rect(cx - w // 2, cy - h // 2, w, h)
        glow = 18 if self.hover else 8
        draw_glow_rect(surf, self.color, rect, glow=glow, radius=10)
        txt_color = BLACK if self.hover else WHITE
        txt = FONT_SMALL.render(self.text, True, txt_color)
        surf.blit(txt, txt.get_rect(center=rect.center))

    def clicked(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos):
            AUDIO.play(SND_CLICK, 0.6)
            return True
        return False

# ------------------------------------------------------------------
# OYUNCU ARABASI
# ------------------------------------------------------------------
CAR_W, CAR_H = 44, 76

def draw_car(surf, x, y, color, w=CAR_W, h=CAR_H, tilt=0, glow=True, headlight_beam=False):
    pad = 26
    car_surf = pygame.Surface((w + pad * 2, h + pad * 2), pygame.SRCALPHA)
    cx, cy = (w + pad * 2) // 2, (h + pad * 2) // 2
    body_rect = pygame.Rect(cx - w // 2, cy - h // 2, w, h)

    def shade(c, amt):
        return (clamp(c[0] + amt, 0, 255), clamp(c[1] + amt, 0, 255), clamp(c[2] + amt, 0, 255))

    if glow:
        for i in range(9, 0, -2):
            alpha = int(38 * (1 - i / 9))
            pygame.draw.rect(car_surf, (*color, alpha),
                              body_rect.inflate(i * 2, i * 2), border_radius=12)

    if headlight_beam:
        beam = pygame.Surface((w + pad * 2, h + pad * 2), pygame.SRCALPHA)
        pts = [(cx - w // 2 + 4, body_rect.top + 2), (cx + w // 2 - 4, body_rect.top + 2),
               (cx + w // 2 + 30, body_rect.top - 60), (cx - w // 2 - 30, body_rect.top - 60)]
        pygame.draw.polygon(beam, (255, 250, 200, 40), pts)
        car_surf.blit(beam, (0, 0))

    body_pts = [
        (cx - w * 0.32, body_rect.top + h * 0.06),
        (cx + w * 0.32, body_rect.top + h * 0.06),
        (cx + w * 0.5, body_rect.top + h * 0.30),
        (cx + w * 0.46, body_rect.bottom - h * 0.10),
        (cx + w * 0.30, body_rect.bottom),
        (cx - w * 0.30, body_rect.bottom),
        (cx - w * 0.46, body_rect.bottom - h * 0.10),
        (cx - w * 0.5, body_rect.top + h * 0.30),
    ]
    pygame.draw.polygon(car_surf, shade(color, -30), body_pts)
    pygame.draw.polygon(car_surf, color, [(px, py - 1) for px, py in body_pts])
    pygame.draw.polygon(car_surf, shade(color, 50), body_pts, 0)
    highlight_pts = [(cx - w * 0.34, body_rect.top + h * 0.08),
                      (cx + w * 0.34, body_rect.top + h * 0.08),
                      (cx + w * 0.40, body_rect.top + h * 0.38),
                      (cx - w * 0.40, body_rect.top + h * 0.38)]
    hl_surf = pygame.Surface((w + pad * 2, h + pad * 2), pygame.SRCALPHA)
    pygame.draw.polygon(hl_surf, (255, 255, 255, 55), highlight_pts)
    car_surf.blit(hl_surf, (0, 0))
    pygame.draw.polygon(car_surf, shade(color, 70), body_pts, 2)

    wheel_w, wheel_h = 9, 20
    wheel_positions = [
        (cx - w * 0.5 - 2, body_rect.top + h * 0.18),
        (cx + w * 0.5 - wheel_w + 2, body_rect.top + h * 0.18),
        (cx - w * 0.5 - 2, body_rect.bottom - h * 0.30),
        (cx + w * 0.5 - wheel_w + 2, body_rect.bottom - h * 0.30),
    ]
    for wx, wy in wheel_positions:
        pygame.draw.rect(car_surf, (15, 15, 18), (wx, wy, wheel_w, wheel_h), border_radius=3)
        pygame.draw.rect(car_surf, (60, 60, 66), (wx + 2, wy + 3, wheel_w - 4, wheel_h - 6), border_radius=2)

    windshield = [
        (cx - w * 0.30, body_rect.top + h * 0.12),
        (cx + w * 0.30, body_rect.top + h * 0.12),
        (cx + w * 0.22, body_rect.top + h * 0.34),
        (cx - w * 0.22, body_rect.top + h * 0.34),
    ]
    glass = pygame.Surface((w + pad * 2, h + pad * 2), pygame.SRCALPHA)
    pygame.draw.polygon(glass, (180, 230, 255, 150), windshield)
    car_surf.blit(glass, (0, 0))

    roof_rect = pygame.Rect(cx - w * 0.26, body_rect.top + h * 0.36, w * 0.52, h * 0.30)
    pygame.draw.rect(car_surf, shade(color, -55), roof_rect, border_radius=6)

    rear_glass = [
        (cx - w * 0.24, body_rect.bottom - h * 0.22),
        (cx + w * 0.24, body_rect.bottom - h * 0.22),
        (cx + w * 0.18, body_rect.bottom - h * 0.08),
        (cx - w * 0.18, body_rect.bottom - h * 0.08),
    ]
    glass2 = pygame.Surface((w + pad * 2, h + pad * 2), pygame.SRCALPHA)
    pygame.draw.polygon(glass2, (180, 230, 255, 110), rear_glass)
    car_surf.blit(glass2, (0, 0))

    pygame.draw.rect(car_surf, shade(color, -20), (body_rect.left - 4, body_rect.top + h * 0.20, 6, 8), border_radius=2)
    pygame.draw.rect(car_surf, shade(color, -20), (body_rect.right - 2, body_rect.top + h * 0.20, 6, 8), border_radius=2)

    draw_glow_circle(car_surf, (255, 250, 210), (int(cx - w * 0.28), int(body_rect.top + 7)), 3, glow=8, alpha_mul=0.8)
    draw_glow_circle(car_surf, (255, 250, 210), (int(cx + w * 0.28), int(body_rect.top + 7)), 3, glow=8, alpha_mul=0.8)
    pygame.draw.rect(car_surf, (255, 50, 60), (cx - w * 0.34, body_rect.bottom - 6, 8, 4), border_radius=1)
    pygame.draw.rect(car_surf, (255, 50, 60), (cx + w * 0.34 - 8, body_rect.bottom - 6, 8, 4), border_radius=1)

    rotated = pygame.transform.rotate(car_surf, tilt)
    rect = rotated.get_rect(center=(x, y))
    surf.blit(rotated, rect)

class Player:
    def __init__(self):
        self.lane_x = WIDTH // 2
        self.y = HEIGHT - 110
        self.vx = 0
        self.tilt = 0
        self.speed = 4.0
        self.base_speed = 4.0
        self.max_speed = 11.0
        self.nitro = False
        self.nitro_timer = 0
        self.alive = True
        self.invincible_timer = 0

    def update(self, keys, dt, speed_mult=1.0):
        move = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            move -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            move += 1
        accel = 0
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            accel = 1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            accel = -1

        self.nitro = bool(keys[pygame.K_SPACE]) and self.nitro_timer < 100
        target_speed = self.base_speed
        if accel > 0:
            target_speed = self.base_speed * 1.4
        elif accel < 0:
            target_speed = self.base_speed * 0.5
        if self.nitro:
            target_speed = self.max_speed
            self.nitro_timer += 1
        else:
            self.nitro_timer = max(0, self.nitro_timer - 2)
        target_speed *= speed_mult

        self.speed = lerp(self.speed, target_speed, 0.08)

        self.lane_x += move * 6.5
        self.lane_x = clamp(self.lane_x, ROAD_X + CAR_W // 2 + 4, ROAD_X + ROAD_W - CAR_W // 2 - 4)
        self.tilt = lerp(self.tilt, -move * 12, 0.3)

        if self.invincible_timer > 0:
            self.invincible_timer -= 1
        if self.nitro:
            STATS["total_nitro_frames"] = STATS.get("total_nitro_frames", 0) + 1

    def draw(self, surf, color=NEON_BLUE):
        if self.invincible_timer > 0 and self.invincible_timer % 10 < 5:
            return
        car_color = NEON_GREEN if self.nitro else color
        draw_car(surf, self.lane_x, self.y, car_color, tilt=self.tilt, headlight_beam=self.nitro)
        exhaust_color = NEON_ORANGE if self.nitro else NEON_PINK
        spawn_exhaust(self.lane_x - 10, self.y + CAR_H // 2, exhaust_color, n=3 if self.nitro else 1)
        spawn_exhaust(self.lane_x + 10, self.y + CAR_H // 2, exhaust_color, n=3 if self.nitro else 1)

    @property
    def rect(self):
        return pygame.Rect(self.lane_x - CAR_W // 2 + 6, self.y - CAR_H // 2 + 6, CAR_W - 12, CAR_H - 12)

# ------------------------------------------------------------------
# TRAFIK / TOPLANABILIRLER
# ------------------------------------------------------------------
TRAFFIC_COLORS = [NEON_PURPLE, NEON_ORANGE, NEON_YELLOW, (255, 90, 90)]

class TrafficCar:
    def __init__(self, lane, y, speed, aggressive=False, label=None, color=None):
        self.lane = lane
        self.x = ROAD_X + lane * LANE_W + LANE_W // 2
        self.y = y
        self.speed = speed
        self.color = color or random.choice(TRAFFIC_COLORS)
        self.aggressive = aggressive
        self.steer_timer = random.randint(40, 140)
        self.label = label

    def update(self, world_speed, player_x=None):
        self.y += world_speed - self.speed
        if self.aggressive and player_x is not None:
            self.steer_timer -= 1
            if self.steer_timer <= 0:
                self.steer_timer = random.randint(60, 120)
                if self.x < player_x - 5:
                    self.x += LANE_W * random.choice([0, 1])
                elif self.x > player_x + 5:
                    self.x -= LANE_W * random.choice([0, 1])
                self.x = clamp(self.x, ROAD_X + CAR_W // 2 + 4, ROAD_X + ROAD_W - CAR_W // 2 - 4)

    def draw(self, surf):
        draw_car(surf, self.x, self.y, self.color, glow=True)
        if self.label:
            txt = FONT_TINY.render(self.label, True, WHITE)
            surf.blit(txt, txt.get_rect(center=(self.x, self.y - CAR_H // 2 - 12)))

    @property
    def rect(self):
        return pygame.Rect(self.x - CAR_W // 2 + 6, self.y - CAR_H // 2 + 6, CAR_W - 12, CAR_H - 12)

class Coin:
    def __init__(self, lane, y):
        self.x = ROAD_X + lane * LANE_W + LANE_W // 2
        self.y = y
        self.angle = 0

    def update(self, world_speed):
        self.y += world_speed
        self.angle += 6

    def draw(self, surf):
        r = abs(math.cos(math.radians(self.angle))) * 12 + 4
        draw_glow_circle(surf, NEON_YELLOW, (int(self.x), int(self.y)), int(r), glow=10)

    @property
    def rect(self):
        return pygame.Rect(self.x - 14, self.y - 14, 28, 28)

class ClockIcon:
    def __init__(self, lane, y):
        self.x = ROAD_X + lane * LANE_W + LANE_W // 2
        self.y = y

    def update(self, world_speed):
        self.y += world_speed

    def draw(self, surf):
        draw_glow_circle(surf, NEON_GREEN, (int(self.x), int(self.y)), 16, glow=12)
        pygame.draw.circle(surf, BLACK, (int(self.x), int(self.y)), 12)
        pygame.draw.line(surf, NEON_GREEN, (self.x, self.y), (self.x, self.y - 7), 2)
        pygame.draw.line(surf, NEON_GREEN, (self.x, self.y), (self.x + 5, self.y + 2), 2)

    @property
    def rect(self):
        return pygame.Rect(self.x - 16, self.y - 16, 32, 32)

class StarPickup:
    def __init__(self, lane, y):
        self.x = ROAD_X + lane * LANE_W + LANE_W // 2
        self.y = y
        self.angle = 0

    def update(self, world_speed):
        self.y += world_speed
        self.angle += 4

    def draw(self, surf):
        pts = []
        for i in range(5):
            a = math.radians(self.angle + i * 72 - 90)
            pts.append((self.x + math.cos(a) * 13, self.y + math.sin(a) * 13))
            a2 = math.radians(self.angle + i * 72 - 90 + 36)
            pts.append((self.x + math.cos(a2) * 6, self.y + math.sin(a2) * 6))
        draw_glow_circle(surf, NEON_BLUE, (int(self.x), int(self.y)), 16, glow=14)
        pygame.draw.polygon(surf, WHITE, pts)

    @property
    def rect(self):
        return pygame.Rect(self.x - 16, self.y - 16, 32, 32)

class FuelCan:
    def __init__(self, lane, y):
        self.x = ROAD_X + lane * LANE_W + LANE_W // 2
        self.y = y
        self.bob = random.uniform(0, math.pi * 2)

    def update(self, world_speed):
        self.y += world_speed
        self.bob += 0.1

    def draw(self, surf):
        oy = math.sin(self.bob) * 3
        draw_glow_circle(surf, NEON_GREEN, (int(self.x), int(self.y + oy)), 15, glow=12)
        body = pygame.Rect(self.x - 9, self.y - 11 + oy, 18, 20)
        pygame.draw.rect(surf, (30, 30, 34), body, border_radius=3)
        pygame.draw.rect(surf, NEON_GREEN, body, 2, border_radius=3)
        cap = pygame.Rect(self.x - 4, self.y - 16 + oy, 8, 6)
        pygame.draw.rect(surf, NEON_GREEN, cap)
        drop = FONT_TINY.render("Y", True, WHITE)
        surf.blit(drop, drop.get_rect(center=(self.x, self.y - 1 + oy)))

    @property
    def rect(self):
        return pygame.Rect(self.x - 16, self.y - 18, 32, 34)

class BoostIcon:
    """Hiz artisi (limitli sure) ikonu."""
    def __init__(self, lane, y):
        self.x = ROAD_X + lane * LANE_W + LANE_W // 2
        self.y = y
        self.angle = 0

    def update(self, world_speed):
        self.y += world_speed
        self.angle += 5

    def draw(self, surf):
        draw_glow_circle(surf, NEON_ORANGE, (int(self.x), int(self.y)), 15, glow=14)
        pts = [(self.x - 6, self.y + 9), (self.x + 1, self.y - 1), (self.x - 3, self.y - 1),
               (self.x + 6, self.y - 10), (self.x - 1, self.y + 1), (self.x + 3, self.y + 1)]
        pygame.draw.polygon(surf, WHITE, pts)

    @property
    def rect(self):
        return pygame.Rect(self.x - 16, self.y - 16, 32, 32)

# ------------------------------------------------------------------
# EKRAN TITREME
# ------------------------------------------------------------------
class ScreenShake:
    def __init__(self):
        self.timer = 0
        self.intensity = 0

    def trigger(self, intensity=8, duration=12):
        self.timer = duration
        self.intensity = intensity

    def offset(self):
        if self.timer > 0:
            self.timer -= 1
            return (random.uniform(-1, 1) * self.intensity, random.uniform(-1, 1) * self.intensity)
        return (0, 0)

shaker = ScreenShake()

# ------------------------------------------------------------------
# WIND LINES
# ------------------------------------------------------------------
class WindLine:
    def __init__(self):
        self.reset()

    def reset(self):
        side = random.choice(["L", "R"])
        self.x = random.uniform(0, 60) if side == "L" else random.uniform(WIDTH - 60, WIDTH)
        self.y = random.uniform(0, HEIGHT)
        self.len = random.uniform(20, 50)
        self.speed = random.uniform(8, 16)

    def update(self, factor):
        self.y += self.speed * factor
        if self.y > HEIGHT:
            self.reset()
            self.y = -20

    def draw(self, surf, alpha, color):
        s = pygame.Surface((4, int(self.len)), pygame.SRCALPHA)
        pygame.draw.line(s, (*color, alpha), (2, 0), (2, self.len), 2)
        surf.blit(s, (self.x, self.y))

wind_lines = [WindLine() for _ in range(24)]

# ------------------------------------------------------------------
# TEXT INPUT
# ------------------------------------------------------------------
class TextInput:
    def __init__(self, max_len=12):
        self.text = ""
        self.max_len = max_len
        self.cursor_timer = 0

    def handle_key(self, event):
        if event.key == pygame.K_BACKSPACE:
            self.text = self.text[:-1]
            AUDIO.play(SND_TYPE, 0.2)
        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            return True
        elif event.unicode and event.unicode.isprintable() and len(self.text) < self.max_len:
            self.text += event.unicode
            AUDIO.play(SND_TYPE, 0.2)
        return False

    def draw(self, surf, pos):
        self.cursor_timer += 1
        cursor = "|" if (self.cursor_timer // 30) % 2 == 0 else " "
        display = (self.text or "") + cursor
        box = pygame.Rect(pos[0] - 160, pos[1] - 26, 320, 52)
        draw_glow_rect(surf, NEON_BLUE, box, glow=10, radius=8)
        pygame.draw.rect(surf, BLACK, box.inflate(-8, -8), border_radius=6)
        txt = FONT_MED.render(display if self.text else "ISMINI YAZ" + cursor, True,
                               WHITE if self.text else GREY)
        surf.blit(txt, txt.get_rect(center=box.center))

# ------------------------------------------------------------------
# GAME STATE
# ------------------------------------------------------------------
STATE_MENU = "menu"
STATE_MODE_SELECT = "mode_select"
STATE_COUNTDOWN = "countdown"
STATE_PLAY = "play"
STATE_PAUSE = "pause"
STATE_NAME_ENTRY = "name_entry"
STATE_GAMEOVER = "gameover"
STATE_LEADERBOARD = "leaderboard"
STATE_ACHIEVEMENTS = "achievements"

MODE_ENDLESS = "endless"
MODE_TIME = "time"
MODE_SURVIVAL = "survival"
MODE_FUEL = "fuel"
MODE_RACE = "race"

MODE_LABELS = {
    MODE_ENDLESS: "SONSUZ YOL", MODE_TIME: "ZAMANA KARSI", MODE_SURVIVAL: "HAYATTA KALIM",
    MODE_FUEL: "YAKIT YARISI", MODE_RACE: "PIST YARISI",
}

RACE_LAP_DISTANCE = 1200
RACE_TOTAL_LAPS = 5
RACE_OPPONENTS = 4

class Game:
    def __init__(self):
        self.state = STATE_MENU
        self.mode = None
        self.theme = THEMES[0]
        self.reset_run()
        self.title_y = -120
        self.title_glitch_timer = 0
        self.countdown_value = 3
        self.countdown_timer = 0
        self.fade_alpha = 0
        self.name_input = TextInput()
        self.pending_score = 0
        self.leaderboard_from = STATE_MENU
        self.combo = 0
        self.combo_timer = 0
        self.achievement_queue = []
        self.achievement_timer = 0

        self.btn_endless = Button("SONSUZ YOL", WIDTH // 2 - 160, 196, 320, 50, NEON_BLUE)
        self.btn_time = Button("ZAMANA KARSI", WIDTH // 2 - 160, 254, 320, 50, NEON_PINK)
        self.btn_survival = Button("HAYATTA KALIM", WIDTH // 2 - 160, 312, 320, 50, NEON_ORANGE)
        self.btn_fuel = Button("YAKIT YARISI", WIDTH // 2 - 160, 370, 320, 50, NEON_GREEN)
        self.btn_race = Button("PIST YARISI", WIDTH // 2 - 160, 428, 320, 50, NEON_PURPLE)
        self.btn_back = Button("GERI", 30, 30, 120, 46, GREY)

        self.btn_retry = Button("YENIDEN DENE", WIDTH // 2 - 160, 410, 320, 52, NEON_GREEN)
        self.btn_save_score = Button("ISIM YAZ VE KAYDET", WIDTH // 2 - 160, 470, 320, 52, NEON_YELLOW)
        self.btn_menu = Button("ANA MENU", WIDTH // 2 - 160, 530, 320, 52, NEON_PURPLE)
        self.btn_skip_name = Button("KAYDETMEDEN GEC", WIDTH // 2 - 160, 470, 320, 50, GREY)

        self.btn_play = Button("OYNA", WIDTH // 2 - 230, 470, 150, 56, NEON_PINK)
        self.btn_scores = Button("SKORLAR", WIDTH // 2 - 70, 470, 150, 56, NEON_BLUE)
        self.btn_achv = Button("BASARIMLAR", WIDTH // 2 + 90, 470, 150, 56, NEON_GREEN)
        self.btn_lb_back = Button("GERI", 30, 30, 120, 46, GREY)
        self.btn_achv_back = Button("GERI", 30, 30, 120, 46, GREY)
        self.lb_tab = MODE_ENDLESS

        tabw = 150
        self.btn_lb_tabs = {
            MODE_ENDLESS: Button("SONSUZ", WIDTH // 2 - 2 * tabw - 10, 110, tabw, 40, NEON_BLUE),
            MODE_TIME: Button("ZAMAN", WIDTH // 2 - tabw - 5, 110, tabw, 40, NEON_PINK),
            MODE_SURVIVAL: Button("HAYATTA", WIDTH // 2 + 5, 110, tabw, 40, NEON_ORANGE),
            MODE_FUEL: Button("YAKIT", WIDTH // 2 + tabw + 10, 110, tabw, 40, NEON_GREEN),
        }

    def reset_run(self):
        self.player = Player()
        self.traffic = []
        self.coins = []
        self.clocks = []
        self.stars_pickup = []
        self.fuel_cans = []
        self.boosts = []
        self.distance = 0
        self.coin_count = 0
        self.world_speed = 4.0
        self.spawn_timer = 0
        self.coin_spawn_timer = 0
        self.clock_spawn_timer = 0
        self.star_spawn_timer = 300
        self.fuel_spawn_timer = 220
        self.boost_spawn_timer = 260
        self.time_left = 60.0
        self.lives = 3
        self.lane_marks = LaneMarks()
        self.game_over_reason = ""
        self.win = False
        self.theme = THEMES[0]
        self.theme_anim_t = 0
        self.combo = 0
        self.combo_timer = 0
        self.elapsed_time = 0.0
        self.run_start_ticks = time_module.time()
        self.crash_free_distance = 0
        self.fuel = 100.0
        self.fuel_max = 100.0
        self.fuel_ran_out = False
        self.speed_boost_timer = 0
        # PIST YARISI
        self.race_opponents = []
        self.race_lap = 1
        self.race_finished = False
        self.race_position = 1
        self.race_started = False

    def start_mode(self, mode):
        self.mode = mode
        self.reset_run()
        if mode == MODE_RACE:
            self.setup_race()
        self.state = STATE_COUNTDOWN
        self.countdown_value = 3
        self.countdown_timer = 0
        AUDIO.play(SND_COUNT, 0.6)
        AUDIO.play_music(self.theme.music_key)

    def setup_race(self):
        names = ["RIVAL-1", "RIVAL-2", "RIVAL-3", "RIVAL-4"]
        for i in range(RACE_OPPONENTS):
            lane = i % LANES
            car = TrafficCar(lane, -150 - i * 90, speed=0, aggressive=False,
                              label=names[i], color=TRAFFIC_COLORS[i % len(TRAFFIC_COLORS)])
            car.progress = 0.0
            # Oyuncuyla AYNI olcekte bir "efektif hiz" kullanir (4.0 taban - 11.0 tepe,
            # tipki Player gibi) boylece gercek bir cekisme olur.
            car.cur_speed = random.uniform(4.5, 6.0)
            car.target_speed = car.cur_speed
            car.personality = random.uniform(0.85, 1.15)   # genel agresiflik carpani
            car.burst_timer = random.uniform(1.0, 3.0)      # ne zaman atak/nitro yapacagi
            self.race_opponents.append(car)


    def spawn_traffic(self):
        lane = random.randint(0, LANES - 1)
        aggressive = self.mode == MODE_SURVIVAL
        speed = random.uniform(1.5, 3.0) if not aggressive else random.uniform(2.5, 4.5)
        self.traffic.append(TrafficCar(lane, -100, speed, aggressive=aggressive))

    def spawn_coin(self):
        lane = random.randint(0, LANES - 1)
        self.coins.append(Coin(lane, -40))

    def spawn_clock(self):
        lane = random.randint(0, LANES - 1)
        self.clocks.append(ClockIcon(lane, -40))

    def spawn_star(self):
        lane = random.randint(0, LANES - 1)
        self.stars_pickup.append(StarPickup(lane, -40))

    def spawn_fuel(self):
        lane = random.randint(0, LANES - 1)
        self.fuel_cans.append(FuelCan(lane, -40))

    def spawn_boost(self):
        lane = random.randint(0, LANES - 1)
        self.boosts.append(BoostIcon(lane, -40))

    def update_play(self, dt, keys):
        self.elapsed_time += dt
        speed_mult = 1.6 if self.speed_boost_timer > 0 else 1.0
        if self.speed_boost_timer > 0:
            self.speed_boost_timer -= 1
        self.player.update(keys, dt, speed_mult=speed_mult)
        difficulty = 1 + self.distance / 6000
        self.world_speed = (4.0 + self.player.speed * 0.4) * min(difficulty, 2.4)
        self.lane_marks.update(self.world_speed)
        self.distance += self.world_speed * 0.08
        self.crash_free_distance += self.world_speed * 0.08
        self.theme_anim_t += self.world_speed

        new_theme = theme_for_distance(self.distance)
        if new_theme.key != self.theme.key:
            self.theme = new_theme
            AUDIO.play_music(self.theme.music_key)
            if self.theme.key not in STATS["themes_seen"]:
                STATS["themes_seen"].append(self.theme.key)

        speed_ratio = clamp((self.player.speed - self.player.base_speed * 0.4) /
                             (self.player.max_speed - self.player.base_speed * 0.4), 0, 1.3)
        AUDIO.update_engine(speed_ratio)

        if self.combo_timer > 0:
            self.combo_timer -= 1
        else:
            self.combo = 0

        self.spawn_timer -= 1
        spawn_rate = max(18, 55 - int(difficulty * 14))
        if self.mode == MODE_SURVIVAL:
            spawn_rate = max(12, spawn_rate - 10)
        if self.mode != MODE_RACE and self.spawn_timer <= 0:
            self.spawn_traffic()
            self.spawn_timer = spawn_rate + random.randint(-5, 10)

        if self.mode == MODE_ENDLESS:
            self.coin_spawn_timer -= 1
            if self.coin_spawn_timer <= 0:
                self.spawn_coin()
                self.coin_spawn_timer = random.randint(40, 80)
            self.star_spawn_timer -= 1
            if self.star_spawn_timer <= 0:
                self.spawn_star()
                self.star_spawn_timer = random.randint(500, 800)

        if self.mode == MODE_TIME:
            self.time_left -= dt
            self.clock_spawn_timer -= 1
            if self.clock_spawn_timer <= 0:
                self.spawn_clock()
                self.clock_spawn_timer = random.randint(90, 160)
            if self.time_left <= 0:
                self.end_game("SURE BITTI!")
                return
            if self.distance > 4000:
                self.end_game("", win=True)
                return

        if self.mode == MODE_FUEL:
            consume_rate = 2.4 + self.player.speed * 0.35
            self.fuel -= consume_rate * dt
            self.fuel_spawn_timer -= 1
            if self.fuel_spawn_timer <= 0:
                self.spawn_fuel()
                self.fuel_spawn_timer = random.randint(260, 380)
            self.boost_spawn_timer -= 1
            if self.boost_spawn_timer <= 0:
                self.spawn_boost()
                self.boost_spawn_timer = random.randint(420, 600)
            for fc in self.fuel_cans[:]:
                fc.update(self.world_speed)
                if fc.y > HEIGHT + 50:
                    self.fuel_cans.remove(fc)
                elif self.player.rect.colliderect(fc.rect):
                    self.fuel_cans.remove(fc)
                    self.fuel = min(self.fuel_max, self.fuel + 38)
                    AUDIO.play(SND_FUEL, 0.5)
            for bo in self.boosts[:]:
                bo.update(self.world_speed)
                if bo.y > HEIGHT + 50:
                    self.boosts.remove(bo)
                elif self.player.rect.colliderect(bo.rect):
                    self.boosts.remove(bo)
                    self.speed_boost_timer = 180
                    AUDIO.play(SND_BOOST, 0.55)
            if self.fuel <= 0:
                self.fuel = 0
                self.fuel_ran_out = True
                self.end_game("YAKIT BITTI!")
                return
            if self.distance >= 3000 and not self.fuel_ran_out:
                newly = check_achievements({"mode": "fuel", "distance": self.distance, "fuel_ran_out": False})
                self.achievement_queue.extend(newly)

        if self.mode == MODE_RACE:
            self.update_race(dt)
            if self.race_finished:
                return

        for car in self.traffic[:]:
            car.update(self.world_speed, self.player.lane_x if car.aggressive else None)
            if car.y > HEIGHT + 100:
                self.traffic.remove(car)
            elif self.player.invincible_timer == 0 and self.player.rect.colliderect(car.rect):
                self.handle_collision(car)

        for c in self.coins[:]:
            c.update(self.world_speed)
            if c.y > HEIGHT + 50:
                self.coins.remove(c)
            elif self.player.rect.colliderect(c.rect):
                self.coins.remove(c)
                self.combo += 1
                self.combo_timer = 90
                STATS["best_combo"] = max(STATS.get("best_combo", 0), self.combo)
                gained = 1 + self.combo // 5
                self.coin_count += gained
                STATS["total_coins"] = STATS.get("total_coins", 0) + gained
                spawn_coin_burst(c.x, c.y)
                AUDIO.play(SND_COIN if self.combo % 2 == 0 else SND_COIN2, 0.5)

        for ck in self.clocks[:]:
            ck.update(self.world_speed)
            if ck.y > HEIGHT + 50:
                self.clocks.remove(ck)
            elif self.player.rect.colliderect(ck.rect):
                self.clocks.remove(ck)
                self.time_left += 5
                AUDIO.play(SND_CLOCK_PICKUP, 0.5)

        for sp in self.stars_pickup[:]:
            sp.update(self.world_speed)
            if sp.y > HEIGHT + 50:
                self.stars_pickup.remove(sp)
            elif self.player.rect.colliderect(sp.rect):
                self.stars_pickup.remove(sp)
                self.player.invincible_timer = 180
                AUDIO.play(SND_HIGHSCORE, 0.4)

        if self.mode == MODE_SURVIVAL:
            STATS["survival_best_time"] = max(STATS.get("survival_best_time", 0), self.elapsed_time)
            if self.lives <= 0:
                self.end_game("CANIN BITTI!")

        STATS["crash_free_best"] = max(STATS.get("crash_free_best", 0), self.crash_free_distance)

    def update_race(self, dt):
        # rakipler oyuncuyla AYNI hiz-mesafe formulunu kullanir, boylece gercek bir
        # cekisme olur. Ayrica geride kalanlar biraz hizlanir (rubber-band),
        # onde olanlar ara sira "atak" (mini nitro) yapar - boylece pozisyonlar
        # surekli degisir ve yaris heyecanli kalir.
        finish_distance = RACE_LAP_DISTANCE * RACE_TOTAL_LAPS
        difficulty = min(1 + self.distance / 6000, 2.4)

        for opp in self.race_opponents:
            opp.burst_timer -= dt
            if opp.burst_timer <= 0:
                opp.burst_timer = random.uniform(1.2, 3.2)
                # bazen atak (yuksek hiz), bazen normal seyir
                if random.random() < 0.45:
                    opp.target_speed = random.uniform(8.5, 11.5) * opp.personality
                else:
                    opp.target_speed = random.uniform(4.5, 6.5) * opp.personality

            # rubber-band: geride kalan rakip biraz daha hizli, onde olan biraz yavas hedefler
            gap = self.distance - opp.progress
            if gap > 250:
                opp.target_speed += 2.2
            elif gap < -250:
                opp.target_speed = max(3.0, opp.target_speed - 1.5)

            opp.cur_speed = lerp(opp.cur_speed, opp.target_speed, 0.06)
            opp.cur_speed = clamp(opp.cur_speed, 2.5, 12.0)

            opp_world_speed = (4.0 + opp.cur_speed * 0.4) * difficulty
            opp.progress += opp_world_speed * 0.08 * (dt * FPS)
            opp.progress = min(opp.progress, finish_distance)

        player_lap = int(self.distance // RACE_LAP_DISTANCE) + 1
        if player_lap > self.race_lap and player_lap <= RACE_TOTAL_LAPS:
            self.race_lap = player_lap
            AUDIO.play(SND_LAP, 0.5)

        all_progress = [self.distance] + [o.progress for o in self.race_opponents]
        sorted_progress = sorted(all_progress, reverse=True)
        self.race_position = sorted_progress.index(self.distance) + 1

        if self.distance >= finish_distance and not self.race_finished:
            self.race_finished = True
            won = self.race_position == 1
            if won:
                STATS["race_wins"] = STATS.get("race_wins", 0) + 1
                AUDIO.play(SND_RACE_WIN, 0.6)
            self.end_game(f"{self.race_position}. SIRADA BITIRDIN!", win=won)

    def handle_collision(self, car):
        if self.player.invincible_timer > 0:
            return
        AUDIO.play(SND_CRASH, 0.85)
        shaker.trigger(10, 14)
        spawn_sparks(self.player.lane_x, self.player.y - 20, n=22)
        self.player.invincible_timer = 60
        self.combo = 0
        self.crash_free_distance = 0
        if car in self.traffic:
            self.traffic.remove(car)

        if self.mode == MODE_SURVIVAL:
            self.lives -= 1
            if self.lives <= 0:
                self.end_game("CANIN BITTI!")
        elif self.mode == MODE_ENDLESS:
            self.end_game("CARPTIN!")
        elif self.mode == MODE_TIME:
            self.time_left -= 4
            self.player.speed *= 0.4
        elif self.mode == MODE_FUEL:
            self.fuel = max(0, self.fuel - 15)
            self.player.speed *= 0.5
        elif self.mode == MODE_RACE:
            self.player.speed *= 0.4

    def end_game(self, reason, win=False):
        AUDIO.stop_engine()
        self.game_over_reason = reason
        self.win = win
        self.fade_alpha = 0
        self.pending_score = int(self.distance)
        STATS["total_distance"] = STATS.get("total_distance", 0) + int(self.distance)
        STATS["runs_finished"] = STATS.get("runs_finished", 0) + 1
        save_data()

        run_ctx = {
            "mode": self.mode, "distance": self.distance, "win": self.win,
            "fuel_ran_out": self.fuel_ran_out, "position": self.race_position if self.mode == MODE_RACE else None,
        }
        new_achievements = check_achievements(run_ctx)
        self.achievement_queue.extend(new_achievements)

        self.state = STATE_GAMEOVER
        AUDIO.play(SND_GAMEOVER, 0.4)

    def confirm_name(self):
        add_score(self.mode, self.name_input.text.strip(), self.pending_score, self.elapsed_time)
        AUDIO.play(SND_HIGHSCORE, 0.5)

    def best_score(self, mode):
        lst = SCORES.get(mode, [])
        return lst[0]["score"] if lst else 0

game = Game()

# ------------------------------------------------------------------
# HUD
# ------------------------------------------------------------------
def draw_hud(surf):
    score_txt = f"MESAFE: {int(game.distance)}m"
    draw_text_glow(surf, score_txt, FONT_SMALL, NEON_GREEN, (16, 16), center=False)
    best = game.best_score(game.mode)
    best_txt = f"REKOR: {best}m"
    draw_text_glow(surf, best_txt, FONT_TINY, NEON_PURPLE, (16, 42), center=False)
    time_txt = f"SURE: {fmt_time(game.elapsed_time)}"
    draw_text_glow(surf, time_txt, FONT_TINY, WHITE, (16, 62), center=False)

    y_extra = 86
    if game.mode == MODE_ENDLESS:
        coin_txt = f"ALTIN: {game.coin_count}"
        draw_text_glow(surf, coin_txt, FONT_SMALL, NEON_YELLOW, (16, y_extra), center=False)
        if game.combo > 1:
            combo_txt = f"KOMBO x{game.combo}"
            draw_text_glow(surf, combo_txt, FONT_TINY, NEON_ORANGE, (16, y_extra + 26), center=False)
    if game.mode == MODE_TIME:
        t = max(0, game.time_left)
        color = NEON_PINK if t > 10 else NEON_RED
        draw_text_glow(surf, f"SURE LIMIT: {t:0.1f}", FONT_MED, color, (WIDTH // 2, 36))
    if game.mode == MODE_SURVIVAL:
        for i in range(3):
            cx = 24 + i * 34
            cy = 92
            color = (255, 60, 90) if i < game.lives else (50, 30, 40)
            pygame.draw.circle(surf, color, (cx, cy), 12)
            pygame.draw.circle(surf, WHITE if i < game.lives else GREY, (cx, cy), 12, 2)
    if game.mode == MODE_FUEL:
        bar_w = 200
        pct = clamp(game.fuel / game.fuel_max, 0, 1)
        col = NEON_GREEN if pct > 0.35 else NEON_RED
        draw_glow_rect(surf, (20, 30, 20), (WIDTH // 2 - bar_w // 2, 14, bar_w, 18), glow=6, radius=8)
        pygame.draw.rect(surf, col, (WIDTH // 2 - bar_w // 2, 14, int(bar_w * pct), 18), border_radius=8)
        ftxt = FONT_TINY.render("YAKIT", True, WHITE)
        surf.blit(ftxt, ftxt.get_rect(center=(WIDTH // 2, 23)))
        if pct < 0.25 and int(game.elapsed_time * 2) % 2 == 0:
            warn = FONT_SMALL.render("YAKIT AZALIYOR!", True, NEON_RED)
            surf.blit(warn, warn.get_rect(center=(WIDTH // 2, 56)))
        if game.speed_boost_timer > 0:
            bt = FONT_TINY.render("HIZ ARTISI!", True, NEON_ORANGE)
            surf.blit(bt, bt.get_rect(center=(WIDTH // 2, 76)))
    if game.mode == MODE_RACE:
        lap_txt = f"TUR: {min(game.race_lap, RACE_TOTAL_LAPS)}/{RACE_TOTAL_LAPS}"
        draw_text_glow(surf, lap_txt, FONT_SMALL, NEON_PURPLE, (WIDTH // 2, 26))
        pos_txt = f"SIRA: {game.race_position}/{RACE_OPPONENTS + 1}"
        pcolor = NEON_YELLOW if game.race_position == 1 else WHITE
        draw_text_glow(surf, pos_txt, FONT_SMALL, pcolor, (WIDTH // 2, 54))

    theme_txt = FONT_TINY.render(game.theme.name, True, GREY)
    surf.blit(theme_txt, theme_txt.get_rect(topright=(WIDTH - 70, 8)))

    if game.player.invincible_timer > 30:
        shield_txt = FONT_TINY.render("KALKAN AKTIF", True, NEON_BLUE)
        surf.blit(shield_txt, shield_txt.get_rect(center=(WIDTH // 2, HEIGHT - 70)))

    bar_w = 160
    pct = max(0, 1 - game.player.nitro_timer / 100)
    draw_glow_rect(surf, (30, 20, 50), (WIDTH - bar_w - 16, HEIGHT - 30, bar_w, 14), glow=4, radius=6)
    pygame.draw.rect(surf, NEON_ORANGE if pct > 0.3 else (255, 80, 80),
                      (WIDTH - bar_w - 16, HEIGHT - 30, int(bar_w * pct), 14), border_radius=6)
    nitro_label = FONT_TINY.render("NITRO", True, WHITE)
    surf.blit(nitro_label, (WIDTH - bar_w - 16, HEIGHT - 48))

    pause_hint = FONT_TINY.render("P: DURAKLAT", True, GREY)
    surf.blit(pause_hint, (WIDTH - bar_w - 16, HEIGHT - 66))

def draw_leaderboard_table(surf, mode, top=10, y0=170):
    entries = SCORES.get(mode, [])[:top]
    if not entries:
        txt = FONT_SMALL.render("Henuz kayit yok. Once oyna!", True, GREY)
        surf.blit(txt, txt.get_rect(center=(WIDTH // 2, y0 + 40)))
        return
    head = FONT_TINY.render("SIRA       ISIM             MESAFE        SURE", True, GREY)
    surf.blit(head, head.get_rect(center=(WIDTH // 2, y0 - 18)))
    for i, e in enumerate(entries):
        row_y = y0 + i * 32
        rank_color = NEON_YELLOW if i == 0 else (NEON_BLUE if i < 3 else WHITE)
        rank = FONT_SMALL.render(f"{i+1}.", True, rank_color)
        name = FONT_SMALL.render(e["name"], True, WHITE)
        score = FONT_SMALL.render(f"{e['score']}m", True, NEON_GREEN)
        tm = FONT_SMALL.render(fmt_time(e.get("time", 0)), True, NEON_ORANGE)
        surf.blit(rank, (WIDTH // 2 - 230, row_y))
        surf.blit(name, (WIDTH // 2 - 170, row_y))
        surf.blit(score, (WIDTH // 2 + 60, row_y))
        surf.blit(tm, (WIDTH // 2 + 170, row_y))

def draw_achievements_screen(surf):
    draw_text_glow(surf, "BASARIMLAR", FONT_MED, NEON_YELLOW, (WIDTH // 2, 70))
    unlocked = set(DATA["achievements_unlocked"])
    cols = 2
    col_w = 410
    start_x = WIDTH // 2 - col_w
    start_y = 115
    row_h = 70
    for i, ach in enumerate(ACHIEVEMENTS):
        col = i % cols
        row = i // cols
        x = start_x + col * col_w
        y = start_y + row * row_h
        box = pygame.Rect(x, y, col_w - 18, row_h - 10)
        is_unlocked = ach.key in unlocked
        color = NEON_GREEN if is_unlocked else GREY
        draw_glow_rect(surf, color if is_unlocked else (40, 40, 46), box, glow=6 if is_unlocked else 2, radius=8)
        if not is_unlocked:
            pygame.draw.rect(surf, (20, 20, 24), box.inflate(-4, -4), border_radius=6)
        icon = "★" if is_unlocked else "🔒"
        name = FONT_SMALL.render(ach.name if is_unlocked else "???", True, WHITE if is_unlocked else GREY)
        desc = FONT_TINY.render(ach.desc if is_unlocked else "Kilitli", True, GREY)
        surf.blit(name, (box.x + 14, box.y + 8))
        surf.blit(desc, (box.x + 14, box.y + 32))
    total = len(ACHIEVEMENTS)
    done = len(unlocked)
    summary = FONT_SMALL.render(f"{done}/{total} BASARIM ACILDI", True, NEON_BLUE)
    surf.blit(summary, summary.get_rect(center=(WIDTH // 2, HEIGHT - 30)))

def draw_achievement_popup(surf, ach, t):
    """t: 0..1 (kalan sure orani)"""
    alpha = 255
    if t > 0.85:
        alpha = int(255 * (1 - t) / 0.15)
    elif t < 0.15:
        alpha = int(255 * t / 0.15)
    box = pygame.Rect(WIDTH // 2 - 200, 90, 400, 64)
    s = pygame.Surface((400, 64), pygame.SRCALPHA)
    glowc = (*NEON_YELLOW, min(255, alpha))
    pygame.draw.rect(s, (10, 10, 16, min(220, alpha)), (0, 0, 400, 64), border_radius=12)
    pygame.draw.rect(s, glowc, (0, 0, 400, 64), 2, border_radius=12)
    title = FONT_TINY.render("BASARIM ACILDI!", True, (*NEON_YELLOW,))
    name = FONT_SMALL.render(ach.name, True, WHITE)
    title.set_alpha(alpha)
    name.set_alpha(alpha)
    s.blit(title, (16, 10))
    s.blit(name, (16, 28))
    surf.blit(s, box.topleft)

# ------------------------------------------------------------------
# ANA DONGU
# ------------------------------------------------------------------
def main():
    global screen
    AUDIO.play_music("city")
    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0

        sw, sh = screen.get_size()
        scale = min(sw / WIDTH, sh / HEIGHT)
        off_x = (sw - int(WIDTH * scale)) // 2
        off_y = (sh - int(HEIGHT * scale)) // 2
        raw_mouse = pygame.mouse.get_pos()
        mouse_pos = (
            clamp((raw_mouse[0] - off_x) / scale, 0, WIDTH) if scale else raw_mouse[0],
            clamp((raw_mouse[1] - off_y) / scale, 0, HEIGHT) if scale else raw_mouse[1],
        )
        keys = pygame.key.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.VIDEORESIZE and not IS_FULLSCREEN:
                screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)

            if event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION):
                event.pos = (int(mouse_pos[0]), int(mouse_pos[1]))

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    AUDIO.toggle_master()
                if event.key in (pygame.K_f, pygame.K_F11):
                    toggle_fullscreen()
                if event.key == pygame.K_ESCAPE:
                    if IS_FULLSCREEN:
                        toggle_fullscreen()
                    elif game.state in (STATE_PLAY, STATE_PAUSE):
                        AUDIO.stop_engine()
                        game.state = STATE_MENU
                        AUDIO.play_music("city")
                    else:
                        game.state = STATE_MENU
                if event.key == pygame.K_p and game.state in (STATE_PLAY, STATE_PAUSE):
                    if game.state == STATE_PLAY:
                        game.state = STATE_PAUSE
                        AUDIO.engine_channel.set_volume(0.0)
                        AUDIO.play(SND_PAUSE, 0.4)
                    else:
                        game.state = STATE_PLAY
                        AUDIO.play(SND_PAUSE, 0.4)

            SOUND_BTN.handle_event(event)

            if game.state == STATE_MENU:
                game.btn_play.update(mouse_pos)
                game.btn_scores.update(mouse_pos)
                game.btn_achv.update(mouse_pos)
                if game.btn_play.clicked(event):
                    game.state = STATE_MODE_SELECT
                elif game.btn_scores.clicked(event):
                    game.leaderboard_from = STATE_MENU
                    game.state = STATE_LEADERBOARD
                elif game.btn_achv.clicked(event):
                    game.state = STATE_ACHIEVEMENTS

            elif game.state == STATE_MODE_SELECT:
                for b in (game.btn_endless, game.btn_time, game.btn_survival, game.btn_fuel, game.btn_race, game.btn_back):
                    b.update(mouse_pos)
                if game.btn_endless.clicked(event):
                    game.start_mode(MODE_ENDLESS)
                elif game.btn_time.clicked(event):
                    game.start_mode(MODE_TIME)
                elif game.btn_survival.clicked(event):
                    game.start_mode(MODE_SURVIVAL)
                elif game.btn_fuel.clicked(event):
                    game.start_mode(MODE_FUEL)
                elif game.btn_race.clicked(event):
                    game.start_mode(MODE_RACE)
                elif game.btn_back.clicked(event):
                    game.state = STATE_MENU

            elif game.state == STATE_LEADERBOARD:
                game.btn_lb_back.update(mouse_pos)
                for b in game.btn_lb_tabs.values():
                    b.update(mouse_pos)
                if game.btn_lb_back.clicked(event):
                    game.state = game.leaderboard_from
                for m, b in game.btn_lb_tabs.items():
                    if b.clicked(event):
                        game.lb_tab = m

            elif game.state == STATE_ACHIEVEMENTS:
                game.btn_achv_back.update(mouse_pos)
                if game.btn_achv_back.clicked(event):
                    game.state = STATE_MENU

            elif game.state == STATE_GAMEOVER:
                for b in (game.btn_retry, game.btn_menu, game.btn_save_score, game.btn_skip_name):
                    b.update(mouse_pos)
                if game.btn_retry.clicked(event):
                    game.start_mode(game.mode)
                elif game.btn_menu.clicked(event):
                    game.state = STATE_MENU
                    AUDIO.play_music("city")
                elif qualifies_for_top(game.mode, game.pending_score) and game.btn_save_score.clicked(event):
                    game.state = STATE_NAME_ENTRY
                    game.name_input = TextInput()
                if event.type == pygame.KEYDOWN and event.key == pygame.K_l:
                    game.leaderboard_from = STATE_GAMEOVER
                    game.state = STATE_LEADERBOARD

            elif game.state == STATE_NAME_ENTRY:
                game.btn_skip_name.update(mouse_pos)
                if event.type == pygame.KEYDOWN:
                    if game.name_input.handle_key(event):
                        game.confirm_name()
                        game.state = STATE_GAMEOVER
                if game.btn_skip_name.clicked(event):
                    game.state = STATE_GAMEOVER

        # -------------------- GUNCELLEME --------------------
        if game.state == STATE_MENU:
            game.title_y = lerp(game.title_y, 100, 0.08)
            game.title_glitch_timer += 1

        elif game.state == STATE_COUNTDOWN:
            game.countdown_timer += dt
            if game.countdown_timer >= 1.0:
                game.countdown_timer = 0
                game.countdown_value -= 1
                if game.countdown_value > 0:
                    AUDIO.play(SND_COUNT, 0.6)
                else:
                    AUDIO.play(SND_GO, 0.7)
                    game.state = STATE_PLAY
                    game.run_start_ticks = time_module.time()

        elif game.state == STATE_PLAY:
            game.update_play(dt, keys)
            if game.player.nitro and random.random() < 0.15:
                AUDIO.play(SND_NITRO, 0.18)

        elif game.state == STATE_GAMEOVER:
            game.fade_alpha = min(180, game.fade_alpha + 6)
            if game.achievement_queue:
                game.achievement_timer += dt
                if game.achievement_timer > 3.0:
                    game.achievement_timer = 0
                    AUDIO.play(SND_ACHIEVEMENT, 0.5)
                    game.achievement_queue.pop(0)

        for p in particles[:]:
            p.update()
            if not p.alive:
                particles.remove(p)

        # -------------------- CIZIM --------------------
        ox, oy = shaker.offset()
        render_surf = pygame.Surface((WIDTH, HEIGHT))

        if game.state == STATE_MENU:
            draw_background(render_surf, THEMES[0])
            for w in wind_lines:
                w.update(0.3)
            title_text = "NEON RACER"
            glitch_x = random.randint(-2, 2) if game.title_glitch_timer % 20 < 2 else 0
            draw_text_glow(render_surf, title_text, FONT_BIG, NEON_PINK,
                            (WIDTH // 2 + glitch_x, int(game.title_y)), glow_color=NEON_BLUE)
            sub = FONT_SMALL.render("S Y N T H W A V E   A R C A D E   R A C E R", True, NEON_BLUE)
            render_surf.blit(sub, sub.get_rect(center=(WIDTH // 2, int(game.title_y) + 46)))
            game.btn_play.draw(render_surf)
            game.btn_scores.draw(render_surf)
            game.btn_achv.draw(render_surf)
            hint = FONT_TINY.render("WASD/OK: Hareket | SPACE: Nitro | P: Duraklat | M: Ses | F: Tam Ekran", True, GREY)
            render_surf.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT - 30)))

        elif game.state == STATE_MODE_SELECT:
            draw_background(render_surf, THEMES[0])
            draw_text_glow(render_surf, "MOD SEC", FONT_MED, WHITE, (WIDTH // 2, 130))
            for b in (game.btn_endless, game.btn_time, game.btn_survival, game.btn_fuel, game.btn_race, game.btn_back):
                b.draw(render_surf)
            tips = [
                "Sonsuz Yol: En uzak mesafeyi yap, carpma! Yildiz = kisa sureli kalkan.",
                "Zamana Karsi: Saat topla, suren dolmadan ilerle.",
                "Hayatta Kalim: Agresif trafik var, 3 canin var.",
                "Yakit Yarisi: Yakit azalir, yakit topla! Turbo ikonu hizlandirir.",
                "Pist Yarisi: 4 rakiple 5 tur yarisirsin, ilk sirayi hedefle.",
            ]
            for i, t in enumerate(tips):
                txt = FONT_TINY.render(t, True, GREY)
                render_surf.blit(txt, txt.get_rect(center=(WIDTH // 2, 494 + i * 20)))

        elif game.state == STATE_LEADERBOARD:
            draw_background(render_surf, THEMES[2])
            draw_text_glow(render_surf, "SKOR TABLOSU", FONT_MED, NEON_YELLOW, (WIDTH // 2, 60))
            for m, b in game.btn_lb_tabs.items():
                b.draw(render_surf)
            sel_rect = game.btn_lb_tabs[game.lb_tab].rect
            pygame.draw.rect(render_surf, WHITE, sel_rect.inflate(6, 6), 2, border_radius=10)
            draw_leaderboard_table(render_surf, game.lb_tab)
            game.btn_lb_back.draw(render_surf)

        elif game.state == STATE_ACHIEVEMENTS:
            draw_background(render_surf, THEMES[3])
            draw_achievements_screen(render_surf)
            game.btn_achv_back.draw(render_surf)

        elif game.state == STATE_COUNTDOWN:
            draw_background(render_surf, game.theme, world_speed=game.world_speed)
            game.lane_marks.draw(render_surf, game.theme)
            game.player.draw(render_surf)
            for car in game.traffic:
                car.draw(render_surf)
            if game.mode == MODE_RACE:
                for opp in game.race_opponents:
                    opp.draw(render_surf)
            val_text = str(game.countdown_value) if game.countdown_value > 0 else "GO!"
            scale = 1.0 + (1 - game.countdown_timer) * 0.3
            f = pygame.font.SysFont("consolas", int(90 * max(scale, 1)), bold=True)
            draw_text_glow(render_surf, val_text, f, NEON_YELLOW, (WIDTH // 2, HEIGHT // 2), glow_color=NEON_PINK)

        elif game.state in (STATE_PLAY, STATE_PAUSE, STATE_NAME_ENTRY, STATE_GAMEOVER):
            speed_factor = game.player.speed / game.player.base_speed if game.state == STATE_PLAY else 1.0
            draw_background(render_surf, game.theme, speed_factor, game.theme_anim_t, game.world_speed)
            game.lane_marks.draw(render_surf, game.theme)
            for c in game.coins:
                c.draw(render_surf)
            for ck in game.clocks:
                ck.draw(render_surf)
            for sp in game.stars_pickup:
                sp.draw(render_surf)
            for fc in game.fuel_cans:
                fc.draw(render_surf)
            for bo in game.boosts:
                bo.draw(render_surf)
            for car in sorted(game.traffic, key=lambda c: c.y):
                car.draw(render_surf)
            if game.mode == MODE_RACE:
                for opp in sorted(game.race_opponents, key=lambda c: c.y):
                    # rakip dunyada gorsel olarak oyuncu hizina gore kayar (basitlestirilmis)
                    rel = (opp.progress - game.distance)
                    draw_y = game.player.y - rel * 0.6
                    if -100 < draw_y < HEIGHT + 100:
                        opp.y = draw_y
                        opp.draw(render_surf)
            game.player.draw(render_surf)
            for p in particles:
                p.draw(render_surf)
            if speed_factor > 1.3:
                for w in wind_lines:
                    w.update(speed_factor)
                    w.draw(render_surf, alpha=min(180, int((speed_factor - 1) * 140)), color=game.theme.accent)
            draw_hud(render_surf)

            if game.state == STATE_PAUSE:
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 150))
                render_surf.blit(overlay, (0, 0))
                draw_text_glow(render_surf, "DURAKLATILDI", FONT_BIG, NEON_BLUE, (WIDTH // 2, HEIGHT // 2 - 30))
                hint = FONT_SMALL.render("Devam icin P'ye bas", True, WHITE)
                render_surf.blit(hint, hint.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 30)))

            if game.state == STATE_NAME_ENTRY:
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 190))
                render_surf.blit(overlay, (0, 0))
                draw_text_glow(render_surf, "YENI REKOR!", FONT_BIG, NEON_YELLOW, (WIDTH // 2, 190), glow_color=NEON_ORANGE)
                score_txt = FONT_MED.render(f"{game.pending_score}m  -  {fmt_time(game.elapsed_time)}", True, NEON_GREEN)
                render_surf.blit(score_txt, score_txt.get_rect(center=(WIDTH // 2, 250)))
                game.name_input.draw(render_surf, (WIDTH // 2, 330))
                hint = FONT_TINY.render("Yazip ENTER'a bas ya da KAYDETMEDEN GEC'e tikla", True, GREY)
                render_surf.blit(hint, hint.get_rect(center=(WIDTH // 2, 390)))
                game.btn_skip_name.draw(render_surf)

            if game.state == STATE_GAMEOVER:
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, game.fade_alpha))
                render_surf.blit(overlay, (0, 0))
                if game.fade_alpha > 100:
                    title = "FINISH!" if game.win else "OYUN BITTI"
                    color = NEON_GREEN if game.win else NEON_PINK
                    draw_text_glow(render_surf, title, FONT_BIG, color, (WIDTH // 2, 130))
                    if game.game_over_reason:
                        r = FONT_SMALL.render(game.game_over_reason, True, WHITE)
                        render_surf.blit(r, r.get_rect(center=(WIDTH // 2, 182)))
                    score_txt = f"MESAFE: {int(game.distance)}m   ALTIN: {game.coin_count}   SURE: {fmt_time(game.elapsed_time)}"
                    s = FONT_SMALL.render(score_txt, True, NEON_YELLOW)
                    render_surf.blit(s, s.get_rect(center=(WIDTH // 2, 216)))
                    best = FONT_TINY.render(f"EN IYI ({MODE_LABELS.get(game.mode,'')}): {game.best_score(game.mode)}m", True, GREY)
                    render_surf.blit(best, best.get_rect(center=(WIDTH // 2, 240)))
                    lb_hint = FONT_TINY.render("Skor tablosunu gormek icin L'ye bas", True, GREY)
                    render_surf.blit(lb_hint, lb_hint.get_rect(center=(WIDTH // 2, 260)))
                    game.btn_retry.draw(render_surf)
                    if qualifies_for_top(game.mode, game.pending_score):
                        game.btn_save_score.draw(render_surf)
                        game.btn_menu.rect.y = 530
                    else:
                        nr = FONT_TINY.render("(Bu skor ilk 10'a giremedi)", True, GREY)
                        render_surf.blit(nr, nr.get_rect(center=(WIDTH // 2, 470)))
                        game.btn_menu.rect.y = 470
                    game.btn_menu.draw(render_surf)

                    if game.achievement_queue:
                        t = clamp(game.achievement_timer / 3.0, 0, 1)
                        draw_achievement_popup(render_surf, game.achievement_queue[0], t)

        SOUND_BTN.draw(render_surf)
        scale, off_x, off_y = blit_scaled(render_surf, ox, oy)
        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
