\# Easy AI Studio — Kurulum Rehberi



\## Gereksinimler

\- Python 3.12+

\- Node.js 18+ (npm dahil)

\- FFmpeg (tam sürüm — https://www.gyan.dev/ffmpeg/builds/ adresinden "ffmpeg-release-full.7z")

\- (Opsiyonel, AI video üretimi için) ComfyUI kurulu ve çalışır durumda

\- (Opsiyonel, AI sohbet için) Ollama kurulu, bir model indirilmiş (örn. `ollama pull llama3`)

\- (Opsiyonel, AI ses efekti için) Ücretsiz bir ElevenLabs hesabı ve API key



\## 1. Projeyi indirin

GitHub'dan indirin veya klonlayın:


git clone https://github.com/Asistan80/EasyAIStudio.git

cd EasyAIStudio


\## 2. FFmpeg'i yerleştirin

İndirdiğiniz FFmpeg'in `bin` klasöründeki `ffmpeg.exe` dosyasını şuraya kopyalayın:


backend/ffmpeg/bin/ffmpeg.exe


\## 3. Backend'i kurun


cd backend

pip install -r requirements.txt


Proje ana klasöründe bir `.env` dosyası oluşturun (opsiyonel, ses efekti için):


ELEVENLABS\_API\_KEY=kendi\_api\_keyiniz


Backend'i başlatın:


python run.py


\## 4. Frontend'i kurun

Yeni bir terminalde:


cd frontend

npm install

npm run dev


\## 5. Kullanmaya başlayın

Tarayıcınızda `http://localhost:5173` adresini açın.



> \*\*Not:\*\* AI video üretimi için ComfyUI'ın, AI sohbet için Ollama'nın ayrıca kurulu ve arka planda çalışıyor olması gerekir. Bu araçlar olmadan da video editörü, GIF ve export özellikleri tam çalışır.








