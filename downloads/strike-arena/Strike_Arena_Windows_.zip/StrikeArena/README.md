# Strike Arena v2 — 3 Boyutlu Bowling

## Çalıştırma
- Windows: `windows/StrikeArena.exe` dosyasına çift tıkla.
- Tarayıcı: `web/` klasöründe `web_baslat.bat` (Linux/Mac: `web_baslat.sh`) çalıştır; http://localhost:8000 açılır. (Python gerekir.)

## v2 yenilikleri
- Top sesi yumuşatıldı ve kısıldı (Ayarlar'dan ses seviyeleri)
- Labutlara çarparken sabit, tüm rafı gösteren kamera; C tuşuyla 4 kamera stili
- Küçük, kompakt skor tablosu; TAB ile aç/kapa
- 3 seçilebilir hat (sol / orta / sağ); mekân ve kamera seçilen hatta göre değişir
- ARKADAŞLARLA ONLINE: Ana menü > Online. Windows exe ile oda kur, arkadaşlar IP:port ile katılır. Sonucu oda kurucusu belirler; kopan oyuncunun yerine bot oynar.
  - Aynı Wi-Fi/LAN'da doğrudan çalışır. İnternet için port yönlendirme ya da Radmin/Hamachi/Tailscale gibi VPN gerekir.
  - Web sürümü odaya katılabilir (http sayfasından), oda kuramaz.

## Kontroller
A/D kaydır • Fare/ok nişan • BOŞLUK / SOL TIK onayla • [ ] top değiştir • C kamera • TAB skor tablosu • ESC duraklat

Kayıtlar `user://bowling.cfg` dosyasında tutulur.
