\# 📚 Kadim Görsel Kütüphane Deposu (Cyber Library Ambar v6.0)



Gelişmiş, modern ve siber estetiğe sahip, Python tabanlı bir masaüstü kitaplık yönetim yazılımıdır. Görüntü işleme teknolojileri, gömülü doküman okuyucular ve akıllı senkronizasyon araçları içeren entegre bir ambar mimarisi sunar.



\## ✨ Öne Çıkan Özellikler



\- \*\*📷 Donanımsal Barkod Okuyucu:\*\* Bilgisayar kamerası üzerinden gerçek kitap barkodlarını (EAN-13) anlık çözer.

\- \*\*🌐 Hibrit İnternet Entegrasyonu:\*\* Okunan barkodları Open Library API sistemiyle eşleştirir; yerel Türkçe veri havuzuyla destekleyerek ad, yazar, sayfa ve yayın yılı bilgilerini otomatik doldurur.

\- \*\*🖼️ Dinamik Kapak Ambarı \& Vitrin:\*\* Kitap kapaklarını otomatik indirir, bulunamayan görseller yerine siber figür tasarımları atar ve en sevilen kitapları "Özel Vitrin" üzerinde kaydırır.

\- \*\*📑 Gömülü PDF / E-Kitap Okuyucu:\*\* PDF dosyalarını kitap kartlarına bağlar ve harici hiçbir programa ihtiyaç duymadan uygulama içinde tam sayfa okuma deneyimi sunar.

\- \*\*📅 Okuma Günlüğü \& Takvim:\*\* Ay takvimi üzerinden seçilen günlere özel okuma notları ve günlük kayıtları düşülmesini sağlar.

\- \*\*🤝 Emanet / Ödünç Takip Sistemi:\*\* Kütüphaneden çıkan veya giren kitapları kişi, tarih ve saat damgalarıyla kayıt altına alır.

\- \*\*🔒 Kriptografik Güvenlik Duvarı:\*\* SHA-256 şifreleme motoru sayesinde veritabanına erişimi şifreli kilit arkasında korur. Şifre 1234

\- \*\*🎨 Siber Temalar:\*\* Kişiselleştirilebilir neon siber temalar ve interaktif animasyonlu kitap kutuları barındırır.



\## 🛠️ Gereksinimler ve Kurulum



Projenin kararlı bir şekilde çalışabilmesi için sisteminizde Python 3.10+ kurulu olmalıdır. Ardından gerekli kütüphaneleri terminal (CMD) üzerinden yükleyebilirsiniz:



```bash

pip install PyQt6 opencv-python pyzbar requests pypdfium2

