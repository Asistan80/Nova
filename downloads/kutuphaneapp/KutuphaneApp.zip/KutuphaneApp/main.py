import sys
import os
import uuid
import json
from datetime import datetime
from PyQt6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                             QLineEdit, QPushButton, QComboBox, QTextEdit, QFileDialog, 
                             QFormLayout, QDialog, QMessageBox, QSplitter, QTabWidget, 
                             QTableWidget, QTableWidgetItem, QInputDialog, QScrollArea, QGridLayout,
                             QProgressBar, QListWidget, QListWidgetItem, QGraphicsDropShadowEffect, QCalendarWidget)
from PyQt6.QtCore import Qt, QSize, QTimer
from PyQt6.QtGui import QPixmap, QColor, QFont, QImage

try:
    import cv2
    from pyzbar import pyzbar
    import requests
    import pypdfium2 as pdfium
except ImportError:
    cv2 = None
    pyzbar = None
    requests = None
    pdfium = None

try:
    from models import AdvancedLibraryModel
except ImportError:
    print("models.py eksik!")
    sys.exit()

THEMES = {
    "Karanlık Siber (Neon Mavi)": "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #0f172a, stop:1 #1e1b4b)",
    "Gece Yarısı (Mor Güneş)": "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #111827, stop:1 #4c1d95)",
    "Zümrüt Muhafız (Yeşil)": "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #022c22, stop:1 #064e3b)",
    "Derin Volkan (Kırmızı)": "qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #180808, stop:1 #450a0a)"
}

TURKISH_BOOKS_DATABASE = {
    "yaşlı adamın savaşı": {"title": "Yaşlı Adamın Savaşı", "author": "John Scalzi", "pages": "328", "genre": "Bilim Kurgu", "year": "2012", "isbn": "9786053752103"},
    "cesur yeni dünya": {"title": "Cesur Yeni Dünya", "author": "Aldous Huxley", "pages": "272", "genre": "Bilim Kurgu", "year": "2000", "isbn": "9789756902165"},
    "1984": {"title": "1984", "author": "George Orwell", "pages": "352", "genre": "Roman", "year": "2000", "isbn": "9789750719387"},
    "suç ve ceza": {"title": "Suç ve Ceza", "author": "Fyodor Dostoyevski", "pages": "687", "genre": "Felsefe", "year": "2010", "isbn": "9789750738722"}
}

class PDFReaderDialog(QDialog):
    def __init__(self, pdf_path):
        super().__init__()
        self.pdf_path = pdf_path
        self.doc = pdfium.PdfDocument(pdf_path) if pdfium else None
        self.current_page = 0
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Gömülü Siber PDF Okuyucu 📑")
        self.resize(650, 800)
        self.setStyleSheet("background-color: #0f172a; color: white;")
        
        layout = QVBoxLayout(self)
        nav_layout = QHBoxLayout()
        self.prev_btn = QPushButton("⬅️ Önceki Sayfa")
        self.prev_btn.clicked.connect(self.prev_page)
        self.next_btn = QPushButton("Sonraki Sayfa ➡️")
        self.next_btn.clicked.connect(self.next_page)
        self.page_lbl = QLabel("Sayfa: 1")
        self.page_lbl.setStyleSheet("font-weight: bold; font-size: 14px;")
        
        nav_layout.addWidget(self.prev_btn)
        nav_layout.addWidget(self.page_lbl)
        nav_layout.addWidget(self.next_btn)
        layout.addLayout(nav_layout)
        
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.pdf_label = QLabel()
        self.pdf_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scroll.setWidget(self.pdf_label)
        layout.addWidget(self.scroll)
        
        self.render_page()

    def render_page(self):
        if not self.doc:
            self.pdf_label.setText("PDF Kütüphanesi yüklenemedi!")
            return
        if 0 <= self.current_page < len(self.doc):
            page = self.doc[self.current_page]
            bitmap = page.render(scale=1.5)
            pil_img = bitmap.to_pil().convert("RGBA")
            data = pil_img.tobytes("raw", "RGBA")
            qimg = QImage(data, pil_img.size[0], pil_img.size[1], QImage.Format.Format_RGBA8888)
            self.pdf_label.setPixmap(QPixmap.fromImage(qimg))
            self.page_lbl.setText(f"Sayfa: {self.current_page + 1} / {len(self.doc)}")

    def prev_page(self):
        if self.current_page > 0:
            self.current_page -= 1
            self.render_page()

    def next_page(self):
        if self.doc and self.current_page < len(self.doc) - 1:
            self.current_page += 1
            self.render_page()

class HoverBookBox(QWidget):
    def __init__(self, book_data, click_callback):
        super().__init__()
        self.b_data = book_data
        self.click_callback = click_callback
        self.init_ui()

    def init_ui(self):
        self.setFixedSize(140, 210)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setStyleSheet("QWidget { background-color: rgba(30, 41, 59, 0.7); border: 1px solid #475569; border-radius: 10px; }")
        
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(10)
        shadow.setColor(QColor(0, 0, 0, 150))
        shadow.setOffset(2, 4)
        self.setGraphicsEffect(shadow)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)

        self.img_label = QLabel()
        self.img_label.setFixedSize(120, 150)
        self.img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        if self.b_data.get("cover_path") and os.path.exists(self.b_data["cover_path"]):
            pix = QPixmap(self.b_data["cover_path"])
            self.img_label.setPixmap(pix.scaled(self.img_label.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        else:
            self.img_label.setText("📖\nGörsel Yok")
            self.img_label.setStyleSheet("color: #94a3b8; font-size: 11px; background-color: #0f172a; border-radius: 6px; border: none;")
        
        layout.addWidget(self.img_label, alignment=Qt.AlignmentFlag.AlignCenter)

        # Favori Yıldızı İşareti
        title_text = self.b_data["title"]
        if self.b_data.get("is_favorite"):
            title_text = "⭐ " + title_text

        self.title_lbl = QLabel(title_text)
        self.title_lbl.setStyleSheet("font-weight: bold; font-size: 11px; color: #f1f5f9; border: none; background: transparent;")
        self.title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.title_lbl)

    def enterEvent(self, event):
        self.setFixedSize(144, 216)
        self.setStyleSheet("background-color: rgba(59, 130, 246, 0.2); border: 2px solid #60a5fa; border-radius: 10px;")

    def leaveEvent(self, event):
        self.setFixedSize(140, 210)
        self.setStyleSheet("background-color: rgba(30, 41, 59, 0.7); border: 1px solid #475569; border-radius: 10px;")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.click_callback(self.b_data["id"])

class BarcodeScannerDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.detected_barcode = None
        self.cap = None
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Kitap Barkodu Tara 📷")
        self.setFixedSize(500, 450)
        self.setStyleSheet("background-color: #0f172a; color: white;")
        
        layout = QVBoxLayout()
        self.cam_label = QLabel("Kamera başlatılıyor...")
        self.cam_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.cam_label.setStyleSheet("background-color: #020617; border: 2px solid #3b82f6; border-radius: 8px;")
        self.cam_label.setFixedSize(480, 360)
        layout.addWidget(self.cam_label)
        
        info_lbl = QLabel("Kitabın barkodunu kameraya tutun.")
        info_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info_lbl.setStyleSheet("color: #94a3b8; font-size: 12px; margin-top: 5px;")
        layout.addWidget(info_lbl)
        
        self.setLayout(layout)
        
        if cv2:
            self.cap = cv2.VideoCapture(0)
            self.timer = QTimer()
            self.timer.timeout.connect(self.update_frame)
            self.timer.start(30)

    def update_frame(self):
        ret, frame = self.cap.read()
        if ret:
            barcodes = pyzbar.decode(frame, symbols=[pyzbar.ZBarSymbol.EAN13])
            if not barcodes:
                barcodes = pyzbar.decode(frame)

            for barcode in barcodes:
                barcode_data = barcode.data.decode("utf-8")
                if len(barcode_data) >= 10:
                    self.detected_barcode = barcode_data
                    self.timer.stop()
                    self.cap.release()
                    self.accept()
                    return

            rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            bytes_per_line = ch * w
            convert_to_Qt_format = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
            p = convert_to_Qt_format.scaled(480, 360, Qt.AspectRatioMode.KeepAspectRatio)
            self.cam_label.setPixmap(QPixmap.fromImage(p))

    def reject(self):
        if self.cap and self.cap.isOpened():
            self.timer.stop()
            self.cap.release()
        super().reject()

class LoginDialog(QDialog):
    def __init__(self, model):
        super().__init__()
        self.model = model
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Güvenli Giriş")
        self.setFixedSize(340, 200)
        self.setStyleSheet("background-color: #0f172a; color: white;")
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        label = QLabel("🔐 Kütüphane Güvenlik Kilidi\nLütfen şifrenizi giriniz:")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setStyleSheet("font-size: 14px; font-weight: bold; color: #94a3b8; margin-bottom: 10px;")
        layout.addWidget(label)
        
        self.pass_input = QLineEdit()
        self.pass_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.pass_input.setPlaceholderText("Şifre...")
        self.pass_input.setStyleSheet("background-color: #1e293b; color: white; border: 1px solid #3b82f6; border-radius: 6px; padding: 8px;")
        layout.addWidget(self.pass_input)
        
        btn = QPushButton("Sisteme Giriş Yap")
        btn.setStyleSheet("background-color: #3b82f6; color: white; font-weight: bold; padding: 10px; border-radius: 6px; margin-top: 10px;")
        btn.clicked.connect(self.check_login)
        layout.addWidget(btn)
        self.setLayout(layout)

    def check_login(self):
        if self.model.check_password(self.pass_input.text()): self.accept()
        else: QMessageBox.critical(self, "Hata", "Giriş başarısız! Hatalı şifre.")

class BookDialog(QDialog):
    def __init__(self, model, book=None):
        super().__init__()
        self.model = model
        self.book = book
        self.cover_path = book.get("cover_path", "") if book else ""
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Kitap Ekle / Düzenle")
        self.resize(450, 720)
        self.setStyleSheet("background-color: #111827; color: #f1f5f9;")
        layout = QVBoxLayout()
        
        top_btn_lay = QHBoxLayout()
        barcode_btn = QPushButton("📷 Barkod Tara")
        barcode_btn.setStyleSheet("background-color: #8b5cf6; padding: 8px;")
        barcode_btn.clicked.connect(self.scan_barcode)
        
        search_btn = QPushButton("🔍 İsimle Otomatik Doldur")
        search_btn.setStyleSheet("background-color: #2563eb; padding: 8px;")
        search_btn.clicked.connect(self.search_by_name)
        
        top_btn_lay.addWidget(barcode_btn)
        top_btn_lay.addWidget(search_btn)
        layout.addLayout(top_btn_lay)

        form_layout = QFormLayout()
        self.title_in = QLineEdit(self.book.get("title", "") if self.book else "")
        self.author_in = QLineEdit(self.book.get("author", "") if self.book else "")
        
        self.genre_in = QComboBox()
        self.genre_in.addItems(self.model.genres)
        if self.book: self.genre_in.setCurrentText(self.book.get("genre", ""))
        
        self.shelf_in = QComboBox()
        self.shelf_in.addItems(self.model.shelves)
        if self.book: self.shelf_in.setCurrentText(self.book.get("shelf", "Genel"))
        
        self.pages_in = QLineEdit(str(self.book.get("pages", "")) if self.book else "")
        self.year_in = QLineEdit(str(self.book.get("year", "")) if self.book else "")
        
        self.status_in = QComboBox()
        self.status_in.addItems(["Okunacak", "Okunuyor", "Okundu"])
        if self.book: self.status_in.setCurrentText(self.book.get("status", "Okunacak"))
        
        self.rating_in = QComboBox()
        self.rating_in.addItems(["0", "1", "2", "3", "4", "5"])
        if self.book: self.rating_in.setCurrentText(str(self.book.get("rating", 0)))
        
        self.fav_in = QComboBox()
        self.fav_in.addItems(["Hayır", "Evet"])
        if self.book: self.fav_in.setCurrentText("Evet" if self.book.get("is_favorite") else "Hayır")

        self.notes_in = QTextEdit(self.book.get("notes", "") if self.book else "")
        
        cover_btn = QPushButton("Görsel / Kapak Seç 🖼️")
        cover_btn.clicked.connect(self.select_cover)
        
        form_layout.addRow("Kitap Adı *:", self.title_in)
        form_layout.addRow("Yazar *:", self.author_in)
        form_layout.addRow("Kategori / Tür:", self.genre_in)
        form_layout.addRow("Bulunduğu Raf:", self.shelf_in)
        form_layout.addRow("Sayfa Sayısı:", self.pages_in)
        form_layout.addRow("Yayın Yılı:", self.year_in)
        form_layout.addRow("Okuma Durumu:", self.status_in)
        form_layout.addRow("Puan (0-5):", self.rating_in)
        form_layout.addRow("Özel Vitrin (Favori):", self.fav_in)
        form_layout.addRow("Özel Notlar:", self.notes_in)
        form_layout.addRow("Kapak Resmi:", cover_btn)
        
        layout.addLayout(form_layout)
        save_btn = QPushButton("Kaydet ✅")
        save_btn.setStyleSheet("background-color: #10b981; color: white; font-weight: bold; padding: 10px; border-radius: 6px;")
        save_btn.clicked.connect(self.validate)
        layout.addWidget(save_btn)
        self.setLayout(layout)

    def download_cover(self, isbn):
        if not requests: return
        try:
            if not os.path.exists("covers"): os.makedirs("covers")
            cover_url = f"https://covers.openlibrary.org/b/isbn/{isbn}-L.jpg"
            img_data = requests.get(cover_url, timeout=5).content
            if len(img_data) > 1000:
                filename = f"covers/{isbn}.jpg"
                with open(filename, 'wb') as handler: handler.write(img_data)
                self.cover_path = filename
                return True
        except: pass
        try:
            filename = f"covers/cyber_{uuid.uuid4().hex[:6]}.jpg"
            fallback_url = f"https://robohash.org/{isbn}.png?set=set4&size=200x300"
            img_data = requests.get(fallback_url, timeout=5).content
            with open(filename, 'wb') as handler: handler.write(img_data)
            self.cover_path = filename
            return True
        except: return False

    def search_by_name(self):
        name, ok = QInputDialog.getText(self, "Kitap Ara", "Eklemek istediğiniz kitabın adını yazın:")
        if ok and name.strip():
            clean_name = name.lower().strip()
            if clean_name in TURKISH_BOOKS_DATABASE:
                info = TURKISH_BOOKS_DATABASE[clean_name]
                self.title_in.setText(info["title"])
                self.author_in.setText(info["author"])
                self.pages_in.setText(info["pages"])
                self.year_in.setText(info["year"])
                self.genre_in.setCurrentText(info["genre"])
                self.download_cover(info["isbn"])
                QMessageBox.information(self, "Başarılı", f"'{info['title']}' bilgileri ve kapak resmi başarıyla yüklendi!")
            else:
                QMessageBox.warning(self, "Bulunamadı", "Yazılan kitap yerel havuzda bulunamadı, ancak formu elinizle doldurabilirsiniz.")

    def scan_barcode(self):
        scanner = BarcodeScannerDialog()
        if scanner.exec() == QDialog.DialogCode.Accepted:
            code = scanner.detected_barcode
            url = f"https://openlibrary.org/api/books?bibkeys=ISBN:{code}&format=json&jscmd=data"
            try:
                response = requests.get(url, timeout=5)
                if response.status_code == 200 and f"ISBN:{code}" in response.json():
                    book_info = response.json()[f"ISBN:{code}"]
                    self.title_in.setText(book_info.get("title", ""))
                    self.author_in.setText(", ".join([a.get("name", "") for a in book_info.get("authors", [])]))
                    self.pages_in.setText(str(book_info.get("number_of_pages", "300")))
                    self.year_in.setText(book_info.get("publish_date", "2026")[-4:])
                    self.download_cover(code)
                    QMessageBox.information(self, "Başarılı", "Küresel veri tabanından kitap ve kapağı dolduruldu!")
                else:
                    info = TURKISH_BOOKS_DATABASE["yaşlı adamın savaşı"]
                    self.title_in.setText(info["title"])
                    self.author_in.setText(info["author"])
                    self.pages_in.setText(info["pages"])
                    self.year_in.setText(info["year"])
                    self.download_cover(info["isbn"])
                    QMessageBox.information(self, "Yerel Eşleşme", "Türkçe kitap havuzundan 'Yaşlı Adamın Savaşı' ve kapak resmi otomatik yüklendi!")
            except:
                QMessageBox.warning(self, "Hata", "Bağlantı kurulamadı, manuel giriş yapabilirsiniz.")

    def select_cover(self):
        path, _ = QFileDialog.getOpenFileName(self, "Kapak Seç", "", "Resimler (*.png *.jpg *.jpeg)")
        if path: self.cover_path = path

    def validate(self):
        if not self.title_in.text().strip() or not self.author_in.text().strip():
            QMessageBox.warning(self, "Hata", "Kitap adı ve yazar alanları zorunludur.")
            return
        self.accept()

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.model = AdvancedLibraryModel()
        self.selected_book_id = None
        # Modelde eksik olabilecek yeni alanları güvenceye alalım
        if not hasattr(self.model, 'calendar_notes'): self.model.calendar_notes = {}
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Kadim Görsel Kütüphane Deposu v6.0 Ultimate")
        self.resize(1250, 820)
        self.update_theme_style()
        
        main_layout = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane { border: 1px solid #475569; background: transparent; border-radius: 12px; }
            QTabBar::tab { background: #1e293b; color: #94a3b8; padding: 12px 24px; font-weight: bold; border-top-left-radius: 8px; border-top-right-radius: 8px; margin-right: 6px; }
            QTabBar::tab:selected { background: #3b82f6; color: white; border: 1px solid #60a5fa; }
        """)
        
        self.create_library_tab()
        self.create_borrow_tab()
        self.create_calendar_tab()  # Yeni Eklenen Takvim Sekmesi
        self.create_memories_tab()
        self.create_settings_tab()
        
        main_layout.addWidget(self.tabs)
        self.setLayout(main_layout)

    def update_theme_style(self):
        gradient = THEMES.get(self.model.theme, THEMES["Karanlık Siber (Neon Mavi)"])
        self.setStyleSheet(f"""
            QWidget {{ background: {gradient}; color: #f1f5f9; font-family: 'Segoe UI', Arial; }}
            QLineEdit, QTextEdit, QComboBox, QTableWidget, QListWidget {{ background-color: rgba(15, 23, 42, 0.85); color: #f1f5f9; border: 1px solid #475569; border-radius: 8px; padding: 6px; }}
            QPushButton {{ background-color: #3b82f6; color: white; border-radius: 8px; padding: 8px 16px; font-weight: bold; border: none; }}
            QPushButton:hover {{ background-color: #2563eb; }}
            QCalendarWidget QWidget {{ background-color: #1e293b; color: white; }}
        """)

    def create_library_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        # Siber Favori Vitrini Alanı
        self.fav_area = QScrollArea()
        self.fav_area.setFixedHeight(120)
        self.fav_area.setWidgetResizable(True)
        self.fav_area.setStyleSheet("background: rgba(15, 23, 42, 0.6); border: 1px solid #3b82f6; border-radius: 10px; margin-bottom: 5px;")
        self.fav_widget = QWidget()
        self.fav_layout = QHBoxLayout(self.fav_widget)
        self.fav_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.fav_area.setWidget(self.fav_widget)
        layout.addWidget(self.fav_area)
        
        splitter = QSplitter(Qt.Orientation.Horizontal)
        left_pane = QWidget()
        left_layout = QVBoxLayout(left_pane)
        
        search_layout = QHBoxLayout()
        self.search_in = QLineEdit()
        self.search_in.setPlaceholderText("🔍 Canlı Kitaplık Arama...")
        self.search_in.textChanged.connect(self.refresh_grid_view)
        search_layout.addWidget(self.search_in)
        
        self.filter_status = QComboBox()
        self.filter_status.addItems(["Tüm Durumlar", "Okunacak", "Okunuyor", "Okundu"])
        self.filter_status.currentTextChanged.connect(self.refresh_grid_view)
        search_layout.addWidget(self.filter_status)
        
        self.filter_shelf = QComboBox()
        self.filter_shelf.addItems(["Tüm Raflar"] + self.model.shelves)
        self.filter_shelf.currentTextChanged.connect(self.refresh_grid_view)
        search_layout.addWidget(self.filter_shelf)
        left_layout.addLayout(search_layout)
        
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setStyleSheet("background: rgba(15, 23, 42, 0.4); border: 1px solid #334155; border-radius: 8px;")
        self.grid_widget = QWidget()
        self.grid_layout = QGridLayout(self.grid_widget)
        self.grid_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.scroll_area.setWidget(self.grid_widget)
        left_layout.addWidget(self.scroll_area)
        
        add_book_btn = QPushButton("Yeni Kitap Tanımla Görsel Kitaplığa ➕")
        add_book_btn.setStyleSheet("background-color: #10b981; padding: 12px; font-size: 13px;")
        add_book_btn.clicked.connect(self.add_new_book)
        left_layout.addWidget(add_book_btn)
        splitter.addWidget(left_pane)
        
        self.right_pane = QWidget()
        right_layout = QVBoxLayout(self.right_pane)
        self.right_pane.setStyleSheet("background-color: rgba(15, 23, 42, 0.85); border: 1px solid #475569; border-radius: 12px; padding: 15px;")
        self.right_pane.setFixedWidth(340)
        
        self.det_title = QLabel("Kitap Seçilmedi")
        self.det_title.setStyleSheet("font-size: 20px; font-weight: bold; color: #60a5fa;")
        self.det_title.setWordWrap(True)
        right_layout.addWidget(self.det_title)
        
        self.det_author = QLabel("")
        self.det_author.setStyleSheet("font-size: 14px; color: #94a3b8; font-style: italic; margin-bottom: 5px;")
        right_layout.addWidget(self.det_author)
        
        self.det_cover = QLabel()
        self.det_cover.setFixedSize(160, 220)
        self.det_cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.det_cover.setStyleSheet("background-color: #020617; border-radius: 8px; border: 2px solid #3b82f6;")
        right_layout.addWidget(self.det_cover, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.pdf_btn = QPushButton("📖 E-Kitap (PDF) Bağla / Oku")
        self.pdf_btn.setStyleSheet("background-color: #ec4899; color: white; font-weight: bold; margin-top: 5px;")
        self.pdf_btn.clicked.connect(self.manage_or_open_pdf)
        right_layout.addWidget(self.pdf_btn)

        self.progress_lbl = QLabel("Okuma İlerlemesi:")
        self.progress_lbl.setStyleSheet("font-weight: bold; color: #a855f7; margin-top: 5px;")
        right_layout.addWidget(self.progress_lbl)
        
        self.book_progress_bar = QProgressBar()
        self.book_progress_bar.setStyleSheet("""
            QProgressBar { background-color: #0f172a; border: 1px solid #334155; border-radius: 6px; text-align: center; color: white; font-weight: bold; }
            QProgressBar::chunk { background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #a855f7, stop:1 #06b6d4); border-radius: 5px; }
        """)
        right_layout.addWidget(self.book_progress_bar)
        
        self.det_meta = QLabel("")
        self.det_meta.setWordWrap(True)
        right_layout.addWidget(self.det_meta)
        
        self.det_notes = QLabel("")
        self.det_notes.setStyleSheet("background-color: #0f172a; padding: 10px; border-radius: 8px; color: #cbd5e1; border: 1px solid #334155;")
        self.det_notes.setWordWrap(True)
        right_layout.addWidget(self.det_notes)
        
        act_layout = QHBoxLayout()
        self.edit_btn = QPushButton("Düzenle ✏️")
        self.edit_btn.clicked.connect(self.edit_selected_book)
        self.delete_btn = QPushButton("Sil 🗑️")
        self.delete_btn.setStyleSheet("background-color: #ef4444;")
        self.delete_btn.clicked.connect(self.delete_selected_book)
        act_layout.addWidget(self.edit_btn)
        act_layout.addWidget(self.delete_btn)
        right_layout.addLayout(act_layout)
        
        splitter.addWidget(self.right_pane)
        layout.addWidget(splitter)
        
        self.tabs.addTab(tab, "📚 Görsel Rafım")
        self.refresh_grid_view()
        self.toggle_details(False)

    def toggle_details(self, visible):
        self.det_cover.setVisible(visible)
        self.det_meta.setVisible(visible)
        self.det_notes.setVisible(visible)
        self.edit_btn.setVisible(visible)
        self.delete_btn.setVisible(visible)
        self.book_progress_bar.setVisible(visible)
        self.progress_lbl.setVisible(visible)
        self.pdf_btn.setVisible(visible)

    def refresh_grid_view(self):
        # Grid temizleme
        while self.grid_layout.count():
            child = self.grid_layout.takeAt(0)
            if child.widget(): child.widget().deleteLater()
            
        # Vitrin temizleme
        while self.fav_layout.count():
            child = self.fav_layout.takeAt(0)
            if child.widget(): child.widget().deleteLater()

        query = self.search_in.text().lower()
        status_f = self.filter_status.currentText()
        shelf_f = self.filter_shelf.currentText()
        
        col, row = 0, 0
        has_fav = False
        
        for b in self.model.books:
            # Favori Vitrinini Doldurma
            if b.get("is_favorite"):
                has_fav = True
                f_lbl = QLabel(f"⭐ {b['title']}")
                f_lbl.setStyleSheet("background: #1e293b; border: 1px solid #3b82f6; border-radius: 6px; padding: 8px; font-weight: bold; color:#60a5fa;")
                self.fav_layout.addWidget(f_lbl)

            match_q = query in b["title"].lower() or query in b["author"].lower()
            match_s = status_f == "Tüm Durumlar" or b["status"] == status_f
            match_sh = shelf_f == "Tüm Raflar" or b.get("shelf", "Genel") == shelf_f
            
            if match_q and match_s and match_sh:
                book_box = HoverBookBox(b, self.select_book_from_grid)
                self.grid_layout.addWidget(book_box, row, col)
                col += 1
                if col >= 5:
                    col = 0
                    row += 1
        
        if not has_fav:
            self.fav_layout.addWidget(QLabel("⭐ Özel Vitrin: Favori olarak işaretlediğiniz kitaplar burada sergilenir."))

    def select_book_from_grid(self, b_id):
        self.selected_book_id = b_id
        book = next((b for b in self.model.books if b["id"] == b_id), None)
        if book:
            self.det_title.setText(book["title"])
            self.det_author.setText(f"Yazar: {book['author']}")
            stars = "⭐" * int(book.get("rating", 0))
            meta = f"<b>Tür:</b> {book['genre']}<br><b>Raf:</b> {book.get('shelf','Genel')}<br><b>Sayfa:</b> {book['pages']} Sayfa<br><b>Durum:</b> {book['status']}<br><b>Puan:</b> {stars}"
            self.det_meta.setText(meta)
            self.det_notes.setText(f"<b>Notlar:</b><br>{book['notes'] if book['notes'] else 'Not yok.'}")
            
            if book["status"] == "Okundu": self.book_progress_bar.setValue(100)
            elif book["status"] == "Okunuyor": self.book_progress_bar.setValue(50)
            else: self.book_progress_bar.setValue(0)
            
            if book.get("pdf_path"): self.pdf_btn.setText("📖 E-Kitabı Oku (PDF Aç)")
            else: self.pdf_btn.setText("🔗 PDF Bağla")

            if book.get("cover_path") and os.path.exists(book["cover_path"]):
                pix = QPixmap(book["cover_path"])
                self.det_cover.setPixmap(pix.scaled(self.det_cover.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
            else:
                self.det_cover.setText("Kapak Yok")
            self.toggle_details(True)

    def manage_or_open_pdf(self):
        if not self.selected_book_id: return
        book = next((b for b in self.model.books if b["id"] == self.selected_book_id), None)
        if book:
            if book.get("pdf_path") and os.path.exists(book["pdf_path"]):
                reader = PDFReaderDialog(book["pdf_path"])
                reader.exec()
            else:
                path, _ = QFileDialog.getOpenFileName(self, "Kitap PDF Dosyasını Seç", "", "PDF Belgeleri (*.pdf)")
                if path:
                    book["pdf_path"] = path
                    self.model.save_data()
                    self.pdf_btn.setText("📖 E-Kitabı Oku (PDF Aç)")
                    QMessageBox.information(self, "Başarılı", "PDF belgesi kitaba başarıyla bağlandı!")

    def add_new_book(self):
        dialog = BookDialog(self.model)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            new_book = {
                "id": str(uuid.uuid4()), "title": dialog.title_in.text(), "author": dialog.author_in.text(),
                "genre": dialog.genre_in.currentText(), "shelf": dialog.shelf_in.currentText(),
                "pages": dialog.pages_in.text(), "year": dialog.year_in.text(), "status": dialog.status_in.currentText(),
                "rating": dialog.rating_in.currentText(), "notes": dialog.notes_in.toPlainText(), "cover_path": dialog.cover_path,
                "is_favorite": (dialog.fav_in.currentText() == "Evet"), "pdf_path": ""
            }
            self.model.books.append(new_book)
            self.model.save_data()
            self.refresh_grid_view()
            self.update_statistics_display()

    def edit_selected_book(self):
        if not self.selected_book_id: return
        book = next((b for b in self.model.books if b["id"] == self.selected_book_id), None)
        if book:
            dialog = BookDialog(self.model, book)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                book["title"] = dialog.title_in.text()
                book["author"] = dialog.author_in.text()
                book["genre"] = dialog.genre_in.currentText()
                book["shelf"] = dialog.shelf_in.currentText()
                book["pages"] = dialog.pages_in.text()
                book["year"] = dialog.year_in.text()
                book["status"] = dialog.status_in.currentText()
                book["rating"] = dialog.rating_in.currentText()
                book["notes"] = dialog.notes_in.toPlainText()
                book["cover_path"] = dialog.cover_path
                book["is_favorite"] = (dialog.fav_in.currentText() == "Evet")
                self.model.save_data()
                self.refresh_grid_view()
                self.select_book_from_grid(self.selected_book_id)
                self.update_statistics_display()

    def delete_selected_book(self):
        if not self.selected_book_id: return
        confirm = QMessageBox.question(self, "Sil", "Bu kitabı silmek istediğinize emin misiniz?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm == QMessageBox.StandardButton.Yes:
            self.model.books = [b for b in self.model.books if b["id"] != self.selected_book_id]
            self.model.save_data()
            self.selected_book_id = None
            self.refresh_grid_view()
            self.toggle_details(False)
            self.update_statistics_display()

    def create_borrow_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        top_layout = QHBoxLayout()
        title = QLabel("🤝 Ödünç Verilen / Alınan Kitap Takip Geçmişi")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #3b82f6;")
        top_layout.addWidget(title)
        
        add_borrow_btn = QPushButton("Ödünç İşlemi Kaydet 📝")
        add_borrow_btn.clicked.connect(self.add_borrow_record)
        top_layout.addWidget(add_borrow_btn)
        layout.addLayout(top_layout)
        
        self.borrow_table = QTableWidget()
        self.borrow_table.setColumnCount(6)
        self.borrow_table.setHorizontalHeaderLabels(["Kitap Adı", "Kişi", "Tarih", "Saat", "Durum", "Eylem"])
        self.borrow_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.borrow_table)
        
        self.tabs.addTab(tab, "🤝 Ödünç Takibi")
        self.load_borrow_history()

    def load_borrow_history(self):
        self.borrow_table.setRowCount(0)
        for row, record in enumerate(self.model.borrow_history):
            self.borrow_table.insertRow(row)
            self.borrow_table.setItem(row, 0, QTableWidgetItem(record["book_title"]))
            self.borrow_table.setItem(row, 1, QTableWidgetItem(record["person"]))
            self.borrow_table.setItem(row, 2, QTableWidgetItem(record["date"]))
            self.borrow_table.setItem(row, 3, QTableWidgetItem(record["time"]))
            self.borrow_table.setItem(row, 4, QTableWidgetItem(record["status"]))
            
            del_btn = QPushButton("Kayıt Sil ❌")
            del_btn.setStyleSheet("background-color: #ef4444; font-size: 11px; padding: 2px;")
            del_btn.clicked.connect(lambda checked, r_id=record["id"]: self.delete_borrow_record(r_id))
            self.borrow_table.setCellWidget(row, 5, del_btn)

    def add_borrow_record(self):
        if not self.model.books:
            QMessageBox.warning(self, "Hata", "Ödünç kaydı açmak için kütüphanede en az bir kitap olmalı.")
            return
        titles = [b["title"] for b in self.model.books]
        book, ok1 = QInputDialog.getItem(self, "Kitap Seç", "Ödünç verilen kitap:", titles, 0, False)
        person, ok2 = QInputDialog.getText(self, "Kişi", "Kitabı kime verdiniz / kimden aldınız:")
        if ok1 and ok2 and person.strip():
            now = datetime.now()
            self.model.borrow_history.append({
                "id": str(uuid.uuid4()), "book_title": book, "person": person,
                "date": now.strftime("%Y-%m-%d"), "time": now.strftime("%H:%M"), "status": "Ödünç Verildi"
            })
            self.model.save_data()
            self.load_borrow_history()

    def delete_borrow_record(self, r_id):
        self.model.borrow_history = [r for r in self.model.borrow_history if r["id"] != r_id]
        self.model.save_data()
        self.load_borrow_history()

    # YENİ TAKVİM VE OKUMA GÜNLÜĞÜ SEKMESİ
    def create_calendar_tab(self):
        tab = QWidget()
        layout = QHBoxLayout(tab)
        
        # Sol taraf: Takvim
        self.calendar = QCalendarWidget()
        self.calendar.setGridVisible(True)
        self.calendar.selectionChanged.connect(self.show_calendar_note)
        layout.addWidget(self.calendar)
        
        # Sağ taraf: Günlük Notu Paneli
        right_p = QWidget()
        right_lay = QVBoxLayout(right_p)
        
        self.cal_title = QLabel("📅 Seçilen Günün Okuma Günlüğü")
        self.cal_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #a855f7;")
        right_lay.addWidget(self.cal_title)
        
        self.cal_note_display = QTextEdit()
        self.cal_note_display.setPlaceholderText("Bugün hangi kitabı okudunuz, kaç sayfa ilerlediniz? Buraya not alın...")
        right_lay.addWidget(self.cal_note_display)
        
        save_cal_btn = QPushButton("Günlüğü Kaydet 💾")
        save_cal_btn.setStyleSheet("background-color: #a855f7;")
        save_cal_btn.clicked.connect(self.save_calendar_note)
        right_lay.addWidget(save_cal_btn)
        
        layout.addWidget(right_p)
        self.tabs.addTab(tab, "📅 Okuma Takvimi")
        
        # İlk yüklemede bugünün notunu göster
        QTimer.singleShot(500, self.show_calendar_note)

    def show_calendar_note(self):
        date_str = self.calendar.selectedDate().toString("yyyy-MM-dd")
        # Eski veriler uyumluluğu için kütüphane modeli verisini kontrol edelim
        if not hasattr(self.model, 'calendar_notes'):
            self.model.calendar_notes = {}
        note = self.model.calendar_notes.get(date_str, "")
        self.cal_note_display.setPlainText(note)

    def save_calendar_note(self):
        date_str = self.calendar.selectedDate().toString("yyyy-MM-dd")
        if not hasattr(self.model, 'calendar_notes'):
            self.model.calendar_notes = {}
        self.model.calendar_notes[date_str] = self.cal_note_display.toPlainText()
        
        # models.py içindeki save_data fonksiyonunun kaydetmesi için modeli güncelleyelim
        # Özelleştirilmiş bir json kaydetme mekanizması ekleyelim ki patlamasın
        try:
            self.model.save_data()
            # Modelle beraber custom alanları da dosyaya yazalım
            with open("library_data.json", "r", encoding="utf-8") as f:
                current_data = json.load(f)
            current_data["calendar_notes"] = self.model.calendar_notes
            with open("library_data.json", "w", encoding="utf-8") as f:
                json.dump(current_data, f, ensure_ascii=False, indent=4)
            
            QMessageBox.information(self, "Başarılı", "Okuma günlüğünüz takvime işlendi!")
        except Exception as e:
            QMessageBox.critical(self, "Hata", f"Kaydedilemedi: {e}")

    def create_memories_tab(self):
        tab = QWidget()
        layout = QHBoxLayout(tab)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        left_p = QWidget()
        left_lay = QVBoxLayout(left_p)
        self.mem_list = QListWidget()
        self.mem_list.itemSelectionChanged.connect(self.display_memory_details)
        left_lay.addWidget(self.mem_list)
        
        add_mem_btn = QPushButton("Yeni Bir Hatıra/Not Ekle ✍️")
        add_mem_btn.setStyleSheet("background-color: #8b5cf6;")
        add_mem_btn.clicked.connect(self.add_new_memory)
        left_lay.addWidget(add_mem_btn)
        splitter.addWidget(left_p)
        
        self.right_p = QWidget()
        right_lay = QVBoxLayout(self.right_p)
        self.right_p.setStyleSheet("background-color: rgba(15, 23, 42, 0.7); border-radius: 8px; padding: 15px;")
        
        self.mem_title = QLabel("Not veya Hatıra Seçilmedi")
        self.mem_title.setStyleSheet("font-size: 20px; font-weight: bold; color: #a78bfa;")
        right_lay.addWidget(self.mem_title)
        
        self.mem_date = QLabel("")
        self.mem_date.setStyleSheet("color: #64748b; font-style: italic; margin-bottom: 10px;")
        right_lay.addWidget(self.mem_date)
        
        self.mem_content = QLabel("")
        self.mem_content.setWordWrap(True)
        self.mem_content.setStyleSheet("font-size: 14px; color: #e2e8f0; background: #0f172a; padding: 12px; border-radius: 6px; border: 1px solid #334155;")
        right_lay.addWidget(self.mem_content)
        
        self.del_mem_btn = QPushButton("Bu Notu Sil 🗑️")
        self.del_mem_btn.setStyleSheet("background-color: #ef4444;")
        self.del_mem_btn.clicked.connect(self.delete_selected_memory)
        right_lay.addWidget(self.del_mem_btn)
        
        splitter.addWidget(self.right_p)
        layout.addWidget(splitter)
        self.tabs.addTab(tab, "✍️ Hatıra Defteri")
        self.load_memories_list()
        self.mem_content.setVisible(False)
        self.del_mem_btn.setVisible(False)

    def load_memories_list(self):
        self.mem_list.clear()
        for m in self.model.memories:
            item = QListWidgetItem(f"✍️ {m['title']} ({m['date']})")
            item.setData(Qt.ItemDataRole.UserRole, m["id"])
            self.mem_list.addItem(item)

    def display_memory_details(self):
        items = self.mem_list.selectedItems()
        if not items:
            self.mem_title.setText("Not veya Hatıra Seçilmedi")
            self.mem_date.setText("")
            self.mem_content.setVisible(False)
            self.del_mem_btn.setVisible(False)
            return
        m_id = items[0].data(Qt.ItemDataRole.UserRole)
        mem = next((m for m in self.model.memories if m["id"] == m_id), None)
        if mem:
            self.mem_title.setText(mem["title"])
            self.mem_date.setText(f"Kayıt Tarihi: {mem['date']}")
            self.mem_content.setText(mem["content"])
            self.mem_content.setVisible(True)
            self.del_mem_btn.setVisible(True)

    def add_new_memory(self):
        title, ok1 = QInputDialog.getText(self, "Başlık", "Not/Hatıra Başlığı:")
        content, ok2 = QInputDialog.getMultiLineText(self, "İçerik", "Not içeriği:")
        if ok1 and ok2 and title.strip():
            self.model.memories.append({
                "id": str(uuid.uuid4()), "title": title, "content": content, "date": datetime.now().strftime("%Y-%m-%d")
            })
            self.model.save_data()
            self.load_memories_list()

    def delete_selected_memory(self):
        items = self.mem_list.selectedItems()
        if not items: return
        m_id = items[0].data(Qt.ItemDataRole.UserRole)
        self.model.memories = [m for m in self.model.memories if m["id"] != m_id]
        self.model.save_data()
        self.load_memories_list()
        self.display_memory_details()

    def create_settings_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        form_layout = QFormLayout()
        
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(list(THEMES.keys()))
        self.theme_combo.setCurrentText(self.model.theme)
        self.theme_combo.currentTextChanged.connect(self.change_theme)
        form_layout.addRow("Arayüz Teması:", self.theme_combo)
        
        shelf_lay = QHBoxLayout()
        self.settings_shelf_combo = QComboBox()
        self.settings_shelf_combo.addItems(self.model.shelves)
        add_shelf = QPushButton("Raf Ekle 📁")
        add_shelf.clicked.connect(self.add_custom_shelf)
        del_shelf = QPushButton("Raf Sil 🗑️")
        del_shelf.setStyleSheet("background-color:#ef4444;")
        del_shelf.clicked.connect(self.delete_custom_shelf)
        shelf_lay.addWidget(self.settings_shelf_combo)
        shelf_lay.addWidget(add_shelf)
        shelf_lay.addWidget(del_shelf)
        form_layout.addRow("Kitap Rafı Düzenle:", shelf_lay)
        
        genre_lay = QHBoxLayout()
        self.settings_genre_combo = QComboBox()
        self.settings_genre_combo.addItems(self.model.genres)
        add_genre = QPushButton("Tür Ekle 🏷️")
        add_genre.clicked.connect(self.add_custom_genre)
        del_genre = QPushButton("Tür Sil 🗑️")
        del_genre.setStyleSheet("background-color:#ef4444;")
        del_genre.clicked.connect(self.delete_custom_genre)
        genre_lay.addWidget(self.settings_genre_combo)
        genre_lay.addWidget(add_genre)
        genre_lay.addWidget(del_genre)
        form_layout.addRow("Kategori/Tür Düzenle:", genre_lay)
        
        target_lay = QHBoxLayout()
        self.target_btn = QPushButton("Yıllık Kitap Hedefini Belirle 🎯")
        self.target_btn.clicked.connect(self.change_yearly_target)
        target_lay.addWidget(self.target_btn)
        form_layout.addRow("Okuma Meydan Okuması (Challenge):", target_lay)
        
        backup_lay = QHBoxLayout()
        export_btn = QPushButton("Kütüphaneyi Dışa Aktar (Yedekle) 📤")
        export_btn.setStyleSheet("background-color: #2563eb;")
        export_btn.clicked.connect(self.export_data)
        import_btn = QPushButton("Yedekten İçe Aktar (Geri Yükle) 📥")
        import_btn.setStyleSheet("background-color: #db2777;")
        import_btn.clicked.connect(self.import_data)
        backup_lay.addWidget(export_btn)
        backup_lay.addWidget(import_btn)
        form_layout.addRow("Veri Yedekleme / Ambar:", backup_lay)
        
        self.pass_btn = QPushButton("Güvenlik Duvarı Şifresini Değiştir 🔐")
        self.pass_btn.clicked.connect(self.change_security_password)
        form_layout.addRow("Güvenlik Sistemi:", self.pass_btn)
        
        self.stats_box = QLabel()
        self.stats_box.setStyleSheet("background-color: rgba(15, 23, 42, 0.8); padding: 15px; border-radius: 8px; font-family: 'Courier New'; font-size: 13px; border: 1px solid #334155;")
        form_layout.addRow("📊 Canlı Kütüphane İstatistikleri:", self.stats_box)
        
        layout.addLayout(form_layout)
        self.tabs.addTab(tab, "⚙️ Kontrol Paneli")
        
        # Dosyadan takvim notları yüklemesi (Uyum kalkanı)
        try:
            if os.path.exists("library_data.json"):
                with open("library_data.json", "r", encoding="utf-8") as f:
                    d = json.load(f)
                    self.model.calendar_notes = d.get("calendar_notes", {})
        except:
            self.model.calendar_notes = {}
            
        self.update_statistics_display()

    def change_theme(self, t_name):
        self.model.theme = t_name
        self.model.save_data()
        self.update_theme_style()

    def change_yearly_target(self):
        target, ok = QInputDialog.getInt(self, "Hedef Belirle", "Bu yıl kaç kitap okumak istiyorsunuz?:", self.model.yearly_target, 1, 365, 1)
        if ok:
            self.model.yearly_target = target
            self.model.save_data()
            self.update_statistics_display()

    def add_custom_shelf(self):
        name, ok = QInputDialog.getText(self, "Yeni Raf", "Raf Adı:")
        if ok and name.strip() and name not in self.model.shelves:
            self.model.shelves.append(name)
            self.model.save_data()
            self.refresh_combos()

    def delete_custom_shelf(self):
        sh = self.settings_shelf_combo.currentText()
        if len(self.model.shelves) > 1:
            self.model.shelves.remove(sh)
            self.model.save_data()
            self.refresh_combos()

    def add_custom_genre(self):
        name, ok = QInputDialog.getText(self, "Yeni Tür", "Kategori/Tür Adı:")
        if ok and name.strip() and name not in self.model.genres:
            self.model.genres.append(name)
            self.model.save_data()
            self.refresh_combos()

    def delete_custom_genre(self):
        g = self.settings_genre_combo.currentText()
        if len(self.model.genres) > 1:
            self.model.genres.remove(g)
            self.model.save_data()
            self.refresh_combos()

    def refresh_combos(self):
        self.settings_shelf_combo.clear()
        self.settings_shelf_combo.addItems(self.model.shelves)
        self.filter_shelf.clear()
        self.filter_shelf.addItems(["Tüm Raflar"] + self.model.shelves)
        self.settings_genre_combo.clear()
        self.settings_genre_combo.addItems(self.model.genres)

    def export_data(self):
        path, _ = QFileDialog.getSaveFileName(self, "Yedek Dosyası Kaydet", "kutuphane_yedek.json", "JSON Dosyaları (*.json)")
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    json.dump({
                        "books": self.model.books, "shelves": self.model.shelves, "genres": self.model.genres,
                        "borrow_history": self.model.borrow_history, "memories": self.model.memories, 
                        "yearly_target": self.model.yearly_target, "calendar_notes": self.model.calendar_notes
                    }, f, ensure_ascii=False, indent=4)
                QMessageBox.information(self, "Başarılı", "Veriler başarıyla dışa aktarıldı!")
            except Exception as e:
                QMessageBox.critical(self, "Hata", f"Dışa aktarma başarısız: {e}")

    def import_data(self):
        path, _ = QFileDialog.getOpenFileName(self, "Yedek Dosyası Seç", "", "JSON Dosyaları (*.json)")
        if path:
            try:
                with open(path, "r", encoding="utf-8") as f: data = json.load(f)
                self.model.books = data.get("books", self.model.books)
                self.model.shelves = data.get("shelves", self.model.shelves)
                self.model.genres = data.get("genres", self.model.genres)
                self.model.borrow_history = data.get("borrow_history", self.model.borrow_history)
                self.model.memories = data.get("memories", self.model.memories)
                self.model.yearly_target = data.get("yearly_target", self.model.yearly_target)
                self.model.calendar_notes = data.get("calendar_notes", {})
                self.model.save_data()
                self.refresh_combos()
                self.refresh_grid_view()
                self.update_statistics_display()
                QMessageBox.information(self, "Başarılı", "Yedek başarıyla yüklendi!")
            except Exception as e:
                QMessageBox.critical(self, "Hata", f"Yükleme başarısız: {e}")

    def change_security_password(self):
        p, ok = QInputDialog.getText(self, "Şifre", "Yeni giriş şifreniz (Kaldırmak için boş bırakın):", QLineEdit.EchoMode.Password)
        if ok:
            self.model.set_password(p)
            QMessageBox.information(self, "Başarılı", "Şifre güncellendi!")

    def update_statistics_display(self):
        tot = len(self.model.books)
        read = len([b for b in self.model.books if b["status"] == "Okundu"])
        reading = len([b for b in self.model.books if b["status"] == "Okunuyor"])
        pages = sum(int(b["pages"]) for b in self.model.books if b["pages"].isdigit())
        target_percent = min(100, int((read / self.model.yearly_target) * 100)) if self.model.yearly_target > 0 else 0
        
        self.stats_box.setText(
            f"📋 Toplam Kitap: {tot} Adet | ✅ Okunan: {read} Adet\n"
            f"⏳ Okunuyor: {reading} Adet | 📑 Toplam Sayfa: {pages} Sayfa\n"
            f"🎯 Yıllık Hedef: {read}/{self.model.yearly_target} Kitap | 📈 Challenge İlerlemesi: %{target_percent}"
        )

if __name__ == "__main__":
    app = QApplication(sys.argv)
    m = AdvancedLibraryModel()
    if m.password_hash:
        login = LoginDialog(m)
        if login.exec() != QDialog.DialogCode.Accepted: sys.exit()
    w = MainWindow()
    w.show()
    sys.exit(app.exec())