import json
import os
import bcrypt

DATA_FILE = "advanced_library_data.json"

class AdvancedLibraryModel:
    def __init__(self):
        self.books = []
        self.shelves = ["Genel", "Favoriler", "Okuma Odası"]
        self.genres = ["Roman", "Bilim Kurgu", "Tarih", "Felsefe", "Yazılım/Teknoloji"]
        self.borrow_history = []
        self.memories = []
        self.password_hash = ""
        self.theme = "Karanlık Siber (Neon Mavi)"
        self.yearly_target = 12  # Varsayılan yıllık kitap okuma hedefi
        self.load_data()

    def load_data(self):
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.books = data.get("books", [])
                    self.shelves = data.get("shelves", self.shelves)
                    self.genres = data.get("genres", self.genres)
                    self.borrow_history = data.get("borrow_history", [])
                    self.memories = data.get("memories", [])
                    self.password_hash = data.get("password_hash", "")
                    self.theme = data.get("theme", "Karanlık Siber (Neon Mavi)")
                    self.yearly_target = data.get("yearly_target", 12)
            except Exception as e:
                print("Veri yükleme hatası:", e)

    def save_data(self):
        try:
            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump({
                    "books": self.books,
                    "shelves": self.shelves,
                    "genres": self.genres,
                    "borrow_history": self.borrow_history,
                    "memories": self.memories,
                    "password_hash": self.password_hash,
                    "theme": self.theme,
                    "yearly_target": self.yearly_target
                }, f, ensure_ascii=False, indent=4)
        except Exception as e:
            print("Veri kaydetme hatası:", e)

    def set_password(self, plain_password):
        if plain_password == "":
            self.password_hash = ""
        else:
            salt = bcrypt.gensalt()
            self.password_hash = bcrypt.hashpw(plain_password.encode('utf-8'), salt).decode('utf-8')
        self.save_data()

    def check_password(self, plain_password):
        if not self.password_hash:
            return True
        return bcrypt.checkpw(plain_password.encode('utf-8'), self.password_hash.encode('utf-8'))