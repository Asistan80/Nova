let categories = JSON.parse(localStorage.getItem('cozy_pro_categories')) || [
    { id: 'doga', name: '🌿 Doğa Sesleri', gradClass: 'grad-mint' },
    { id: 'mekan', name: '☕ Mekan Sesleri', gradClass: 'grad-peach' },
    { id: 'scifi', name: '🚀 Sci-Fi / Oyun', gradClass: 'grad-purple' }
];

let savedPresets = JSON.parse(localStorage.getItem('cozy_pro_presets')) || {};

const loadedAudios = {};
let masterVolume = 0.8;
let timerInterval = null;
let audioCtx, masterGain, bassFilter, trebleFilter;

// WEB AUDIO API INITIALIZATION (EQ & Pitch Altyapısı)
function initAudioContext() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        masterGain = audioCtx.createGain();

        bassFilter = audioCtx.createBiquadFilter();
        bassFilter.type = 'lowshelf';
        bassFilter.frequency.value = 200;

        trebleFilter = audioCtx.createBiquadFilter();
        trebleFilter.type = 'highshelf';
        trebleFilter.frequency.value = 3000;

        bassFilter.connect(trebleFilter);
        trebleFilter.connect(masterGain);
        masterGain.connect(audioCtx.destination);
    }
}

// ARKA PLAN GÖRSEL PARÇACIKLARI
const pCanvas = document.getElementById('particleCanvas');
const pCtx = pCanvas.getContext('2d');
let particles = [];

function initParticles() {
    pCanvas.width = window.innerWidth;
    pCanvas.height = window.innerHeight;
    particles = [];
    for (let i = 0; i < 45; i++) {
        particles.push({
            x: Math.random() * pCanvas.width,
            y: Math.random() * pCanvas.height,
            r: Math.random() * 3 + 1,
            speedY: Math.random() * 0.4 + 0.1,
            opacity: Math.random() * 0.5 + 0.2
        });
    }
}

function animateParticles() {
    pCtx.clearRect(0, 0, pCanvas.width, pCanvas.height);
    particles.forEach(p => {
        p.y -= p.speedY;
        if (p.y < 0) p.y = pCanvas.height;

        pCtx.beginPath();
        pCtx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        pCtx.fillStyle = `rgba(255, 255, 255, ${p.opacity})`;
        pCtx.fill();
    });
    requestAnimationFrame(animateParticles);
}
window.addEventListener('resize', initParticles);
initParticles();
animateParticles();

// VISUALIZER
const canvas = document.getElementById('visualizerCanvas');
const ctx = canvas.getContext('2d');
let hueOffset = 0;

function drawRainbowVisualizer() {
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    let isPlaying = Object.values(loadedAudios).some(item => !item.audio.paused && item.audio.volume > 0);
    const bars = 50;
    const barWidth = canvas.width / bars;

    hueOffset += 1;

    for (let i = 0; i < bars; i++) {
        let barHeight = isPlaying ? Math.random() * (canvas.height * 0.8) + 4 : 3;
        const barHue = (i * 7 + hueOffset) % 360;
        ctx.fillStyle = `hsl(${barHue}, 90%, 65%)`;
        ctx.fillRect(i * barWidth, canvas.height - barHeight, barWidth - 2, barHeight);
    }
}
setInterval(drawRainbowVisualizer, 60);

const { ipcRenderer } = require('electron');

// PENCERE KONTROLLERİ
document.getElementById('closeBtn').addEventListener('click', () => {
    ipcRenderer.send('window-close');
});

document.getElementById('minBtn').addEventListener('click', () => {
    ipcRenderer.send('window-min');
});

let isPinned = false;
document.getElementById('pinBtn').addEventListener('click', (e) => {
    isPinned = !isPinned;
    e.target.classList.toggle('active', isPinned);
    ipcRenderer.send('window-pin', isPinned);
});

// EKOLAYZIR & PITCH AYARLARI
document.getElementById('eqBass').addEventListener('input', (e) => {
    initAudioContext();
    bassFilter.gain.value = parseFloat(e.target.value);
});

document.getElementById('eqTreble').addEventListener('input', (e) => {
    initAudioContext();
    trebleFilter.gain.value = parseFloat(e.target.value);
});

document.getElementById('globalPitch').addEventListener('input', (e) => {
    const pitchVal = parseFloat(e.target.value);
    Object.values(loadedAudios).forEach(item => {
        item.audio.playbackRate = pitchVal; // Ses inceltme / kalınlaştırma
    });
});

// RASTGELE ATMOSFER (RANDOMIZER)
document.getElementById('randomMixBtn').addEventListener('click', () => {
    Object.keys(loadedAudios).forEach(id => {
        const item = loadedAudios[id];
        const randomVol = Math.random() > 0.4 ? (Math.random() * 0.7 + 0.1).toFixed(2) : 0;
        
        item.audio.volume = randomVol * masterVolume;
        const slider = document.getElementById(`slider_${id}`);
        if (slider) slider.value = randomVol;

        const box = document.getElementById(`box_${id}`);
        if (randomVol > 0) {
            if (item.audio.paused) item.audio.play();
            if (box) box.classList.add('playing');
        } else {
            item.audio.pause();
            if (box) box.classList.remove('playing');
        }
    });
});

// SES EKLEME VE YÖNETİMİ
function addSoundToUI(id, title, categoryId, icon) {
    const listEl = document.getElementById(`list-${categoryId}`);
    if (!listEl) return;

    const box = document.createElement('div');
    box.className = 'sound-item-box';
    box.id = `box_${id}`;
    box.innerHTML = `
        <div class="sound-controls-row">
            <span>${icon} ${title}</span>
            <div class="sound-action-btns">
                <button class="btn-mini" onclick="toggleSolo('${id}')">S</button>
                <button class="btn-mini" onclick="toggleMute('${id}')">M</button>
                <button class="small-btn red-btn" onclick="removeSound('${id}')">✕</button>
            </div>
        </div>
        <div style="display:flex; align-items:center; gap:8px;">
            <input type="range" class="horizontal-slider" id="slider_${id}" min="0" max="1" step="0.01" value="0">
            <input type="range" class="pan-slider" id="pan_${id}" min="-1" max="1" step="0.1" value="0" title="Sol / Sağ Kulaklık">
        </div>
    `;

    const slider = box.querySelector(`#slider_${id}`);
    slider.addEventListener('input', (e) => {
        initAudioContext();
        const val = parseFloat(e.target.value);
        const item = loadedAudios[id];

        if (val > 0) {
            item.audio.volume = val * masterVolume;
            if (item.audio.paused) item.audio.play();
            box.classList.add('playing');
        } else {
            item.audio.volume = 0;
            item.audio.pause();
            box.classList.remove('playing');
        }
    });

    listEl.appendChild(box);
}

function toggleMute(id) {
    const item = loadedAudios[id];
    if (item) {
        item.audio.muted = !item.audio.muted;
    }
}

function toggleSolo(id) {
    Object.keys(loadedAudios).forEach(key => {
        if (key !== id) {
            loadedAudios[key].audio.volume = 0;
            const slider = document.getElementById(`slider_${key}`);
            if (slider) slider.value = 0;
        }
    });
}

// KLAVYE KISAYOLLARI (HOTKEYS)
document.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
        e.preventDefault();
        document.getElementById('stopAllBtn').click();
    }
});

// TEMA / RENDER DİĞER FONKSİYONLAR
const mainContainer = document.getElementById('mainContainer');
document.getElementById('themeToggleBtn').addEventListener('click', () => {
    const panel = document.getElementById('themePanel');
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
});

function setPanelMode(m) { mainContainer.className = `main-container ${m} border-neon`; }
function setBorderMode(b) { mainContainer.className = `main-container panel-grad-loop ${b}`; }

// RENDER & INITIALIZE
function renderStudio() {
    const categoryGrid = document.getElementById('categoryGrid');
    const modalCategorySelect = document.getElementById('modalCategorySelect');
    categoryGrid.innerHTML = '';
    modalCategorySelect.innerHTML = '';

    categories.forEach(cat => {
        const card = document.createElement('div');
        card.className = `category-card ${cat.gradClass || 'grad-mint'}`;
        card.innerHTML = `
            <div class="category-header">
                <span>${cat.name}</span>
                <button class="small-btn red-btn" onclick="removeCategory('${cat.id}')">✕</button>
            </div>
            <div class="sound-list" id="list-${cat.id}"></div>
        `;
        categoryGrid.appendChild(card);

        const opt = document.createElement('option');
        opt.value = cat.id;
        opt.innerText = cat.name;
        modalCategorySelect.appendChild(opt);
    });

    const newOpt = document.createElement('option');
    newOpt.value = 'NEW_CATEGORY';
    newOpt.innerText = '➕ [Yeni Kategori Ekle]';
    modalCategorySelect.appendChild(newOpt);
}

// MODAL VE FORM
document.getElementById('openModalBtn').addEventListener('click', () => document.getElementById('addSoundModal').style.display = 'flex');
document.getElementById('closeModalBtn').addEventListener('click', () => document.getElementById('addSoundModal').style.display = 'none');

document.getElementById('addSoundForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const fileInput = document.getElementById('modalFileInput');
    const title = document.getElementById('modalTitleInput').value.trim();
    let categoryId = document.getElementById('modalCategorySelect').value;
    const icon = document.getElementById('modalIconInput').value.trim() || '🎵';

    if (fileInput.files.length === 0) return;

    const file = fileInput.files[0];
    const id = 'sound_' + Date.now();
    const objectUrl = URL.createObjectURL(file);

    const audio = new Audio(objectUrl);
    audio.loop = true;

    loadedAudios[id] = { audio: audio };
    addSoundToUI(id, title, categoryId, icon);

    document.getElementById('addSoundModal').style.display = 'none';
    if (typeof confetti === 'function') confetti({ particleCount: 50, spread: 60 });
});

document.getElementById('stopAllBtn').addEventListener('click', () => {
    Object.keys(loadedAudios).forEach(id => {
        loadedAudios[id].audio.pause();
        loadedAudios[id].audio.volume = 0;
        const slider = document.getElementById(`slider_${id}`);
        if (slider) slider.value = 0;
        const box = document.getElementById(`box_${id}`);
        if (box) box.classList.remove('playing');
    });
});

renderStudio();