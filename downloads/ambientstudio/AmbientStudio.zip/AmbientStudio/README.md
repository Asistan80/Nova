\# 🎧 Cozy Ambient Soundscape \& Focus Studio v1.0 Ultra



> \*\*Oyun geliştiricileri, yazılımcılar ve odaklanmak isteyenler için tasarlanmış 3D Atmosferik Ses Mikseri \& Özelleştirilebilir Arayüz Konsolu.\*\*



!\[Cozy Studio Banner](https://raw.githubusercontent.com/placeholder-banner.png)



\---



\## ✨ Öne Çıkan Özellikler



\- \*\*🎨 Dinamik Arayüz \& Çerçeve Stüdyosu:\*\* 

&#x20; - Özel 2'li renk seçici (Color Picker) ile kendi gradyan arka planını oluşturma.

&#x20; - \*Neon Cyberpunk\*, \*Akan Gökkuşağı\*, \*Altın Varak\* ve \*Noktalı Soft\* çerçeve modelleri.

\- \*\*🎛️ Gelişmiş Mikser \& Ses Kontrolleri:\*\*

&#x20; - Kategori bazlı sürükle-bırak ses yönetimi.

&#x20; - Her kanal için bağımsız \*\*Solo (S)\*\*, \*\*Mute (M)\*\* ve \*\*Sol/Sağ Kulaklık (Pan)\*\* dengesi.

&#x20; - Pitch \& Frekans değiştirici ile sesleri kalınlaştırma veya inceltme.

\- \*\*🎲 Randomizer (Sürpriz Atmosfer):\*\* Tek tıkla rastgele kanalları ve ses seviyelerini harmanlayarak anında benzersiz ortam sesleri üretme.

\- \*\*⏱️ Pomodoro \& Fade-Out Zamanlayıcı:\*\* Odaklanma sürelerinizi yönetin. Süre biterken sesler aniden kesilmez, son 10 saniyede yavaşça kısılarak (Uyku Modu) kapanır.

\- \*\*🌈 Canlı Renkli Visualizer:\*\* Çalan seslerin frekansına göre dinamik renk değiştiren alt görselleştirici.

\- \*\*🎹 Klavye Kısayolları (Hotkeys):\*\* `Space` tuşu ile tüm sesleri anında durdurma ve başlatma.



\---



\## 🛠️ Teknolojiler



\- \*\*Frontend:\*\* HTML5, CSS3, JavaScript (ES6+)

\- \*\*Audio Engine:\*\* Web Audio API \& HTML5 Audio

\- \*\*Desktop Framework:\*\* Electron.js

\- \*\*Icons \& Effects:\*\* Canvas Confetti, Google Fonts



\---



\## 🚀 Kurulum ve Çalıştırma



\### Web Üzerinde Çalıştırma

Sadece `index.html` dosyasını herhangi bir modern tarayıcıda açmanız yeterlidir.



\### Masaüstü Uygulaması Olarak Derleme (.exe)



```bash

\# Projeyi klonlayın

git clone \[https://github.com/KULLANICI\_ADI/cozy-soundscape-studio.git](https://github.com/KULLANICI\_ADI/cozy-soundscape-studio.git)



\# Proje klasörüne gidin

cd cozy-soundscape-studio



\# Gerekli paketleri yükleyin

npm install



\# Masaüstü uygulamasını (.exe) derleyin

npm run build

