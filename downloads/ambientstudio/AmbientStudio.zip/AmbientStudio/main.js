const { app, BrowserWindow, ipcMain } = require('electron');

// Windows şeffaflık hatasını/siyahlığını çözen kritik ayarlar
app.commandLine.appendSwitch('enable-transparent-visuals');
app.disableHardwareAcceleration(); // Siyah kutu kalmasını engeller

let mainWindow;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1080,
        height: 780,
        minWidth: 900,
        minHeight: 650,
        frame: false,
        transparent: true,
        backgroundColor: '#00000000',
        resizable: true,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        }
    });

    mainWindow.loadFile('index.html');

    mainWindow.on('closed', function () {
        mainWindow = null;
    });
}

// IPC KONTROLLERİ
ipcMain.on('window-min', () => {
    if (mainWindow) mainWindow.minimize();
});

ipcMain.on('window-close', () => {
    if (mainWindow) mainWindow.close();
});

ipcMain.on('window-pin', (event, isPinned) => {
    if (mainWindow) mainWindow.setAlwaysOnTop(isPinned);
});

app.whenReady().then(() => {
    // Şeffaflık işleminin oturması için minik bir gecikme
    setTimeout(createWindow, 100);
});

app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') app.quit();
});

app.on('activate', function () {
    if (mainWindow === null) createWindow();
});