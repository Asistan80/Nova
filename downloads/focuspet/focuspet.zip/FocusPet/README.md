\# 🐉 FocusPet RPG - Masaüstü Odaklanma Canavarı



Masaüstünüzün köşesinde yaşayan, siz işlerinize veya kitaplarınıza odaklandıkça büyüyen, evrim geçiren ve sizinle iletişim kuran retro piksel bir sanal bebek / Pomodoro uygulaması.



\## ✨ Özellikler



\- \*\*Şeffaf \& Katmanlı Arayüz:\*\* Masaüstünde pencerelerin en üstünde durur, arka planı tamamen şeffaftır ve istediğiniz yere sürüklenebilir.

\- \*\*25 Dakikalık Pomodoro Sayacı:\*\* Odaklanma seanslarınızı yönetmenizi sağlar.

\- \*\*RPG Evrim Sistemi:\*\* 

&#x20; - `Seviye 1:` Yumurta 🥚

&#x20; - `Seviye 2:` Bebek Ejderha 🐣 \*(İlk odaklanma bittiğinde çatlama garantili!)\*

&#x20; - `Seviye 3:` Genç Ejderha 🦎

&#x20; - `Seviye 4+:` Kadim Ejderha 🐉

\- \*\*Dinamik Konuşma Balonu:\*\* Ejderhanız o anki açlık, seans veya evrim durumuna göre gerçek zamanlı konuşur ve sizi motive eder.

\- \*\*Açlık \& Bakım Mekaniği:\*\* Zamanla acıkır, odaklanma tamamladıkça kazandığınız puanlarla onu besleyebilirsiniz.

\- \*\*Otomatic Kayıt:\*\* Programı kapatsanız dahi verileriniz `pet\_data.json` dosyasına kaydedilir ve kaldığınız yerden devam eder.



\## 🚀 Kurulum ve Çalıştırma



Projenin bilgisayarınızda çalışması için bilgisayarınızda \*\*Python\*\* kurulu olmalıdır.



1\. Bu depoyu (repository) bilgisayarınıza indirin.

2\. Klasörün içinde bir terminal/komut satırı (CMD) açın.

3\. Gerekli arayüz eklentisini yüklemek için şu komutu çalıştırın:

&#x20;  ```bash

&#x20;  pip install PyQt6

