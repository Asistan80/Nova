import sys
import os
import math
import json
import random
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QProgressBar
from PyQt6.QtCore import Qt, QTimer, QPoint

DATA_FILE = "pet_data.json"

class FocusPetApp(QWidget):
    def __init__(self):
        super().__init__()
        self.time_left = 25 * 60  
        self.timer_running = False
        self.animation_step = 0
        
        self.load_game_data()
        self.init_ui()
        
    def load_game_data(self):
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r") as f:
                    data = json.load(f)
                    self.level = data.get("level", 1)
                    self.xp = data.get("xp", 0)
                    self.hunger = data.get("hunger", 100)
            except:
                self.set_default_data()
        else:
            self.set_default_data()
            
    def set_default_data(self):
        self.level = 1
        self.xp = 0
        self.hunger = 100
        
    def save_game_data(self):
        data = {"level": self.level, "xp": self.xp, "hunger": self.hunger}
        with open(DATA_FILE, "w") as f:
            json.dump(data, f)

    def get_pet_avatar(self):
        if self.hunger < 20: return "🥺"
        if self.level == 1: return "🥚"
        elif self.level == 2: return "🐣"
        elif self.level == 3: return "🦎"
        else: return "🐉"

    def get_xp_needed(self):
        return self.level * 100

    def get_pet_speech(self):
        if self.hunger < 20:
            return random.choice(["Çok açım... 🍗", "Enerjim tükeniyor... 💤"])
        if self.timer_running:
            return random.choice(["Harika gidiyorsun! 🔥", "Derin odaklanma modu... 📚", "Birlikte başaracağız! ✨"])
        
        if self.level == 1:
            return "Tık... Tık... İçeride biri var mı? 🥚"
        elif self.level == 2:
            return "Dünya çok büyükmüş! 🐣"
        elif self.level == 3:
            return "Kanatlarım mı çıkıyor ne? 🦎"
        else:
            return "Kütüphanenin kadim koruyucusuyum! 🐉"

    def init_ui(self):
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.SubWindow)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(260, 400)
        
        screen = QApplication.primaryScreen().geometry()
        self.move(screen.width() - 290, screen.height() - 460)
        
        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Üst Bilgi Barı
        self.info_label = QLabel(f"Lv. {self.level} Ejderha", self)
        self.info_label.setStyleSheet("color: #c084fc; font-weight: bold; font-family: 'Courier New'; font-size: 14px; background: rgba(15, 23, 42, 0.85); border-radius: 8px; padding: 4px 10px;")
        self.info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.info_label)

        # Ejderha Konuşma Balonu
        self.speech_label = QLabel(self.get_pet_speech(), self)
        self.speech_label.setStyleSheet("color: #f1f5f9; font-size: 11px; font-family: 'Courier New'; background: rgba(30, 41, 59, 0.9); border: 1px solid #475569; border-radius: 6px; padding: 6px; margin-top: 5px;")
        self.speech_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.speech_label.setWordWrap(True)
        layout.addWidget(self.speech_label)
        
        # Karakter Alanı
        self.pet_label = QLabel(self.get_pet_avatar(), self)
        self.pet_label.setStyleSheet("font-size: 75px; margin: 5px;")
        self.pet_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.pet_label)
        
        # Durum Göstergeleri
        self.stats_label = QLabel(f"🍖 Açlık: %{int(self.hunger)}", self)
        self.stats_label.setStyleSheet("color: #f97316; font-size: 11px; font-weight: bold; font-family: 'Courier New'; background: rgba(15, 23, 42, 0.7); border-radius: 5px; padding: 2px;")
        self.stats_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.stats_label)
        
        # XP İlerleme Çubuğu
        self.xp_bar = QProgressBar(self)
        self.xp_bar.setMaximum(self.get_xp_needed())
        self.xp_bar.setValue(self.xp)
        self.xp_bar.setTextVisible(False)
        self.xp_bar.setStyleSheet("""
            QProgressBar { background-color: rgba(15, 23, 42, 0.8); border-radius: 4px; max-height: 6px; }
            QProgressBar::chunk { background-color: #3b82f6; border-radius: 4px; }
        """)
        layout.addWidget(self.xp_bar)
        
        # Sayaç Yazısı
        self.time_label = QLabel("25:00", self)
        self.time_label.setStyleSheet("color: #22c55e; font-size: 26px; font-weight: bold; font-family: 'Courier New'; background: rgba(15, 23, 42, 0.85); border-radius: 8px; padding: 2px 12px; margin-top: 5px;")
        self.time_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.time_label)
        
        # Kontrol Butonları
        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("ODAKLAN", self)
        self.start_btn.setStyleSheet("background-color: #22c55e; color: white; font-weight: bold; border-radius: 5px; padding: 6px; font-family: 'Courier New';")
        self.start_btn.clicked.connect(self.toggle_timer)
        
        self.feed_btn = QPushButton("BESLE 🍖", self)
        self.feed_btn.setStyleSheet("background-color: #f97316; color: white; font-weight: bold; border-radius: 5px; padding: 6px; font-family: 'Courier New';")
        self.feed_btn.clicked.connect(self.feed_pet)
        
        self.close_btn = QPushButton("❌", self)
        self.close_btn.setStyleSheet("background-color: #ef4444; color: white; font-weight: bold; border-radius: 5px; padding: 6px; max-width: 30px;")
        self.close_btn.clicked.connect(self.close)
        
        btn_layout.addWidget(self.start_btn)
        btn_layout.addWidget(self.feed_btn)
        btn_layout.addWidget(self.close_btn)
        layout.addLayout(btn_layout)
        
        self.setLayout(layout)
        
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        
        self.anim_timer = QTimer()
        self.anim_timer.timeout.connect(self.animate_pet)
        self.anim_timer.start(300)
        
        self.hunger_timer = QTimer()
        self.hunger_timer.timeout.connect(self.get_hungrier)
        self.hunger_timer.start(30000)
        
        self.update_ui_display()

    def toggle_timer(self):
        if self.timer_running:
            self.timer.stop()
            self.start_btn.setText("ODAKLAN")
            self.start_btn.setStyleSheet("background-color: #22c55e; color: white; font-weight: bold; border-radius: 5px; padding: 6px;")
        else:
            self.timer.start(1000)
            self.start_btn.setText("DURDUR")
            self.start_btn.setStyleSheet("background-color: #eab308; color: white; font-weight: bold; border-radius: 5px; padding: 6px;")
        self.timer_running = not self.timer_running
        self.speech_label.setText(self.get_pet_speech())
        
    def update_timer(self):
        if self.time_left > 0:
            self.time_left -= 1
            mins, secs = divmod(self.time_left, 60)
            self.time_label.setText(f"{mins:02d}:{secs:02d}")
            
            if self.time_left % 60 == 0:
                self.gain_xp(5)
                self.hunger = max(0, self.hunger - 1)
                self.update_ui_display()
                if random.random() < 0.3: 
                    self.speech_label.setText(self.get_pet_speech())
        else:
            self.timer.stop()
            self.timer_running = False
            self.time_left = 25 * 60
            self.time_label.setText("25:00")
            self.start_btn.setText("ODAKLAN")
            self.start_btn.setStyleSheet("background-color: #22c55e; color: white; font-weight: bold; border-radius: 5px; padding: 6px;")
            
            if self.level == 1:
                self.level = 2
                self.gain_xp(50)
                self.speech_label.setText("Yumurtadan çıktım! Merhaba dünya! 🎉")
            else:
                self.gain_xp(100)
                self.speech_label.setText("Harika bir seanstı, büyüdüğümü hissediyorum! 💪")
                
            self.update_ui_display()
            
    def gain_xp(self, amount):
        self.xp += amount
        while self.xp >= self.get_xp_needed():
            self.xp -= self.get_xp_needed()
            self.level += 1
            self.speech_label.setText("EVRİMLEŞİYORUM! 🌟 Evrim tamamlandı!")
        self.save_game_data()
        self.update_ui_display()
        
    def feed_pet(self):
        if self.hunger < 100:
            self.hunger = min(100, self.hunger + 25)
            self.speech_label.setText("Mmm, lezizdi! Teşekkürler! 🍗")
            self.save_game_data()
            self.update_ui_display()
            
    def get_hungrier(self):
        if self.timer_running:
            self.hunger = max(0, self.hunger - 1)
        else:
            self.hunger = max(0, self.hunger - 2)
        
        if self.hunger < 20:
            self.speech_label.setText(self.get_pet_speech())
            
        self.save_game_data()
        self.update_ui_display()
        
    def update_ui_display(self):
        self.info_label.setText(f"Lv. {self.level} Ejderha")
        self.pet_label.setText(self.get_pet_avatar())
        self.stats_label.setText(f"🍖 Açlık: %{int(self.hunger)}")
        self.xp_bar.setMaximum(self.get_xp_needed())
        self.xp_bar.setValue(self.xp)
        
    def animate_pet(self):
        self.animation_step += 0.5
        offset = int(math.sin(self.animation_step) * 4)
        self.pet_label.setMargin(5 + offset)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FocusPetApp()
    window.show()
    sys.exit(app.exec())