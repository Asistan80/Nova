# Bozkurt Survivors v6

Türk mitolojisi temalı Vampire Survivors tarzı oyun. Godot 4.3, GDScript. Harici görsel/ses dosyası yok; her şey kodla çizilir ve üretilir.

## Çalıştırma
1. Godot 4.3+ ile `project.godot` dosyasını aç (Import).
2. F5 ile çalıştır.

## Kontroller
WASD / Oklar: hareket · ESC/P: duraklat · 1/2/3: yükseltme seç · R: yeniden başla · Enter: başlat · M: müzik aç/kapa · N: efekt sesi aç/kapa · F11 veya Alt+Enter: tam ekran

## v3 yenilikleri
- **7 karakter**: Bozkurt, Alp, Kam, Umay Ana, Tulpar, Dede Korkut, Oğuz Han (altınla açılır)
- **5 bölge**: Bozkır, Orman (bataklık), Lav Arenası (lav havuzu + meteor), Deniz (akıntı + girdap), Fırtına (yıldırım uyarılı)
- **13 düşman + 5 boss**: bölen, patlayan, zikzak, atılan, uzaktan atan, iyileştiren; boss desenleri (yere vurma, çağırma, halka, hamle)
- **Evrim silahları** (iki silah Sv.5 olunca): Tengri Oku (Ok+Yıldırım), Alev Çemberi (Çember+Aura), Kurt Sürüsü (Pençe+Kurt)
- **Skor tablosu** (ilk 10), kritik vuruş, hasar sayıları, parçacık efektleri, ekran sarsıntısı
- **Her bölgeye özel arka plan müziği** (kodla üretilir, ilk açılışta ~4 sn sonra başlar)
- Ocak: kalıcı geliştirmeler; kayıt `user://bozkurt_save.json`

## v4 yenilikleri
- Tam ekran (F11 / Alt+Enter / Ayarlar): geniş ekranlarda siyah bant yok, oyun alanı pencereyi doldurur
- Ana menüde isim kutusu; skor tablosunda ve ölüm ekranında isim görünür
- Ayarlar sayfası: müzik ve efekt sesi kaydırıcıları (kayıtlı)
- Ocak: yükseltmeler 25 seviyeye çıktı (seviye başına etki küçüldü, maliyet yavaş artar)

## v5 yenilikleri
- 4 yeni boss (toplam 9): Yelbegen (spiral mermi), Kara Ejder (ateş konisi), Kar Kağanı (buz dalgası), Erlik Han (final boss, tüm saldırılar)
- 3 yeni silah: Alp Mızrağı (delici), Savaş Baltası (gidip gelir), Kırağı (buz dalgası, yavaşlatır)
- Boss yenince Hazine Sandığı düşer (bedava güç seçimi)
- Kombo sayacı (2.5 sn içinde öldürmeye devam et; 25/50/100/200'de bonus, skora etkisi)
- 15 dakikayı tamamlayınca ZAFER bonusu (oyun devam eder)
- 22 başarım + istatistikler (ana menü > Başarımlar), altın ödüllü, ekranda bildirim

## v6 yenilikleri
- 2 yeni evrim: Gök Mızrağı (Mızrak+Balta), Kış Fırtınası (Kırağı+Ateş Aurası) - toplam 5 evrim
- 3 yeni karakter: Asena, Mergen (yüksek kritik), Bilge Kağan - toplam 10
- 2 yeni bölge: Buzul Geçidi (buz zemin, kar), Tamu/Yeraltı (zehirli çukurlar, yıldırım, en zoru) - toplam 7, kendi müzikleriyle
- Web sürümü: `build/web` klasörü (bozkurt-survivors-web.zip). Müzik tarayıcıda donmadan, adım adım üretilir

## Web'e koyma (portföy sitesi)
1. bozkurt-survivors-web.zip içindekileri sitenin bir klasörüne yükle (örn. /oyunlar/bozkurt/)
2. `index.html` adresini aç. Özel sunucu ayarı gerekmez (iş parçacıksız derleme).
3. `.wasm` dosyasının `application/wasm` olarak servis edilmesi gerekir (çoğu sunucu zaten yapar).
4. Sitene iframe ile de gömebilirsin: <iframe src="/oyunlar/bozkurt/index.html" width="1280" height="720" allowfullscreen></iframe>
Not: Tarayıcıda ses, ilk tıklama/tuş basışından sonra başlar (tarayıcı kuralı). Kayıtlar tarayıcıda saklanır.

## Android'e aktarma
Godot 4.3 editöründe: Editor > Manage Export Templates (indir), Editor Settings > Export > Android bölümünde JDK ve Android SDK yollarını ver,
Project > Export > Add > Android, keystore oluştur, "Export Project" ile .apk/.aab al.
Dokunmatik kontrol için oyuna sanal joystick eklenmesi gerekir (henüz yok); istersen sonraki sürümde eklerim.
