extends Node2D
## Bozkurt Survivors v3 - Türk mitolojisi temalı hayatta kalma oyunu
## Tüm görseller ve sesler kodla üretilir, harici dosya gerekmez.
## Kontroller: WASD / Oklar = hareket | 1-2-3 = güç seç | ESC / P = duraklat | M = müzik | N = ses efektleri | R = yeniden başla

const Data := preload("res://data.gd")
const AudioBank := preload("res://audio_bank.gd")

const ARENA := 2600.0
const SPAWN_DIST := 720.0
const BASE_VW := 1400.0
const BASE_VH := 820.0
const MAX_ENEMIES := 300
const MAX_WEAPON_LEVEL := 8
const MAX_META := 25
const POOL_CELL := 340.0
const MAX_PARTS := 600
const SAVE_PATH := "user://bozkurt_save.json"

enum State { MENU, PLAYING, LEVELUP, PAUSED, DEAD }

var state := State.MENU

# --- Kayıt ---
var save_data := {"gold": 0, "meta": {}, "chars": {"bozkurt": true}, "stages": {"bozkir": true},
	"char": "bozkurt", "stage": "bozkir", "best_time": 0.0, "best_kills": 0,
	"sound": true, "music": true, "scores": [], "music_vol": 0.7, "sfx_vol": 0.8, "fullscreen": false, "name": "", "ach": {},
	"stats": {"kills": 0, "bosses": 0, "chests": 0, "runs": 0, "boss_seen": {}, "evo_seen": {}, "char_played": {}, "stage_played": {}}}
var selected_char := "bozkurt"
var stage_id := "bozkir"
var sound_on := true
var music_on := true
var music_vol := 0.7
var sfx_vol := 0.8
var fullscreen_on := false
var player_name := ""
var vw := BASE_VW
var vh := BASE_VH
var spawn_dist := SPAWN_DIST

# --- Oyuncu ---
var player_pos := Vector2.ZERO
var player_hp := 100.0
var player_max_hp := 100.0
var player_speed := 230.0
var player_level := 1
var xp := 0.0
var xp_next := 5.0
var time_alive := 0.0
var kills := 0
var bosses_killed := 0
var invuln := 0.0
var facing := Vector2.RIGHT
var player_moving := false
var char_color := Color.WHITE
var char_style := "wolf"
var speed_mod := 1.0
var crit_chance := 0.05

# --- Silahlar ---
var wlevel := {}
var evolved := {}
var consumed := {}
var bow_cd := 0.0
var aura_tick := 0.0
var thunder_cd := 1.0
var claw_cd := 0.6
var tengri_cd := 0.5
var orbit_angle := 0.0
var magnet_range := 100.0
var dmg_mult := 1.0
var xp_mult := 1.0
var regen := 0.0
var chain_cd := 0.0
var mizrak_cd := 0.8
var balta_cd := 0.8
var kirag_cd := 1.5
var axes: Array = []
var gok_cd := 0.8
var buz_tick := 0.4
var buz_nova := 2.0
var combo := 0
var combo_t := 0.0
var best_combo := 0
var victory_done := false
var ach_timer := 0.0
var toasts: Array = []
var toast_t := 0.0
var toast_label: Label
var ach_vb: VBoxContainer
var ach_head: Label

# --- Dünya ---
var enemies: Array = []
var arrows: Array = []
var gems: Array = []
var popups: Array = []
var fx: Array = []
var parts: Array = []
var strikes: Array = []
var eproj: Array = []
var wolves: Array = []
var next_id := 0
var spawn_timer := 0.0
var boss_timer := 60.0
var boss_count := 0
var shake := 0.0
var flash_a := 0.0
var hurt_a := 0.0
var anim_t := 0.0
var pool_kind := ""
var pool_density := 0.0
var pool_tick := 0.0
var stage_salt := 1
var hazard_timer := 4.0
var stars: Array = []
var last_gold_earned := 0
var last_score := 0
var last_rank := 0

# --- Ses ---
var bank := AudioBank.new()
var sfx_last := {}
var sfx_players: Array = []
var sfx_idx := 0
var music_player: AudioStreamPlayer
var music_thread: Thread
var bake_cancel := false
var use_thread := true
var want_music := ""
var cur_music := ""
var music_poll := 0.0

# --- Arayüz ---
var cam: Camera2D
var ui: CanvasLayer
var hud: Control
var tint_rect: ColorRect
var hurt_rect: ColorRect
var flash_rect: ColorRect
var xp_bar: ProgressBar
var hp_bar: ProgressBar
var boss_bar: ProgressBar
var info_label: Label
var weapon_label: Label
var boss_label: Label
var banner: Label
var banner_tw: Tween
var zoom_tw: Tween
var levelup_wrap: Control
var levelup_title: Label
var level_buttons: Array = []
var choices: Array = []
var death_wrap: Control
var death_label: Label
var pause_wrap: Control
var pages := {}
var menu_page := "main"
var menu_summary: Label
var gold_label: Label
var best_label: Label
var music_button: Button
var name_edit: LineEdit
var fs_button: Button
var music_slider: HSlider
var sfx_slider: HSlider
var music_pct: Label
var sfx_pct: Label
var sound_button: Button
var char_buttons := {}
var chars_gold: Label
var chars_msg: Label
var stage_buttons := {}
var stages_gold: Label
var stages_msg: Label
var shop_buttons := {}
var shop_gold_label: Label
var score_grid: GridContainer


func _ready() -> void:
	randomize()
	cam = Camera2D.new()
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 10.0
	add_child(cam)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in 80:
		stars.append({"pos": Vector2(rng.randf_range(-640, 640), rng.randf_range(-360, 200)), "r": rng.randf_range(0.8, 2.2), "a": rng.randf_range(0.3, 1.0), "p": rng.randf_range(0.0, 6.0)})
	for w in Data.WEAPON_ORDER:
		wlevel[w] = 0
	_load_save()
	bank.build_sfx()
	for i in 14:
		var p := AudioStreamPlayer.new()
		add_child(p)
		sfx_players.append(p)
	music_player = AudioStreamPlayer.new()
	music_player.volume_db = -12.0 + _vol_db(music_vol)
	add_child(music_player)
	_build_ui()
	_apply_fullscreen()
	use_thread = not OS.has_feature("web")
	if use_thread:
		music_thread = Thread.new()
		music_thread.start(_bake_music)
	else:
		bank.queue_theme("menu")
	_set_state(State.MENU)


func _exit_tree() -> void:
	bake_cancel = true
	if music_thread != null and music_thread.is_started():
		music_thread.wait_to_finish()


func _bake_music() -> void:
	for th in ["menu", "bozkir", "orman", "lav", "deniz", "firtina", "kar", "yeralti"]:
		if bake_cancel:
			return
		bank.music(th)


func _process(delta: float) -> void:
	anim_t = Time.get_ticks_msec() / 1000.0
	var vs := get_viewport_rect().size
	vw = maxf(BASE_VW, vs.x + 140.0)
	vh = maxf(BASE_VH, vs.y + 100.0)
	spawn_dist = maxf(SPAWN_DIST, Vector2(vs.x, vs.y).length() * 0.5 + 40.0)
	match state:
		State.PLAYING:
			_update_game(delta)
		State.LEVELUP, State.DEAD:
			_update_fx(delta)
	if state != State.PAUSED:
		shake = maxf(0.0, shake - 40.0 * delta)
		flash_a = maxf(0.0, flash_a - 2.2 * delta)
		hurt_a = maxf(0.0, hurt_a - 1.6 * delta)
	cam.position = player_pos
	if shake > 0.0:
		cam.offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * shake
	else:
		cam.offset = Vector2.ZERO
	if not use_thread:
		bank.step_bake(5)
	music_poll -= delta
	if music_poll <= 0.0:
		music_poll = 0.5
		_try_start_music()
	_update_toast(delta)
	_update_ui()
	queue_redraw()


func _unhandled_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k == null or not k.pressed or k.echo:
		return
	if k.keycode == KEY_F11 or ((k.keycode == KEY_ENTER or k.keycode == KEY_KP_ENTER) and k.alt_pressed):
		_toggle_fullscreen()
		return
	if k.keycode == KEY_M:
		_toggle_music()
		return
	if k.keycode == KEY_N:
		_toggle_sound()
		return
	match state:
		State.MENU:
			if menu_page != "main":
				if k.keycode == KEY_ESCAPE:
					_show_page("main")
			elif k.keycode == KEY_ENTER or k.keycode == KEY_KP_ENTER or k.keycode == KEY_SPACE:
				_on_start_pressed()
		State.PLAYING:
			if k.keycode == KEY_ESCAPE or k.keycode == KEY_P:
				_set_state(State.PAUSED)
		State.PAUSED:
			if k.keycode == KEY_ESCAPE or k.keycode == KEY_P:
				_set_state(State.PLAYING)
		State.LEVELUP:
			if k.keycode == KEY_1:
				_on_pick(0)
			elif k.keycode == KEY_2:
				_on_pick(1)
			elif k.keycode == KEY_3:
				_on_pick(2)
		State.DEAD:
			if k.keycode == KEY_R:
				_on_start_pressed()


func _set_state(s: State) -> void:
	state = s
	hud.visible = s != State.MENU
	levelup_wrap.visible = s == State.LEVELUP
	pause_wrap.visible = s == State.PAUSED
	death_wrap.visible = s == State.DEAD
	if s == State.MENU:
		player_pos = Vector2.ZERO
		shake = 0.0
		flash_a = 0.0
		hurt_a = 0.0
		cam.zoom = Vector2.ONE
		tint_rect.color = Color(0, 0, 0, 0)
		_play_music("menu")
		_show_page("main", false)
	else:
		for key in pages:
			pages[key].visible = false


# ============================================================
#  KAYIT / YÜKLEME
# ============================================================

func _load_save() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if f != null:
			var parsed = JSON.parse_string(f.get_as_text())
			if parsed is Dictionary:
				for key in parsed:
					save_data[key] = parsed[key]
	if not (save_data["meta"] is Dictionary):
		save_data["meta"] = {}
	if not (save_data["chars"] is Dictionary):
		save_data["chars"] = {"bozkurt": true}
	if not (save_data["stages"] is Dictionary):
		save_data["stages"] = {"bozkir": true}
	if not (save_data["scores"] is Array):
		save_data["scores"] = []
	save_data["chars"]["bozkurt"] = true
	save_data["stages"]["bozkir"] = true
	if not (save_data["ach"] is Dictionary):
		save_data["ach"] = {}
	if not (save_data["stats"] is Dictionary):
		save_data["stats"] = {}
	for sk in ["kills", "bosses", "chests", "runs"]:
		if not save_data["stats"].has(sk):
			save_data["stats"][sk] = 0
	for sk in ["boss_seen", "evo_seen", "char_played", "stage_played"]:
		if not (save_data["stats"].get(sk, null) is Dictionary):
			save_data["stats"][sk] = {}
	selected_char = str(save_data.get("char", "bozkurt"))
	if not Data.CHARS.has(selected_char) or not save_data["chars"].has(selected_char):
		selected_char = "bozkurt"
	stage_id = str(save_data.get("stage", "bozkir"))
	if not Data.STAGES.has(stage_id) or not save_data["stages"].has(stage_id):
		stage_id = "bozkir"
	sound_on = bool(save_data.get("sound", true))
	music_on = bool(save_data.get("music", true))
	music_vol = clampf(float(save_data.get("music_vol", 0.7)), 0.0, 1.0)
	sfx_vol = clampf(float(save_data.get("sfx_vol", 0.8)), 0.0, 1.0)
	fullscreen_on = bool(save_data.get("fullscreen", false))
	player_name = str(save_data.get("name", "")).strip_edges().left(12)


func _write_save() -> void:
	save_data["char"] = selected_char
	save_data["stage"] = stage_id
	save_data["sound"] = sound_on
	save_data["music"] = music_on
	save_data["music_vol"] = music_vol
	save_data["sfx_vol"] = sfx_vol
	save_data["fullscreen"] = fullscreen_on
	save_data["name"] = player_name
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(save_data))


func _meta(key: String) -> int:
	return int(save_data["meta"].get(key, 0))


func _meta_cost(key: String) -> int:
	var d: Dictionary = Data.META[key]
	return int(round(float(d["base"]) * (1.0 + 0.25 * float(_meta(key)))))


# ============================================================
#  SES VE MÜZİK
# ============================================================

func _vol_db(v: float) -> float:
	return -60.0 if v <= 0.01 else linear_to_db(v)


func _play(sname: String, vol_db: float = 0.0, min_gap: float = 0.0) -> void:
	if not sound_on or not bank.sfx.has(sname):
		return
	var now := Time.get_ticks_msec()
	if min_gap > 0.0 and sfx_last.has(sname) and now - int(sfx_last[sname]) < int(min_gap * 1000.0):
		return
	sfx_last[sname] = now
	var p: AudioStreamPlayer = sfx_players[sfx_idx]
	sfx_idx = (sfx_idx + 1) % sfx_players.size()
	p.stream = bank.sfx[sname]
	p.volume_db = vol_db + _vol_db(sfx_vol)
	p.pitch_scale = randf_range(0.93, 1.07)
	p.play()


func _play_music(theme: String) -> void:
	want_music = theme
	if not use_thread:
		bank.queue_theme(theme, true)
	_try_start_music()


func _try_start_music() -> void:
	if not music_on or want_music == "":
		if music_player.playing:
			music_player.stop()
		cur_music = ""
		return
	if cur_music == want_music and music_player.playing:
		return
	var st := bank.ready_music(want_music)
	if st == null:
		return
	music_player.stream = st
	music_player.play()
	cur_music = want_music


func _toggle_sound() -> void:
	sound_on = not sound_on
	_write_save()
	_refresh_menu()
	if sound_on:
		_play("click")


func _toggle_music() -> void:
	music_on = not music_on
	_write_save()
	_refresh_menu()
	_try_start_music()


# ============================================================
#  KOŞU BAŞLATMA / BİTİRME
# ============================================================

func _start_run() -> void:
	var c: Dictionary = Data.CHARS[selected_char]
	var st: Dictionary = Data.STAGES[stage_id]
	char_color = c["color"]
	char_style = c["style"]
	player_pos = Vector2.ZERO
	player_max_hp = float(c["hp"]) + 6.0 * _meta("hp")
	player_hp = player_max_hp
	player_speed = float(c["speed"]) * (1.0 + 0.012 * _meta("speed"))
	dmg_mult = float(c["dmg"]) + 0.02 * _meta("dmg")
	regen = float(c["regen"]) + 0.06 * _meta("regen")
	xp_mult = float(c["xp"]) + 0.025 * _meta("xp")
	magnet_range = 100.0 * float(c["magnet"]) * (1.0 + 0.06 * _meta("magnet"))
	crit_chance = 0.05 + float(c.get("crit", 0.0))
	player_level = 1
	xp = 0.0
	xp_next = 5.0
	time_alive = 0.0
	kills = 0
	bosses_killed = 0
	invuln = 0.0
	facing = Vector2.RIGHT
	player_moving = false
	speed_mod = 1.0
	for w in Data.WEAPON_ORDER:
		wlevel[w] = 0
	var start: Dictionary = c["start"]
	for w in start:
		wlevel[w] = int(start[w])
	evolved.clear()
	consumed.clear()
	bow_cd = 0.0
	aura_tick = 0.0
	thunder_cd = 1.0
	claw_cd = 0.6
	tengri_cd = 0.5
	orbit_angle = 0.0
	chain_cd = 0.0
	mizrak_cd = 0.8
	balta_cd = 0.8
	kirag_cd = 1.5
	gok_cd = 0.8
	buz_tick = 0.4
	buz_nova = 2.0
	axes.clear()
	combo = 0
	combo_t = 0.0
	best_combo = 0
	victory_done = false
	ach_timer = 0.0
	save_data["stats"]["char_played"][selected_char] = true
	save_data["stats"]["stage_played"][stage_id] = true
	enemies.clear()
	arrows.clear()
	gems.clear()
	popups.clear()
	fx.clear()
	parts.clear()
	strikes.clear()
	eproj.clear()
	wolves.clear()
	next_id = 0
	spawn_timer = 0.0
	boss_timer = 60.0
	boss_count = 0
	shake = 0.0
	flash_a = 0.0
	hurt_a = 0.0
	pool_kind = st["pool"]
	pool_density = st["pool_density"]
	pool_tick = 0.0
	stage_salt = Data.STAGE_ORDER.find(stage_id) + 1
	hazard_timer = 4.0
	tint_rect.color = st["tint"]
	cam.zoom = Vector2.ONE
	_play_music(st["music"])
	_set_state(State.PLAYING)
	_show_banner(st["name"], Color(1, 1, 1))


func _calc_score() -> int:
	var st: Dictionary = Data.STAGES[stage_id]
	return int((kills * 10.0 + time_alive * 3.0 + bosses_killed * 500.0 + player_level * 50.0 + best_combo * 5.0) * float(st["gold_mult"]))


func _record_score(sc: int) -> int:
	var entry := {"name": player_name, "score": sc, "char": selected_char, "stage": stage_id, "time": time_alive, "kills": kills, "level": player_level}
	var list: Array = save_data["scores"]
	list.append(entry)
	list.sort_custom(func(a, b): return int(a["score"]) > int(b["score"]))
	var rank := list.find(entry) + 1
	if list.size() > 10:
		list.resize(10)
	return rank if rank <= 10 else 0


func _finish_run() -> int:
	var st: Dictionary = Data.STAGES[stage_id]
	var earned := int((kills * 0.4 + time_alive / 8.0 + player_level * 3 + bosses_killed * 40) * float(st["gold_mult"]))
	save_data["gold"] = int(save_data["gold"]) + earned
	if time_alive > float(save_data["best_time"]):
		save_data["best_time"] = time_alive
	if kills > int(save_data["best_kills"]):
		save_data["best_kills"] = kills
	_stat_add("runs")
	_check_ach()
	last_score = _calc_score()
	last_rank = _record_score(last_score)
	last_gold_earned = earned
	_write_save()
	return earned


# ============================================================
#  OYUN MANTIĞI
# ============================================================

func _update_game(delta: float) -> void:
	time_alive += delta
	invuln = maxf(0.0, invuln - delta)
	chain_cd = maxf(0.0, chain_cd - delta)
	if combo > 0:
		combo_t -= delta
		if combo_t <= 0.0:
			combo = 0
	ach_timer -= delta
	if ach_timer <= 0.0:
		ach_timer = 0.5
		_check_ach()
	if not victory_done and time_alive >= 900.0:
		victory_done = true
		var vb := int(300.0 * float(Data.STAGES[stage_id]["gold_mult"]))
		save_data["gold"] = int(save_data["gold"]) + vb
		_show_banner("ZAFER! Efsane tamamlandı  +%d altın" % vb, Color(1, 0.9, 0.3))
		_play("score")
		flash_a = 0.5
		_zoom_punch(0.05)
		_unlock("zafer")
		_write_save()

	var dir := Vector2(
		float(Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT)) - float(Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)),
		float(Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN)) - float(Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP))
	)
	player_moving = dir != Vector2.ZERO
	if player_moving:
		dir = dir.normalized()
		facing = dir
	_update_pools(delta)
	var push := Vector2.ZERO
	var cur: float = Data.STAGES[stage_id]["current"]
	if cur > 0.0:
		push = Vector2.from_angle(time_alive * 0.12) * cur
	player_pos += (dir * player_speed * speed_mod + push) * delta
	player_pos = player_pos.clamp(Vector2(-ARENA, -ARENA), Vector2(ARENA, ARENA))
	if player_moving and randf() < delta * 16.0:
		_spark(player_pos + Vector2(0, 14), Vector2(randf_range(-25, 25), randf_range(-15, -2)), Color(0.85, 0.85, 0.75, 0.5), 0.35, 3.0)

	if regen > 0.0:
		player_hp = minf(player_max_hp, player_hp + regen * delta)

	_update_stage_hazards(delta)
	_update_spawning(delta)
	_update_weapons(delta)
	_update_enemies(delta)
	_update_arrows(delta)
	_update_eproj(delta)
	_update_strikes(delta)
	_update_gems(delta)
	_update_fx(delta)

	if player_hp <= 0.0:
		_die()
	elif xp >= xp_next and state == State.PLAYING:
		_level_up()


# --- Havuzlar (bataklık, lav, girdap) ---

func _hash2(ix: int, iy: int, salt: int = 0) -> float:
	var h: int = ix * 374761393 + iy * 668265263 + salt * 144665 + 1013
	h = (h ^ (h >> 13)) * 1274126177
	h = h ^ (h >> 16)
	return float(h & 0xFFFF) / 65535.0


func _pool_in_cell(ix: int, iy: int) -> Dictionary:
	if pool_kind == "":
		return {}
	if _hash2(ix, iy, 3 + stage_salt * 11) > pool_density:
		return {}
	var c := Vector2((ix + 0.2 + 0.6 * _hash2(ix, iy, 5)) * POOL_CELL, (iy + 0.2 + 0.6 * _hash2(ix, iy, 7)) * POOL_CELL)
	if c.length() < 300.0 or absf(c.x) > ARENA - 120.0 or absf(c.y) > ARENA - 120.0:
		return {}
	return {"pos": c, "r": 50.0 + 45.0 * _hash2(ix, iy, 9)}


func _update_pools(delta: float) -> void:
	speed_mod = 1.0
	if pool_kind == "":
		return
	var cx := floori(player_pos.x / POOL_CELL)
	var cy := floori(player_pos.y / POOL_CELL)
	for ix in range(cx - 1, cx + 2):
		for iy in range(cy - 1, cy + 2):
			var pool := _pool_in_cell(ix, iy)
			if pool.is_empty():
				continue
			var pp: Vector2 = pool["pos"]
			if player_pos.distance_to(pp) < float(pool["r"]):
				match pool_kind:
					"swamp":
						speed_mod = minf(speed_mod, 0.55)
					"ice":
						speed_mod = minf(speed_mod, 0.6)
						if randf() < delta * 10.0:
							_spark(player_pos + Vector2(randf_range(-10, 10), 12), Vector2(randf_range(-20, 20), -30), Color(0.8, 0.95, 1.0, 0.8), 0.4, 2.5)
					"void":
						speed_mod = minf(speed_mod, 0.75)
						pool_tick -= delta
						if randf() < delta * 12.0:
							_spark(player_pos + Vector2(randf_range(-10, 10), 10), Vector2(randf_range(-20, 20), -60), Color(0.75, 0.3, 0.95, 0.9), 0.5, 3.0)
						if pool_tick <= 0.0:
							pool_tick = 0.5
							_hurt_player(4.0, true)
					"lava":
						pool_tick -= delta
						if randf() < delta * 14.0:
							_spark(player_pos + Vector2(randf_range(-10, 10), 10), Vector2(randf_range(-20, 20), -70), Color(1, 0.55, 0.15, 0.9), 0.5, 3.0)
						if pool_tick <= 0.0:
							pool_tick = 0.5
							_hurt_player(5.0, true)
					"whirl":
						speed_mod = minf(speed_mod, 0.7)
						player_pos += (pp - player_pos).normalized() * 110.0 * delta


func _update_stage_hazards(delta: float) -> void:
	var st: Dictionary = Data.STAGES[stage_id]
	var hz: String = st["hazard"]
	if hz == "":
		return
	hazard_timer -= delta
	if hazard_timer <= 0.0:
		hazard_timer = float(st["hazard_interval"]) * randf_range(0.7, 1.3)
		var target := player_pos + Vector2.from_angle(randf() * TAU) * randf_range(40.0, 380.0) + facing * 100.0
		target = target.clamp(Vector2(-ARENA, -ARENA), Vector2(ARENA, ARENA))
		if hz == "meteor":
			_add_strike(target, 75.0, 1.1, 16.0, "meteor", true)
		else:
			_add_strike(target, 70.0, 0.9, 18.0, "lightning", true)
			if randf() < 0.4:
				flash_a = maxf(flash_a, 0.25)


# --- Tehlike vuruşları (uyarı dairesi, sonra patlama) ---

func _add_strike(pos: Vector2, r: float, delay: float, dmg: float, kind: String, hit_enemies: bool) -> void:
	strikes.append({"pos": pos, "r": r, "t": 0.0, "delay": delay, "dmg": dmg, "kind": kind, "he": hit_enemies})
	_play("warn", -10.0, 0.1)


func _update_strikes(delta: float) -> void:
	for i in range(strikes.size() - 1, -1, -1):
		var s: Dictionary = strikes[i]
		s["t"] = float(s["t"]) + delta
		if float(s["t"]) >= float(s["delay"]):
			_resolve_strike(s)
			strikes.remove_at(i)


func _resolve_strike(s: Dictionary) -> void:
	var pos: Vector2 = s["pos"]
	var r: float = s["r"]
	match String(s["kind"]):
		"lightning":
			_add_bolt(pos, r)
			flash_a = maxf(flash_a, 0.5)
			_play("thunder", -3.0)
			shake = maxf(shake, 6.0)
			_burst(pos, Color(0.8, 0.9, 1.0), 14, 220.0, 0.5, 3.0)
		"meteor":
			_ring(pos, Color(1, 0.5, 0.1), r * 1.5, 0.45)
			_burst(pos, Color(1, 0.55, 0.15), 18, 240.0, 0.7, 4.0)
			_play("explode", -3.0)
			shake = maxf(shake, 7.0)
		_:
			_ring(pos, Color(0.9, 0.8, 0.6), r * 1.3, 0.5)
			_burst(pos, Color(0.9, 0.8, 0.6), 16, 220.0, 0.6, 4.0)
			_play("slam", -2.0)
			shake = maxf(shake, 10.0)
	if player_pos.distance_to(pos) < r + 10.0:
		_hurt_player(float(s["dmg"]))
	if s["he"]:
		for e in enemies:
			if e["hp"] > 0.0 and pos.distance_to(e["pos"]) < r + e["radius"]:
				e["hp"] = float(e["hp"]) - float(s["dmg"]) * 4.0
				e["flash"] = 0.1


func _hurt_player(amount: float, ignore_inv: bool = false) -> void:
	if not ignore_inv:
		if invuln > 0.0:
			return
		invuln = 0.55
	player_hp -= amount
	shake = maxf(shake, 3.0 if ignore_inv else 8.0)
	hurt_a = maxf(hurt_a, 0.25 if ignore_inv else 0.55)
	_play("hurt", -2.0, 0.1)
	_popup(player_pos + Vector2(0, -30), "-%d" % int(amount), Color(1, 0.3, 0.3), 0.7)
	_burst(player_pos, Color(1, 0.3, 0.3), 6, 140.0, 0.4, 3.0)


# --- Düşman doğurma ---

func _update_spawning(delta: float) -> void:
	var st: Dictionary = Data.STAGES[stage_id]
	spawn_timer -= delta
	if spawn_timer <= 0.0:
		spawn_timer = maxf(0.16, 1.0 - time_alive / 200.0) / float(st["spawn_mult"])
		var count := 1 + int(time_alive / 80.0)
		for i in count:
			if enemies.size() < MAX_ENEMIES:
				var k := _pick_kind()
				var first := _spawn_enemy(k)
				if k == "kara_kurt" and randf() < 0.5:
					for j in 2:
						if enemies.size() < MAX_ENEMIES:
							_spawn_enemy(k, (first["pos"] as Vector2) + Vector2.from_angle(randf() * TAU) * 40.0)
	boss_timer -= delta
	if boss_timer <= 0.0:
		boss_timer = 75.0
		var e := _spawn_enemy("boss")
		var bi: int = (boss_count + int(st["boss_offset"])) % Data.BOSS_LIST.size()
		var b: Dictionary = Data.BOSS_LIST[bi]
		e["name"] = b["name"]
		e["pattern"] = b["pattern"]
		e["color"] = b["color"]
		if String(b["pattern"]) == "erlik":
			e["hp"] = float(e["hp"]) * 1.8
		e["hp"] = float(e["hp"]) * (1.0 + 0.7 * boss_count)
		e["max_hp"] = e["hp"]
		boss_count += 1
		_show_banner("BOSS: %s" % b["name"], Color(1, 0.35, 0.35))
		_play("boss")
		shake = maxf(shake, 10.0)
		_zoom_punch(0.05)


func _pick_kind() -> String:
	var roster: Array = Data.STAGES[stage_id]["roster"]
	var total := 0.0
	for r in roster:
		if time_alive >= float(r[1]):
			total += float(r[2])
	var pick := randf() * total
	for r in roster:
		if time_alive >= float(r[1]):
			pick -= float(r[2])
			if pick <= 0.0:
				return String(r[0])
	return "albasti"


func _spawn_enemy(kind: String, at: Vector2 = Vector2.INF) -> Dictionary:
	var t: Dictionary = Data.ENEMIES[kind]
	var st: Dictionary = Data.STAGES[stage_id]
	var pos := at
	if at == Vector2.INF:
		pos = player_pos + Vector2.from_angle(randf() * TAU) * spawn_dist
	pos = pos.clamp(Vector2(-ARENA, -ARENA), Vector2(ARENA, ARENA))
	var hp: float = float(t["hp"]) * (1.0 + time_alive / 90.0) * float(st["hp_mult"])
	var dmg_scale := 1.0 + minf(time_alive / 360.0, 1.5)
	var e := {
		"id": next_id, "pos": pos, "hp": hp, "max_hp": hp,
		"speed": float(t["speed"]) * (1.0 + randf() * 0.2),
		"radius": float(t["radius"]), "dmg": float(t["dmg"]) * dmg_scale,
		"xp": int(t["xp"]), "armor": float(t["armor"]),
		"color": t["color"], "kind": kind, "ai": t["ai"], "look": t["look"], "name": t["name"], "pattern": "",
		"flash": 0.0, "orb_cd": 0.0, "spawn_t": 0.0, "burn": 0.0, "burn_dps": 0.0,
		"mode": 0, "mt": randf_range(1.5, 3.5), "dir": Vector2.RIGHT, "pt": 3.0,
		"shoot": randf_range(0.8, 2.2), "heal_t": 2.0, "slow": 0.0,
	}
	enemies.append(e)
	next_id += 1
	return e


func _nearest_enemy_to(from: Vector2, max_d: float):
	var best = null
	var best_d := max_d * max_d
	for e in enemies:
		if e["hp"] <= 0.0:
			continue
		var d := from.distance_squared_to(e["pos"])
		if d < best_d:
			best_d = d
			best = e
	return best


func _nearest_enemy():
	return _nearest_enemy_to(player_pos, 700.0)


func _lv(w: String) -> int:
	return int(wlevel[w])


# ============================================================
#  SİLAHLAR
# ============================================================

func _update_weapons(delta: float) -> void:
	orbit_angle += delta * 3.2

	# --- Ok Yağmuru ---
	var bow := _lv("bow")
	if bow > 0:
		bow_cd -= delta
		if bow_cd <= 0.0:
			var target = _nearest_enemy()
			if target != null:
				bow_cd = maxf(0.22, 0.85 - 0.07 * bow)
				var count := 1 + int(bow / 2.0)
				var base: float = (target["pos"] - player_pos).angle()
				for i in count:
					var off := (i - (count - 1) / 2.0) * 0.18
					arrows.append({
						"pos": player_pos, "vel": Vector2.from_angle(base + off) * 520.0,
						"dmg": (9.0 + 2.5 * bow) * dmg_mult, "life": 1.4,
						"pierce": 1 + int(bow / 3.0), "hit": [], "chain": false,
					})
				_play("shoot", -8.0, 0.06)

	# --- Tengri Oku (evrim) ---
	var teng := _lv("tengri")
	if teng > 0:
		tengri_cd -= delta
		if tengri_cd <= 0.0:
			var target2 = _nearest_enemy()
			if target2 != null:
				tengri_cd = maxf(0.28, 0.62 - 0.04 * teng)
				var n2 := 3 + int(teng / 2.0)
				var base2: float = (target2["pos"] - player_pos).angle()
				for i in n2:
					var off2 := (i - (n2 - 1) / 2.0) * 0.13
					arrows.append({
						"pos": player_pos, "vel": Vector2.from_angle(base2 + off2) * 700.0,
						"dmg": (26.0 + 6.0 * teng) * dmg_mult, "life": 1.2,
						"pierce": 99, "hit": [], "chain": true,
					})
				_play("shoot", -5.0, 0.06)

	# --- Kılıç Çemberi ---
	var orbit := _lv("orbit")
	if orbit > 0:
		var on := orbit + 1
		for i in on:
			var sp := player_pos + Vector2.from_angle(orbit_angle + TAU * i / on) * 85.0
			if randf() < delta * 10.0:
				_spark(sp, Vector2.ZERO, Color(0.8, 0.9, 1.0, 0.7), 0.25, 2.5)
			for e in enemies:
				if e["hp"] > 0.0 and e["orb_cd"] <= 0.0 and sp.distance_to(e["pos"]) < e["radius"] + 12.0:
					_hit_enemy(e, (12.0 + 3.0 * orbit) * dmg_mult)
					e["orb_cd"] = 0.45

	# --- Alev Çemberi (evrim) ---
	var alev := _lv("alev")
	if alev > 0:
		var an := 5 + int(alev / 2.0)
		var arad := 112.0 + 3.0 * alev
		for i in an:
			var asp := player_pos + Vector2.from_angle(orbit_angle * 1.15 + TAU * i / an) * arad
			if randf() < delta * 30.0:
				_spark(asp, Vector2(randf_range(-15, 15), -45), Color(1, 0.5, 0.1, 0.85), 0.4, 4.0)
			for e in enemies:
				if e["hp"] > 0.0 and e["orb_cd"] <= 0.0 and asp.distance_to(e["pos"]) < e["radius"] + 16.0:
					_hit_enemy(e, (22.0 + 5.0 * alev) * dmg_mult)
					e["orb_cd"] = 0.35
					e["burn"] = 3.0
					e["burn_dps"] = 8.0 + 2.0 * alev

	# --- Ateş Aurası ---
	var aura := _lv("aura")
	if aura > 0:
		aura_tick -= delta
		if aura_tick <= 0.0:
			aura_tick = 0.5
			var r := _aura_radius()
			for e in enemies:
				if e["hp"] > 0.0 and player_pos.distance_to(e["pos"]) < r + e["radius"]:
					_hit_enemy(e, (4.0 + 3.0 * aura) * dmg_mult, false)
		if randf() < delta * 12.0:
			var ang := randf() * TAU
			_spark(player_pos + Vector2.from_angle(ang) * _aura_radius() * randf_range(0.3, 1.0), Vector2(0, -50), Color(1, 0.5, 0.15, 0.7), 0.5, 3.0)

	# --- Gök Gürültüsü ---
	var th := _lv("thunder")
	if th > 0:
		thunder_cd -= delta
		if thunder_cd <= 0.0:
			var cands: Array = []
			for e in enemies:
				if e["hp"] > 0.0 and player_pos.distance_squared_to(e["pos"]) < 650.0 * 650.0:
					cands.append(e)
			if cands.size() > 0:
				thunder_cd = maxf(0.7, 2.2 - 0.17 * th)
				cands.shuffle()
				var strikes_n := mini(cands.size(), 1 + int(th / 2.0))
				var radius := 55.0 + 4.0 * th
				for i in strikes_n:
					var spos: Vector2 = cands[i]["pos"]
					_add_bolt(spos, radius)
					for e in enemies:
						if e["hp"] > 0.0 and spos.distance_to(e["pos"]) < radius + e["radius"]:
							_hit_enemy(e, (26.0 + 8.0 * th) * dmg_mult)
				_play("thunder", -4.0, 0.1)
				shake = maxf(shake, 4.0)
				flash_a = maxf(flash_a, 0.12)
			else:
				thunder_cd = 0.3

	# --- Kurt Pençesi ---
	var cl := _lv("claw")
	if cl > 0:
		claw_cd -= delta
		if claw_cd <= 0.0:
			var tgt = _nearest_enemy()
			if tgt != null:
				claw_cd = maxf(0.45, 1.15 - 0.08 * cl)
				var cang: float = (tgt["pos"] - player_pos).angle()
				_claw_slash(cang, cl)
				if cl >= 5:
					_claw_slash(cang + PI, cl)
				_play("claw", -4.0, 0.08)
				shake = maxf(shake, 2.5)
			else:
				claw_cd = 0.2

	# --- Alp Mızrağı ---
	var mz := _lv("mizrak")
	if mz > 0:
		mizrak_cd -= delta
		if mizrak_cd <= 0.0:
			var tm = _nearest_enemy()
			if tm != null:
				mizrak_cd = maxf(0.7, 1.7 - 0.12 * mz)
				var cnt := 1 + int(mz / 3.0)
				var mbase: float = (tm["pos"] - player_pos).angle()
				for i in cnt:
					var moff := (i - (cnt - 1) / 2.0) * 0.22
					arrows.append({
						"pos": player_pos, "vel": Vector2.from_angle(mbase + moff) * 820.0,
						"dmg": (22.0 + 7.0 * mz) * dmg_mult, "life": 0.75,
						"pierce": 99, "hit": [], "chain": false, "spear": true,
					})
				_play("shoot", -4.0, 0.06)
			else:
				mizrak_cd = 0.2

	# --- Savaş Baltası ---
	var bl := _lv("balta")
	if bl > 0:
		balta_cd -= delta
		if balta_cd <= 0.0:
			var tb = _nearest_enemy()
			if tb != null:
				balta_cd = maxf(0.9, 2.2 - 0.14 * bl)
				var nb := 1 + int(bl / 3.0)
				var ab: float = (tb["pos"] - player_pos).angle()
				for i in nb:
					axes.append({"pos": player_pos, "ang": ab + (i - (nb - 1) / 2.0) * 0.5, "t": 0.0,
						"dmg": (16.0 + 5.0 * bl) * dmg_mult, "hit": [], "back": false, "rot": 0.0})
				_play("claw", -6.0, 0.1)
			else:
				balta_cd = 0.25
	_update_axes(delta)

	# --- Kırağı ---
	var kr := _lv("kirag")
	if kr > 0:
		kirag_cd -= delta
		if kirag_cd <= 0.0:
			var krad := 120.0 + 14.0 * kr
			var near := false
			for e in enemies:
				if e["hp"] > 0.0 and player_pos.distance_to(e["pos"]) < krad * 1.3:
					near = true
					break
			if near:
				kirag_cd = maxf(1.6, 4.0 - 0.28 * kr)
				for e in enemies:
					if e["hp"] > 0.0 and player_pos.distance_to(e["pos"]) < krad + e["radius"]:
						_hit_enemy(e, (10.0 + 4.0 * kr) * dmg_mult, false)
						e["slow"] = 2.0 + 0.2 * kr
				fx.append({"kind": "frost", "r": krad, "life": 0.5, "max": 0.5})
				_burst(player_pos, Color(0.7, 0.9, 1.0), 14, 260.0, 0.5, 3.0)
				_play("splash", -4.0, 0.1)
			else:
				kirag_cd = 0.3

	# --- Gök Mızrağı (evrim) ---
	var gm := _lv("gokmizrak")
	if gm > 0:
		gok_cd -= delta
		if gok_cd <= 0.0:
			var tgm = _nearest_enemy()
			if tgm != null:
				gok_cd = maxf(0.5, 1.1 - 0.07 * gm)
				var gn := 3 + int(gm / 2.0)
				var gbase: float = (tgm["pos"] - player_pos).angle()
				for i in gn:
					var goff := (i - (gn - 1) / 2.0) * 0.16
					arrows.append({
						"pos": player_pos, "vel": Vector2.from_angle(gbase + goff) * 900.0,
						"dmg": (40.0 + 9.0 * gm) * dmg_mult, "life": 0.85,
						"pierce": 99, "hit": [], "chain": true, "spear": true,
					})
				if axes.size() < 8:
					axes.append({"pos": player_pos, "ang": gbase, "t": 0.0, "dmg": (24.0 + 6.0 * gm) * dmg_mult, "hit": [], "back": false, "rot": 0.0})
				_play("thunder", -8.0, 0.1)
			else:
				gok_cd = 0.2

	# --- Kış Fırtınası (evrim) ---
	var bf := _lv("buzfirtina")
	if bf > 0:
		var brad := 150.0 + 18.0 * bf
		buz_tick -= delta
		if buz_tick <= 0.0:
			buz_tick = 0.4
			for e in enemies:
				if e["hp"] > 0.0 and player_pos.distance_to(e["pos"]) < brad + e["radius"]:
					_hit_enemy(e, (8.0 + 3.5 * bf) * dmg_mult, false)
					e["slow"] = 1.2
		if randf() < delta * 30.0:
			var ba := randf() * TAU
			var bcol := Color(0.8, 0.95, 1.0, 0.8) if randf() < 0.6 else Color(1.0, 0.55, 0.2, 0.8)
			_spark(player_pos + Vector2.from_angle(ba) * brad * randf_range(0.2, 1.0), Vector2(randf_range(-20, 20), -40), bcol, 0.5, 3.0)
		buz_nova -= delta
		if buz_nova <= 0.0:
			buz_nova = maxf(1.8, 3.6 - 0.2 * bf)
			var nrad := brad * 1.6
			for e in enemies:
				if e["hp"] > 0.0 and player_pos.distance_to(e["pos"]) < nrad + e["radius"]:
					_hit_enemy(e, (30.0 + 9.0 * bf) * dmg_mult)
					e["slow"] = 2.5
					e["burn"] = 2.0
					e["burn_dps"] = 6.0 + 2.0 * bf
			fx.append({"kind": "frost", "r": nrad, "life": 0.55, "max": 0.55})
			_burst(player_pos, Color(0.8, 0.95, 1.0), 20, 320.0, 0.6, 3.5)
			_play("splash", -3.0, 0.1)
			shake = maxf(shake, 3.0)

	_update_wolves(delta)


func _update_axes(delta: float) -> void:
	var bl := maxi(_lv("balta"), _lv("gokmizrak"))
	for i in range(axes.size() - 1, -1, -1):
		var a: Dictionary = axes[i]
		a["rot"] = float(a["rot"]) + delta * 16.0
		var p: Vector2 = a["pos"]
		if not a["back"]:
			a["t"] = float(a["t"]) + delta
			p += Vector2.from_angle(float(a["ang"])) * 430.0 * delta
			if float(a["t"]) > 0.5 + 0.025 * bl:
				a["back"] = true
				a["hit"] = []
		else:
			var to_p := player_pos - p
			if to_p.length() < 22.0:
				axes.remove_at(i)
				continue
			p += to_p.normalized() * 560.0 * delta
		a["pos"] = p
		for e in enemies:
			if e["hp"] > 0.0 and not a["hit"].has(e["id"]) and p.distance_to(e["pos"]) < float(e["radius"]) + 16.0:
				a["hit"].append(e["id"])
				_hit_enemy(e, a["dmg"])


func _update_wolves(delta: float) -> void:
	var sl := _lv("suru")
	var wl := _lv("wolf")
	var want := 0
	var bite := 0.0
	var spd := 300.0
	if sl > 0:
		want = 3 + int(sl / 2.0)
		bite = 22.0 + 6.0 * sl
		spd = 380.0
	elif wl > 0:
		want = 1 + int(wl / 2.0)
		bite = 12.0 + 3.0 * wl
		spd = 310.0
	while wolves.size() < want:
		wolves.append({"pos": player_pos + Vector2.from_angle(randf() * TAU) * 40.0, "target": null,
			"cd": 0.0, "retarget": 0.0, "phase": randf() * TAU, "dir": Vector2.RIGHT})
	while wolves.size() > want:
		wolves.pop_back()
	for i in wolves.size():
		var w: Dictionary = wolves[i]
		w["cd"] = maxf(0.0, float(w["cd"]) - delta)
		w["retarget"] = float(w["retarget"]) - delta
		var tg = w["target"]
		if tg == null or float(tg["hp"]) <= 0.0 or float(w["retarget"]) <= 0.0:
			w["retarget"] = 0.5
			tg = _nearest_enemy_to(w["pos"], 450.0)
			w["target"] = tg
		var goal: Vector2
		if tg != null:
			goal = tg["pos"]
		else:
			goal = player_pos + Vector2.from_angle(float(w["phase"]) + anim_t * 1.2 + TAU * i / maxf(1.0, float(wolves.size()))) * 70.0
		var wp: Vector2 = w["pos"]
		var to_g := goal - wp
		var dist := to_g.length()
		if dist > 1.0:
			w["dir"] = to_g / dist
			w["pos"] = wp + to_g / dist * minf(spd * delta, dist)
		if sl > 0 and randf() < delta * 20.0:
			_spark(w["pos"], Vector2.ZERO, Color(0.6, 0.85, 1.0, 0.6), 0.35, 3.0)
		if tg != null and dist < float(tg["radius"]) + 14.0 and float(w["cd"]) <= 0.0:
			_hit_enemy(tg, bite * dmg_mult)
			w["cd"] = 0.5
			_play("bite", -8.0, 0.05)
			_burst(tg["pos"], Color(1, 0.9, 0.7), 4, 150.0, 0.25, 2.5)


func _claw_slash(ang: float, cl: int) -> void:
	var reach := 115.0 + 10.0 * cl
	fx.append({"kind": "claw", "dir": ang, "range": reach, "life": 0.2, "max": 0.2})
	for e in enemies:
		if e["hp"] <= 0.0:
			continue
		var to_e: Vector2 = e["pos"] - player_pos
		if to_e.length() < reach + e["radius"] and absf(angle_difference(ang, to_e.angle())) < 0.95:
			_hit_enemy(e, (20.0 + 6.0 * cl) * dmg_mult)


func _add_bolt(pos: Vector2, radius: float) -> void:
	var pts := PackedVector2Array()
	var top := pos + Vector2(randf_range(-40.0, 40.0), -520.0)
	var segs := 8
	for i in segs + 1:
		var p := top.lerp(pos, float(i) / float(segs))
		if i > 0 and i < segs:
			p.x += randf_range(-22.0, 22.0)
		pts.append(p)
	fx.append({"kind": "bolt", "pts": pts, "pos": pos, "r": radius, "life": 0.28, "max": 0.28})
	_burst(pos, Color(0.8, 0.9, 1.0), 6, 160.0, 0.35, 2.5)


func _aura_radius() -> float:
	return 70.0 + 18.0 * _lv("aura")


func _hit_enemy(e: Dictionary, dmg: float, can_crit: bool = true) -> void:
	var d := dmg
	var crit := false
	if can_crit and randf() < crit_chance:
		d *= 1.8
		crit = true
	d = maxf(1.0, d - float(e["armor"]))
	e["hp"] = float(e["hp"]) - d
	e["flash"] = 0.08
	if popups.size() < 60:
		var pc := Color(1, 0.85, 0.2) if crit else Color(1, 1, 0.6)
		_popup(e["pos"] + Vector2(0, -float(e["radius"])), str(int(d)), pc, 0.6 if crit else 0.45, 26 if crit else 18)
	var away: Vector2 = (e["pos"] - player_pos).normalized()
	e["pos"] += away * (1.5 if e["kind"] == "boss" else 6.0)
	if parts.size() < MAX_PARTS - 100:
		_burst(e["pos"], Color(1, 0.9, 0.6), 2, 120.0, 0.22, 2.2)
	_play("hit", -10.0, 0.05)


# ============================================================
#  DÜŞMAN YAPAY ZEKÂSI
# ============================================================

func _update_enemies(delta: float) -> void:
	for i in range(enemies.size() - 1, -1, -1):
		var e: Dictionary = enemies[i]
		if e["hp"] <= 0.0:
			_on_enemy_killed(e)
			enemies.remove_at(i)
			continue
		e["spawn_t"] = float(e["spawn_t"]) + delta
		e["flash"] = maxf(0.0, float(e["flash"]) - delta)
		e["orb_cd"] = maxf(0.0, float(e["orb_cd"]) - delta)
		if float(e["burn"]) > 0.0:
			e["burn"] = float(e["burn"]) - delta
			e["hp"] = float(e["hp"]) - float(e["burn_dps"]) * delta
			if randf() < delta * 6.0:
				_spark(e["pos"] + Vector2(randf_range(-6, 6), -float(e["radius"])), Vector2(0, -40), Color(1, 0.55, 0.15, 0.9), 0.35, 3.0)
		var ep: Vector2 = e["pos"]
		var to_p := player_pos - ep
		var d := to_p.length()
		if d > spawn_dist * 2.0 and e["kind"] != "boss":
			e["pos"] = player_pos + Vector2.from_angle(randf() * TAU) * spawn_dist
			continue
		var dir := to_p / d if d > 0.001 else Vector2.ZERO
		var sp0: float = e["speed"]
		if float(e["slow"]) > 0.0:
			e["slow"] = float(e["slow"]) - delta
			e["speed"] = sp0 * 0.5
		_enemy_ai(e, delta, dir, d)
		e["speed"] = sp0
		var np: Vector2 = e["pos"]
		e["pos"] = np.clamp(Vector2(-ARENA, -ARENA), Vector2(ARENA, ARENA))
		if d < float(e["radius"]) + 14.0 and float(e["spawn_t"]) > 0.4:
			if e["ai"] == "exploder":
				e["hp"] = -1.0
			elif invuln <= 0.0:
				_hurt_player(float(e["dmg"]))


func _dash_ai(e: Dictionary, delta: float, dir: Vector2, dash_speed: float, interval: float, tele: float, dur: float) -> void:
	e["mt"] = float(e["mt"]) - delta
	match int(e["mode"]):
		0:
			e["pos"] += dir * float(e["speed"]) * delta
			if float(e["mt"]) <= 0.0:
				e["mode"] = 1
				e["mt"] = tele
				e["dir"] = dir
		1:
			e["dir"] = dir
			if float(e["mt"]) <= 0.0:
				e["mode"] = 2
				e["mt"] = dur
				_play("dash", -8.0, 0.1)
		2:
			var dd: Vector2 = e["dir"]
			e["pos"] += dd * dash_speed * delta
			if randf() < delta * 40.0:
				_spark(e["pos"], -dd * 60.0, e["color"], 0.3, 4.0)
			if float(e["mt"]) <= 0.0:
				e["mode"] = 0
				e["mt"] = interval


func _enemy_ai(e: Dictionary, delta: float, dir: Vector2, d: float) -> void:
	var spd: float = e["speed"]
	match String(e["ai"]):
		"chase", "split", "exploder":
			e["pos"] += dir * spd * delta
		"zigzag":
			var sway := sin(float(e["spawn_t"]) * 5.0 + float(e["id"])) * 0.9
			e["pos"] += (dir + dir.orthogonal() * sway).normalized() * spd * delta
		"dash":
			_dash_ai(e, delta, dir, 430.0, 3.0, 0.55, 0.5)
		"ranged":
			var side := 1.0 if int(e["id"]) % 2 == 0 else -1.0
			if d > 300.0:
				e["pos"] += dir * spd * delta
			elif d < 200.0:
				e["pos"] -= dir * spd * 0.8 * delta
			else:
				e["pos"] += dir.orthogonal() * side * spd * 0.6 * delta
			e["shoot"] = float(e["shoot"]) - delta
			if float(e["shoot"]) <= 0.0 and d < 520.0:
				e["shoot"] = 2.2
				_fire_eproj(e["pos"], dir, 230.0, float(e["dmg"]), e["color"])
		"healer":
			if d > 280.0:
				e["pos"] += dir * spd * delta
			elif d < 190.0:
				e["pos"] -= dir * spd * 0.7 * delta
			e["heal_t"] = float(e["heal_t"]) - delta
			if float(e["heal_t"]) <= 0.0:
				e["heal_t"] = 3.0
				_ring(e["pos"], Color(0.4, 1.0, 0.7), 170.0, 0.6)
				for o in enemies:
					if o != e and o["hp"] > 0.0 and (o["pos"] as Vector2).distance_to(e["pos"]) < 170.0:
						o["hp"] = minf(float(o["max_hp"]), float(o["hp"]) + float(o["max_hp"]) * 0.18)
						_spark(o["pos"], Vector2(0, -50), Color(0.4, 1.0, 0.7, 0.9), 0.5, 3.0)
				_play("heal", -16.0, 0.4)
		"boss":
			_boss_ai(e, delta, dir)
		_:
			e["pos"] += dir * spd * delta


func _boss_ai(e: Dictionary, delta: float, dir: Vector2) -> void:
	var spd: float = e["speed"]
	e["pt"] = float(e["pt"]) - delta
	match String(e["pattern"]):
		"summon":
			e["pos"] += dir * spd * 0.8 * delta
			if float(e["pt"]) <= 0.0:
				e["pt"] = 7.0
				for k in 4:
					if enemies.size() < MAX_ENEMIES:
						_spawn_enemy("albasti", (e["pos"] as Vector2) + Vector2.from_angle(TAU * k / 4.0) * 70.0)
				_ring(e["pos"], Color(0.7, 0.3, 0.9), 150.0, 0.6)
				shake = maxf(shake, 5.0)
		"ring":
			e["pos"] += dir * spd * 0.7 * delta
			if float(e["pt"]) <= 0.0:
				e["pt"] = 3.4
				var off := randf() * TAU
				for k in 12:
					_fire_eproj(e["pos"], Vector2.from_angle(off + TAU * k / 12.0), 190.0, float(e["dmg"]) * 0.5, e["color"])
		"dash":
			_dash_ai(e, delta, dir, 400.0, 4.0, 0.7, 0.7)
		"spiral":
			e["pos"] += dir * spd * 0.5 * delta
			if float(e["pt"]) <= 0.0:
				e["pt"] = 0.14
				e["heal_t"] = float(e["heal_t"]) + 0.55
				_fire_eproj(e["pos"], Vector2.from_angle(float(e["heal_t"])), 175.0, float(e["dmg"]) * 0.35, e["color"])
				_fire_eproj(e["pos"], Vector2.from_angle(float(e["heal_t"]) + PI), 175.0, float(e["dmg"]) * 0.35, e["color"])
		"breath":
			e["pos"] += dir * spd * 0.9 * delta
			if float(e["pt"]) <= 0.0:
				e["pt"] = 2.8
				e["mode"] = int(e["mode"]) + 1
				var cone: float = dir.angle()
				for k in 9:
					_fire_eproj(e["pos"], Vector2.from_angle(cone + (k - 4) * 0.11), 270.0, float(e["dmg"]) * 0.45, Color(1.0, 0.5, 0.15))
				if int(e["mode"]) % 2 == 0:
					_add_strike(player_pos, 110.0, 1.0, float(e["dmg"]), "slam", false)
		"frost":
			e["pos"] += dir * spd * 0.7 * delta
			if float(e["pt"]) <= 0.0:
				e["pt"] = 5.0
				_add_strike(e["pos"], 260.0, 1.2, float(e["dmg"]) * 1.2, "slam", false)
				for k in 10:
					_fire_eproj(e["pos"], Vector2.from_angle(TAU * k / 10.0), 150.0, float(e["dmg"]) * 0.4, Color(0.6, 0.9, 1.0))
		"erlik":
			e["pos"] += dir * spd * 0.9 * delta
			if float(e["pt"]) <= 0.0:
				e["pt"] = 3.0
				e["mode"] = int(e["mode"]) + 1
				match int(e["mode"]) % 4:
					0:
						_add_strike(player_pos, 125.0, 1.0, float(e["dmg"]), "slam", false)
						_add_strike(player_pos + Vector2.from_angle(randf() * TAU) * 170.0, 110.0, 1.2, float(e["dmg"]), "slam", false)
					1:
						var off2 := randf() * TAU
						for k in 16:
							_fire_eproj(e["pos"], Vector2.from_angle(off2 + TAU * k / 16.0), 200.0, float(e["dmg"]) * 0.45, e["color"])
					2:
						for k in 6:
							if enemies.size() < MAX_ENEMIES:
								_spawn_enemy("albasti" if k % 2 == 0 else "kara_kurt", (e["pos"] as Vector2) + Vector2.from_angle(TAU * k / 6.0) * 80.0)
						_ring(e["pos"], Color(0.8, 0.1, 0.3), 180.0, 0.6)
					3:
						for ring_i in 3:
							var off3 := randf() * TAU
							for k in 8:
								_fire_eproj(e["pos"], Vector2.from_angle(off3 + TAU * k / 8.0), 130.0 + 45.0 * ring_i, float(e["dmg"]) * 0.4, Color(1.0, 0.3, 0.5))
				shake = maxf(shake, 4.0)
		_:
			e["pos"] += dir * spd * delta
			if float(e["pt"]) <= 0.0:
				e["pt"] = 4.0
				_add_strike(player_pos, 125.0, 1.0, float(e["dmg"]), "slam", false)


func _fire_eproj(pos: Vector2, dir: Vector2, spd: float, dmg: float, col: Color) -> void:
	if eproj.size() > 120:
		return
	eproj.append({"pos": pos, "vel": dir.normalized() * spd, "dmg": dmg, "life": 4.0, "r": 6.0, "col": col})
	_play("eshot", -12.0, 0.08)


func _on_enemy_killed(e: Dictionary) -> void:
	kills += 1
	_stat_add("kills")
	combo += 1
	combo_t = 2.5
	best_combo = maxi(best_combo, combo)
	if combo == 25 or combo == 50 or combo == 100 or combo == 200:
		_popup(player_pos + Vector2(0, -60), "KOMBO x%d!" % combo, Color(1, 0.6, 0.2), 1.2, 28)
		gems.append({"pos": player_pos + Vector2(40, 0), "value": combo / 5, "type": "xp"})
		_ring(player_pos, Color(1, 0.6, 0.2), 140.0, 0.5)
	var kind: String = e["kind"]
	var pos: Vector2 = e["pos"]
	var col: Color = e["color"]
	gems.append({"pos": pos, "value": e["xp"], "type": "xp"})
	if parts.size() < MAX_PARTS - 40:
		_burst(pos, col, 8, 170.0, 0.5, 3.5)
		_ring(pos, col, float(e["radius"]) * 2.4, 0.35)
	match kind:
		"boss":
			bosses_killed += 1
			_stat_add("bosses")
			save_data["stats"]["boss_seen"][String(e["name"])] = true
			gems.append({"pos": pos + Vector2(0, -44), "value": 0, "type": "chest"})
			for j in 4:
				gems.append({"pos": pos + Vector2.from_angle(j * TAU / 4.0) * 30.0, "value": 10, "type": "xp"})
			gems.append({"pos": pos + Vector2(0, 40), "value": 0, "type": "heal"})
			_popup(pos, "BOSS YENİLDİ!", Color(1, 0.85, 0.3), 1.6, 26)
			_burst(pos, col, 30, 320.0, 0.9, 5.0)
			_ring(pos, Color(1, 0.9, 0.5), 260.0, 0.8)
			shake = maxf(shake, 12.0)
			flash_a = maxf(flash_a, 0.3)
			_play("thunder", -2.0)
			_zoom_punch(0.04)
		"cin":
			_ring(pos, Color(1, 0.6, 0.2), 85.0, 0.4)
			_burst(pos, Color(1, 0.6, 0.2), 14, 220.0, 0.5, 4.0)
			_play("explode", -6.0, 0.05)
			shake = maxf(shake, 4.0)
			if player_pos.distance_to(pos) < 85.0:
				_hurt_player(float(e["dmg"]))
		"catal":
			for k in 2:
				if enemies.size() < MAX_ENEMIES:
					_spawn_enemy("minik", pos + Vector2.from_angle(TAU * k / 2.0 + randf()) * 14.0)
	if kind != "boss" and kind != "minik" and randf() < 0.025:
		gems.append({"pos": pos + Vector2(10, 0), "value": 0, "type": "heal"})


func _update_arrows(delta: float) -> void:
	for i in range(arrows.size() - 1, -1, -1):
		var a: Dictionary = arrows[i]
		a["pos"] += a["vel"] * delta
		a["life"] = float(a["life"]) - delta
		if a["chain"] and randf() < delta * 40.0:
			_spark(a["pos"], Vector2.ZERO, Color(0.7, 0.9, 1.0, 0.8), 0.25, 3.0)
		var remove: bool = a["life"] <= 0.0
		if not remove:
			for e in enemies:
				if e["hp"] > 0.0 and not a["hit"].has(e["id"]) and a["pos"].distance_to(e["pos"]) < e["radius"] + 6.0:
					a["hit"].append(e["id"])
					_hit_enemy(e, a["dmg"])
					if a["chain"] and chain_cd <= 0.0 and randf() < 0.35:
						chain_cd = 0.06
						var cpos: Vector2 = e["pos"]
						_add_bolt(cpos, 55.0)
						for o in enemies:
							if o != e and o["hp"] > 0.0 and cpos.distance_to(o["pos"]) < 55.0 + o["radius"]:
								_hit_enemy(o, float(a["dmg"]) * 0.6, false)
					a["pierce"] = int(a["pierce"]) - 1
					if a["pierce"] <= 0:
						remove = true
						break
		if remove:
			arrows.remove_at(i)


func _update_eproj(delta: float) -> void:
	for i in range(eproj.size() - 1, -1, -1):
		var b: Dictionary = eproj[i]
		b["pos"] += b["vel"] * delta
		b["life"] = float(b["life"]) - delta
		var bp: Vector2 = b["pos"]
		if randf() < delta * 25.0:
			_spark(bp, Vector2.ZERO, b["col"], 0.25, 2.5)
		if bp.distance_to(player_pos) < float(b["r"]) + 13.0 and invuln <= 0.0:
			_hurt_player(float(b["dmg"]))
			eproj.remove_at(i)
		elif float(b["life"]) <= 0.0 or absf(bp.x) > ARENA + 50.0 or absf(bp.y) > ARENA + 50.0:
			eproj.remove_at(i)


func _update_gems(delta: float) -> void:
	for i in range(gems.size() - 1, -1, -1):
		var g: Dictionary = gems[i]
		var d := player_pos.distance_to(g["pos"])
		if d < magnet_range:
			g["pos"] = (g["pos"] as Vector2).move_toward(player_pos, 420.0 * delta)
		if d < 18.0:
			if g["type"] == "chest":
				gems.remove_at(i)
				_stat_add("chests")
				_popup(player_pos + Vector2(0, -40), "Hazine Sandığı!", Color(1, 0.85, 0.3), 1.0, 24)
				_burst(player_pos, Color(1, 0.85, 0.3), 20, 240.0, 0.6, 3.5)
				_level_up(true)
				return
			if g["type"] == "heal":
				player_hp = minf(player_max_hp, player_hp + player_max_hp * 0.25)
				_popup(player_pos + Vector2(0, -34), "Kımız +can", Color(0.5, 1, 0.6), 0.9)
				_burst(player_pos, Color(0.5, 1, 0.6), 10, 150.0, 0.5, 3.0)
				_play("heal", -2.0)
			else:
				xp += float(g["value"]) * xp_mult
				_burst(player_pos, Color(0.5, 0.95, 1.0), 3, 100.0, 0.25, 2.5)
				_play("gem", -12.0, 0.04)
			gems.remove_at(i)


# ============================================================
#  PARÇACIKLAR VE EFEKTLER
# ============================================================

func _spark(pos: Vector2, vel: Vector2, col: Color, life: float, size: float) -> void:
	if parts.size() >= MAX_PARTS:
		return
	parts.append({"pos": pos, "vel": vel, "life": life, "max": life, "col": col, "size": size, "kind": 0})


func _burst(pos: Vector2, col: Color, n: int, spd: float, life: float, size: float) -> void:
	if parts.size() >= MAX_PARTS:
		return
	for i in n:
		var v := Vector2.from_angle(randf() * TAU) * spd * randf_range(0.4, 1.0)
		var l := life * randf_range(0.6, 1.0)
		parts.append({"pos": pos, "vel": v, "life": l, "max": l, "col": col, "size": size * randf_range(0.6, 1.2), "kind": 0})


func _ring(pos: Vector2, col: Color, r_end: float, life: float) -> void:
	if parts.size() >= MAX_PARTS + 40:
		return
	parts.append({"pos": pos, "vel": Vector2.ZERO, "life": life, "max": life, "col": col, "size": r_end, "kind": 2})


func _update_fx(delta: float) -> void:
	for i in range(popups.size() - 1, -1, -1):
		var p: Dictionary = popups[i]
		p["life"] = float(p["life"]) - delta
		p["pos"] += Vector2(0, -40.0) * delta
		if p["life"] <= 0.0:
			popups.remove_at(i)
	for i in range(fx.size() - 1, -1, -1):
		fx[i]["life"] = float(fx[i]["life"]) - delta
		if fx[i]["life"] <= 0.0:
			fx.remove_at(i)
	var drag := maxf(0.0, 1.0 - 3.0 * delta)
	for i in range(parts.size() - 1, -1, -1):
		var q: Dictionary = parts[i]
		q["life"] = float(q["life"]) - delta
		if q["life"] <= 0.0:
			parts.remove_at(i)
			continue
		q["pos"] += q["vel"] * delta
		q["vel"] *= drag


func _popup(pos: Vector2, text: String, color: Color, life: float = 0.6, fsize: int = 18) -> void:
	popups.append({"pos": pos, "text": text, "color": color, "life": life, "max": life, "size": fsize})


func _show_banner(text: String, col: Color) -> void:
	banner.text = text
	banner.add_theme_color_override("font_color", col)
	banner.modulate.a = 1.0
	if banner_tw != null:
		banner_tw.kill()
	banner_tw = create_tween()
	banner_tw.tween_interval(1.5)
	banner_tw.tween_property(banner, "modulate:a", 0.0, 0.8)


func _zoom_punch(amount: float) -> void:
	if zoom_tw != null:
		zoom_tw.kill()
	cam.zoom = Vector2.ONE
	zoom_tw = create_tween()
	zoom_tw.tween_property(cam, "zoom", Vector2(1.0 + amount, 1.0 + amount), 0.08)
	zoom_tw.tween_property(cam, "zoom", Vector2.ONE, 0.3)


# ============================================================
#  SEVİYE ATLAMA VE EVRİM
# ============================================================

func _available_evos() -> Array:
	var out: Array = []
	for eid in Data.EVO_ORDER:
		if evolved.has(eid):
			continue
		var ev: Dictionary = Data.EVOS[eid]
		if _lv(ev["a"]) >= Data.EVO_MIN_LV and _lv(ev["b"]) >= Data.EVO_MIN_LV:
			out.append(eid)
	return out


func _all_upgrades() -> Array:
	var list: Array = []
	for w in Data.WEAPON_ORDER:
		var wd: Dictionary = Data.WEAPONS[w]
		var lv := _lv(w)
		if wd["evo"]:
			if lv > 0 and lv < MAX_WEAPON_LEVEL:
				list.append({"id": w, "kind": "weapon", "title": "%s (Sv %d)" % [wd["name"], lv + 1], "desc": "Evrim silahını güçlendir"})
		elif not consumed.has(w) and lv < MAX_WEAPON_LEVEL:
			var title := ("%s (YENİ)" % wd["name"]) if lv == 0 else ("%s (Sv %d)" % [wd["name"], lv + 1])
			list.append({"id": w, "kind": "weapon", "title": title, "desc": wd["desc"]})
	list.append({"id": "speed", "kind": "passive", "title": "Bozkır Rüzgarı", "desc": "Hareket hızı +%12"})
	list.append({"id": "hp", "kind": "passive", "title": "Demir Yürek", "desc": "Maksimum can +25 ve 25 can yenile"})
	list.append({"id": "heal", "kind": "passive", "title": "Şifa", "desc": "Canının yarısını yenile"})
	list.append({"id": "magnet", "kind": "passive", "title": "Mıknatıs", "desc": "XP toplama menzili +%50"})
	list.append({"id": "power", "kind": "passive", "title": "Alp Gücü", "desc": "Tüm hasar +%15"})
	list.append({"id": "regen", "kind": "passive", "title": "Yenilenme", "desc": "Saniyede 0.6 can yenile"})
	list.append({"id": "crit", "kind": "passive", "title": "Keskin Göz", "desc": "Kritik vuruş şansı +%6"})
	return list


func _level_up(free: bool = false) -> void:
	if not free:
		xp -= xp_next
		player_level += 1
		xp_next = floorf(xp_next * 1.3 + 3.0)
	var pool := _all_upgrades()
	pool.shuffle()
	choices = []
	var evos := _available_evos()
	if evos.size() > 0:
		var eid: String = evos[0]
		var ev: Dictionary = Data.EVOS[eid]
		var wa: Dictionary = Data.WEAPONS[ev["a"]]
		var wb: Dictionary = Data.WEAPONS[ev["b"]]
		var wn: Dictionary = Data.WEAPONS[eid]
		choices.append({"id": eid, "kind": "evo", "title": "* EVRİM: %s *" % wn["name"],
			"desc": "%s + %s birleşir" % [wa["name"], wb["name"]]})
	for p in pool:
		if choices.size() >= 3:
			break
		choices.append(p)
	levelup_title.text = "Hazine Sandığı! Bir güç seç (1-2-3)" if free else "Seviye %d! Bir güç seç (1-2-3)" % player_level
	for i in level_buttons.size():
		var b: Button = level_buttons[i]
		if i < choices.size():
			b.text = "%s\n%s" % [choices[i]["title"], choices[i]["desc"]]
			b.visible = true
			_style_button(b, choices[i]["kind"] == "evo")
		else:
			b.visible = false
	_play("levelup")
	_ring(player_pos, Color(1, 0.9, 0.4), 160.0, 0.6)
	_burst(player_pos, Color(1, 0.9, 0.4), 16, 220.0, 0.6, 3.5)
	_zoom_punch(0.03)
	_set_state(State.LEVELUP)


func _on_pick(i: int) -> void:
	if state != State.LEVELUP or i >= choices.size():
		return
	var ch: Dictionary = choices[i]
	var cid: String = ch["id"]
	if ch["kind"] == "evo":
		var ev: Dictionary = Data.EVOS[cid]
		wlevel[ev["a"]] = 0
		wlevel[ev["b"]] = 0
		consumed[ev["a"]] = true
		consumed[ev["b"]] = true
		wlevel[cid] = 1
		evolved[cid] = true
		save_data["stats"]["evo_seen"][cid] = true
		tengri_cd = 0.1
		wolves.clear()
		_evolve_fx(cid)
	elif ch["kind"] == "weapon":
		wlevel[cid] = _lv(cid) + 1
		if cid == "thunder":
			thunder_cd = minf(thunder_cd, 0.4)
		if cid == "claw":
			claw_cd = minf(claw_cd, 0.3)
	else:
		match cid:
			"speed":
				player_speed *= 1.12
			"hp":
				player_max_hp += 25.0
				player_hp = minf(player_max_hp, player_hp + 25.0)
			"heal":
				player_hp = minf(player_max_hp, player_hp + player_max_hp * 0.5)
			"magnet":
				magnet_range *= 1.5
			"power":
				dmg_mult += 0.15
			"regen":
				regen += 0.6
			"crit":
				crit_chance += 0.06
	if ch["kind"] != "evo":
		_play("click")
	_set_state(State.PLAYING)


func _evolve_fx(eid: String) -> void:
	var wn: Dictionary = Data.WEAPONS[eid]
	_show_banner("EVRİM! %s" % wn["name"], Color(1, 0.85, 0.3))
	_play("evolve")
	flash_a = 0.7
	shake = 12.0
	_zoom_punch(0.06)
	for k in 3:
		_ring(player_pos, Color(1, 0.85, 0.3), 120.0 + 80.0 * k, 0.5 + 0.2 * k)
	_burst(player_pos, Color(1, 0.9, 0.5), 40, 360.0, 0.9, 4.5)


func _die() -> void:
	var earned := _finish_run()
	var rank_txt := ""
	if last_rank == 1:
		rank_txt = "   * YENİ REKOR! (#1) *"
	elif last_rank > 0:
		rank_txt = "   (Skor tablosu #%d)" % last_rank
	var cn: Dictionary = Data.CHARS[selected_char]
	death_label.text = "%s (%s) düştü!\n\nSüre: %s   Seviye: %d   Öldürülen: %d   Boss: %d   Kombo: %d\nSkor: %d%s\nKazanılan altın: +%d" % [cn["name"], player_name if player_name != "" else "Adsız", _fmt_time(time_alive), player_level, kills, bosses_killed, best_combo, last_score, rank_txt, earned]
	_play("death")
	shake = 14.0
	flash_a = 0.3
	_burst(player_pos, char_color, 30, 300.0, 0.9, 4.5)
	_ring(player_pos, char_color, 200.0, 0.8)
	_set_state(State.DEAD)
	if last_rank == 1:
		_play("score")


func _stat(k: String) -> int:
	return int(save_data["stats"].get(k, 0))


func _stat_add(k: String, n: int = 1) -> void:
	save_data["stats"][k] = _stat(k) + n


func _unlock(id: String) -> void:
	if save_data["ach"].has(id) or not Data.ACH.has(id):
		return
	save_data["ach"][id] = true
	var a: Dictionary = Data.ACH[id]
	save_data["gold"] = int(save_data["gold"]) + int(a["gold"])
	toasts.append("Başarım: %s   (+%d altın)" % [a["name"], int(a["gold"])])
	_play("score", -4.0)
	_write_save()


func _check_ach() -> void:
	var max_w := 0
	for w in Data.WEAPON_ORDER:
		if not Data.WEAPONS[w]["evo"]:
			max_w = maxi(max_w, _lv(w))
	var max_meta := 0
	for k in Data.META_ORDER:
		max_meta = maxi(max_meta, _meta(k))
	var checks := {
		"ilk_av": kills >= 1, "yuz_kafa": kills >= 100, "bes_yuz": kills >= 500,
		"toplam_5k": _stat("kills") >= 5000,
		"ilk_boss": _stat("bosses") >= 1, "boss_25": _stat("bosses") >= 25,
		"tum_devler": save_data["stats"]["boss_seen"].size() >= Data.BOSS_LIST.size(),
		"dk5": time_alive >= 300.0, "dk10": time_alive >= 600.0, "dk15": time_alive >= 900.0,
		"sv20": player_level >= 20, "evrim1": save_data["stats"]["evo_seen"].size() >= 1,
		"evrim3": save_data["stats"]["evo_seen"].size() >= Data.EVO_ORDER.size(),
		"silah8": max_w >= MAX_WEAPON_LEVEL, "sandik10": _stat("chests") >= 10,
		"kombo50": best_combo >= 50, "kombo100": best_combo >= 100,
		"gezgin": save_data["stats"]["stage_played"].size() >= Data.STAGE_ORDER.size(),
		"her_karakter": save_data["stats"]["char_played"].size() >= Data.CHAR_ORDER.size(),
		"ocak_ustasi": max_meta >= MAX_META, "zengin": int(save_data["gold"]) >= 5000,
	}
	for id in checks:
		if checks[id]:
			_unlock(id)


func _update_toast(delta: float) -> void:
	if toast_t > 0.0:
		toast_t -= delta
		toast_label.modulate.a = clampf(toast_t / 0.5, 0.0, 1.0)
		if toast_t <= 0.0:
			toast_label.visible = false
	elif toasts.size() > 0:
		toast_label.text = toasts.pop_front()
		toast_label.visible = true
		toast_label.modulate.a = 1.0
		toast_t = 3.2


func _refresh_ach() -> void:
	for c in ach_vb.get_children():
		ach_vb.remove_child(c)
		c.queue_free()
	var done := 0
	for id in Data.ACH_ORDER:
		var a: Dictionary = Data.ACH[id]
		var got: bool = save_data["ach"].has(id)
		if got:
			done += 1
		var l := _mk_label("%s %s  -  %s  (+%d)" % ["[x]" if got else "[  ]", a["name"], a["desc"], int(a["gold"])], 17)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		l.modulate = Color(0.55, 1.0, 0.6) if got else Color(1, 1, 1, 0.55)
		ach_vb.add_child(l)
	ach_head.text = "Başarımlar: %d/%d   |   Toplam öldürme: %d   Boss: %d   Sandık: %d   Koşu: %d" % [done, Data.ACH_ORDER.size(), _stat("kills"), _stat("bosses"), _stat("chests"), _stat("runs")]


func _fmt_time(sec: float) -> String:
	var t := int(sec)
	return "%02d:%02d" % [floori(t / 60.0), t % 60]


# ============================================================
#  MENÜ, SAYFALAR VE BUTON OLAYLARI
# ============================================================

func _show_page(p: String, click: bool = true) -> void:
	if click:
		_play("click")
	menu_page = p
	for key in pages:
		pages[key].visible = key == p
	_refresh_menu()


func _on_start_pressed() -> void:
	if name_edit != null:
		name_edit.release_focus()
	_play("click")
	_start_run()


func _on_char_pressed(id: String) -> void:
	var c: Dictionary = Data.CHARS[id]
	if save_data["chars"].has(id):
		selected_char = id
		chars_msg.text = ""
		_play("click")
	elif int(save_data["gold"]) >= int(c["cost"]):
		save_data["gold"] = int(save_data["gold"]) - int(c["cost"])
		save_data["chars"][id] = true
		selected_char = id
		chars_msg.text = "%s açıldı!" % c["name"]
		_play("buy")
	else:
		chars_msg.text = "Yetersiz altın: %d gerekli" % int(c["cost"])
		_play("error")
	_write_save()
	_refresh_menu()


func _on_stage_pressed(id: String) -> void:
	var s: Dictionary = Data.STAGES[id]
	if save_data["stages"].has(id):
		stage_id = id
		stages_msg.text = ""
		_play("click")
	elif int(save_data["gold"]) >= int(s["cost"]):
		save_data["gold"] = int(save_data["gold"]) - int(s["cost"])
		save_data["stages"][id] = true
		stage_id = id
		stages_msg.text = "%s açıldı!" % s["name"]
		_play("buy")
	else:
		stages_msg.text = "Yetersiz altın: %d gerekli" % int(s["cost"])
		_play("error")
	_write_save()
	_refresh_menu()


func _on_meta_pressed(key: String) -> void:
	var lvl := _meta(key)
	var cost := _meta_cost(key)
	if lvl >= MAX_META:
		_play("error")
	elif int(save_data["gold"]) >= cost:
		save_data["gold"] = int(save_data["gold"]) - cost
		save_data["meta"][key] = lvl + 1
		_play("buy")
		_write_save()
	else:
		_play("error")
	_refresh_menu()


func _on_quit_run() -> void:
	_finish_run()
	_play("click")
	_set_state(State.MENU)


func _on_death_menu() -> void:
	_play("click")
	_set_state(State.MENU)


func _refresh_menu() -> void:
	var gold := int(save_data["gold"])
	var cn: Dictionary = Data.CHARS[selected_char]
	var sn: Dictionary = Data.STAGES[stage_id]
	gold_label.text = "Altın: %d" % gold
	chars_gold.text = "Altın: %d" % gold
	stages_gold.text = "Altın: %d" % gold
	shop_gold_label.text = "Altın: %d" % gold
	menu_summary.text = "Karakter: %s   |   Bölge: %s" % [cn["name"], sn["name"]]
	for id in Data.CHAR_ORDER:
		var c: Dictionary = Data.CHARS[id]
		var b: Button = char_buttons[id]
		var status := ""
		if not save_data["chars"].has(id):
			status = "KİLİTLİ - %d altın" % int(c["cost"])
		elif id == selected_char:
			status = "[ SEÇİLİ ]"
		else:
			status = "Seçmek için tıkla"
		b.text = "%s\n%s\nCan %d  Hız %d\n%s" % [c["name"], c["desc"], int(c["hp"]), int(c["speed"]), status]
		_style_button(b, id == selected_char)
	for id in Data.STAGE_ORDER:
		var s: Dictionary = Data.STAGES[id]
		var b2: Button = stage_buttons[id]
		var status2 := ""
		if not save_data["stages"].has(id):
			status2 = "KİLİTLİ - %d altın" % int(s["cost"])
		elif id == stage_id:
			status2 = "[ SEÇİLİ ]"
		else:
			status2 = "Seçmek için tıkla"
		b2.text = "%s   -   %s\n%s" % [s["name"], status2, s["desc"]]
		_style_button(b2, id == stage_id)
	for key in Data.META_ORDER:
		var d: Dictionary = Data.META[key]
		var lvl := _meta(key)
		var b3: Button = shop_buttons[key]
		if lvl >= MAX_META:
			b3.text = "%s  [MAKS %d/%d]\n%s" % [d["name"], lvl, MAX_META, d["desc"]]
		else:
			b3.text = "%s  [%d/%d]  -  %d altın\n%s" % [d["name"], lvl, MAX_META, _meta_cost(key), d["desc"]]
	best_label.text = "En iyi süre: %s   |   En çok öldürme: %d" % [_fmt_time(float(save_data["best_time"])), int(save_data["best_kills"])]
	music_button.text = "Müzik: Açık (M)" if music_on else "Müzik: Kapalı (M)"
	sound_button.text = "Ses efektleri: Açık (N)" if sound_on else "Ses efektleri: Kapalı (N)"
	fs_button.text = "Tam ekran: Açık (F11)" if fullscreen_on else "Tam ekran: Kapalı (F11)"
	music_pct.text = "Müzik sesi: %d%%" % int(round(music_vol * 100.0))
	sfx_pct.text = "Efekt sesi: %d%%" % int(round(sfx_vol * 100.0))
	music_slider.set_value_no_signal(music_vol)
	sfx_slider.set_value_no_signal(sfx_vol)
	_refresh_scores()
	_refresh_ach()


func _refresh_scores() -> void:
	for c in score_grid.get_children():
		score_grid.remove_child(c)
		c.queue_free()
	var widths := [40.0, 140.0, 100.0, 150.0, 150.0, 80.0]
	var heads := ["#", "İsim", "Skor", "Karakter", "Bölge", "Süre"]
	for i in 6:
		var h := _mk_label(heads[i], 18)
		h.custom_minimum_size = Vector2(widths[i], 0)
		h.modulate = Color(1.0, 0.85, 0.3)
		score_grid.add_child(h)
	var list: Array = save_data["scores"]
	for r in 10:
		var cells: Array = []
		if r < list.size():
			var en: Dictionary = list[r]
			var chn := str(en["char"])
			var stn := str(en["stage"])
			var pn := str(en.get("name", ""))
			cells = ["%d" % (r + 1), pn if pn != "" else "Adsız", str(int(en["score"])),
				str(Data.CHARS[chn]["name"]) if Data.CHARS.has(chn) else chn,
				str(Data.STAGES[stn]["name"]) if Data.STAGES.has(stn) else stn,
				_fmt_time(float(en["time"]))]
		else:
			cells = ["%d" % (r + 1), "-", "-", "-", "-", "-"]
		for i in 6:
			var l := _mk_label(str(cells[i]), 17)
			l.custom_minimum_size = Vector2(widths[i], 0)
			if r >= list.size():
				l.modulate = Color(1, 1, 1, 0.35)
			score_grid.add_child(l)


# ============================================================
#  ARAYÜZ KURULUMU
# ============================================================

func _mk_label(text: String, font_size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


func _box(bg: Color, border: Color, border_w: int) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(border_w)
	sb.set_corner_radius_all(8)
	sb.content_margin_left = 10
	sb.content_margin_right = 10
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6
	return sb


func _style_button(b: Button, selected: bool = false) -> void:
	if selected:
		b.add_theme_stylebox_override("normal", _box(Color(0.24, 0.21, 0.1), Color(1.0, 0.85, 0.3), 3))
	else:
		b.add_theme_stylebox_override("normal", _box(Color(0.17, 0.2, 0.28), Color(0.35, 0.4, 0.55), 1))
	b.add_theme_stylebox_override("hover", _box(Color(0.25, 0.3, 0.42), Color(0.6, 0.7, 0.95), 2))
	b.add_theme_stylebox_override("pressed", _box(Color(0.12, 0.15, 0.22), Color(0.6, 0.7, 0.95), 2))


func _mk_button(text: String, w: float, h: float, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(w, h)
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	_style_button(b)
	return b


func _mk_slider(cb: Callable) -> HSlider:
	var sl := HSlider.new()
	sl.min_value = 0.0
	sl.max_value = 1.0
	sl.step = 0.05
	sl.custom_minimum_size = Vector2(420, 26)
	sl.focus_mode = Control.FOCUS_NONE
	sl.value_changed.connect(cb)
	return sl


func _set_music_vol(v: float) -> void:
	music_vol = v
	music_player.volume_db = -12.0 + _vol_db(music_vol)
	_write_save()
	_refresh_menu()


func _set_sfx_vol(v: float) -> void:
	sfx_vol = v
	_write_save()
	_refresh_menu()
	_play("click")


func _on_name_changed(t: String) -> void:
	player_name = t.strip_edges().left(12)
	save_data["name"] = player_name
	_write_save()


func _apply_fullscreen() -> void:
	if fullscreen_on:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)


func _toggle_fullscreen() -> void:
	fullscreen_on = not fullscreen_on
	_apply_fullscreen()
	_write_save()
	_refresh_menu()


func _input(event: InputEvent) -> void:
	var mb := event as InputEventMouseButton
	if mb != null and mb.pressed and name_edit != null and name_edit.has_focus():
		if not name_edit.get_global_rect().has_point(mb.position):
			name_edit.release_focus()


func _mk_panel(sep: int) -> Dictionary:
	var wrap := CenterContainer.new()
	wrap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(wrap)
	wrap.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _box(Color(0.06, 0.07, 0.1, 0.97), Color(0.35, 0.4, 0.55), 2))
	wrap.add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 18)
	panel.add_child(margin)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", sep)
	margin.add_child(vb)
	return {"wrap": wrap, "vb": vb}


func _mk_overlay(col: Color) -> ColorRect:
	var r := ColorRect.new()
	r.color = col
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(r)
	r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	return r


func _build_ui() -> void:
	ui = CanvasLayer.new()
	add_child(ui)

	tint_rect = _mk_overlay(Color(0, 0, 0, 0))
	hurt_rect = _mk_overlay(Color(0.8, 0.05, 0.05, 0))
	flash_rect = _mk_overlay(Color(1, 1, 1, 0))

	# --- HUD ---
	hud = Control.new()
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	xp_bar = ProgressBar.new()
	xp_bar.show_percentage = false
	xp_bar.custom_minimum_size = Vector2(0, 16)
	var xp_fill := StyleBoxFlat.new()
	xp_fill.bg_color = Color(0.3, 0.6, 1.0)
	xp_bar.add_theme_stylebox_override("fill", xp_fill)
	hud.add_child(xp_bar)
	xp_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)

	info_label = Label.new()
	info_label.position = Vector2(12, 22)
	info_label.add_theme_font_size_override("font_size", 20)
	hud.add_child(info_label)

	weapon_label = Label.new()
	weapon_label.position = Vector2(12, 50)
	weapon_label.add_theme_font_size_override("font_size", 16)
	weapon_label.modulate = Color(1, 1, 1, 0.8)
	hud.add_child(weapon_label)

	boss_label = _mk_label("", 18)
	boss_label.position = Vector2(440, 76)
	boss_label.custom_minimum_size = Vector2(400, 0)
	hud.add_child(boss_label)

	boss_bar = ProgressBar.new()
	boss_bar.show_percentage = false
	boss_bar.position = Vector2(440, 100)
	boss_bar.custom_minimum_size = Vector2(400, 14)
	var boss_fill := StyleBoxFlat.new()
	boss_fill.bg_color = Color(0.85, 0.15, 0.2)
	boss_bar.add_theme_stylebox_override("fill", boss_fill)
	hud.add_child(boss_bar)

	hp_bar = ProgressBar.new()
	hp_bar.show_percentage = false
	hp_bar.custom_minimum_size = Vector2(0, 18)
	var hp_fill := StyleBoxFlat.new()
	hp_fill.bg_color = Color(0.85, 0.2, 0.2)
	hp_bar.add_theme_stylebox_override("fill", hp_fill)
	hud.add_child(hp_bar)
	hp_bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)

	banner = _mk_label("", 54)
	banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	banner.add_theme_constant_override("outline_size", 8)
	hud.add_child(banner)
	banner.anchor_right = 1.0
	banner.offset_top = 150.0
	banner.offset_bottom = 230.0
	banner.modulate.a = 0.0

	# --- Seviye atlama ---
	var lp := _mk_panel(10)
	levelup_wrap = lp["wrap"]
	var lvb: VBoxContainer = lp["vb"]
	levelup_title = _mk_label("", 26)
	lvb.add_child(levelup_title)
	for i in 3:
		var b := _mk_button("", 520, 66, _on_pick.bind(i))
		lvb.add_child(b)
		level_buttons.append(b)

	# --- Duraklatma ---
	var pp := _mk_panel(12)
	pause_wrap = pp["wrap"]
	var pvb: VBoxContainer = pp["vb"]
	pvb.add_child(_mk_label("Duraklatıldı", 30))
	pvb.add_child(_mk_button("Devam Et (ESC)", 320, 52, func(): _set_state(State.PLAYING)))
	pvb.add_child(_mk_button("Koşuyu Bitir ve Menüye Dön", 320, 52, _on_quit_run))

	# --- Ölüm ---
	var dp := _mk_panel(14)
	death_wrap = dp["wrap"]
	var dvb: VBoxContainer = dp["vb"]
	death_label = _mk_label("", 22)
	dvb.add_child(death_label)
	dvb.add_child(_mk_button("Yeniden Başla (R)", 320, 54, _on_start_pressed))
	dvb.add_child(_mk_button("Menüye Dön", 320, 54, _on_death_menu))

	# --- Ana menü ---
	var mp := _mk_panel(8)
	pages["main"] = mp["wrap"]
	var mvb: VBoxContainer = mp["vb"]
	mvb.add_child(_mk_label("BOZKURT SURVIVORS", 44))
	menu_summary = _mk_label("", 17)
	mvb.add_child(menu_summary)
	gold_label = _mk_label("", 22)
	gold_label.modulate = Color(1.0, 0.85, 0.3)
	mvb.add_child(gold_label)
	mvb.add_child(_mk_button("BAŞLA (Enter)", 340, 58, _on_start_pressed))
	mvb.add_child(_mk_button("Karakter Seç", 340, 44, _show_page.bind("chars")))
	mvb.add_child(_mk_button("Bölge Seç", 340, 44, _show_page.bind("stages")))
	mvb.add_child(_mk_button("Ocak (Kalıcı Yükseltmeler)", 340, 44, _show_page.bind("shop")))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(_mk_button("Skor Tablosu", 166, 44, _show_page.bind("scores")))
	row.add_child(_mk_button("Başarımlar", 166, 44, _show_page.bind("ach")))
	mvb.add_child(row)
	mvb.add_child(_mk_button("Ayarlar (Ses / Tam Ekran)", 340, 44, _show_page.bind("settings")))
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "Adını yaz (skor tablosu için)"
	name_edit.max_length = 12
	name_edit.alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_edit.custom_minimum_size = Vector2(340, 38)
	name_edit.text = player_name
	name_edit.text_changed.connect(_on_name_changed)
	name_edit.text_submitted.connect(func(_t: String): name_edit.release_focus())
	mvb.add_child(name_edit)
	if not OS.has_feature("web"):
		mvb.add_child(_mk_button("Çıkış", 340, 38, func(): get_tree().quit()))
	best_label = _mk_label("", 15)
	best_label.modulate = Color(1, 1, 1, 0.7)
	mvb.add_child(best_label)

	# --- Karakter sayfası ---
	var cp := _mk_panel(10)
	pages["chars"] = cp["wrap"]
	var cvb: VBoxContainer = cp["vb"]
	cvb.add_child(_mk_label("KARAKTER SEÇ", 34))
	chars_gold = _mk_label("", 20)
	chars_gold.modulate = Color(1.0, 0.85, 0.3)
	cvb.add_child(chars_gold)
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	cvb.add_child(grid)
	for id in Data.CHAR_ORDER:
		var cb := _mk_button("", 215, 136, _on_char_pressed.bind(id))
		cb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		cb.add_theme_font_size_override("font_size", 15)
		grid.add_child(cb)
		char_buttons[id] = cb
	chars_msg = _mk_label("", 16)
	chars_msg.modulate = Color(1.0, 0.6, 0.4)
	cvb.add_child(chars_msg)
	cvb.add_child(_mk_button("Geri (ESC)", 300, 44, _show_page.bind("main")))

	# --- Bölge sayfası ---
	var sp := _mk_panel(8)
	pages["stages"] = sp["wrap"]
	var svb: VBoxContainer = sp["vb"]
	svb.add_child(_mk_label("BÖLGE SEÇ", 34))
	stages_gold = _mk_label("", 20)
	stages_gold.modulate = Color(1.0, 0.85, 0.3)
	svb.add_child(stages_gold)
	for id in Data.STAGE_ORDER:
		var sb := _mk_button("", 660, 54, _on_stage_pressed.bind(id))
		sb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		svb.add_child(sb)
		stage_buttons[id] = sb
	stages_msg = _mk_label("", 16)
	stages_msg.modulate = Color(1.0, 0.6, 0.4)
	svb.add_child(stages_msg)
	svb.add_child(_mk_button("Geri (ESC)", 300, 44, _show_page.bind("main")))

	# --- Ocak ---
	var hp2 := _mk_panel(8)
	pages["shop"] = hp2["wrap"]
	var hvb: VBoxContainer = hp2["vb"]
	hvb.add_child(_mk_label("OCAK", 36))
	hvb.add_child(_mk_label("Altınla kalıcı güçlen", 16))
	shop_gold_label = _mk_label("", 22)
	shop_gold_label.modulate = Color(1.0, 0.85, 0.3)
	hvb.add_child(shop_gold_label)
	for key in Data.META_ORDER:
		var mb := _mk_button("", 460, 56, _on_meta_pressed.bind(key))
		hvb.add_child(mb)
		shop_buttons[key] = mb
	hvb.add_child(_mk_button("Geri (ESC)", 460, 46, _show_page.bind("main")))

	# --- Ayarlar ---
	var gp := _mk_panel(10)
	pages["settings"] = gp["wrap"]
	var gvb: VBoxContainer = gp["vb"]
	gvb.add_child(_mk_label("AYARLAR", 34))
	fs_button = _mk_button("", 420, 44, _toggle_fullscreen)
	gvb.add_child(fs_button)
	music_button = _mk_button("", 420, 40, _toggle_music)
	gvb.add_child(music_button)
	music_pct = _mk_label("", 16)
	gvb.add_child(music_pct)
	music_slider = _mk_slider(func(v: float): _set_music_vol(v))
	gvb.add_child(music_slider)
	sound_button = _mk_button("", 420, 40, _toggle_sound)
	gvb.add_child(sound_button)
	sfx_pct = _mk_label("", 16)
	gvb.add_child(sfx_pct)
	sfx_slider = _mk_slider(func(v: float): _set_sfx_vol(v))
	gvb.add_child(sfx_slider)
	gvb.add_child(_mk_button("Geri (ESC)", 300, 44, _show_page.bind("main")))

	# --- Başarımlar ---
	var ap := _mk_panel(8)
	pages["ach"] = ap["wrap"]
	var avb: VBoxContainer = ap["vb"]
	avb.add_child(_mk_label("BAŞARIMLAR", 34))
	ach_head = _mk_label("", 16)
	ach_head.modulate = Color(1.0, 0.85, 0.3)
	avb.add_child(ach_head)
	var asc := ScrollContainer.new()
	asc.custom_minimum_size = Vector2(760, 400)
	asc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	avb.add_child(asc)
	ach_vb = VBoxContainer.new()
	ach_vb.add_theme_constant_override("separation", 6)
	ach_vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	asc.add_child(ach_vb)
	avb.add_child(_mk_button("Geri (ESC)", 300, 44, _show_page.bind("main")))

	toast_label = _mk_label("", 22)
	toast_label.add_theme_color_override("font_color", Color(1, 0.88, 0.35))
	toast_label.add_theme_constant_override("outline_size", 6)
	toast_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_label.visible = false
	ui.add_child(toast_label)
	toast_label.anchor_left = 0.0
	toast_label.anchor_right = 1.0
	toast_label.anchor_top = 1.0
	toast_label.anchor_bottom = 1.0
	toast_label.offset_top = -86.0
	toast_label.offset_bottom = -50.0

	# --- Skor tablosu ---
	var tp := _mk_panel(10)
	pages["scores"] = tp["wrap"]
	var tvb: VBoxContainer = tp["vb"]
	tvb.add_child(_mk_label("SKOR TABLOSU", 34))
	score_grid = GridContainer.new()
	score_grid.columns = 6
	score_grid.add_theme_constant_override("h_separation", 6)
	score_grid.add_theme_constant_override("v_separation", 4)
	tvb.add_child(score_grid)
	tvb.add_child(_mk_button("Geri (ESC)", 300, 44, _show_page.bind("main")))


func _update_ui() -> void:
	flash_rect.color = Color(1, 1, 1, clampf(flash_a, 0.0, 0.85))
	var low := 0.0
	if state == State.PLAYING and player_hp < player_max_hp * 0.3:
		low = 0.1 + 0.07 * sin(anim_t * 6.0)
	hurt_rect.color = Color(0.8, 0.05, 0.05, clampf(hurt_a * 0.5 + low, 0.0, 0.7))
	if state == State.MENU:
		return
	xp_bar.max_value = xp_next
	xp_bar.value = xp
	hp_bar.max_value = player_max_hp
	hp_bar.value = maxf(player_hp, 0.0)
	var sn: Dictionary = Data.STAGES[stage_id]
	info_label.text = "Seviye %d   |   Süre %s   |   Öldürülen %d   |   Can %d/%d   |   %s%s" % [player_level, _fmt_time(time_alive), kills, int(maxf(player_hp, 0.0)), int(player_max_hp), sn["name"], ("   |   KOMBO x%d" % combo) if combo >= 5 else ""]
	var wparts: Array = []
	for w in Data.WEAPON_ORDER:
		if _lv(w) > 0:
			var wd: Dictionary = Data.WEAPONS[w]
			wparts.append("%s %d" % [wd["name"], _lv(w)])
	weapon_label.text = "  •  ".join(wparts)
	var boss = null
	for e in enemies:
		if e["kind"] == "boss" and e["hp"] > 0.0:
			boss = e
			break
	boss_label.visible = boss != null
	boss_bar.visible = boss != null
	if boss != null:
		boss_label.text = boss["name"]
		boss_bar.max_value = boss["max_hp"]
		boss_bar.value = maxf(boss["hp"], 0.0)


# ============================================================
#  ÇİZİM - BÖLGE
# ============================================================

func _draw() -> void:
	if state == State.MENU:
		_draw_menu_bg()
		return
	var font := ThemeDB.fallback_font
	var st: Dictionary = Data.STAGES[stage_id]
	_draw_ground(st)
	_draw_decor()
	_draw_pools()
	_draw_strikes()

	# Ateş aurası
	if _lv("aura") > 0:
		var ar := _aura_radius()
		var pulse := 1.0 + 0.04 * sin(anim_t * 6.0)
		draw_circle(player_pos, ar * pulse, Color(1.0, 0.45, 0.1, 0.12))
		draw_arc(player_pos, ar * pulse, 0.0, TAU, 48, Color(1.0, 0.5, 0.15, 0.55), 2.0)

	var bfl := _lv("buzfirtina")
	if bfl > 0:
		var bar := (150.0 + 18.0 * bfl) * (1.0 + 0.04 * sin(anim_t * 5.0))
		draw_circle(player_pos, bar, Color(0.6, 0.85, 1.0, 0.1))
		draw_arc(player_pos, bar, 0.0, TAU, 56, Color(0.8, 0.95, 1.0, 0.6), 2.5)
		draw_arc(player_pos, bar * 0.8, anim_t, anim_t + 2.4, 20, Color(1.0, 0.55, 0.2, 0.55), 3.0)

	# Kristaller ve kımız
	for g in gems:
		var gp: Vector2 = g["pos"]
		if absf(gp.x - player_pos.x) > vw * 0.5 or absf(gp.y - player_pos.y) > vh * 0.5:
			continue
		var gb := sin(anim_t * 5.0 + gp.x * 0.05) * 2.0
		if g["type"] == "chest":
			var cb := gp + Vector2(0, gb)
			draw_circle(cb, 20.0, Color(1, 0.85, 0.3, 0.18 + 0.1 * sin(anim_t * 5.0)))
			draw_rect(Rect2(cb + Vector2(-12, -8), Vector2(24, 18)), Color(0.55, 0.33, 0.12))
			draw_rect(Rect2(cb + Vector2(-12, -8), Vector2(24, 7)), Color(0.7, 0.45, 0.15))
			draw_rect(Rect2(cb + Vector2(-2, -4), Vector2(4, 8)), Color(1, 0.85, 0.3))
			draw_rect(Rect2(cb + Vector2(-12, -8), Vector2(24, 18)), Color(1, 0.85, 0.3), false, 1.5)
		elif g["type"] == "heal":
			draw_circle(gp + Vector2(0, gb), 9.0, Color(0.95, 0.95, 0.85))
			draw_circle(gp + Vector2(0, gb), 6.0, Color(0.4, 0.9, 0.5))
			draw_line(gp + Vector2(-4, gb), gp + Vector2(4, gb), Color.WHITE, 2.0)
			draw_line(gp + Vector2(0, gb - 4), gp + Vector2(0, gb + 4), Color.WHITE, 2.0)
		else:
			var big: bool = g["value"] >= 5
			var gc := Color(1.0, 0.85, 0.3) if big else Color(0.4, 0.9, 1.0)
			var gr := (8.0 if big else 5.0) + sin(anim_t * 7.0 + gp.y * 0.07) * 0.9
			draw_circle(gp + Vector2(0, gb), gr + 4.0, Color(gc.r, gc.g, gc.b, 0.18))
			draw_circle(gp + Vector2(0, gb), gr, gc)
			draw_circle(gp + Vector2(-gr * 0.3, gb - gr * 0.3), gr * 0.3, Color(1, 1, 1, 0.8))

	# Düşmanlar
	for e in enemies:
		_draw_enemy(e)
		if float(e["slow"]) > 0.0:
			draw_arc(e["pos"], float(e["radius"]) + 4.0, 0.0, TAU, 16, Color(0.6, 0.9, 1.0, 0.75), 2.0)

	# Düşman mermileri
	for b in eproj:
		var bp: Vector2 = b["pos"]
		var bc: Color = b["col"]
		draw_circle(bp, 11.0, Color(bc.r, bc.g, bc.b, 0.25))
		draw_circle(bp, 6.0, bc)
		draw_circle(bp, 3.0, Color(1, 1, 1, 0.9))

	# Yoldaş kurtlar
	var sl := _lv("suru")
	for w in wolves:
		var wp: Vector2 = w["pos"]
		var wdir: Vector2 = w["dir"]
		var gcol := Color(0.6, 0.85, 1.0, 0.85) if sl > 0 else Color(0.85, 0.8, 0.7, 0.95)
		var leg := sin(anim_t * 20.0 + float(w["phase"])) * 4.0
		draw_circle(wp - wdir * 9.0, 8.0, gcol)
		draw_circle(wp, 9.0, gcol)
		draw_circle(wp + wdir * 10.0, 6.0, gcol.darkened(0.15))
		var wo := wdir.orthogonal()
		draw_colored_polygon(PackedVector2Array([wp + wdir * 8.0 + wo * 5.0, wp + wdir * 4.0 + wo * 11.0, wp + wdir * 1.0 + wo * 5.0]), gcol.darkened(0.3))
		draw_colored_polygon(PackedVector2Array([wp + wdir * 8.0 - wo * 5.0, wp + wdir * 4.0 - wo * 11.0, wp + wdir * 1.0 - wo * 5.0]), gcol.darkened(0.3))
		draw_line(wp - wdir * 15.0, wp - wdir * 24.0 + wo * leg, gcol, 3.0)
		draw_circle(wp + wdir * 13.0 + wo * 2.5, 1.6, Color(1, 0.2, 0.2))
		draw_circle(wp + wdir * 13.0 - wo * 2.5, 1.6, Color(1, 0.2, 0.2))

	# Oklar
	for a in arrows:
		var v: Vector2 = (a["vel"] as Vector2).normalized()
		var ap: Vector2 = a["pos"]
		if a.get("spear", false):
			draw_line(ap, ap - v * 52.0, Color(0.85, 0.9, 1.0, 0.25), 7.0)
			draw_line(ap, ap - v * 40.0, Color(0.55, 0.38, 0.22), 3.0)
			var sv := v.orthogonal()
			draw_colored_polygon(PackedVector2Array([ap + v * 16.0, ap + sv * 5.0, ap - sv * 5.0]), Color(0.9, 0.93, 1.0))
		elif a["chain"]:
			draw_line(ap, ap - v * 30.0, Color(0.5, 0.8, 1.0, 0.4), 7.0)
			draw_line(ap, ap - v * 24.0, Color(0.8, 0.95, 1.0), 3.5)
			draw_circle(ap, 4.5, Color.WHITE)
		else:
			draw_line(ap, ap - v * 22.0, Color(1.0, 0.8, 0.3, 0.35), 5.0)
			draw_line(ap, ap - v * 16.0, Color(1.0, 0.9, 0.5), 3.0)
			draw_circle(ap, 3.0, Color(1.0, 1.0, 0.8))

	# Baltalar
	for ax in axes:
		var axp: Vector2 = ax["pos"]
		var adv := Vector2.from_angle(float(ax["rot"]))
		var apv := adv.orthogonal()
		draw_circle(axp, 20.0, Color(1, 1, 1, 0.08))
		draw_line(axp - adv * 13.0, axp + adv * 13.0, Color(0.55, 0.4, 0.25), 4.0)
		draw_colored_polygon(PackedVector2Array([axp + adv * 13.0, axp + adv * 5.0 + apv * 14.0, axp - adv * 3.0 + apv * 8.0]), Color(0.82, 0.86, 0.92))
		draw_colored_polygon(PackedVector2Array([axp + adv * 13.0, axp + adv * 5.0 - apv * 14.0, axp - adv * 3.0 - apv * 8.0]), Color(0.82, 0.86, 0.92))

	# Kılıçlar
	var orbit := _lv("orbit")
	if orbit > 0:
		var on := orbit + 1
		for i in on:
			_draw_sword(orbit_angle + TAU * i / on, 85.0, Color(0.85, 0.9, 1.0), 0.5)
	var alev := _lv("alev")
	if alev > 0:
		var an := 5 + int(alev / 2.0)
		for i in an:
			_draw_sword(orbit_angle * 1.15 + TAU * i / an, 112.0 + 3.0 * alev, Color(1.0, 0.65, 0.25), 0.8)

	# Efektler (yıldırım, pençe)
	for f in fx:
		var k: float = clampf(f["life"] / f["max"], 0.0, 1.0)
		if f["kind"] == "bolt":
			var pts: PackedVector2Array = f["pts"]
			draw_circle(f["pos"], f["r"] * (1.4 - k * 0.4), Color(0.7, 0.85, 1.0, 0.35 * k))
			draw_polyline(pts, Color(0.75, 0.9, 1.0, k), 5.0)
			draw_polyline(pts, Color(1, 1, 1, k), 2.0)
		elif f["kind"] == "frost":
			var frr: float = float(f["r"]) * (1.0 - k * k)
			draw_circle(player_pos, frr, Color(0.6, 0.85, 1.0, 0.18 * k))
			draw_arc(player_pos, frr, 0.0, TAU, 48, Color(0.85, 0.95, 1.0, k), 4.0)
		elif f["kind"] == "claw":
			var a0: float = f["dir"]
			var rr: float = f["range"]
			for j in 3:
				draw_arc(player_pos, rr * (0.62 + 0.19 * j), a0 - 0.95, a0 + 0.95, 20, Color(1.0, 0.95, 0.7, k), 5.0 - j)

	_draw_player()

	# Parçacıklar
	for q in parts:
		var qk: float = clampf(float(q["life"]) / float(q["max"]), 0.0, 1.0)
		var qc: Color = q["col"]
		qc.a *= qk
		if int(q["kind"]) == 2:
			draw_arc(q["pos"], float(q["size"]) * (1.0 - qk), 0.0, TAU, 28, qc, 3.0)
		else:
			draw_circle(q["pos"], float(q["size"]) * (0.4 + 0.6 * qk), qc)

	# Hasar yazıları
	for pp in popups:
		var c: Color = pp["color"]
		c.a = clampf(pp["life"] / pp["max"] * 1.5, 0.0, 1.0)
		draw_string(font, pp["pos"], pp["text"], HORIZONTAL_ALIGNMENT_CENTER, -1, int(pp["size"]), c)

	_draw_ambient()


func _draw_sword(ang: float, dist: float, col: Color, glow: float) -> void:
	var radial := Vector2.from_angle(ang)
	var sp := player_pos + radial * dist
	for t in 4:
		var ta := ang - 0.12 * (t + 1)
		var tp := player_pos + Vector2.from_angle(ta) * dist
		draw_circle(tp, 5.0 - t, Color(col.r, col.g, col.b, glow * 0.25 / (t + 1)))
	draw_line(sp - radial * 12.0, sp + radial * 12.0, col, 5.0)
	draw_circle(sp + radial * 12.0, 4.0, Color.WHITE)


func _draw_ground(st: Dictionary) -> void:
	var gcol: Color = st["ground"]
	draw_rect(Rect2(-ARENA, -ARENA, ARENA * 2.0, ARENA * 2.0), gcol)
	var grid: Color = st["grid"]
	if grid.a > 0.0:
		var step := 120.0
		var gx := floorf((player_pos.x - (vw * 0.5 + 100.0)) / step) * step
		while gx < player_pos.x + (vw * 0.5 + 100.0):
			if gx >= -ARENA and gx <= ARENA:
				draw_line(Vector2(gx, maxf(-ARENA, player_pos.y - (vh * 0.5 + 100.0))), Vector2(gx, minf(ARENA, player_pos.y + (vh * 0.5 + 100.0))), grid, 1.0)
			gx += step
		var gy := floorf((player_pos.y - (vh * 0.5 + 100.0)) / step) * step
		while gy < player_pos.y + (vh * 0.5 + 100.0):
			if gy >= -ARENA and gy <= ARENA:
				draw_line(Vector2(maxf(-ARENA, player_pos.x - (vw * 0.5 + 100.0)), gy), Vector2(minf(ARENA, player_pos.x + (vw * 0.5 + 100.0)), gy), grid, 1.0)
			gy += step
	var edge: Color = st["edge"]
	draw_rect(Rect2(-ARENA, -ARENA, ARENA * 2.0, ARENA * 2.0), edge, false, 6.0)


func _draw_decor() -> void:
	var cell := 170.0
	var x0 := floori((player_pos.x - (vw * 0.5 + 100.0)) / cell)
	var x1 := floori((player_pos.x + (vw * 0.5 + 100.0)) / cell)
	var y0 := floori((player_pos.y - (vh * 0.5 + 80.0)) / cell)
	var y1 := floori((player_pos.y + (vh * 0.5 + 120.0)) / cell)
	for ix in range(x0, x1 + 1):
		for iy in range(y0, y1 + 1):
			if _hash2(ix, iy, stage_salt) > 0.5:
				continue
			var pos := Vector2((ix + _hash2(ix, iy, 1)) * cell, (iy + _hash2(ix, iy, 2)) * cell)
			if absf(pos.x) > ARENA or absf(pos.y) > ARENA:
				continue
			var h := _hash2(ix, iy, 4)
			match stage_id:
				"bozkir":
					if h < 0.75:
						var sw := sin(anim_t * 2.0 + pos.x) * 2.0
						var gc := Color(0.35, 0.5, 0.25, 0.7)
						draw_line(pos, pos + Vector2(-4 + sw, -10), gc, 1.5)
						draw_line(pos, pos + Vector2(0 + sw, -13), gc, 1.5)
						draw_line(pos, pos + Vector2(4 + sw, -10), gc, 1.5)
					else:
						draw_circle(pos + Vector2(0, 3), 11.0, Color(0, 0, 0, 0.2))
						draw_circle(pos, 10.0, Color(0.4, 0.4, 0.38))
						draw_circle(pos + Vector2(-3, -3), 4.0, Color(0.55, 0.55, 0.5))
				"orman":
					if h < 0.55:
						var cr := 26.0 + h * 24.0
						draw_circle(pos + Vector2(0, 10), cr * 0.9, Color(0, 0, 0, 0.25))
						draw_rect(Rect2(pos.x - 5, pos.y - 8, 10, 26), Color(0.3, 0.2, 0.12))
						draw_circle(pos + Vector2(0, -24), cr, Color(0.07, 0.25, 0.12))
						draw_circle(pos + Vector2(-cr * 0.5, -14), cr * 0.65, Color(0.09, 0.3, 0.15))
						draw_circle(pos + Vector2(cr * 0.5, -16), cr * 0.6, Color(0.1, 0.33, 0.16))
					elif h < 0.8:
						draw_rect(Rect2(pos.x - 2, pos.y - 6, 4, 8), Color(0.85, 0.85, 0.75))
						draw_circle(pos + Vector2(0, -8), 8.0, Color(0.75, 0.15, 0.15))
						draw_circle(pos + Vector2(-3, -10), 1.6, Color.WHITE)
						draw_circle(pos + Vector2(3, -7), 1.4, Color.WHITE)
					else:
						var fc := Color(0.15, 0.4, 0.2)
						draw_line(pos, pos + Vector2(-9, -12), fc, 2.0)
						draw_line(pos, pos + Vector2(0, -15), fc, 2.0)
						draw_line(pos, pos + Vector2(9, -12), fc, 2.0)
				"lav":
					if h < 0.6:
						var glow := 0.55 + 0.25 * sin(anim_t * 2.0 + h * 9.0)
						var pts := PackedVector2Array([pos, pos + Vector2(30 * h, 18), pos + Vector2(55, 10 + 25 * h), pos + Vector2(85 * h + 20, 40)])
						draw_polyline(pts, Color(1, 0.4, 0.1, glow * 0.5), 6.0)
						draw_polyline(pts, Color(1, 0.75, 0.3, glow), 2.0)
					else:
						draw_circle(pos + Vector2(0, 3), 12.0, Color(0, 0, 0, 0.3))
						draw_circle(pos, 11.0, Color(0.16, 0.12, 0.12))
						draw_circle(pos + Vector2(-3, -3), 4.0, Color(0.28, 0.2, 0.18))
				"deniz":
					if h < 0.8:
						var wo := sin(anim_t * 0.8 + h * 6.0) * 8.0
						draw_arc(pos + Vector2(wo, 0), 16.0 + h * 16.0, 0.3, PI - 0.3, 10, Color(1, 1, 1, 0.16), 2.0)
						draw_arc(pos + Vector2(wo + 6, 8), 10.0 + h * 8.0, 0.3, PI - 0.3, 8, Color(1, 1, 1, 0.1), 2.0)
					else:
						draw_line(pos, pos + Vector2(34, 6), Color(0.35, 0.25, 0.15), 6.0)
						draw_circle(pos + Vector2(34, 6), 3.0, Color(0.5, 0.4, 0.25))
				"kar":
					if h < 0.5:
						var sh := 14.0 + h * 26.0
						draw_colored_polygon(PackedVector2Array([pos + Vector2(-6, 6), pos + Vector2(0, -sh), pos + Vector2(6, 6)]), Color(0.7, 0.88, 1.0, 0.6))
						draw_colored_polygon(PackedVector2Array([pos + Vector2(2, 6), pos + Vector2(10, -sh * 0.6), pos + Vector2(15, 6)]), Color(0.85, 0.95, 1.0, 0.5))
					else:
						draw_circle(pos + Vector2(0, 4), 18.0, Color(0, 0, 0, 0.15))
						draw_circle(pos, 16.0 + h * 8.0, Color(0.88, 0.94, 1.0, 0.75))
				"yeralti":
					if h < 0.5:
						var vh2 := 16.0 + h * 30.0
						draw_colored_polygon(PackedVector2Array([pos + Vector2(-5, 6), pos + Vector2(0, -vh2), pos + Vector2(5, 6)]), Color(0.5, 0.15, 0.7, 0.8))
						draw_circle(pos + Vector2(0, -vh2), 2.5, Color(0.9, 0.5, 1.0, 0.6 + 0.3 * sin(anim_t * 3.0 + h * 9.0)))
					else:
						draw_circle(pos, 9.0, Color(0.8, 0.78, 0.72, 0.85))
						draw_circle(pos + Vector2(-3, -1), 2.0, Color(0.09, 0.04, 0.12))
						draw_circle(pos + Vector2(3, -1), 2.0, Color(0.09, 0.04, 0.12))
				"firtina":
					if h < 0.7:
						var pr := 14.0 + h * 22.0
						var rp := fposmod(anim_t * 0.8 + h * 3.0, 1.0)
						draw_circle(pos, pr, Color(0.35, 0.45, 0.65, 0.3))
						draw_arc(pos, pr * (0.3 + 0.7 * rp), 0.0, TAU, 14, Color(1, 1, 1, 0.3 * (1.0 - rp)), 1.5)
					else:
						draw_circle(pos + Vector2(0, 3), 11.0, Color(0, 0, 0, 0.25))
						draw_circle(pos, 10.0, Color(0.25, 0.27, 0.33))


func _draw_pools() -> void:
	if pool_kind == "":
		return
	var cx0 := floori((player_pos.x - (vw * 0.5 + 120.0)) / POOL_CELL)
	var cx1 := floori((player_pos.x + (vw * 0.5 + 120.0)) / POOL_CELL)
	var cy0 := floori((player_pos.y - (vh * 0.5 + 120.0)) / POOL_CELL)
	var cy1 := floori((player_pos.y + (vh * 0.5 + 120.0)) / POOL_CELL)
	for ix in range(cx0, cx1 + 1):
		for iy in range(cy0, cy1 + 1):
			var pool := _pool_in_cell(ix, iy)
			if pool.is_empty():
				continue
			var pos: Vector2 = pool["pos"]
			var r: float = pool["r"]
			match pool_kind:
				"swamp":
					draw_circle(pos, r + 4.0, Color(0.05, 0.12, 0.05, 0.9))
					draw_circle(pos, r, Color(0.14, 0.27, 0.1, 0.9))
					draw_circle(pos, r * 0.7, Color(0.2, 0.36, 0.14, 0.8))
					for k in 4:
						var a := anim_t * 0.7 + k * 1.7
						draw_circle(pos + Vector2(cos(a), sin(a * 1.3)) * r * 0.5, 3.0 + sin(anim_t * 3.0 + k) * 1.5, Color(0.5, 0.7, 0.3, 0.6))
				"lava":
					var pul := 0.5 + 0.5 * sin(anim_t * 2.5 + pos.x)
					draw_circle(pos, r + 14.0, Color(1.0, 0.3, 0.05, 0.12 + 0.06 * pul))
					draw_circle(pos, r + 5.0, Color(0.2, 0.04, 0.0))
					draw_circle(pos, r, Color(1.0, 0.35, 0.05))
					draw_circle(pos, r * 0.65, Color(1.0, 0.6, 0.15, 0.7 + 0.3 * pul))
					draw_circle(pos, r * 0.3, Color(1.0, 0.9, 0.4, 0.8))
					for k in 3:
						var a2 := anim_t * 0.9 + k * 2.1
						draw_circle(pos + Vector2(cos(a2), sin(a2)) * r * 0.45, 4.0 + pul * 2.0, Color(1.0, 0.8, 0.3, 0.6))
				"ice":
					draw_circle(pos, r + 3.0, Color(0.55, 0.75, 0.9, 0.5))
					draw_circle(pos, r, Color(0.7, 0.88, 1.0, 0.55))
					draw_circle(pos, r * 0.6, Color(0.85, 0.96, 1.0, 0.45))
					for k in 3:
						var ia := k * 2.1 + pos.x
						draw_line(pos, pos + Vector2(cos(ia), sin(ia)) * r * 0.85, Color(1, 1, 1, 0.45), 1.5)
				"void":
					var vp := 0.5 + 0.5 * sin(anim_t * 2.0 + pos.y)
					draw_circle(pos, r + 8.0, Color(0.6, 0.1, 0.8, 0.12 + 0.06 * vp))
					draw_circle(pos, r, Color(0.12, 0.02, 0.18, 0.92))
					draw_circle(pos, r * 0.6, Color(0.35, 0.08, 0.5, 0.7))
					for k in 3:
						var va := anim_t * 1.1 + k * 2.1
						draw_circle(pos + Vector2(cos(va), sin(va)) * r * 0.45, 3.5 + vp * 1.5, Color(0.8, 0.4, 1.0, 0.7))
				"whirl":
					draw_circle(pos, r, Color(0.02, 0.08, 0.18, 0.85))
					for k in 4:
						var sa := anim_t * (2.0 - 0.3 * k) + k
						draw_arc(pos, r * (0.25 + 0.2 * k), sa, sa + 2.2, 12, Color(0.6, 0.85, 1.0, 0.5), 2.5)
					draw_arc(pos, r, 0.0, TAU, 32, Color(0.7, 0.9, 1.0, 0.5), 2.0)


func _draw_strikes() -> void:
	for s in strikes:
		var k: float = clampf(float(s["t"]) / float(s["delay"]), 0.0, 1.0)
		var col := Color(1.0, 0.35, 0.2)
		match String(s["kind"]):
			"lightning":
				col = Color(0.7, 0.85, 1.0)
			"slam":
				col = Color(1.0, 0.8, 0.3)
		var sp: Vector2 = s["pos"]
		var sr: float = s["r"]
		draw_circle(sp, sr, Color(col.r, col.g, col.b, 0.1 + 0.15 * k))
		draw_circle(sp, sr * k, Color(col.r, col.g, col.b, 0.25))
		draw_arc(sp, sr, 0.0, TAU, 32, Color(col.r, col.g, col.b, 0.8), 3.0)
		if String(s["kind"]) == "meteor":
			var fy := -300.0 * (1.0 - k)
			draw_circle(sp + Vector2(0, fy), 12.0, Color(1.0, 0.6, 0.15))
			draw_line(sp + Vector2(0, fy), sp + Vector2(0, fy - 40.0), Color(1.0, 0.4, 0.1, 0.6), 8.0)


func _draw_ambient() -> void:
	var c := player_pos
	match stage_id:
		"bozkir":
			for i in 26:
				var sx := fposmod(float(i) * 173.3 + anim_t * 30.0, vw) - vw * 0.5
				var sy := fposmod(float(i) * 91.7 + anim_t * (8.0 + (i % 3) * 5.0), vh) - vh * 0.5
				draw_circle(c + Vector2(sx, sy + sin(anim_t + i) * 10.0), 1.6, Color(0.9, 0.9, 0.7, 0.25))
		"orman":
			for i in 28:
				var fx2 := fposmod(float(i) * 211.0 + sin(anim_t * 0.5 + i) * 60.0, vw) - vw * 0.5
				var fy2 := fposmod(float(i) * 137.0 + cos(anim_t * 0.4 + i) * 50.0, vh) - vh * 0.5
				var ba := 0.5 + 0.5 * sin(anim_t * 2.0 + i * 1.7)
				draw_circle(c + Vector2(fx2, fy2), 6.0, Color(0.8, 1.0, 0.4, ba * 0.15))
				draw_circle(c + Vector2(fx2, fy2), 2.2, Color(0.85, 1.0, 0.45, ba * 0.9))
		"lav":
			for i in 40:
				var ex := fposmod(float(i) * 131.0 + sin(anim_t + i) * 30.0, vw) - vw * 0.5
				var ey := fposmod(float(i) * 57.0 - anim_t * (40.0 + (i % 5) * 12.0), vh) - vh * 0.5
				draw_circle(c + Vector2(ex, ey), 1.8 + (i % 3) * 0.6, Color(1.0, 0.55, 0.15, 0.7))
		"deniz":
			var cd := Vector2.from_angle(time_alive * 0.12)
			for i in 18:
				var lx := fposmod(float(i) * 197.0 + anim_t * cd.x * 40.0, vw) - vw * 0.5
				var ly := fposmod(float(i) * 83.0 + anim_t * cd.y * 40.0, vh) - vh * 0.5
				draw_line(c + Vector2(lx, ly), c + Vector2(lx, ly) + cd * 26.0, Color(1, 1, 1, 0.14), 2.0)
			for i in 22:
				var bx := fposmod(float(i) * 151.0, vw) - vw * 0.5
				var by := fposmod(float(i) * 61.0 - anim_t * (14.0 + (i % 4) * 6.0), vh) - vh * 0.5
				draw_arc(c + Vector2(bx + sin(anim_t + i) * 8.0, by), 2.0 + (i % 3), 0.0, TAU, 8, Color(0.8, 0.95, 1.0, 0.3), 1.2)
		"kar":
			for i in 90:
				var kx := fposmod(float(i) * 113.7 + anim_t * 70.0, vw) - vw * 0.5
				var ky := fposmod(float(i) * 61.3 + anim_t * (50.0 + (i % 4) * 14.0), vh) - vh * 0.5
				draw_circle(c + Vector2(kx, ky), 1.6 + (i % 3) * 0.7, Color(1, 1, 1, 0.7))
		"yeralti":
			for i in 34:
				var yx := fposmod(float(i) * 149.0 + sin(anim_t * 0.7 + i) * 40.0, vw) - vw * 0.5
				var yy := fposmod(float(i) * 71.0 - anim_t * (25.0 + (i % 5) * 9.0), vh) - vh * 0.5
				draw_circle(c + Vector2(yx, yy), 2.0 + (i % 3) * 0.6, Color(0.75, 0.35, 0.95, 0.6))
		"firtina":
			for i in 150:
				var rx := fposmod(float(i) * 97.31 + anim_t * 130.0, vw) - vw * 0.5
				var ry := fposmod(float(i) * 53.7 + anim_t * 1100.0, vh) - vh * 0.5
				draw_line(c + Vector2(rx, ry), c + Vector2(rx - 6.0, ry + 22.0), Color(0.7, 0.8, 1.0, 0.4), 1.5)


# ============================================================
#  ÇİZİM - DÜŞMANLAR
# ============================================================

func _eyes(p: Vector2, rad: float, toward: Vector2, spread: float, size: float, col: Color) -> void:
	var side := toward.orthogonal() * rad * spread
	var up := Vector2(0, -rad * 0.1)
	draw_circle(p + side + up, rad * size, col)
	draw_circle(p - side + up, rad * size, col)
	var pup := Color(0.08, 0.0, 0.05)
	draw_circle(p + side + up + toward * rad * size * 0.4, rad * size * 0.5, pup)
	draw_circle(p - side + up + toward * rad * size * 0.4, rad * size * 0.5, pup)


func _draw_enemy(e: Dictionary) -> void:
	var p: Vector2 = e["pos"]
	if absf(p.x - player_pos.x) > 760.0 or absf(p.y - player_pos.y) > 440.0:
		return
	var sc := minf(1.0, float(e["spawn_t"]) / 0.35)
	var rad: float = float(e["radius"]) * (0.4 + 0.6 * sc)
	var ph: float = anim_t * 7.0 + float(e["id"]) * 0.9
	var bob := sin(ph) * rad * 0.1
	var col: Color = Color.WHITE if float(e["flash"]) > 0.0 else e["color"]
	var toward := (player_pos - p).normalized()
	var look: String = e["look"]
	draw_circle(p + Vector2(0, rad * 0.9), rad * 0.8, Color(0, 0, 0, 0.25))
	var bp := p + Vector2(0, bob)
	match look:
		"blob":
			var sw := sin(ph) * rad * 0.35
			draw_circle(p + Vector2(-rad * 0.95, sw * 0.5), rad * 0.28, col.darkened(0.15))
			draw_circle(p + Vector2(rad * 0.95, -sw * 0.5), rad * 0.28, col.darkened(0.15))
			draw_circle(bp, rad, col)
			_eyes(bp, rad, toward, 0.35, 0.2, Color.WHITE)
		"spiky":
			for k in 7:
				var a := ph * 0.25 + TAU * k / 7.0
				var tip := bp + Vector2.from_angle(a) * rad * 1.5
				var b1 := bp + Vector2.from_angle(a - 0.3) * rad
				var b2 := bp + Vector2.from_angle(a + 0.3) * rad
				draw_colored_polygon(PackedVector2Array([b1, tip, b2]), col.darkened(0.25))
			draw_circle(bp, rad, col)
			_eyes(bp, rad, toward, 0.38, 0.22, Color(1, 1, 0.6))
		"cyclops":
			var boss: bool = e["kind"] == "boss"
			if boss:
				draw_circle(bp, rad * (1.3 + 0.05 * sin(ph)), Color(col.r, col.g, col.b, 0.16))
				draw_colored_polygon(PackedVector2Array([bp + Vector2(-rad * 0.8, -rad * 0.6), bp + Vector2(-rad * 0.55, -rad * 1.45), bp + Vector2(-rad * 0.2, -rad * 0.9)]), col.darkened(0.3))
				draw_colored_polygon(PackedVector2Array([bp + Vector2(rad * 0.8, -rad * 0.6), bp + Vector2(rad * 0.55, -rad * 1.45), bp + Vector2(rad * 0.2, -rad * 0.9)]), col.darkened(0.3))
			draw_circle(bp, rad, col)
			draw_circle(bp, rad * 0.42, Color.WHITE)
			draw_circle(bp + toward * rad * 0.14, rad * 0.2, Color(0.1, 0.0, 0.0))
			draw_arc(bp + Vector2(0, rad * 0.4), rad * 0.4, 0.3, PI - 0.3, 10, col.darkened(0.5), 2.0)
		"wolf":
			var tele := int(e["mode"]) == 1
			var cc := col
			if tele:
				cc = col.lerp(Color(1, 0.2, 0.2), 0.5 + 0.5 * sin(anim_t * 30.0))
			var wo := toward.orthogonal()
			draw_circle(bp, rad, cc)
			draw_colored_polygon(PackedVector2Array([bp + wo * rad * 0.8, bp + wo * rad * 0.5 - toward * rad * 1.1, bp + wo * rad * 0.1 - toward * rad * 0.2]), cc.darkened(0.2))
			draw_colored_polygon(PackedVector2Array([bp - wo * rad * 0.8, bp - wo * rad * 0.5 - toward * rad * 1.1, bp - wo * rad * 0.1 - toward * rad * 0.2]), cc.darkened(0.2))
			draw_circle(bp + toward * rad * 0.8, rad * 0.45, cc.darkened(0.2))
			draw_circle(bp + toward * rad * 0.35 + wo * rad * 0.35, rad * 0.14, Color(1, 0.2, 0.2))
			draw_circle(bp + toward * rad * 0.35 - wo * rad * 0.35, rad * 0.14, Color(1, 0.2, 0.2))
			if tele:
				draw_line(bp, bp + toward * rad * 7.0, Color(1, 0.2, 0.2, 0.45), 2.0)
		"archer":
			draw_colored_polygon(PackedVector2Array([bp + Vector2(0, -rad * 1.4), bp + Vector2(rad, rad * 0.9), bp + Vector2(-rad, rad * 0.9)]), col)
			draw_circle(bp + Vector2(0, -rad * 0.2), rad * 0.5, col.darkened(0.55))
			draw_circle(bp + Vector2(-rad * 0.2, -rad * 0.25), rad * 0.1, Color(1, 0.9, 0.3))
			draw_circle(bp + Vector2(rad * 0.2, -rad * 0.25), rad * 0.1, Color(1, 0.9, 0.3))
			var ta := toward.angle()
			draw_arc(bp + toward * rad * 1.1, rad * 0.9, ta - 1.0, ta + 1.0, 8, Color(0.9, 0.8, 0.5), 2.0)
		"armor":
			var s := rad * 1.7
			var stomp := absf(sin(ph * 0.5)) * 2.0
			draw_rect(Rect2(p.x - s * 0.5, p.y - s * 0.5 - stomp, s, s), col)
			draw_rect(Rect2(p.x - s * 0.5, p.y - s * 0.5 - stomp, s, s), col.darkened(0.45), false, 3.0)
			draw_rect(Rect2(p.x - s * 0.3, p.y - s * 0.15 - stomp, s * 0.6, s * 0.14), Color(1, 0.7, 0.2))
			for cxm in [-1.0, 1.0]:
				for cym in [-1.0, 1.0]:
					draw_circle(Vector2(p.x + cxm * s * 0.38, p.y + cym * s * 0.38 - stomp), 2.2, col.darkened(0.3))
		"ghost":
			var ga := 0.55 + 0.25 * sin(ph * 0.7)
			var gc := Color(col.r, col.g, col.b, ga)
			draw_circle(bp, rad, gc)
			draw_colored_polygon(PackedVector2Array([bp + Vector2(-rad, 0), bp + Vector2(-rad * 0.7, rad * 1.3), bp + Vector2(-rad * 0.35, rad * 0.8), bp + Vector2(0, rad * 1.3), bp + Vector2(rad * 0.35, rad * 0.8), bp + Vector2(rad * 0.7, rad * 1.3), bp + Vector2(rad, 0)]), gc)
			draw_circle(bp + Vector2(-rad * 0.35, -rad * 0.1), rad * 0.2, Color(0.05, 0.05, 0.15, 0.9))
			draw_circle(bp + Vector2(rad * 0.35, -rad * 0.1), rad * 0.2, Color(0.05, 0.05, 0.15, 0.9))
		"flame":
			var fl := sin(anim_t * 20.0 + float(e["id"])) * rad * 0.2
			draw_colored_polygon(PackedVector2Array([bp + Vector2(fl, -rad * 1.7), bp + Vector2(rad * 0.9, 0), bp + Vector2(rad * 0.5, rad * 0.9), bp + Vector2(-rad * 0.5, rad * 0.9), bp + Vector2(-rad * 0.9, 0)]), col)
			draw_colored_polygon(PackedVector2Array([bp + Vector2(-fl * 0.5, -rad * 0.9), bp + Vector2(rad * 0.5, rad * 0.1), bp + Vector2(0, rad * 0.8), bp + Vector2(-rad * 0.5, rad * 0.1)]), Color(1, 0.9, 0.4))
			draw_circle(bp + Vector2(-rad * 0.25, rad * 0.1), rad * 0.1, Color(0.2, 0.0, 0.0))
			draw_circle(bp + Vector2(rad * 0.25, rad * 0.1), rad * 0.1, Color(0.2, 0.0, 0.0))
			if randf() < 0.2:
				_spark(bp + Vector2(randf_range(-rad, rad), -rad), Vector2(0, -50), Color(1, 0.6, 0.2, 0.8), 0.4, 2.5)
		"splitter":
			draw_circle(bp + Vector2(-rad * 0.45, 0), rad * 0.75, col)
			draw_circle(bp + Vector2(rad * 0.45, 0), rad * 0.75, col.lightened(0.08))
			_eyes(bp + Vector2(-rad * 0.45, 0), rad * 0.75, toward, 0.0, 0.0, Color.WHITE)
			draw_circle(bp + Vector2(-rad * 0.45, -rad * 0.05), rad * 0.2, Color.WHITE)
			draw_circle(bp + Vector2(rad * 0.45, -rad * 0.05), rad * 0.2, Color.WHITE)
			draw_circle(bp + Vector2(-rad * 0.45, -rad * 0.05) + toward * rad * 0.08, rad * 0.1, Color(0.1, 0, 0.05))
			draw_circle(bp + Vector2(rad * 0.45, -rad * 0.05) + toward * rad * 0.08, rad * 0.1, Color(0.1, 0, 0.05))
		"droplet":
			draw_circle(bp + Vector2(0, rad * 0.2), rad, col)
			draw_colored_polygon(PackedVector2Array([bp + Vector2(-rad * 0.85, 0), bp + Vector2(0, -rad * 1.7), bp + Vector2(rad * 0.85, 0)]), col)
			_eyes(bp + Vector2(0, rad * 0.2), rad, toward, 0.35, 0.2, Color.WHITE)
			if e["ai"] == "healer":
				var pa := 0.5 + 0.5 * sin(anim_t * 4.0)
				draw_line(bp + Vector2(-4, rad * 0.8), bp + Vector2(4, rad * 0.8), Color(1, 1, 1, 0.5 + 0.4 * pa), 2.0)
				draw_line(bp + Vector2(0, rad * 0.8 - 4), bp + Vector2(0, rad * 0.8 + 4), Color(1, 1, 1, 0.5 + 0.4 * pa), 2.0)
		_:
			draw_circle(bp, rad, col)
	if float(e["burn"]) > 0.0:
		draw_circle(p + Vector2(sin(ph) * 3.0, -rad - 4.0), 4.0, Color(1.0, 0.6, 0.1, 0.85))
		draw_circle(p + Vector2(sin(ph) * 3.0, -rad - 6.0), 2.2, Color(1.0, 0.9, 0.4, 0.9))
	if float(e["hp"]) < float(e["max_hp"]) and e["kind"] != "boss":
		var bw := rad * 2.0
		draw_rect(Rect2(p.x - rad, p.y - rad - 12.0, bw, 4.0), Color(0, 0, 0, 0.6))
		draw_rect(Rect2(p.x - rad, p.y - rad - 12.0, bw * clampf(float(e["hp"]) / float(e["max_hp"]), 0.0, 1.0), 4.0), Color(0.9, 0.2, 0.2))


# ============================================================
#  ÇİZİM - OYUNCU VE MENÜ
# ============================================================

func _draw_player() -> void:
	var blink := invuln > 0.0 and fmod(anim_t * 20.0, 2.0) < 1.0
	var pa := 0.35 if blink else 1.0
	var bob := sin(anim_t * 14.0) * 2.0 if player_moving else sin(anim_t * 3.0) * 1.0
	var P := player_pos + Vector2(0, bob)
	var body := char_color
	body.a = pa
	var dark := char_color.darkened(0.3)
	dark.a = pa
	var gold := Color(1.0, 0.85, 0.3, pa)
	draw_circle(player_pos + Vector2(0, 17), 14.0, Color(0, 0, 0, 0.3))
	# ayaklar
	var foot := sin(anim_t * 14.0) * 6.0 if player_moving else 0.0
	draw_circle(P + Vector2(-7 + foot, 15), 4.0, dark)
	draw_circle(P + Vector2(7 - foot, 15), 4.0, dark)
	if char_style == "rider":
		var fl := sin(anim_t * 10.0) * 9.0
		var wing := Color(0.9, 0.97, 1.0, pa * 0.85)
		draw_colored_polygon(PackedVector2Array([P + Vector2(-12, -4), P + Vector2(-36, -16 + fl), P + Vector2(-30, 6 + fl * 0.5), P + Vector2(-12, 6)]), wing)
		draw_colored_polygon(PackedVector2Array([P + Vector2(12, -4), P + Vector2(36, -16 + fl), P + Vector2(30, 6 + fl * 0.5), P + Vector2(12, 6)]), wing)
	draw_circle(P, 17.0, body)
	match char_style:
		"knight":
			draw_arc(P, 17.0, PI, TAU, 16, dark, 8.0)
			draw_colored_polygon(PackedVector2Array([P + Vector2(-5, -20), P + Vector2(0, -34), P + Vector2(5, -20)]), dark)
		"shaman":
			draw_colored_polygon(PackedVector2Array([P + Vector2(-13, -12), P + Vector2(0, -34), P + Vector2(13, -12)]), dark)
			draw_line(P + Vector2(0, -34), P + Vector2(8, -44), gold, 3.0)
		"mother":
			var halo := 0.6 + 0.4 * sin(anim_t * 3.0)
			draw_arc(P + Vector2(0, -26), 11.0, 0.0, TAU, 20, Color(1.0, 0.9, 0.5, pa * halo), 3.0)
			draw_arc(P, 17.0, PI + 0.4, TAU - 0.4, 14, dark, 6.0)
		"rider":
			draw_colored_polygon(PackedVector2Array([P + Vector2(-9, -15), P + Vector2(0, -30), P + Vector2(9, -15)]), dark)
		"sage":
			draw_colored_polygon(PackedVector2Array([P + Vector2(-10, 6), P + Vector2(0, 28), P + Vector2(10, 6)]), Color(0.95, 0.95, 0.95, pa))
			draw_line(P + Vector2(14, 4), P + Vector2(26, -12), Color(0.5, 0.35, 0.2, pa), 3.0)
			draw_circle(P + Vector2(13, 6), 5.0, Color(0.6, 0.4, 0.25, pa))
		"hunter":
			draw_colored_polygon(PackedVector2Array([P + Vector2(-14, -6), P + Vector2(0, -32), P + Vector2(14, -6)]), dark)
			draw_line(P + Vector2(6, -26), P + Vector2(18, -40), Color(0.9, 0.3, 0.3, pa), 3.0)
			draw_line(P + Vector2(-16, 2), P + Vector2(-16, 22), Color(0.5, 0.35, 0.2, pa), 3.0)
		"kagan":
			draw_colored_polygon(PackedVector2Array([P + Vector2(-13, -14), P + Vector2(-12, -27), P + Vector2(0, -22), P + Vector2(12, -27), P + Vector2(13, -14)]), Color(0.85, 0.9, 1.0, pa))
			draw_line(P + Vector2(0, -22), P + Vector2(0, -42), gold, 3.0)
			draw_line(P + Vector2(-6, -24), P + Vector2(-12, -38), gold, 2.0)
			draw_line(P + Vector2(6, -24), P + Vector2(12, -38), gold, 2.0)
		"khan":
			draw_colored_polygon(PackedVector2Array([P + Vector2(-12, -15), P + Vector2(-9, -28), P + Vector2(-4, -18), P + Vector2(0, -30), P + Vector2(4, -18), P + Vector2(9, -28), P + Vector2(12, -15)]), gold)
		_:
			draw_colored_polygon(PackedVector2Array([P + Vector2(-13, -8), P + Vector2(-7, -26), P + Vector2(-1, -12)]), dark)
			draw_colored_polygon(PackedVector2Array([P + Vector2(13, -8), P + Vector2(7, -26), P + Vector2(1, -12)]), dark)
	draw_circle(P + facing * 14.0, 7.0, dark)
	var eye_side := facing.orthogonal() * 6.0
	draw_circle(P + facing * 6.0 + eye_side, 2.5, Color(1.0, 0.8, 0.2, pa))
	draw_circle(P + facing * 6.0 - eye_side, 2.5, Color(1.0, 0.8, 0.2, pa))


func _draw_menu_bg() -> void:
	draw_rect(Rect2(-vw * 0.5, -vh * 0.5, vw, vh), Color(0.05, 0.06, 0.1))
	for s in stars:
		var tw := 0.6 + 0.4 * sin(anim_t * 1.5 + float(s["p"]))
		draw_circle((s["pos"] as Vector2) * Vector2(vw / BASE_VW, vh / BASE_VH), s["r"], Color(1, 1, 1, float(s["a"]) * tw))
	draw_circle(Vector2(430, -170), 70.0, Color(0.95, 0.93, 0.8, 0.9))
	draw_circle(Vector2(455, -185), 62.0, Color(0.05, 0.06, 0.1, 0.35))
	draw_rect(Rect2(-vw * 0.5, 210, vw, vh * 0.5), Color(0.07, 0.09, 0.12))
	for i in 3:
		var bx := -520.0 + i * 70.0
		var by := 240.0 + sin(anim_t * 1.5 + i) * 2.0
		draw_circle(Vector2(bx, by), 20.0, Color(0.15, 0.17, 0.22))
		draw_colored_polygon(PackedVector2Array([Vector2(bx - 14, by - 10), Vector2(bx - 8, by - 32), Vector2(bx - 2, by - 14)]), Color(0.15, 0.17, 0.22))
		draw_colored_polygon(PackedVector2Array([Vector2(bx + 14, by - 10), Vector2(bx + 8, by - 32), Vector2(bx + 2, by - 14)]), Color(0.15, 0.17, 0.22))
