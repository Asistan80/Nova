extends RefCounted
## Kodla üretilen ses efektleri ve döngülü arka plan müziği (harici ses dosyası yok)

const SFX_RATE := 22050
const MUSIC_RATE := 16000

const THEMES := {
	"menu": {"bpm": 76, "root": 50, "scale": [0, 1, 4, 5, 7, 8, 11], "drums": 0, "seed": 11, "lead": 0.9},
	"bozkir": {"bpm": 108, "root": 45, "scale": [0, 3, 5, 7, 10], "drums": 1, "seed": 22, "lead": 0.8},
	"orman": {"bpm": 88, "root": 48, "scale": [0, 2, 3, 5, 7, 9, 10], "drums": 0, "seed": 33, "lead": 0.8},
	"lav": {"bpm": 128, "root": 40, "scale": [0, 1, 4, 5, 7, 8, 10], "drums": 2, "seed": 44, "lead": 0.7},
	"deniz": {"bpm": 84, "root": 48, "scale": [0, 2, 4, 6, 7, 9, 11], "drums": 0, "seed": 55, "lead": 0.9},
	"firtina": {"bpm": 120, "root": 43, "scale": [0, 1, 4, 5, 7, 8, 11], "drums": 2, "seed": 66, "lead": 0.7},
	"kar": {"bpm": 72, "root": 52, "scale": [0, 2, 4, 7, 9], "drums": 0, "seed": 77, "lead": 0.95},
	"yeralti": {"bpm": 100, "root": 38, "scale": [0, 1, 3, 6, 7, 10], "drums": 1, "seed": 88, "lead": 0.7},
}

const PROGRESSION := [0, 0, 3, 4, 0, 5, 3, 4]

var sfx := {}
var music_cache := {}
var mutex := Mutex.new()
var rng := RandomNumberGenerator.new()


# ============================================================
#  EFEKTLER
# ============================================================

func _tone(freq0: float, freq1: float, dur: float, vol: float, wave: int) -> AudioStreamWAV:
	var n := int(SFX_RATE * dur)
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	var phase := 0.0
	for i in n:
		var t := float(i) / float(n)
		phase += lerpf(freq0, freq1, t) / float(SFX_RATE)
		var s := 0.0
		match wave:
			0:
				s = sin(phase * TAU)
			1:
				s = 1.0 if fposmod(phase, 1.0) < 0.5 else -1.0
			2:
				s = randf() * 2.0 - 1.0
			3:
				s = fposmod(phase, 1.0) * 2.0 - 1.0
		var env := (1.0 - t) * (1.0 - t)
		var att := minf(1.0, float(i) / (float(SFX_RATE) * 0.004))
		var v := clampi(int(s * env * att * vol * 32767.0), -32768, 32767)
		bytes.encode_s16(i * 2, v)
	var st := AudioStreamWAV.new()
	st.format = AudioStreamWAV.FORMAT_16_BITS
	st.mix_rate = SFX_RATE
	st.stereo = false
	st.data = bytes
	return st


func build_sfx() -> void:
	sfx["shoot"] = _tone(720.0, 320.0, 0.08, 0.28, 1)
	sfx["hit"] = _tone(240.0, 90.0, 0.06, 0.4, 3)
	sfx["gem"] = _tone(880.0, 1500.0, 0.07, 0.3, 0)
	sfx["heal"] = _tone(520.0, 980.0, 0.22, 0.4, 0)
	sfx["levelup"] = _tone(380.0, 1250.0, 0.4, 0.45, 0)
	sfx["hurt"] = _tone(240.0, 60.0, 0.2, 0.55, 3)
	sfx["boss"] = _tone(95.0, 45.0, 0.9, 0.6, 3)
	sfx["death"] = _tone(320.0, 35.0, 1.0, 0.6, 3)
	sfx["thunder"] = _tone(1.0, 1.0, 0.4, 0.6, 2)
	sfx["claw"] = _tone(1.0, 1.0, 0.13, 0.4, 2)
	sfx["click"] = _tone(520.0, 520.0, 0.05, 0.3, 1)
	sfx["buy"] = _tone(500.0, 1100.0, 0.15, 0.4, 1)
	sfx["error"] = _tone(160.0, 130.0, 0.15, 0.4, 1)
	sfx["bite"] = _tone(420.0, 150.0, 0.07, 0.4, 3)
	sfx["evolve"] = _tone(220.0, 1700.0, 0.9, 0.5, 3)
	sfx["explode"] = _tone(1.0, 1.0, 0.45, 0.7, 2)
	sfx["slam"] = _tone(95.0, 30.0, 0.5, 0.75, 3)
	sfx["warn"] = _tone(660.0, 660.0, 0.12, 0.25, 1)
	sfx["eshot"] = _tone(520.0, 260.0, 0.1, 0.25, 1)
	sfx["splash"] = _tone(1.0, 1.0, 0.2, 0.3, 2)
	sfx["dash"] = _tone(300.0, 700.0, 0.12, 0.3, 3)
	sfx["score"] = _tone(600.0, 1800.0, 0.5, 0.45, 1)


# ============================================================
#  MÜZİK
# ============================================================

func _degree_midi(root: int, scale: Array, idx: int) -> int:
	var s := scale.size()
	var oct := floori(float(idx) / float(s))
	return root + int(scale[posmod(idx, s)]) + 12 * oct


func _freq(midi: int) -> float:
	return 440.0 * pow(2.0, (float(midi) - 69.0) / 12.0)


func _add_note(buf: PackedFloat32Array, start: int, freq: float, dur: float, amp: float, att: float, vib: float) -> void:
	var n := int(MUSIC_RATE * dur)
	var total := buf.size()
	var ph := 0.0
	var step := freq / float(MUSIC_RATE)
	var att_n := maxf(att * MUSIC_RATE, 2.0)
	for i in n:
		var idx := (start + i) % total
		var t := float(i) / float(n)
		var env := minf(1.0, float(i) / att_n) * pow(1.0 - t, 1.4)
		if vib > 0.0:
			ph += step * (1.0 + vib * sin(float(i) * 0.012))
		else:
			ph += step
		buf[idx] += (sin(ph * TAU) + 0.3 * sin(ph * TAU * 2.0)) * env * amp


func _add_kick(buf: PackedFloat32Array, start: int, amp: float) -> void:
	var n := int(MUSIC_RATE * 0.16)
	var total := buf.size()
	var ph := 0.0
	for i in n:
		var t := float(i) / float(n)
		ph += lerpf(130.0, 42.0, t) / float(MUSIC_RATE)
		var env := (1.0 - t) * (1.0 - t)
		buf[(start + i) % total] += sin(ph * TAU) * env * amp


func _add_noise(buf: PackedFloat32Array, start: int, dur: float, amp: float) -> void:
	var n := int(MUSIC_RATE * dur)
	var total := buf.size()
	for i in n:
		var t := float(i) / float(n)
		buf[(start + i) % total] += (rng.randf() * 2.0 - 1.0) * (1.0 - t) * (1.0 - t) * amp


func ready_music(theme: String) -> AudioStreamWAV:
	mutex.lock()
	var st: AudioStreamWAV = music_cache.get(theme, null)
	mutex.unlock()
	return st


## Müzik üretimi parçalara bölünmüştür: web (tek iş parçacıklı) sürümde kare başına küçük adımlarla üretilir.
const SECTIONS := 5

var job: Dictionary = {}
var job_queue: Array = []


func _job_begin(theme: String) -> Dictionary:
	var t: Dictionary = THEMES[theme]
	var spb := 60.0 / float(t["bpm"])
	var bars := 8
	var n := int(float(MUSIC_RATE) * spb * float(bars * 4))
	var buf := PackedFloat32Array()
	buf.resize(n)
	rng.seed = int(t["seed"])
	var scale: Array = t["scale"]
	return {"theme": theme, "spb": spb, "bars": bars, "n": n, "buf": buf, "scale": scale,
		"root": int(t["root"]), "drums": int(t["drums"]), "lead_amt": float(t["lead"]),
		"sb": int(float(MUSIC_RATE) * spb), "s_size": scale.size(), "li": scale.size(),
		"phase": 0, "step": 0, "peak": 0.001, "bytes": PackedByteArray()}


func _job_section(j: Dictionary, bar: int, sec: int) -> void:
	var buf: PackedFloat32Array = j["buf"]
	var spb: float = j["spb"]
	var scale: Array = j["scale"]
	var root: int = j["root"]
	var drums: int = j["drums"]
	var sb: int = j["sb"]
	var s_size: int = j["s_size"]
	var d: int = int(PROGRESSION[bar]) % s_size
	var bar_start := bar * 4 * sb
	match sec:
		0:
			for k in 3:
				_add_note(buf, bar_start, _freq(_degree_midi(root, scale, d + k * 2)), spb * 4.0, 0.06, spb * 0.8, 0.0)
		1:
			for b in 4:
				if drums == 0 and b % 2 == 1:
					continue
				_add_note(buf, bar_start + b * sb, _freq(_degree_midi(root - 12, scale, d)), spb * 0.9, 0.22, 0.01, 0.0)
		2:
			for e in 8:
				var tone_idx: int = d + int([0, 2, 4, 2][e % 4]) + s_size
				_add_note(buf, bar_start + e * (sb / 2), _freq(_degree_midi(root, scale, tone_idx)), spb * 0.45, 0.05, 0.005, 0.0)
		3:
			var li: int = j["li"]
			for b in 2:
				if rng.randf() < float(j["lead_amt"]):
					li = clampi(li + rng.randi_range(-2, 2), s_size - 2, s_size * 2 + 2)
					_add_note(buf, bar_start + b * 2 * sb, _freq(_degree_midi(root + 12, scale, li)), spb * 1.7, 0.09, 0.03, 0.01)
			j["li"] = li
		4:
			if drums >= 1:
				for b in 4:
					_add_kick(buf, bar_start + b * sb, 0.42)
					if b % 2 == 1:
						_add_noise(buf, bar_start + b * sb, 0.09, 0.16)
				if drums >= 2:
					for e in 8:
						_add_noise(buf, bar_start + e * (sb / 2) + sb / 4, 0.03, 0.07)
						if e % 4 == 3:
							_add_kick(buf, bar_start + e * (sb / 2), 0.25)
	j["buf"] = buf


## Bir iş adımı ilerletir; iş bittiğinde true döner
func _job_step(j: Dictionary) -> bool:
	var n: int = j["n"]
	var chunk := 40000
	match int(j["phase"]):
		0:
			var st: int = j["step"]
			_job_section(j, st / SECTIONS, st % SECTIONS)
			st += 1
			j["step"] = st
			if st >= int(j["bars"]) * SECTIONS:
				j["phase"] = 1
				j["step"] = 0
		1:
			var buf: PackedFloat32Array = j["buf"]
			var from: int = j["step"]
			var peak: float = j["peak"]
			for i in range(from, mini(n, from + chunk)):
				peak = maxf(peak, absf(buf[i]))
			j["peak"] = peak
			j["step"] = from + chunk
			if from + chunk >= n:
				j["phase"] = 2
				j["step"] = 0
				var bytes := PackedByteArray()
				bytes.resize(n * 2)
				j["bytes"] = bytes
		2:
			var buf2: PackedFloat32Array = j["buf"]
			var bytes2: PackedByteArray = j["bytes"]
			var gain := 0.8 / float(j["peak"])
			var from2: int = j["step"]
			for i in range(from2, mini(n, from2 + chunk)):
				bytes2.encode_s16(i * 2, clampi(int(buf2[i] * gain * 32767.0), -32768, 32767))
			j["bytes"] = bytes2
			j["step"] = from2 + chunk
			if from2 + chunk >= n:
				return true
	return false


func _job_store(j: Dictionary) -> AudioStreamWAV:
	var n: int = j["n"]
	var st := AudioStreamWAV.new()
	st.format = AudioStreamWAV.FORMAT_16_BITS
	st.mix_rate = MUSIC_RATE
	st.stereo = false
	st.data = j["bytes"]
	st.loop_mode = AudioStreamWAV.LOOP_FORWARD
	st.loop_begin = 0
	st.loop_end = n
	mutex.lock()
	music_cache[j["theme"]] = st
	mutex.unlock()
	return st


## Eşzamanlı üretim (masaüstünde arka plan iş parçacığında kullanılır)
func music(theme: String) -> AudioStreamWAV:
	var cached := ready_music(theme)
	if cached != null:
		return cached
	var j := _job_begin(theme)
	while not _job_step(j):
		pass
	return _job_store(j)


## Aşamalı üretim: kuyruktaki temaları bütçe (ms) dahilinde ilerletir
func queue_theme(theme: String, front: bool = false) -> void:
	if ready_music(theme) != null or job_queue.has(theme) or (not job.is_empty() and job["theme"] == theme):
		return
	if front:
		job_queue.push_front(theme)
	else:
		job_queue.append(theme)


func step_bake(budget_ms: int) -> void:
	var t0 := Time.get_ticks_msec()
	while Time.get_ticks_msec() - t0 < budget_ms:
		if job.is_empty():
			if job_queue.is_empty():
				return
			job = _job_begin(job_queue.pop_front())
		if _job_step(job):
			_job_store(job)
			job = {}
