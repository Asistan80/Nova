extends RefCounted
## Oyun verileri: karakterler, silahlar, düşmanlar, bölgeler, evrimler, yükseltmeler

const CHAR_ORDER := ["bozkurt", "alp", "saman", "umay", "tulpar", "korkut", "oguz", "asena", "mergen", "kagan"]
const CHARS := {
	"bozkurt": {"name": "Bozkurt", "desc": "Dengeli. Ok Yağmuru ile başlar.", "cost": 0,
		"hp": 100.0, "speed": 230.0, "dmg": 1.0, "regen": 0.0, "xp": 1.0, "magnet": 1.0,
		"start": {"bow": 1}, "color": Color(0.72, 0.78, 0.88), "style": "wolf"},
	"alp": {"name": "Alp Er", "desc": "Çok canlı, yavaş. Kılıç Çemberi ile başlar.", "cost": 150,
		"hp": 150.0, "speed": 208.0, "dmg": 1.1, "regen": 0.0, "xp": 1.0, "magnet": 1.0,
		"start": {"orbit": 1}, "color": Color(0.85, 0.62, 0.3), "style": "knight"},
	"saman": {"name": "Kam", "desc": "Hızlı, az canlı. Gök Gürültüsü ile başlar.", "cost": 300,
		"hp": 85.0, "speed": 245.0, "dmg": 1.0, "regen": 0.5, "xp": 1.2, "magnet": 1.0,
		"start": {"thunder": 1}, "color": Color(0.7, 0.45, 0.95), "style": "shaman"},
	"umay": {"name": "Umay Ana", "desc": "Şifacı. Ateş Aurası ile başlar, hızlı can yeniler.", "cost": 400,
		"hp": 110.0, "speed": 225.0, "dmg": 1.0, "regen": 1.2, "xp": 1.0, "magnet": 1.0,
		"start": {"aura": 1}, "color": Color(0.95, 0.7, 0.75), "style": "mother"},
	"tulpar": {"name": "Tulpar Süvarisi", "desc": "Çok hızlı. Kurt Pençesi ile başlar.", "cost": 550,
		"hp": 90.0, "speed": 285.0, "dmg": 1.0, "regen": 0.0, "xp": 1.0, "magnet": 1.0,
		"start": {"claw": 1}, "color": Color(0.55, 0.85, 0.95), "style": "rider"},
	"korkut": {"name": "Korkut Ata", "desc": "Bilge. Çok XP, geniş mıknatıs. Yoldaş Kurt ile başlar.", "cost": 700,
		"hp": 95.0, "speed": 228.0, "dmg": 0.95, "regen": 0.0, "xp": 1.4, "magnet": 1.8,
		"start": {"wolf": 1}, "color": Color(0.6, 0.8, 0.5), "style": "sage"},
	"oguz": {"name": "Oğuz Han", "desc": "Güçlü hükümdar. Ok ve Kılıç ile başlar.", "cost": 1000,
		"hp": 140.0, "speed": 238.0, "dmg": 1.25, "regen": 0.3, "xp": 1.1, "magnet": 1.0,
		"start": {"bow": 1, "orbit": 1}, "color": Color(0.95, 0.85, 0.35), "style": "khan"},
	"asena": {"name": "Asena", "desc": "Kutsal dişi kurt. Hızlı; Yoldaş Kurt ve Pençe ile başlar.", "cost": 1300,
		"hp": 105.0, "speed": 252.0, "dmg": 1.05, "regen": 0.3, "xp": 1.0, "magnet": 1.2,
		"start": {"wolf": 1, "claw": 1}, "color": Color(0.92, 0.95, 1.0), "style": "wolf"},
	"mergen": {"name": "Mergen", "desc": "Usta avcı. Yüksek kritik şansı; Alp Mızrağı ile başlar.", "cost": 1700,
		"hp": 92.0, "speed": 244.0, "dmg": 1.1, "regen": 0.0, "xp": 1.1, "magnet": 1.0, "crit": 0.12,
		"start": {"mizrak": 1}, "color": Color(0.45, 0.7, 0.4), "style": "hunter"},
	"kagan": {"name": "Bilge Kağan", "desc": "Güçlü ve bilge. Savaş Baltası ve Kırağı ile başlar.", "cost": 2300,
		"hp": 135.0, "speed": 232.0, "dmg": 1.2, "regen": 0.4, "xp": 1.2, "magnet": 1.3,
		"start": {"balta": 1, "kirag": 1}, "color": Color(0.4, 0.6, 0.95), "style": "kagan"},
}

const WEAPON_ORDER := ["bow", "orbit", "aura", "thunder", "claw", "wolf", "mizrak", "balta", "kirag", "tengri", "alev", "suru", "gokmizrak", "buzfirtina"]
const WEAPONS := {
	"bow": {"name": "Ok Yağmuru", "desc": "Daha güçlü, daha hızlı ve daha fazla ok", "evo": false},
	"orbit": {"name": "Kılıç Çemberi", "desc": "Etrafında dönen kılıçlar, yakındakileri doğrar", "evo": false},
	"aura": {"name": "Ateş Aurası", "desc": "Çevrendeki düşmanları yakan alan", "evo": false},
	"thunder": {"name": "Gök Gürültüsü", "desc": "Gökten rastgele düşmanlara yıldırım düşer", "evo": false},
	"claw": {"name": "Kurt Pençesi", "desc": "Önündeki düşmanları yırtan geniş pençe darbesi", "evo": false},
	"wolf": {"name": "Yoldaş Kurt", "desc": "Düşmanları kovalayıp ısıran ruh kurtları", "evo": false},
	"mizrak": {"name": "Alp Mızrağı", "desc": "Sıradaki düşmanları delip geçen uzun, ağır mızraklar", "evo": false},
	"balta": {"name": "Savaş Baltası", "desc": "Fırlayıp geri dönen, gidiş-dönüşte vuran baltalar", "evo": false},
	"kirag": {"name": "Kırağı", "desc": "Çevrene buz dalgası yayar; düşmanları yavaşlatıp hasar verir", "evo": false},
	"gokmizrak": {"name": "Gök Mızrağı", "desc": "EVRİM: Yıldırım çarpan mızrak yağmuru ve peşinden dönen baltalar", "evo": true},
	"buzfirtina": {"name": "Kış Fırtınası", "desc": "EVRİM: Yakıp donduran dev alan ve periyodik buz patlaması", "evo": true},
	"tengri": {"name": "Tengri Oku", "desc": "EVRİM: Her şeyi delen, yıldırım çarpan oklar", "evo": true},
	"alev": {"name": "Alev Çemberi", "desc": "EVRİM: Düşmanları tutuşturan dev kılıç halkası", "evo": true},
	"suru": {"name": "Kurt Sürüsü", "desc": "EVRİM: Hayalet kurtlardan oluşan ölümcül sürü", "evo": true},
}

const EVO_ORDER := ["tengri", "alev", "suru", "gokmizrak", "buzfirtina"]
const EVOS := {
	"tengri": {"a": "bow", "b": "thunder"},
	"alev": {"a": "orbit", "b": "aura"},
	"suru": {"a": "claw", "b": "wolf"},
	"gokmizrak": {"a": "mizrak", "b": "balta"},
	"buzfirtina": {"a": "kirag", "b": "aura"},
}
const EVO_MIN_LV := 5

const META_ORDER := ["hp", "dmg", "speed", "magnet", "xp", "regen"]
const META := {
	"hp": {"name": "Demir Yürek", "desc": "+6 maksimum can", "base": 40},
	"dmg": {"name": "Alp Gücü", "desc": "+%2 hasar", "base": 60},
	"speed": {"name": "Bozkır Rüzgarı", "desc": "+%1.2 hareket hızı", "base": 50},
	"magnet": {"name": "Mıknatıs", "desc": "+%6 XP toplama menzili", "base": 40},
	"xp": {"name": "Bilgelik", "desc": "+%2.5 XP kazancı", "base": 70},
	"regen": {"name": "Yenilenme", "desc": "+0.06 can/sn yenilenme", "base": 80},
}

## ai: chase, dash, ranged, zigzag, exploder, healer, split, boss
## look: blob, spiky, cyclops, wolf, archer, armor, ghost, flame, splitter, droplet
const ENEMIES := {
	"albasti": {"name": "Albastı", "hp": 10.0, "speed": 95.0, "radius": 12.0, "dmg": 8.0, "xp": 1, "armor": 0.0,
		"color": Color(0.75, 0.35, 0.9), "ai": "chase", "look": "blob"},
	"surale": {"name": "Şüräle", "hp": 22.0, "speed": 135.0, "radius": 14.0, "dmg": 10.0, "xp": 2, "armor": 0.0,
		"color": Color(0.3, 0.85, 0.5), "ai": "chase", "look": "spiky"},
	"tepegoz": {"name": "Tepegöz", "hp": 70.0, "speed": 55.0, "radius": 24.0, "dmg": 16.0, "xp": 5, "armor": 0.0,
		"color": Color(0.95, 0.6, 0.25), "ai": "chase", "look": "cyclops"},
	"kara_kurt": {"name": "Kara Kurt", "hp": 20.0, "speed": 85.0, "radius": 15.0, "dmg": 11.0, "xp": 3, "armor": 0.0,
		"color": Color(0.3, 0.3, 0.38), "ai": "dash", "look": "wolf"},
	"yek": {"name": "Yek", "hp": 16.0, "speed": 70.0, "radius": 13.0, "dmg": 9.0, "xp": 3, "armor": 0.0,
		"color": Color(0.8, 0.3, 0.35), "ai": "ranged", "look": "archer"},
	"demir_dev": {"name": "Demir Dev", "hp": 95.0, "speed": 48.0, "radius": 22.0, "dmg": 17.0, "xp": 6, "armor": 5.0,
		"color": Color(0.6, 0.65, 0.72), "ai": "chase", "look": "armor"},
	"ruh": {"name": "Ruh", "hp": 14.0, "speed": 110.0, "radius": 12.0, "dmg": 8.0, "xp": 2, "armor": 0.0,
		"color": Color(0.6, 0.85, 0.95), "ai": "zigzag", "look": "ghost"},
	"cin": {"name": "Ateş Cini", "hp": 12.0, "speed": 125.0, "radius": 13.0, "dmg": 16.0, "xp": 3, "armor": 0.0,
		"color": Color(1.0, 0.5, 0.15), "ai": "exploder", "look": "flame"},
	"catal": {"name": "Çatal Ruh", "hp": 30.0, "speed": 80.0, "radius": 17.0, "dmg": 10.0, "xp": 3, "armor": 0.0,
		"color": Color(0.4, 0.7, 0.5), "ai": "split", "look": "splitter"},
	"minik": {"name": "Minik", "hp": 6.0, "speed": 150.0, "radius": 8.0, "dmg": 6.0, "xp": 1, "armor": 0.0,
		"color": Color(0.5, 0.8, 0.55), "ai": "chase", "look": "blob"},
	"iye": {"name": "İye", "hp": 28.0, "speed": 60.0, "radius": 15.0, "dmg": 6.0, "xp": 4, "armor": 0.0,
		"color": Color(0.3, 0.85, 0.8), "ai": "healer", "look": "droplet"},
	"kor_dev": {"name": "Kor Dev", "hp": 85.0, "speed": 55.0, "radius": 22.0, "dmg": 18.0, "xp": 6, "armor": 4.0,
		"color": Color(0.85, 0.25, 0.15), "ai": "chase", "look": "armor"},
	"su_iyesi": {"name": "Su İyesi", "hp": 18.0, "speed": 65.0, "radius": 13.0, "dmg": 9.0, "xp": 3, "armor": 0.0,
		"color": Color(0.3, 0.6, 0.95), "ai": "ranged", "look": "droplet"},
	"boss": {"name": "Boss", "hp": 700.0, "speed": 62.0, "radius": 46.0, "dmg": 25.0, "xp": 40, "armor": 0.0,
		"color": Color(0.85, 0.15, 0.2), "ai": "boss", "look": "cyclops"},
}

## pattern: slam, summon, ring, dash
const BOSS_LIST := [
	{"name": "Dev Tepegöz", "pattern": "slam", "color": Color(0.85, 0.2, 0.2)},
	{"name": "Erlik'in Gölgesi", "pattern": "summon", "color": Color(0.45, 0.15, 0.6)},
	{"name": "Şahmaran", "pattern": "ring", "color": Color(0.2, 0.65, 0.4)},
	{"name": "Kara Kam", "pattern": "dash", "color": Color(0.25, 0.2, 0.35)},
	{"name": "Demir Dev", "pattern": "slam", "color": Color(0.55, 0.6, 0.7)},
	{"name": "Yelbegen", "pattern": "spiral", "color": Color(0.3, 0.55, 0.35)},
	{"name": "Kara Ejder", "pattern": "breath", "color": Color(0.8, 0.3, 0.1)},
	{"name": "Kar Kağanı", "pattern": "frost", "color": Color(0.55, 0.8, 0.95)},
	{"name": "Erlik Han", "pattern": "erlik", "color": Color(0.6, 0.05, 0.25)},
]

const STAGE_ORDER := ["bozkir", "orman", "lav", "deniz", "firtina", "kar", "yeralti"]
## roster: [düşman, başlangıç saniyesi, ağırlık]
const STAGES := {
	"bozkir": {"name": "Bozkır", "desc": "Sonsuz bozkır. Başlangıç bölgesi.", "cost": 0,
		"ground": Color(0.15, 0.18, 0.12), "grid": Color(1, 1, 1, 0.04), "edge": Color(0.9, 0.3, 0.3),
		"tint": Color(0, 0, 0, 0), "hp_mult": 1.0, "gold_mult": 1.0, "spawn_mult": 1.0, "music": "bozkir",
		"pool": "", "pool_density": 0.0, "hazard": "", "hazard_interval": 0.0, "current": 0.0, "boss_offset": 0,
		"roster": [["albasti", 0.0, 10.0], ["surale", 25.0, 6.0], ["kara_kurt", 45.0, 4.0], ["tepegoz", 60.0, 3.0],
			["yek", 90.0, 3.0], ["ruh", 110.0, 2.0], ["demir_dev", 130.0, 2.0], ["catal", 150.0, 2.0]]},
	"orman": {"name": "Gölgeli Orman", "desc": "Kurt sürüleri ve zehirli bataklıklar (yavaşlatır). Altın x1.25", "cost": 120,
		"ground": Color(0.06, 0.13, 0.08), "grid": Color(1, 1, 1, 0.0), "edge": Color(0.3, 0.8, 0.4),
		"tint": Color(0.0, 0.08, 0.02, 0.18), "hp_mult": 1.1, "gold_mult": 1.25, "spawn_mult": 1.0, "music": "orman",
		"pool": "swamp", "pool_density": 0.2, "hazard": "", "hazard_interval": 0.0, "current": 0.0, "boss_offset": 5,
		"roster": [["albasti", 0.0, 6.0], ["kara_kurt", 0.0, 6.0], ["surale", 20.0, 4.0], ["iye", 50.0, 3.0],
			["yek", 70.0, 3.0], ["catal", 90.0, 3.0], ["tepegoz", 100.0, 3.0], ["ruh", 120.0, 2.0]]},
	"lav": {"name": "Lav Arenası", "desc": "Lav havuzları yakar, gökten meteor düşer. Altın x1.5", "cost": 280,
		"ground": Color(0.11, 0.07, 0.07), "grid": Color(1, 0.4, 0.1, 0.03), "edge": Color(1.0, 0.45, 0.1),
		"tint": Color(0.25, 0.04, 0.0, 0.12), "hp_mult": 1.25, "gold_mult": 1.5, "spawn_mult": 1.0, "music": "lav",
		"pool": "lava", "pool_density": 0.17, "hazard": "meteor", "hazard_interval": 3.4, "current": 0.0, "boss_offset": 6,
		"roster": [["albasti", 0.0, 5.0], ["cin", 0.0, 7.0], ["surale", 20.0, 4.0], ["kor_dev", 60.0, 3.0],
			["yek", 70.0, 3.0], ["tepegoz", 90.0, 2.0], ["catal", 100.0, 2.0], ["demir_dev", 140.0, 2.0]]},
	"deniz": {"name": "Deniz Kıyısı", "desc": "Akıntı seni sürükler, girdaplar çeker. Altın x1.5", "cost": 450,
		"ground": Color(0.05, 0.14, 0.22), "grid": Color(1, 1, 1, 0.0), "edge": Color(0.3, 0.7, 1.0),
		"tint": Color(0.0, 0.1, 0.2, 0.12), "hp_mult": 1.25, "gold_mult": 1.5, "spawn_mult": 1.0, "music": "deniz",
		"pool": "whirl", "pool_density": 0.15, "hazard": "", "hazard_interval": 0.0, "current": 38.0, "boss_offset": 2,
		"roster": [["albasti", 0.0, 6.0], ["su_iyesi", 0.0, 5.0], ["ruh", 20.0, 5.0], ["surale", 30.0, 4.0],
			["iye", 60.0, 3.0], ["catal", 80.0, 3.0], ["demir_dev", 110.0, 2.0], ["tepegoz", 100.0, 2.0]]},
	"firtina": {"name": "Fırtına Ovası", "desc": "Yağmur, gökten yıldırım. Çok zor. Altın x1.9", "cost": 700,
		"ground": Color(0.09, 0.1, 0.15), "grid": Color(0.6, 0.7, 1.0, 0.04), "edge": Color(0.7, 0.8, 1.0),
		"tint": Color(0.02, 0.03, 0.1, 0.35), "hp_mult": 1.5, "gold_mult": 1.9, "spawn_mult": 1.15, "music": "firtina",
		"pool": "", "pool_density": 0.0, "hazard": "lightning", "hazard_interval": 2.8, "current": 0.0, "boss_offset": 4,
		"roster": [["albasti", 0.0, 5.0], ["ruh", 0.0, 5.0], ["surale", 15.0, 5.0], ["kara_kurt", 30.0, 4.0],
			["yek", 50.0, 4.0], ["catal", 70.0, 3.0], ["demir_dev", 90.0, 3.0], ["cin", 100.0, 2.0], ["iye", 110.0, 2.0]]},
	"kar": {"name": "Buzul Geçidi", "desc": "Buz zemin yavaşlatır, tipi savrulur. Altın x2.1", "cost": 950,
		"ground": Color(0.17, 0.22, 0.29), "grid": Color(0.8, 0.9, 1.0, 0.05), "edge": Color(0.8, 0.92, 1.0),
		"tint": Color(0.05, 0.1, 0.2, 0.22), "hp_mult": 1.65, "gold_mult": 2.1, "spawn_mult": 1.1, "music": "kar",
		"pool": "ice", "pool_density": 0.2, "hazard": "", "hazard_interval": 0.0, "current": 0.0, "boss_offset": 7,
		"roster": [["kara_kurt", 0.0, 6.0], ["albasti", 0.0, 4.0], ["ruh", 20.0, 5.0], ["kor_dev", 40.0, 4.0],
			["iye", 60.0, 3.0], ["demir_dev", 90.0, 3.0], ["catal", 100.0, 3.0], ["yek", 110.0, 3.0]]},
	"yeralti": {"name": "Tamu (Yeraltı)", "desc": "Erlik'in diyarı. Yıldırım ve zehirli çukurlar. En zoru. Altın x2.6", "cost": 1400,
		"ground": Color(0.09, 0.04, 0.12), "grid": Color(0.7, 0.3, 0.9, 0.05), "edge": Color(0.75, 0.2, 0.85),
		"tint": Color(0.12, 0.0, 0.15, 0.25), "hp_mult": 2.0, "gold_mult": 2.6, "spawn_mult": 1.25, "music": "yeralti",
		"pool": "void", "pool_density": 0.16, "hazard": "lightning", "hazard_interval": 2.2, "current": 0.0, "boss_offset": 1,
		"roster": [["ruh", 0.0, 5.0], ["cin", 0.0, 5.0], ["yek", 20.0, 5.0], ["surale", 30.0, 4.0], ["kor_dev", 50.0, 4.0],
			["demir_dev", 70.0, 4.0], ["tepegoz", 80.0, 3.0], ["catal", 100.0, 3.0], ["iye", 110.0, 2.0]]},
}


## Başarımlar: id, ad, açıklama, altın ödülü
const ACH_ORDER := ["ilk_av", "yuz_kafa", "bes_yuz", "toplam_5k", "ilk_boss", "boss_25", "tum_devler",
	"dk5", "dk10", "dk15", "zafer", "sv20", "evrim1", "evrim3", "silah8", "sandik10", "kombo50", "kombo100",
	"gezgin", "her_karakter", "ocak_ustasi", "zengin"]
const ACH := {
	"ilk_av": {"name": "İlk Av", "desc": "Bir düşman öldür", "gold": 20},
	"yuz_kafa": {"name": "Yüz Kafa", "desc": "Tek koşuda 100 düşman öldür", "gold": 40},
	"bes_yuz": {"name": "Kırım", "desc": "Tek koşuda 500 düşman öldür", "gold": 120},
	"toplam_5k": {"name": "Bozkırın Kâbusu", "desc": "Toplamda 5000 düşman öldür", "gold": 250},
	"ilk_boss": {"name": "Dev Avcısı", "desc": "İlk bossu yen", "gold": 60},
	"boss_25": {"name": "Efsane Avcı", "desc": "Toplamda 25 boss yen", "gold": 300},
	"tum_devler": {"name": "Tüm Devler", "desc": "9 boss türünün hepsini yen", "gold": 400},
	"dk5": {"name": "Beş Dakika", "desc": "5 dakika hayatta kal", "gold": 40},
	"dk10": {"name": "On Dakika", "desc": "10 dakika hayatta kal", "gold": 100},
	"dk15": {"name": "Çeyrek Saat", "desc": "15 dakika hayatta kal", "gold": 200},
	"zafer": {"name": "Zafer!", "desc": "15 dakikayı tamamla (Zafer ekranı)", "gold": 300},
	"sv20": {"name": "Yirminci Seviye", "desc": "Bir koşuda 20. seviyeye ulaş", "gold": 80},
	"evrim1": {"name": "Evrim", "desc": "İlk evrim silahını yap", "gold": 80},
	"evrim3": {"name": "Evrim Ustası", "desc": "5 evrim silahının hepsini yap", "gold": 350},
	"silah8": {"name": "Silah Ustası", "desc": "Bir silahı en üst seviyeye (8) çıkar", "gold": 120},
	"sandik10": {"name": "Hazine Avcısı", "desc": "Toplamda 10 sandık aç", "gold": 150},
	"kombo50": {"name": "Kombo", "desc": "50'lik kombo yap", "gold": 60},
	"kombo100": {"name": "Kombo Ustası", "desc": "100'lük kombo yap", "gold": 150},
	"gezgin": {"name": "Gezgin", "desc": "7 bölgenin hepsinde oyna", "gold": 150},
	"her_karakter": {"name": "On Kahraman", "desc": "10 karakterin hepsiyle oyna", "gold": 200},
	"ocak_ustasi": {"name": "Ocak Ustası", "desc": "Bir kalıcı yükseltmeyi 25. seviyeye çıkar", "gold": 300},
	"zengin": {"name": "Hazinedar", "desc": "5000 altına sahip ol", "gold": 150},
}
