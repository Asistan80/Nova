const $=s=>document.querySelector(s);
let INFO=null,ST=null,cur=null,selLoc=null,busy=false,cfg={};
const api=(u,b)=>fetch(u,b===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}).then(r=>r.json());
function speak(t,sid){ if(!cfg.voice||!('speechSynthesis' in window))return; try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='tr-TR';
  const vs=speechSynthesis.getVoices().filter(v=>/^tr/i.test(v.lang));const fem=sid==='leman'||sid==='sureyya';
  const pick=vs.find(v=>fem?/(emel|female|kad)/i.test(v.name):/(tolga|male|erkek)/i.test(v.name))||vs[0];if(pick)u.voice=pick;
  u.pitch={leman:1.0,sureyya:1.4,cevdet:0.9,artin:0.7,kemal:1.1}[sid]||1;u.rate={sureyya:1.1,artin:0.9}[sid]||1;speechSynthesis.speak(u);}catch(e){} }
// --- ses (WebAudio, dosyasız)
let AC=null;
function snd(kind){
  if(cfg.sound===false)return;
  try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();
  const t=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();o.connect(g);g.connect(AC.destination);
  const P={click:[520,.05,'triangle',.06],found:[330,.35,'sine',.1],bad:[120,.4,'sawtooth',.07],conf:[90,.9,'sawtooth',.1],send:[400,.06,'triangle',.05]}[kind]||[400,.05,'sine',.05];
  o.frequency.value=P[0];o.type=P[2];g.gain.setValueAtTime(P[3],t);g.gain.exponentialRampToValueAtTime(.0001,t+P[1]);
  if(kind==='found')o.frequency.setValueAtTime(330,t),o.frequency.setValueAtTime(495,t+.12);
  o.start(t);o.stop(t+P[1]);}catch(e){}
}
function esc(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}
async function init(){
  INFO=await api('/api/info');cfg=INFO.config;ST=await api('/api/state');
  $('#intro').textContent=INFO.intro;$('#introTxt').textContent=INFO.intro;
  const fill=(sel,obj)=>{$(sel).innerHTML=Object.entries(obj).map(([k,v])=>`<option value="${k}">${esc(v)}</option>`).join('')};
  fill('#aS',Object.fromEntries(INFO.order.map(k=>[k,INFO.suspects[k].name])));fill('#aM',INFO.methods);fill('#aN',INFO.motives);
  cur=INFO.order[0];drawMap();drawSus();render();
  let seen=false;try{seen=localStorage.getItem('dedektif_intro')===ST.seed+''}catch(e){}
  if(!seen&&ST.found.length===0&&ST.time==='00:10')$('#mIntro').classList.add('on');
  if(ST.over)showRes(ST.over);
}
function drawMap(){
  $('#map').innerHTML=Object.entries(INFO.locations).map(([k,l])=>`<button class="pin${ST.visited.includes(k)?' v':''}${selLoc===k?' hot':''}" data-k="${k}" style="left:${l.x}%;top:${l.y}%">${esc(l.short)}</button>`).join('');
  document.querySelectorAll('.pin').forEach(b=>b.onclick=()=>{selLoc=b.dataset.k;snd('click');const l=INFO.locations[selLoc];
    $('#locinfo').innerHTML=`<b>${esc(l.name)}</b> — ${esc(l.desc)}<br>Arama: ${l.cost} dk`+(ST.visited.includes(selLoc)?' · <i>daha önce arandı</i>':'');
    $('#bSearch').disabled=!!ST.over;drawMap();});
}
function drawSus(){
  $('#sus').innerHTML=INFO.order.map(k=>{const s=INFO.suspects[k];return `<button class="s${k===cur?' on':''}" data-k="${k}"><div class="av" style="background:${s.color}">${s.initial}</div>${esc(k==='artin'?'Artin':s.name.split(' ')[0])}<div class="pr"><i style="width:${ST.pressure[k]||0}%"></i></div></button>`}).join('');
  document.querySelectorAll('.s').forEach(b=>b.onclick=()=>{cur=b.dataset.k;snd('click');drawSus();drawChat()});
}
function drawChat(){
  const s=INFO.suspects[cur];
  $('#wAv').style.background=s.color;$('#wAv').textContent=s.initial;$('#wName').textContent=s.name;$('#wRole').textContent=s.role+' · '+s.age+' · '+s.attire;
  $('#claim').textContent=ST.asked.includes(cur)?'İfadesi: '+s.claim:'Henüz ifadesini almadın.';
  const L=ST.log[cur]||[];
  $('#chat').innerHTML=(L.length?'':`<div class="m sys">${esc(s.name)} karşında oturuyor. Soruna başla.</div>`)+L.map(m=>`<div class="m ${m.who}">${esc(m.text)}</div>`).join('');
  $('#chat').scrollTop=1e9;
  const q=[['Gece neredeydin?','neredeydin']];
  q.push(['Nazım Efendi ile aranız nasıldı?',''],['Saklayacak bir şey var mı?','']);
  INFO.order.filter(k=>k!==cur).forEach(k=>q.push(['"'+(k==='artin'?'Artin':INFO.suspects[k].name.split(' ')[0])+'" hakkında ne düşünüyorsun?','']));
  $('#quick').innerHTML=q.map(x=>`<button data-q="${esc(x[0])}">${esc(x[0])}</button>`).join('');
  document.querySelectorAll('#quick button').forEach(b=>b.onclick=()=>{$('#q').value=b.dataset.q.replace(/&quot;/g,'"');$('#q').focus()});
}
function drawEv(){
  $('#evCount').textContent='('+ST.found.length+')';
  $('#evl').innerHTML=ST.found.slice().reverse().map(e=>`<div class="ev ${e.kind}"><b>${esc(e.name)}</b>${esc(e.text)}<div class="tag">${esc(INFO.locations[e.loc].name)}</div></div>`).join('')||'<div class="tag">Henüz kanıt yok. Odaları ara.</div>';
  const v=$('#evSel').value;
  $('#evSel').innerHTML='<option value="">Kanıt göstermeden</option>'+ST.found.map(e=>`<option value="${e.id}">${esc(e.name)}</option>`).join('');$('#evSel').value=v;
}
function render(){
  $('#time').textContent=ST.time;$('#tbar').style.width=(ST.minutes_left/ST.deadline*100)+'%';$('#bHint').textContent='İpucu ('+ST.hints+')';
  drawSus();drawChat();drawEv();drawMap();$('#notes').value=ST.notes||'';
  $('#aiTag').textContent=ST.over?'Soruşturma bitti.':'';
}
$('#bStart').onclick=()=>{$('#mIntro').classList.remove('on');try{localStorage.setItem('dedektif_intro',ST.seed+'')}catch(e){}snd('click')};
$('#bSearch').onclick=async()=>{
  if(!selLoc||busy)return;busy=true;const r=await api('/api/search',{loc:selLoc});busy=false;
  if(r.error){alert(r.error);return}
  ST=r.state;render();
  const l=INFO.locations[selLoc];
  let h=`<h3>${esc(l.name)} <span class="tag">(${r.cost} dk geçti)</span></h3>`;
  if(r.new.length){snd('found');h+=r.new.map(e=>`<div class="ev found ${e.kind}"><b>${esc(e.name)}</b>${esc(e.text)}</div>`).join('')}
  else h+='<p>Yeni bir şey bulamadın.</p>';
  if(r.hidden)h+=`<p class="tag">Bu odada henüz anlam veremediğin ${r.hidden} ayrıntı olabilir; ilgili kişinin ifadesini veya başka bir kanıtı aldıktan sonra tekrar bak.</p>`;
  $('#locBox').innerHTML=h+'<div class="row"><button class="btn" id="lx">Tamam</button></div>';$('#mLoc').classList.add('on');$('#lx').onclick=()=>{$('#mLoc').classList.remove('on');if(ST.over)showRes(ST.over)};
};
$('#form').onsubmit=async e=>{
  e.preventDefault();if(busy||ST.over)return;
  const text=$('#q').value.trim(),ev=$('#evSel').value;if(!text&&!ev)return;
  busy=true;$('#send').disabled=true;snd('send');
  const L=ST.log[cur];L.push({who:'you',text:ev?'[Kanıt] '+text:text});L.push({who:'them',text:'…'});drawChat();
  $('#q').value='';$('#evSel').value='';
  const r=await api('/api/ask',{suspect:cur,text,evidence:ev});
  busy=false;$('#send').disabled=false;
  if(r.error){L.pop();L.pop();drawChat();alert(r.error);return}
  ST=r.state;render();
  speak(r.reply,cur);
  if(r.confess){snd('conf');const c=[...document.querySelectorAll('#chat .m.them')].pop();if(c)c.classList.add('conf')}
  $('#aiTag').textContent='Yanıt: '+({yerel:'çevrimdışı',claude:'Claude',groq:'Groq',ollama:'Ollama'}[r.provider]||r.provider)+(r.reveal?' · sır açıldı':'')+(r.confess?' · İTİRAF':'');
  if(ST.over)showRes(ST.over);
};
$('#bHint').onclick=async()=>{if(ST.over||busy)return;if(!confirm('İpucu 15 dakikaya mal olur ve puanını 3 düşürür. Devam?'))return;
  const r=await api('/api/hint',{});if(r.error){alert(r.error);return}ST=r.state;render();$('#locBox').innerHTML='<h3>İpucu</h3><p>'+esc(r.hint)+'</p><div class="row"><button class="btn" id="lx">Tamam</button></div>';$('#mLoc').classList.add('on');$('#lx').onclick=()=>{$('#mLoc').classList.remove('on');if(ST.over)showRes(ST.over)}};
$('#bNotes').onclick=()=>$('#mNotes').classList.add('on');
$('#nClose').onclick=async()=>{await api('/api/notes',{notes:$('#notes').value});ST.notes=$('#notes').value;$('#mNotes').classList.remove('on')};
$('#bNew').onclick=async()=>{if(!confirm('Yeni vaka başlasın mı? Mevcut soruşturma silinir.'))return;ST=await api('/api/new',{});selLoc=null;$('#mRes').classList.remove('on');$('#locinfo').textContent='Bir odaya tıkla.';$('#bSearch').disabled=true;render();$('#mIntro').classList.add('on')};
$('#bAcc').onclick=()=>{if(ST.over)return;$('#mAcc').classList.add('on')};
$('#aX').onclick=()=>$('#mAcc').classList.remove('on');
$('#aGo').onclick=async()=>{
  if(!confirm('Emin misin? Bu karar kesindir.'))return;
  const r=await api('/api/accuse',{suspect:$('#aS').value,method:$('#aM').value,motive:$('#aN').value});
  if(r.error){alert(r.error);return}
  ST=r.state;$('#mAcc').classList.remove('on');render();showRes(r.result);
};
function showRes(o){
  snd(o.win?'found':'bad');
  $('#resBox').className='box res '+(o.win?'win':'lose');
  let best='';if(o.win){try{const k='dd_best';const b=Math.max(+localStorage.getItem(k)||0,o.score);localStorage.setItem(k,b);best=`<p class="best">En yüksek puanın: ${b}</p>`}catch(e){}}
  $('#resBox').innerHTML=`<h3>${esc(o.title)}</h3><p>${esc(o.text)}</p>`+(o.win?`<p>Puan: <b>${o.score}</b> / 140</p>${best}`:'')+`<div class="row"><button class="btn pri" id="rn">Yeni vaka</button><button class="btn" id="rc">Kapat</button></div>`;
  $('#mRes').classList.add('on');
  $('#rn').onclick=()=>$('#bNew').click();$('#rc').onclick=()=>$('#mRes').classList.remove('on');
}
$('#bCfg').onclick=()=>{const c=cfg;$('#cProv').value=c.provider;$('#cOl').value=c.ollama_url;$('#cOm').value=c.ollama_model;$('#cSnd').value=c.sound?'1':'0';$('#cVoice').value=c.voice?'1':'0';$('#cDiff').value=c.difficulty||'normal';
  $('#cCl').placeholder=c.claude_key_set?'(kayıtlı — değiştirmek için yaz)':'sk-ant-...';$('#cGr').placeholder=c.groq_key_set?'(kayıtlı — değiştirmek için yaz)':'gsk_...';$('#cOut').textContent='';$('#mCfg').classList.add('on')};
$('#cX').onclick=()=>$('#mCfg').classList.remove('on');
$('#cSave').onclick=async()=>{cfg=await api('/api/config',{provider:$('#cProv').value,claude_key:$('#cCl').value,groq_key:$('#cGr').value,ollama_url:$('#cOl').value,ollama_model:$('#cOm').value,sound:$('#cSnd').value==='1',voice:$('#cVoice').value==='1',difficulty:$('#cDiff').value});$('#cCl').value='';$('#cGr').value='';$('#cOut').textContent='Kaydedildi. Zorluk yeni vakada geçerli.'};
$('#cTest').onclick=async()=>{$('#cOut').textContent='Deneniyor…';const r=await api('/api/test-ai',{});
  $('#cOut').innerHTML=esc(r.summary)+'<br>'+r.results.map(x=>x.ok?`✓ ${esc(x.label)}: ${esc(x.model||'')} (${x.ms} ms)`:`✗ ${esc(x.error||'hata')}${x.models&&x.models.length?'<br>&nbsp;&nbsp;Yüklü modeller: '+esc(x.models.slice(0,6).join(', ')):''}`).join('<br>')};
init();
