"""Vaka verisi ve üretici. Pera Köşkü, Mart 1927: Hacı Nazım Efendi zehirlenerek öldürüldü.
Katil her oyunda rastgele seçilir; kanıt metinleri katile göre değişir."""
import random

VICTIM = {
    "name": "Hacı Nazım Efendi", "age": 62, "role": "İthalat tüccarı, köşkün sahibi",
}

INTRO = (
    "12 Mart 1927, gece 00:10. Pera'daki Nazım Efendi'nin köşkü kar fırtınasının ortasında kalmış; yollar kapalı. "
    "Evin reisi Hacı Nazım Efendi, yıl dönümü yemeğinden sonra çalışma odasında ölü bulundu. "
    "Oda içeriden kilitliydi. Kadehinde arsenik var. Köşkte beş kişi ve kapıcı var; kimse içeri girmedi, kimse çıkmadı. "
    "Sabah 06:00'da yol açılınca Komiser Rıza ekibiyle gelecek ve dosyayı kapatacak. "
    "Katili o zamana kadar bulmak sana kaldı."
)

LOCATIONS = {
    "calisma": {"name": "Çalışma Odası", "desc": "Cinayet yeri. Meşe masa, deri koltuk, kilitli kapı.", "cost": 20, "x": 66, "y": 12, "short": "Çalışma Odası"},
    "salon": {"name": "Salon", "desc": "Yemekten sonra herkesin toplandığı geniş oda.", "cost": 12, "x": 24, "y": 34, "short": "Salon"},
    "hol": {"name": "Giriş Holü", "desc": "Telefon, kapıcı defteri ve ana merdiven.", "cost": 12, "x": 50, "y": 46, "short": "Giriş Holü"},
    "kutuphane": {"name": "Kütüphane", "desc": "Rafların arasında okuma masası ve şirket defterleri.", "cost": 15, "x": 22, "y": 12, "short": "Kütüphane"},
    "mutfak": {"name": "Mutfak", "desc": "Uşakların dünyası: dolaplar, defter, bulaşık teknesi.", "cost": 15, "x": 78, "y": 34, "short": "Mutfak"},
    "bahce": {"name": "Bahçe", "desc": "Karla kaplı yol, çardak ve bahçe kulübesi.", "cost": 18, "x": 50, "y": 95, "short": "Bahçe"},
    "leman_oda": {"name": "Leman Hanım'ın Odası", "desc": "Üst kat, doğu kanadı.", "cost": 15, "x": 27, "y": 59, "short": "Leman'ın odası"},
    "cevdet_oda": {"name": "Cevdet Bey'in Odası", "desc": "Üst kat, misafir odası.", "cost": 15, "x": 72, "y": 59, "short": "Cevdet'in odası"},
    "artin_oda": {"name": "Dr. Artin'in Odası", "desc": "Üst kat, batı kanadı.", "cost": 15, "x": 27, "y": 72, "short": "Artin'in odası"},
    "sureyya_oda": {"name": "Süreyya'nın Odası", "desc": "Çatı katındaki dar hizmetçi odası.", "cost": 15, "x": 50, "y": 84, "short": "Süreyya'nın odası"},
    "kemal_oda": {"name": "Kemal'in Odası", "desc": "Üst kat, bahçeye bakan oda.", "cost": 15, "x": 73, "y": 72, "short": "Kemal'in odası"},
}

# --------------------------------------------------------------------------------------------
SUSPECTS = {
    "leman": {
        "name": "Leman Hanım", "age": 46, "role": "Nazım Efendi'nin eşi", "color": "#8b5a8c",
        "attire": "mor ipek şal, sedef broş", "fiber": "mor ipek şal lifi", "initial": "L",
        "style": "Kibar, soğukkanlı ve gururlu. Kısa, keskin cümleler kurar; duygusunu belli etmez. 'Efendim' der.",
        "claim": "Yemekten sonra başım ağrıdı, 22:30'da odama çekildim ve mektup yazdım. Kimseyi görmedim.",
        "claim_short": "22:30'dan sonra odasında mektup yazıyordu.",
        "relation": "Yirmi iki yıllık eşi. Evlilikleri son yıllarda soğuk ve resmîydi.",
        "secret": "Avukat Mösyö Kerim'e boşanma dilekçesi hazırlıyordu; Nazım Efendi öğrenirse onu mirastan edecekti.",
        "slip": "Mektubun ne olduğunu söylemek zorunda değilim... sadece özel bir yazışma.",
        "cleared": "Peki... Avukatıma yazıyordum. Boşanmak istiyordum, evet. Ama bunun için kimseyi öldürmem; yalnızca imzayı beklerdim.",
        "method": "Bahçe kulübesindeki gül ilacındaki arseniği kadehe kattı.",
        "motive": "Boşanırsa mirastan eli boş kalacaktı; Nazım ölürse her şey ona kalıyordu.",
        "confession": "Evet... ben yaptım. Yirmi iki yılımı çaldı, bir de her şeyimi elimden alacaktı. Gül ilacı bahçe kulübesindeydi; kadehine ben kattım, sonra kendi kadehimi yıkadım.",
        "gossip": {"cevdet": "Cevdet Bey kasaya son aylarda sık girip çıkıyordu, defterleri de gizliyordu.",
                   "kemal": "Kemal yine borçlanmıştı; Tarlabaşı'ndan biri kapıda onu bekliyormuş."},
        "room": "leman_oda", "alibi_loc": "mutfak", "src_loc": "bahce",
        "room_text": "Yazı masasında yarım kalmış bir mektup: 'Sayın Mösyö Kerim, boşanma davası için gerekli belgeleri...' Mürekkep taze görünüyor.",
        "room_vial": "Yatak başlığının arkasına sıkıştırılmış ipek mendil içinde küçük cam şişe: dibinde mavimsi beyaz tortu var.",
        "a_clear": "Mutfak çay defteri: '23:15 — Leman Hanım'a ıhlamur; hanım yazı masasındaydı, kapıyı aralık tuttu, 'bırak' dedi.'",
        "a_break": "Mutfak çay defteri: '23:15 — Leman Hanım'a ıhlamur götürdüm; kapıyı çaldım, ses gelmedi. Fincanı kapıya bıraktım.' Fincan sabah hâlâ dolu.",
        "src_clear": "Bahçe kulübesinde gül ilacı kutusu: mühür sağlam, kutu dolu.",
        "src_bad": "Bahçe kulübesinde arsenikli gül ilacı kutusu: kapak yeni açılmış, yarısı eksik; kilit kırılmamış, yani anahtarı olan biri açmış.",
    },
    "cevdet": {
        "name": "Cevdet Bey", "age": 51, "role": "Nazım Efendi'nin iş ortağı", "color": "#7a5a2e",
        "attire": "kahverengi takım, kehribar tespih", "fiber": "kehribar tespih tanesi", "initial": "C",
        "style": "Terli, çok konuşan, her şeyi yumuşatmaya çalışan biri. 'Aman efendim', 'Allah Allah' der; panikleyince lafı uzatır.",
        "claim": "Saat 23:00'ten sonra holdeki telefondan Galata Bankası'ndan Mösyö Vitali ile görüştüm; uzun sürdü.",
        "claim_short": "23:00'ten sonra telefonda banka ile görüşüyordu.",
        "relation": "Yirmi yıllık ortağı. Şirketi birlikte kurdular ama kâr payı eşit değildi.",
        "secret": "Şirket kasasından 4.200 lira zimmetine geçirmişti; Nazım Efendi defterlerde açığı bulmuştu.",
        "slip": "Hesaplar... evet, ufak tefek düzeltmeler. Muhasebe işi böyle, efendim.",
        "cleared": "Tamam! Açık var, evet. Parayı geri koyacaktım. Bankayla o yüzden görüşüyordum. Ama adam öldürmek? Asla.",
        "method": "Fabrikadan getirdiği arsenikli boya numunesini kadehe kattı.",
        "motive": "Zimmet açığı yarın ortaya çıkacak ve ihbar edilecekti.",
        "confession": "Kapana kısıldım... Beni savcıya verecekti! Valizimdeki boya numunesinden aldım; kadehine kattım, sonra holde telefon çalıyormuş gibi durdum.",
        "gossip": {"leman": "Leman Hanım son haftalarda avukat Kerim'le mektuplaşıyor, bunu bana bahçıvan söyledi.",
                   "artin": "Doktor Artin'in çantası ağırdı, ellerinin titremesini fark ettim."},
        "room": "cevdet_oda", "alibi_loc": "hol", "src_loc": "cevdet_oda",
        "room_text": "Çekmecede defter sayfaları ve Galata Bankası'ndan ödenmemiş bir senet: açığı kapatmak için borçlanmış.",
        "room_vial": "Valizin çift dibinde cam şişe: etiketsiz, mavimsi tortulu; yanında boya fabrikasından bir irsaliye.",
        "a_clear": "Santral kaydı: 23:05–23:32 Galata Bankası, Mösyö Vitali, 27 dakika. Cevdet Bey o saatte hatta.",
        "a_break": "Santral kaydı: 22:00'den sonra köşkten HİÇBİR görüşme yapılmamış. Bankayla görüşmesi yok.",
        "src_clear": "Valizdeki boya numuneleri: arsenikli kutu mühürlü, sayılı, dokunulmamış.",
        "src_bad": "Arsenikli boya numune kutusunun mührü kırık; içinden bir miktar eksik.",
    },
    "artin": {
        "name": "Dr. Artin Vartanyan", "age": 55, "role": "Aile doktoru", "color": "#4a6a7a",
        "attire": "gri yün palto, siyah doktor çantası", "fiber": "gri yün palto lifi", "initial": "A",
        "style": "Ağırbaşlı, yorgun, hep bir doktor tonuyla konuşur. Latince kelimeler karıştırır, sakin görünür ama ellerini hiç durduramaz.",
        "claim": "Yemekten sonra kütüphaneye geçip saat 23:00'te hasta notlarımı yazdım; Nazım Efendi'yi son olarak yemekte gördüm.",
        "claim_short": "23:00–23:40 arası kütüphanede not yazıyordu.",
        "relation": "On beş yıldır ailenin doktoru ve Nazım Efendi'nin satranç arkadaşı.",
        "secret": "Morfine bağımlıydı; üstelik eski bir hastası Madam Roza'nın ölümüne yol açan doz hatasını Nazım Efendi biliyordu ve ifşa etmekle tehdit ediyordu.",
        "slip": "Çantamdaki ilaçlar mesleğimin gereği. Ve geçmişteki bir vaka... soruşturulmuş, kapanmış.",
        "cleared": "Evet, morfin kullanıyorum; Madam Roza'nın ölümünde hatam vardı ve Nazım bunu biliyordu. Ama o gece kütüphanedeydim, öldürmedim.",
        "method": "Tıbbi çantasındaki arsenikli tonikten kadehe kattı.",
        "motive": "Nazım Efendi, morfin bağımlılığını ve Madam Roza'nın ölümündeki hatasını yarın ifşa edecekti.",
        "confession": "Mesleğimi, adımı elimden alacaktı... Tonik çantamdaydı; kadehine bir miktar kattım. Bir doktor olarak ne kadar yeteceğini biliyordum.",
        "gossip": {"leman": "Leman Hanım'ın geceleri odasında yazı yazdığını biliyorum; ışığı sabaha kadar yanıyor.",
                   "sureyya": "Süreyya yorgun görünüyordu, gözleri kızarmıştı. Annesi hastaymış galiba."},
        "room": "artin_oda", "alibi_loc": "kutuphane", "src_loc": "artin_oda",
        "room_text": "Doktor çantasında morfin ampulleri ve kullanılmış bir şırınga; yarım bırakılmış 'Nazım, lütfen konuşalım' notu.",
        "room_vial": "Çantanın astarının altında cam şişe: arsenikli tonik, neredeyse boş; etiketi kazınmış.",
        "a_clear": "Kütüphanede okuma lambası yanmış, masada Doktor'un 23:00–23:40 arası yazdığı hasta notları var; mürekkep taze.",
        "a_break": "Kütüphanede okuma lambası hiç yakılmamış, gaz seviyesi tam; defter kapalı, koltuk soğuk.",
        "src_clear": "Tıbbi çanta: arsenikli tonik şişesi dolu, mühürlü.",
        "src_bad": "Tıbbi çanta: arsenikli tonik şişesi neredeyse boş, mühür sökülmüş.",
    },
    "sureyya": {
        "name": "Süreyya", "age": 24, "role": "Hizmetçi", "color": "#3b6fa0",
        "attire": "mavi pamuklu önlük, beyaz tülbent", "fiber": "mavi pamuk önlük lifi", "initial": "S",
        "style": "Ürkek, saygılı, başı hep önde. 'Hanımefendi', 'Efendim', 'Allah korusun' der; korkunca kekeler.",
        "claim": "Akşam yemeğinden sonra mutfakta bulaşık yıkadım, sonra odama çıktım. Başka bir yere gitmedim.",
        "claim_short": "Mutfakta bulaşık yıkıyordu.",
        "relation": "Üç yıldır köşkte çalışıyor; Nazım Efendi ona hep sert davranırdı.",
        "secret": "Gümüş kaşıkları çalıp rehincide bozduruyordu; hasta annesinin ilaç parası içindi.",
        "slip": "Efendim ben... kaşıkları saydım, hepsi yerinde... yani neredeyse.",
        "cleared": "Çaldım efendim... annem için! Ama o gece mutfaktaydım. Beyefendiye bir şey yapmadım, Allah şahit.",
        "method": "Mutfaktaki fare zehrini kadehe kattı.",
        "motive": "Nazım Efendi hırsızlığını öğrenmiş, yarın polise verecekti.",
        "confession": "Beni hapse atacaktı, annem de ölecekti... Fare zehrini kadehe kattım, tepsiye geri koydum. Kimse beni görmez, hiç görmedi.",
        "gossip": {"kemal": "Kemal Bey'i gece bahçede gördüm sanki, elinde sigara; kar üstünde iz bırakıyordu.",
                   "cevdet": "Cevdet Bey öğleden sonra defter çekmecesini kilitledi; elleri titriyordu."},
        "room": "sureyya_oda", "alibi_loc": "mutfak", "src_loc": "mutfak",
        "room_text": "Yatağın altında bohça: gümüş kaşıklar, rehinci makbuzu ve annesinden gelmiş telgraf: 'Hastayım, para gönder.'",
        "room_vial": "Yatak başlığının altında kavanoz kapağı ve içinde mavimsi tozla bulaşmış bez: kadehteki tortuyla aynı.",
        "a_clear": "Mutfak: bulaşık teknesinde 23:30'a kadar yıkanmış tabaklar, sabun hâlâ ılık; kurutma bezi ıslak.",
        "a_break": "Mutfak: tabaklar kirli, sabun kurumuş; bulaşığa hiç dokunulmamış.",
        "src_clear": "Mutfak rafı: fare zehri kavanozu en üstte, tozlu, dokunulmamış.",
        "src_bad": "Mutfak rafı: fare zehri kavanozunun tozu silinmiş, yarısı eksik, kapakta parmak izi.",
    },
    "kemal": {
        "name": "Kemal", "age": 27, "role": "Nazım Efendi'nin yeğeni", "color": "#a0392b",
        "attire": "kırmızı yün atkı, koyu palto", "fiber": "kırmızı yün atkı lifi", "initial": "K",
        "style": "Havalı, küstah, alaycı; ama korkunca sesi çatlar. Argo kelimeler ve 'amca' der; sinirlenince bağırır.",
        "claim": "Yemekten sonra 22:50'de bahçeye çıkıp çardakta sigara içtim; 23:40'a kadar dışarıdaydım.",
        "claim_short": "22:50–23:40 bahçede sigara içiyordu.",
        "relation": "Öksüz kaldığı için amcası yetiştirdi; ama harçlığını kesmeye başlamıştı.",
        "secret": "Tarlabaşı'nda kumarda 3.000 lira borçlanmıştı; bahçe kapısında tefeciyle buluşup süre istiyordu. Amcası onu vasiyetten çıkaracaktı.",
        "slip": "Dışarıda biriyle... işim vardı. Sana ne?",
        "cleared": "Tamam! Borçluyum, tefeci kapıdaydı. Ama o gece bahçedeydim, amcama zarar vermedim. Ona minnettardım bile.",
        "method": "Pera Eczanesi'nden sahte reçeteyle aldığı arseniği kadehe kattı.",
        "motive": "Vasiyetten çıkarılacaktı ve kumar borcunu ancak mirasla ödeyebilirdi.",
        "confession": "Beni sokağa atacaktı... Eczaneden sahte reçeteyle aldım; kadehine kattım, sonra bahçeye çıktım. Ama yemin ederim sadece uyusun sandım!",
        "gossip": {"artin": "Doktor Artin geceleri yalnız dolaşıyor, bazen kütüphanede hiç ışık yakmadan oturuyor.",
                   "leman": "Yenge geceleri kimseye görünmeden gazete okuyor, avukat ilanlarına bakıyor."},
        "room": "kemal_oda", "alibi_loc": "bahce", "src_loc": "kemal_oda",
        "room_text": "Çekmecede Tarlabaşı Hayri imzalı 3.000 liralık borç senedi; sandalyede kırmızı yün atkı asılı.",
        "room_vial": "Paltonun iç cebinde cam şişe ve içinde mavimsi tortu; yanında Pera Eczanesi etiketi.",
        "a_clear": "Bahçe: yolda taze ayak izleri; 22:55'ten 23:40'a kadar kapı ile çardak arasında gidiş-geliş, çardakta altı izmarit.",
        "a_break": "Bahçe: kar bozulmamış; çardak dahil hiçbir yerde taze iz yok. Kimse dışarı çıkmamış.",
        "src_clear": "Palto cebi: Pera Eczanesi makbuzu — 'öksürük şurubu', masum bir alışveriş.",
        "src_bad": "Palto cebi: Pera Eczanesi makbuzu — 'arsenik trioksit 20 gr, 11 Mart', sahte reçeteyle alınmış.",
    },
}

WITNESS = {
    "name": "Kapıcı Hamdi", "age": 58, "role": "Köşkün kapıcısı", "color": "#5c6b4a",
    "style": "Yaşlı, mahcup, Anadolu ağzıyla konuşur. 'Beyim', 'vallahi' der; aşağı sınıf olduğunu bilir, çekingendir.",
    "claim": "Kapıyı saat 21:00'de kilitledim, anahtar bende. Fırtına yüzünden kimse çıkmadı, kimse girmedi.",
}

ORDER = ["leman", "cevdet", "artin", "sureyya", "kemal"]
METHODS = {
    "leman": "Bahçe kulübesindeki gül ilacındaki arsenik",
    "cevdet": "Fabrika boya numunesindeki arsenik",
    "artin": "Doktor çantasındaki arsenikli tonik",
    "sureyya": "Mutfaktaki fare zehri",
    "kemal": "Eczaneden sahte reçeteyle alınan arsenik",
}
MOTIVES = {
    "leman": "Boşanırsa mirasın dışında kalacaktı",
    "cevdet": "Zimmet açığı ortaya çıkıp ihbar edilecekti",
    "artin": "Morfin bağımlılığı ve hastasının ölümü ifşa olacaktı",
    "sureyya": "Hırsızlığı öğrenilip polise verilecekti",
    "kemal": "Vasiyetten çıkarılacak, kumar borcu ödenemeyecekti",
}


def build(seed=None, culprit=None):
    rnd = random.Random(seed)
    c = culprit or rnd.choice(ORDER)
    innocents = [s for s in ORDER if s != c]
    decoy = rnd.choice(innocents)
    S = SUSPECTS
    ev = []

    def add(eid, loc, name, text, strength=0, req=None, targets=None, kind="genel"):
        ev.append({"id": eid, "loc": loc, "name": name, "text": text, "strength": strength,
                   "req": req or [], "targets": targets or {}, "kind": kind})

    # --- ortak kanıtlar ---------------------------------------------------------------
    add("body", "calisma", "Nazım Efendi'nin cesedi",
        "Nazım Efendi koltuğunda, başı yana düşmüş. Dudakları morarmış. Ölüm saati 23:00–23:40 arası. Kapı içeriden kilitliydi, "
        "anahtar yeleğindeydi: yani katil, Nazım kapıyı kilitlemeden ÖNCE çıkmış, zehir ise sonradan etki etmiş.", kind="olay")
    add("glasses", "calisma", "İki kadeh",
        "Masada iki kadeh: biri yarı dolu konyaklı, tabanında beyaz tortu; test kâğıdım arsenik gösterdi. İkinci kadeh yıkanıp ters çevrilmiş: "
        "biri onunla içer gibi yapmış ve izini silmiş. Katil Nazım'la yüz yüze oturmuş.", kind="olay")
    add("calendar", "calisma", "Masa takvimi",
        "12 Mart satırında 'Saat 23:00 — görüşme' yazıyor; yanındaki isim silinmiş. Kurşun kalemle gölgelediğimde baş harf belirdi: "
        "'%s.'" % S[c]["initial"], 22, targets={c: 22}, kind="isaret")
    add("fiber", "calisma", "Koltuk altındaki lif",
        "Koltuğun altında, ikinci kadehin yakınında bir parça: %s." % S[c]["fiber"], 22, targets={c: 22}, kind="isaret")
    add("decoy", "calisma", "Halıdaki ikinci lif",
        "Halıda başka bir iz: %s. Odaya birisi daha girmiş olmalı." % S[decoy]["fiber"], 0, targets={decoy: 40}, kind="sahte")
    add("notes", "calisma", "Nazım Efendi'nin cep defteri",
        "Yarınki kahvaltı için not almış: 'L. — avukat Kerim meselesi. C. — defterlerdeki açık. A. — Madam Roza'nın ölümü ve morfin. "
        "S. — gümüş kaşıklar. K. — borç ve vasiyet.' Herkesin bir sırrı varmış; herkesin bir nedeni.", 0,
        targets={s: 14 for s in ORDER}, kind="motif")
    add("will", "calisma", "Vasiyet taslağı",
        "İmzasız yeni vasiyet: ev ve gelirler Leman Hanım'a; Kemal'in payı silinmiş; Cevdet'in ortaklık payı Leman'a devrediliyor. "
        "İmzalanmadan ölmüş; bu, gerçek varisleri belirsiz bırakıyor.", 0, targets={"kemal": 14, "cevdet": 14, "leman": 8}, kind="motif")
    add("seating", "salon", "Yemek sofrası düzeni",
        "Sofra 22:25'te dağıldı. Nazım Efendi kadehini kaldırıp 'Yarın kahvaltıda herkesin hesabı görülecek' demiş. "
        "Herkes kendi yoluna gitmiş; 22:30–23:40 arası kimin nerede olduğu tek tek sorulmalı.", kind="olay")
    add("doorman", "hol", "Kapıcı defteri",
        "Kapıcı defteri: 21:00'de ana kapı ve bahçe kapısı kilitlendi, fırtına yüzünden köşke giren çıkan olmadı. "
        "Katil içeridekilerden biri.", kind="olay")
    add("ledger", "kutuphane", "Şirket defterleri",
        "Şirket defterlerinde 4.200 liralık açık; düzeltmeler Cevdet Bey'in el yazısıyla.", 0, targets={"cevdet": 40}, kind="motif")

    # --- şüpheli bazlı kanıtlar ------------------------------------------------------
    for sid in ORDER:
        s = S[sid]
        guilty = sid == c
        # alibi kanıtı: şüpheli alibisini anlattıktan sonra erişilir
        add("a_" + sid, s["alibi_loc"], "Alibi kontrolü: " + s["name"],
            s["a_break"] if guilty else s["a_clear"], 24 if guilty else 0,
            req=[("asked", sid)], targets={sid: 24 if guilty else 55}, kind="alibi_kotu" if guilty else "alibi_iyi")
        # zehir kaynağı: zehir bilindikten sonra
        add("src_" + sid, s["src_loc"], "Zehir kaynağı: " + s["name"],
            s["src_bad"] if guilty else s["src_clear"], 24 if guilty else 0,
            req=["glasses"], targets={sid: 24 if guilty else 0}, kind="kaynak_kotu" if guilty else "kaynak_iyi")
        # oda
        if guilty:
            add("vial_" + sid, s["room"], "Gizlenmiş şişe",
                s["room_vial"], 30, req=["glasses"], targets={sid: 30}, kind="kesin")
        else:
            add("room_" + sid, s["room"], s["name"].split()[0] + "'in odasında bulunan",
                s["room_text"], 0, targets={sid: 45}, kind="sir")
    return {"culprit": c, "decoy": decoy, "evidence": ev}


def location_of(ev_id, case):
    for e in case["evidence"]:
        if e["id"] == ev_id:
            return e["loc"]
    return None
