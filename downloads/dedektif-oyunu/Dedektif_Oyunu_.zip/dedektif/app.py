"""Pera Köşkü Cinayeti: yapay zekâlı dedektif oyunu. http://127.0.0.1:5056"""
import json
import os
import threading
from flask import Flask, jsonify, request, send_from_directory

import case as C
import config
import engine
import providers

app = Flask(__name__, static_folder="static", static_url_path="/static")
SAVE = os.path.join(config.DATA, "save.json")
_lock = threading.Lock()
G = None


def to_dict(g):
    d = {k: v for k, v in vars(g).items() if k != "case"}
    d["presented"] = {k: sorted(v) for k, v in g.presented.items()}
    for k in ("asked", "revealed", "visited"):
        d[k] = sorted(d[k])
    d["culprit"] = g.case["culprit"]
    return d


def from_dict(d):
    g = engine.Game(d["seed"], d["culprit"])
    for k, v in d.items():
        if k in ("culprit", "seed"):
            continue
        if k in ("asked", "revealed", "visited"):
            v = set(v)
        if k == "presented":
            v = {a: set(b) for a, b in v.items()}
        setattr(g, k, v)
    return g


def save():
    try:
        with open(SAVE, "w", encoding="utf-8") as f:
            json.dump(to_dict(G), f, ensure_ascii=False)
    except OSError:
        pass


def load():
    global G
    try:
        with open(SAVE, encoding="utf-8") as f:
            G = from_dict(json.load(f))
    except Exception:
        G = None


def ensure():
    global G
    if G is None:
        G = engine.Game(diff=config.load().get("difficulty", "normal"))
        save()
    return G


def ai_reply(g, sid, plan, text):
    cfg = config.load()
    if cfg.get("provider") == "yerel":
        return g.offline_reply(sid, plan, text), "yerel"
    system = g.system_prompt(sid, plan)
    msgs = []
    for m in g.log[sid][-10:]:
        msgs.append({"role": "user" if m["who"] == "you" else "assistant", "content": m["text"]})
    msgs.append({"role": "user", "content": text or "(Dedektif sana bir kanıt gösteriyor.)"})
    # ardışık aynı rol birleştir
    merged = []
    for m in msgs:
        if merged and merged[-1]["role"] == m["role"]:
            merged[-1]["content"] += "\n" + m["content"]
        else:
            merged.append(dict(m))
    while merged and merged[0]["role"] != "user":
        merged.pop(0)
    out, name = [], "yerel"
    for n, chunk in providers.stream(cfg, system, merged, text or "x"):
        if chunk.startswith("\0ERR:"):
            return g.offline_reply(sid, plan, text), "yerel"
        name = n
        out.append(chunk)
    reply = "".join(out).strip()
    if not reply:
        return g.offline_reply(sid, plan, text), "yerel"
    # güvenlik: itiraf izni yokken katil itiraf ettiyse, çevrimdışı metne dön
    if sid == g.case["culprit"] and not plan["confess"]:
        low = reply.lower()
        if any(k in low for k in ("ben öldürdüm", "ben yaptım", "evet, ben yaptım", "kadehine ben kattım", "zehri ben")):
            return g.offline_reply(sid, plan, text), "yerel"
    return reply, name


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/info")
def info():
    return jsonify({**engine.static_info(), "config": config.public(config.load())})


@app.get("/api/state")
def state():
    with _lock:
        return jsonify(ensure().state())


@app.post("/api/new")
def new():
    global G
    with _lock:
        b = request.get_json(silent=True) or {}
        G = engine.Game(b.get("seed"), b.get("culprit") if b.get("culprit") in C.ORDER else None, config.load().get("difficulty", "normal"))
        save()
        return jsonify(G.state())


@app.post("/api/search")
def search():
    with _lock:
        g = ensure()
        r = g.search((request.get_json(silent=True) or {}).get("loc"))
        save()
        return jsonify({**r, "state": g.state()})


@app.post("/api/ask")
def ask():
    b = request.get_json(silent=True) or {}
    sid, text, ev = b.get("suspect"), (b.get("text") or "").strip()[:400], b.get("evidence") or None
    with _lock:
        g = ensure()
        if not text and not ev:
            return jsonify({"error": "Bir şey sor ya da kanıt göster."}), 400
        if ev:
            text = text or "Bunu açıklar mısın?"
            ev_name = g.ev.get(ev, {}).get("name", "")
            shown = "[Kanıt: %s] %s" % (ev_name, text)
        else:
            shown = text
        plan = g.ask(sid, text, ev)
        if "error" in plan:
            return jsonify(plan), 400
    reply, prov = ai_reply(g, sid, plan, shown)
    with _lock:
        g.record(sid, "you", shown)
        g.record(sid, "them", reply)
        save()
        return jsonify({"reply": reply, "provider": prov, "stage": plan["stage"], "confess": plan["confess"],
                        "reveal": plan["reveal"], "state": g.state()})


@app.post("/api/hint")
def hint():
    with _lock:
        g = ensure()
        r = g.hint()
        save()
        if "error" in r:
            return jsonify(r), 400
        return jsonify({**r, "state": g.state()})


@app.post("/api/notes")
def notes():
    with _lock:
        g = ensure()
        g.notes = str((request.get_json(silent=True) or {}).get("notes", ""))[:6000]
        save()
        return jsonify({"ok": True})


@app.post("/api/accuse")
def accuse():
    b = request.get_json(silent=True) or {}
    with _lock:
        g = ensure()
        if b.get("suspect") not in C.ORDER:
            return jsonify({"error": "Şüpheli seç."}), 400
        r = g.accuse(b["suspect"], b.get("method"), b.get("motive"))
        save()
        return jsonify({"result": r, "state": g.state()})


@app.post("/api/config")
def set_config():
    cfg = config.update(request.get_json(silent=True) or {})
    providers.reset_state()
    return jsonify(config.public(cfg))


@app.post("/api/test-ai")
def test_ai():
    """Her sağlayıcıyı ayrı dener; anahtarı olmayanlar 'girilmemiş' görünür."""
    providers.reset_state()
    cfg = config.load()
    res = [providers.diagnose(cfg, n) for n in ("claude", "groq", "ollama")]
    ok = [r for r in res if r["ok"]]
    return jsonify({"ok": bool(ok), "results": res,
                    "summary": ("Çalışan: " + ", ".join(r["label"] + " (" + r.get("model", "?") + ")" for r in ok)) if ok
                    else "Hiçbiri çalışmıyor; oyun çevrimdışı yanıtlarla oynanır."})


load()
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5056)), threaded=True)
