# Pera Köşkü Cinayeti — Yapay Zekâlı Dedektif Oyunu

12 Mart 1927, İstanbul. Kar fırtınasında kapalı kalan köşkte Hacı Nazım Efendi zehirlenmiş. Beş şüpheli var; sabah 06:00'da dosya kapanacak.

## Çalıştırma
- Windows: `baslat.bat` çift tıkla (Python 3.10+ gerekir).
- Mac/Linux: `./baslat.sh`
Tarayıcıda http://127.0.0.1:5056 açılır.

## Nasıl oynanır
1. **Odaları ara** (harita): her arama 12–20 dk sürer. Bazı kanıtlar, ilgili kişinin ifadesini aldıktan veya zehir bulunduktan sonra görünür; odaya tekrar bak.
2. **Sorgula**: şüpheliye serbest cümleyle soru sor (gece neredeydin, ilişkiniz, sırrı, diğerleri hakkında). Her soru 4 dk.
3. **Kanıt göster**: listeden bir kanıt seç. Doğru kanıtlar baskıyı artırır; masumlar sırlarını açar, katil yeterince kanıtla çöker.
4. **Suçla**: katil, yöntem ve nedeni seç. Tek hakkın var.
Katil her yeni vakada rastgele değişir; kanıt metinleri ona göre yazılır.

## Yapay zekâ
Ayarlar'dan Claude veya Groq anahtarı gir (ya da yerelde Ollama çalıştır). Şüpheliler karakterlerine göre canlı konuşur. Anahtar yoksa hazır çevrimdışı yanıtlar kullanılır; oyun yine tam oynanır. Önemli kararlar (itiraf, sır açma) her zaman oyun kuralları tarafından verilir; yapay zekâ yalnızca ifadeyi yazar ve izinsiz itiraf ederse yanıt reddedilir. Anahtarlar yalnızca `data/config.json` içinde, bu bilgisayarda tutulur.

## Dosyalar
`case.py` vaka/kanıt verisi · `engine.py` oyun kuralları · `app.py` sunucu · `providers.py` Claude/Groq/Ollama · `static/` arayüz · `tests/test_all.py`
