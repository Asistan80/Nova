"""Ayarlar: data/config.json + ortam değişkenleri. Anahtarlar yalnızca bu bilgisayarda tutulur."""
import json
import os
import threading

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get("DEDEKTIF_DATA", os.path.join(BASE, "data"))
os.makedirs(DATA, exist_ok=True)
CFG_PATH = os.path.join(DATA, "config.json")
_lock = threading.Lock()

DEFAULTS = {
    "player": "Dedektif",
    "provider": "auto",             # auto | claude | groq | ollama | yerel
    "claude_key": "", "claude_model": "claude-sonnet-5-5",
    "claude_url": "https://api.anthropic.com/v1/messages",
    "groq_key": "", "groq_model": "llama-3.3-70b-versatile",
    "groq_url": "https://api.groq.com/openai/v1/chat/completions",
    "ollama_url": "http://localhost:11434", "ollama_model": "llama3.1",
    "ollama_enabled": True,
    "sound": True,
    "difficulty": "normal",    # kolay | normal | zor (yeni vakada geçerli)
    "voice": False,            # yanıtları sesli oku
}
SECRET = ("claude_key", "groq_key")
ENV = {"claude_key": "ANTHROPIC_API_KEY", "groq_key": "GROQ_API_KEY"}


def load() -> dict:
    cfg = dict(DEFAULTS)
    with _lock:
        try:
            with open(CFG_PATH, encoding="utf-8") as f:
                cfg.update(json.load(f))
        except (FileNotFoundError, ValueError):
            pass
    for k, env in ENV.items():
        if not cfg.get(k) and os.environ.get(env):
            cfg[k] = os.environ[env]
    return cfg


def save(cfg: dict):
    with _lock:
        tmp = CFG_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CFG_PATH)


def update(changes: dict) -> dict:
    cfg = load()
    for k, v in changes.items():
        if k not in DEFAULTS:
            continue
        if k in SECRET:
            if v == "__clear__":
                cfg[k] = ""
            elif v:
                cfg[k] = v
            continue
        if isinstance(DEFAULTS[k], bool):
            cfg[k] = bool(v)
        else:
            cfg[k] = v
    save(cfg)
    return cfg


def public(cfg: dict) -> dict:
    out = {k: v for k, v in cfg.items() if k not in SECRET}
    for k in SECRET:
        out[k + "_set"] = bool(cfg.get(k))
    return out
