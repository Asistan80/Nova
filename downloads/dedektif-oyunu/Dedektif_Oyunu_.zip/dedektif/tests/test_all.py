import os, sys, tempfile, json
os.environ["DEDEKTIF_DATA"] = tempfile.mkdtemp()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import case as C, engine, app as A

def play_win(seed, culprit):
    g = engine.Game(seed, culprit)
    for l in C.LOCATIONS: g.search(l)
    for s in C.ORDER: g.ask(s, "neredeydin?")
    for l in C.LOCATIONS: g.search(l)
    g.minute = 100; g.over = None
    return g

fails = 0
def check(c, m):
    global fails
    print(("OK  " if c else "FAIL"), m)
    if not c: fails += 1

for cu in C.ORDER:
    g = play_win(3, cu)
    check(g.case["culprit"] == cu, "katil " + cu)
    # masum biri kanıtla itiraf etmemeli
    for s in C.ORDER:
        for e in list(g.found):
            g.minute = 100; p = g.ask(s, "bu ne", e)
            if s != cu: assert not p["confess"], (s, e)
    check(g.confessed == cu, cu + " itiraf etti; masumlar etmedi")
    # katilin sunulan kanıtı yetersizken itiraf etmemeli
    g2 = engine.Game(3, cu); g2.search("calisma"); g2.search("hol"); g2.ask(cu, "neredeydin"); 
    p = g2.ask(cu, "sen yaptın"); check(not p["confess"], cu + " kanıtsız itiraf etmedi")
    prompt = g.system_prompt(cu, p)
    check("GİZLİ GERÇEK" in prompt and C.SUSPECTS[cu]["method"] in prompt, "yönerge katil")
    r = g.accuse(cu, cu, cu); check(r["win"] and r["score"] >= 100, "doğru suçlama %s puan=%s" % (cu, r["score"]))
    g3 = engine.Game(3, cu); wrong = [s for s in C.ORDER if s != cu][0]
    check(not g3.accuse(wrong, wrong, wrong)["win"], "yanlış suçlama")

# zaman aşımı
g = engine.Game(1)
for _ in range(100): g.search("calisma")
check(g.over and g.over["timeout"], "zaman aşımı")

# tüm intent / çevrimdışı yanıtlar boş değil
g = engine.Game(5)
for s in C.ORDER:
    for t in ["merhaba","neredeydin","aranız nasıldı","sır var mı","para borç","sen katilsin","Kemal hakkında","Leman nasıl biri","bilmem ne"]:
        p = g.ask(s, t); r = g.offline_reply(s, p, t)
        assert r and len(r) > 5, (s, t)
check(True, "çevrimdışı yanıtlar dolu")

# Flask
c = A.app.test_client()
r = c.get("/api/info").get_json(); check(len(r["order"]) == 5, "info")
c.post("/api/new", json={"seed": 9, "culprit": "kemal"})
r = c.post("/api/search", json={"loc": "calisma"}).get_json(); check(len(r["new"]) >= 5, "arama")
c.post("/api/config", json={"provider": "yerel"})
r = c.post("/api/ask", json={"suspect": "kemal", "text": "Gece neredeydin?"}).get_json()
check(r["provider"] == "yerel" and r["reply"], "ask yerel")
r = c.post("/api/ask", json={"suspect": "kemal", "text": ""}); check(r.status_code == 400, "boş soru 400")
r = c.post("/api/ask", json={"suspect": "x", "text": "a"}); check(r.status_code == 400, "bilinmeyen kişi")
c.post("/api/config", json={"provider": "auto", "ollama_enabled": False})
r = c.post("/api/ask", json={"suspect": "kemal", "text": "Peki ya Leman?"}).get_json(); check(r["provider"] == "yerel", "sağlayıcı yoksa çevrimdışı")
A.G = None; A.load(); check(A.G is not None and A.G.case["culprit"] == "kemal", "kayıt/yükleme")
check("claude_key" not in c.get("/api/info").get_json()["config"], "anahtar sızmıyor")
# sahte yapay zekâ: katil izinsiz itiraf ederse reddedilmeli
A.providers.stream = lambda *a, **k: iter([("claude", "Evet, ben yaptım, kadehine ben kattım.")])
c.post("/api/config", json={"provider": "claude", "claude_key": "x"})
r = c.post("/api/ask", json={"suspect": "kemal", "text": "Katil sen misin?"}).get_json()
check(r["provider"] == "yerel", "izinsiz itiraf filtrelendi")
A.providers.stream = lambda *a, **k: iter([("claude", "Hmm, gece bahçedeydim.")])
r = c.post("/api/ask", json={"suspect": "kemal", "text": "Başka?"}).get_json(); check(r["provider"] == "claude", "yapay zekâ yolu")
print("HATA:", fails); sys.exit(1 if fails else 0)
