@echo off
cd /d "%~dp0"
if not exist .venv (python -m venv .venv || (echo Python bulunamadi & pause & exit /b 1))
call .venv\Scripts\activate
pip install -q -r requirements.txt
start "" http://127.0.0.1:5056
python app.py
pause
