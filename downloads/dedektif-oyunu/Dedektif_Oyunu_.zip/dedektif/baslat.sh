#!/usr/bin/env bash
cd "$(dirname "$0")"
if [ ! -d .venv ]; then python3 -m venv .venv || { echo "python3 bulunamadı"; exit 1; }; fi
. .venv/bin/activate
pip install -q -r requirements.txt
(sleep 2; (xdg-open http://127.0.0.1:5056 || open http://127.0.0.1:5056) >/dev/null 2>&1) &
python app.py
