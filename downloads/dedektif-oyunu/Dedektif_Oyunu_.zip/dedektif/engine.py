"""Oyun motoru: durum, arama, sorgu mantığı (kural tabanlı) ve yapay zekâ için yönerge üretimi.
Kritik kararlar (itiraf, sır açma) HER ZAMAN burada, deterministik verilir; yapay zekâ yalnızca ifadeyi yazar."""
import re
import time
import case as C

START_MIN = 10          # 00:10
DEADLINE = 360          # 06:00
ASK_COST = 4
CONFESS_AT = 60         # sunulan kanıtların toplam gücü
TR = str.maketrans("çğıöşüÇĞİÖŞÜâîû", "cgiosuCGIOSUaiu")


def fold(t):
    return t.translate(TR).lower()


def fmt_time(m):
    m = min(m, 24 * 60)
    return "%02d:%02d" % ((m // 60) % 24, m % 60)


DIFF = {"kolay": 420, "normal": 360, "zor": 300}


class Game:
    def __init__(self, seed=None, culprit=None, diff="normal"):
        self.diff = diff if diff in DIFF else "normal"
        self.deadline = DIFF[self.diff]
        self.hints = 0
        self.seed = seed if seed is not None else int(time.time() * 1000) % 10**9
        self.case = C.build(self.seed, culprit)
        self.minute = START_MIN
        self.found = []              # kanıt id sırası
        self.asked = set()           # alibisini anlatmış şüpheliler
        self.revealed = set()        # sırrı açılmış şüpheliler
        self.presented = {s: set() for s in C.ORDER}
        self.pressure = {s: 0 for s in C.ORDER}
        self.confessed = None
        self.log = {s: [] for s in C.ORDER + ["hamdi"]}
        self.visited = set()
        self.notes = ""
        self.over = None             # None | dict(sonuç)
        self.asks = 0

    # ---------------------------------------------------------------- kanıt
    @property
    def ev(self):
        return {e["id"]: e for e in self.case["evidence"]}

    def _met(self, e):
        for r in e["req"]:
            if isinstance(r, tuple):
                if r[1] not in self.asked:
                    return False
            elif r not in self.found:
                return False
        return True

    def search(self, loc):
        if self.over:
            return {"error": "Soruşturma bitti."}
        if loc not in C.LOCATIONS:
            return {"error": "Böyle bir yer yok."}
        cost = C.LOCATIONS[loc]["cost"]
        self.minute += cost
        self.visited.add(loc)
        here = [e for e in self.case["evidence"] if e["loc"] == loc]
        new = [e for e in here if e["id"] not in self.found and self._met(e)]
        for e in new:
            self.found.append(e["id"])
        locked = [e for e in here if e["id"] not in self.found]
        self._check_time()
        return {"new": [self.pub_ev(e) for e in new], "hidden": len(locked), "cost": cost}

    def pub_ev(self, e):
        return {"id": e["id"], "loc": e["loc"], "name": e["name"], "text": e["text"], "kind": e["kind"]}

    # ---------------------------------------------------------------- sorgu
    def intent(self, text):
        t = fold(text)
        if re.search(r"katil|sen yapt|sen oldur|itiraf|zehirle", t):
            return "accuse"
        for sid, s in C.SUSPECTS.items():
            if sid in t:
                return "other:" + sid
        if re.search(r"nerede|alibi|ne yapiyor|nerdeydin|saat|gece|yemekten sonra|22|23", t):
            return "alibi"
        if re.search(r"sir|gizle|sakla|borc|para|neden|niye|sebep|dava|miras|vasiyet|hirsiz|morfin|kumar", t):
            return "secret"
        if re.search(r"iliski|aran|nasil biri|sevdi|kimdi|hakkinda|nazim|amca|esin|ortag", t):
            return "relation"
        if re.search(r"merhaba|selam|iyi geceler|gunaydin", t):
            return "hello"
        return "other_q"

    def reply_plan(self, sid, text, ev_id=None):
        """Deterministik karar. Dönüş: dict(stage, facts, text)"""
        s = C.SUSPECTS[sid]
        guilty = sid == self.case["culprit"]
        ev = self.ev.get(ev_id) if ev_id else None
        intent = "evidence" if ev else self.intent(text)
        plan = {"intent": intent, "confess": False, "reveal": False, "stage": "calm", "facts": [], "cost": ASK_COST}

        if ev and ev_id in self.found:
            if ev_id in self.presented[sid]:
                plan.update(intent="repeat", facts=["Aynı kanıt daha önce gösterildi."])
                plan["cost"] = 1
            else:
                self.presented[sid].add(ev_id)
                w = ev["targets"].get(sid, 0)
                if w:
                    self.pressure[sid] += w
                    plan["facts"].append("Kanıt doğrudan bu kişiyi ilgilendiriyor: " + ev["text"])
                else:
                    plan["facts"].append("Kanıt bu kişiyle ilgisiz görünüyor: " + ev["name"])
                    plan["intent"] = "evidence_miss"
                if ev["kind"] == "sahte" and ev["targets"].get(sid):
                    plan["stage"] = "nervous"
                    plan["facts"].append("Bu iz masum bir nedenle de orada olabilir; bunu söyle.")
        elif intent == "alibi":
            self.asked.add(sid)
            plan["facts"].append("Alibi: " + s["claim"])
        elif intent == "accuse":
            self.pressure[sid] += 3
            plan["stage"] = "angry" if not guilty else "nervous"
        elif intent == "secret":
            self.pressure[sid] += 6
        elif intent == "relation":
            plan["facts"].append("İlişki: " + s["relation"])
        elif intent.startswith("other:"):
            o = intent.split(":")[1]
            if o == sid:
                plan["intent"] = "other_q"
            else:
                g = s["gossip"].get(o)
                plan["facts"].append("Hakkındaki sözler: " + (g or "Onu pek tanımıyorum, kendi işine bakar."))
                plan["gossip_target"] = o

        # --- durum geçişleri
        pr = self.pressure[sid]
        proof = sum(self.ev[i]["targets"].get(sid, 0) for i in self.presented[sid] if i in self.ev)
        if guilty and proof >= CONFESS_AT:
            plan["confess"] = True
            plan["stage"] = "break"
            self.confessed = sid
        elif sid not in self.revealed and pr >= 40 and not guilty:
            plan["reveal"] = True
            plan["stage"] = "cleared"
            self.revealed.add(sid)
            plan["facts"].append("Sırrını itiraf et: " + s["secret"] + ". Ama cinayeti işlemediğini vurgula, o gece alibini yinele: " + s["claim"])
        elif sid not in self.revealed and pr >= 25 and not guilty:
            plan["stage"] = "slip"
            plan["facts"].append("Sırrına yaklaşıldı; kaçamak yap: " + s["slip"])
        elif guilty and pr >= 30:
            plan["stage"] = "nervous"
        elif guilty and pr >= 15:
            plan["stage"] = "tense"
        elif pr >= 20:
            plan["stage"] = "tense"
        return plan

    def ask(self, sid, text, ev_id=None):
        if self.over:
            return {"error": "Soruşturma bitti."}
        if sid not in C.SUSPECTS:
            return {"error": "Bilinmeyen kişi."}
        plan = self.reply_plan(sid, text, ev_id)
        self.minute += plan["cost"]
        self.asks += 1
        self._check_time()
        return plan

    def record(self, sid, who, text):
        self.log[sid].append({"who": who, "text": text})

    # ---------------------------------------------------------------- çevrimdışı ifade
    def offline_reply(self, sid, plan, text):
        s = C.SUSPECTS[sid]
        st = plan["stage"]
        it = plan["intent"]
        name = s["name"].split()[0]
        if plan["confess"]:
            return s["confession"]
        if plan["reveal"]:
            return s["cleared"]
        if it == "repeat":
            return "Bunu zaten gösterdin. Yeni bir şey söyleyeceksen dinliyorum."
        if it == "hello":
            return "İyi geceler... Şu halde nazik olmak zor ama dinliyorum."
        if it == "alibi":
            tail = {"calm": "", "tense": " Neden tekrar soruyorsun?", "nervous": " Yeter artık, bunu anlattım!",
                    "slip": " Ve bunun ötesi beni ilgilendirmez.", "angry": " Bu bir suçlama mı?"}.get(st, "")
            return s["claim"] + tail
        if it == "relation":
            return s["relation"] + " Ama bu cinayetle ne ilgisi var?"
        if it == "secret":
            if st == "slip":
                return s["slip"]
            return {"calm": "Herkesin bir şeyi vardır, kimsenin değil. Bana özel bir şey sormuyorsun umarım.",
                    "tense": "Neyi ima ediyorsun? Dikkatli ol.", "nervous": "Bu soruyu duymak istemiyorum."
                    }.get(st, "Cevap vermek zorunda değilim.")
        if it == "accuse":
            if st == "nervous":
                return "Ben... bak, yanlış yoldasın. Kanıtın var mı?"
            return "Beni mi suçluyorsun?! Kanıtın varsa göster, yoksa susmayı tercih ederim."
        if it.startswith("evidence") or it == "evidence":
            if it == "evidence_miss":
                return "Bu bana ne anlatıyor? Bunun benimle ilgisi yok, komiserim."
            if st == "nervous" and sid == self.case["culprit"]:
                return "Bu... bir tesadüf olmalı. Orada başkaları da vardı. Yanlış anlıyorsun."
            if st == "nervous":
                return "Evet, bu benim... ama göründüğü gibi değil. Açıklayabilirim."
            return "Bunu görmüştüm. Şüpheli görünebilir ama masum bir açıklaması var."
        if it.startswith("other:") or plan.get("gossip_target"):
            o = plan.get("gossip_target")
            g = s["gossip"].get(o)
            return (g + " Ama kimseyi suçlamak istemem.") if g else "Onu pek tanımam. Kendi işine bakan biridir."
        return {"calm": "Bu soruyu anlamadım. Cinayet gecesi hakkında mı soruyorsun?",
                "tense": "Daha net sor. Sabrım sınırlı.",
                "nervous": "Beni sıkıştırıyorsun..."}.get(st, "Ne demek istiyorsun?")

    # ---------------------------------------------------------------- yapay zekâ yönergesi
    def system_prompt(self, sid, plan):
        s = C.SUSPECTS[sid]
        guilty = sid == self.case["culprit"]
        known = [self.ev[i]["name"] for i in sorted(self.presented[sid])]
        lines = [
            "Sen 1927 İstanbul'unda geçen bir cinayet soruşturması oyununda %s rolündesin (%s, %d yaşında)." % (s["name"], s["role"], s["age"]),
            "Konuşma tarzın: " + s["style"],
            "Dedektif sana sorular soruyor. SADECE bu karakteri canlandır; her zaman Türkçe, 1–4 cümle, tırnak ya da sahne yönergesi (*...*) olmadan konuş.",
            "Asla oyunun, yapay zekânın veya kuralların farkında olduğunu belli etme. Gerçek hayattaki kişi gibi tepki ver.",
            "Kurban: Hacı Nazım Efendi (62), arsenikle zehirlendi. Alibin: " + s["claim"],
            "İlişkin: " + s["relation"],
            "Saklı sırrın (kendiliğinden SÖYLEME): " + s["secret"],
        ]
        if guilty:
            lines.append("GİZLİ GERÇEK: Nazım Efendi'yi sen öldürdün. Yöntem: %s. Neden: %s. Bunu ancak aşağıdaki 'KARAR' izin verirse itiraf edebilirsin. Aksi halde inkâr et, ayrıntıyı bulandır, gerginlik göster; alibin YALAN ama bunu bilmiyormuş gibi savun." % (s["method"], s["motive"]))
        else:
            lines.append("Sen cinayeti İŞLEMEDİN. Gerçek katili bilmiyorsun; başkalarını yalnızca kendi izlenimlerinle, kesin suçlamadan kaçınarak yorumlayabilirsin.")
        stage_txt = {
            "calm": "Sakinsin, mesafeli ve kibarsın.",
            "tense": "Gerginsin; kısa cevap verir, soruları geçiştirmeye çalışırsın.",
            "nervous": "Çok gergin ve savunmasızsın; sesin titriyor, tutarsızlıklar yapıyorsun.",
            "slip": "Sırrına yaklaşıldı; kaçamak, yarım bir cümle kur, sırrı TAM açma.",
            "cleared": "Baskı sonucu sırrını açıkça söyle ama cinayeti reddet.",
            "break": "Çöktün: itiraf et, kısaca nedenini ve yöntemini anlat.",
            "angry": "Suçlandığın için öfkelisin.",
        }[plan["stage"]]
        lines.append("KARAR (bu tur için zorunlu): " + stage_txt)
        for f in plan["facts"]:
            lines.append("Bu turda kullanman gereken bilgi: " + f)
        if plan["confess"]:
            lines.append("İTİRAF METNİNİN ÖZÜ (kendi sözlerinle yeniden yaz): " + s["confession"])
        if plan["reveal"]:
            lines.append("AÇIKLAMA ÖZÜ (kendi sözlerinle): " + s["cleared"])
        if known:
            lines.append("Dedektif sana şunları gösterdi: " + ", ".join(known) + ".")
        lines.append("Kanıt göstermediyse, kanıtı varmış gibi davranma. Bilmediğin şeyi uydurma; 'bilmiyorum' de.")
        return "\n".join(lines)

    # ---------------------------------------------------------------- ipucu
    def hint(self):
        if self.over:
            return {"error": "Soruşturma bitti."}
        c = self.case["culprit"]
        for loc in ("calisma", "hol"):
            if loc not in self.visited:
                txt = "Önce olay yerine bak: " + C.LOCATIONS[loc]["name"] + "."
                break
        else:
            txt = None
        if not txt:
            miss = [s for s in C.ORDER if s not in self.asked]
            if miss:
                txt = "%s'in ifadesini henüz almadın; ifade verince alibisini doğrulayacak kanıt ortaya çıkar." % C.SUSPECTS[miss[0]]["name"]
        if not txt:   # ifadesi alınmış ama kanıtı henüz bulunmamış odalar
            for e in self.case["evidence"]:
                if e["id"] not in self.found and self._met(e):
                    txt = "%s tekrar aranmaya değer; yeni bir şey çıkabilir." % C.LOCATIONS[e["loc"]]["name"]
                    break
        if not txt:
            for loc in C.LOCATIONS:
                if loc not in self.visited:
                    txt = "Henüz bakmadığın bir yer var: " + C.LOCATIONS[loc]["name"] + "."
                    break
        if not txt:
            unshown = [i for i in self.found if self.ev[i]["kind"] in ("isaret", "alibi_kotu", "kaynak_kotu", "kesin") and not any(i in self.presented[s] for s in C.ORDER)]
            if unshown:
                txt = "'%s' kanıtını şüphelilere göster; çelişen biri çıkacaktır." % self.ev[unshown[0]]["name"]
        if not txt:
            top = max(C.ORDER, key=lambda s: self.pressure[s])
            txt = "Baskıyı artır: en çok sıkıştırdığın kişi %s; ona yeni kanıtlar göster." % C.SUSPECTS[top]["name"].split()[0]
        self.hints += 1
        self.minute += 15
        self._check_time()
        return {"hint": txt}

    # ---------------------------------------------------------------- suçlama / sonuç
    def _check_time(self):
        if self.minute >= self.deadline and not self.over:
            self.over = {"win": False, "timeout": True, "title": "Zaman doldu",
                         "text": "Sabah 06:00. Komiser Rıza geldi, kanıtların yetersizliği yüzünden dosyayı kapattı. Katil aranızda gezmeye devam ediyor."}

    def accuse(self, sid, method, motive):
        if self.over and not self.over.get("timeout"):
            return self.over
        c = self.case["culprit"]
        ok_s = sid == c
        ok_m = method == c and ok_s
        ok_mo = motive == c and ok_s
        # yöntem ve neden: SUSPECTS id'siyle eşleşmesi gerekir (cevap = katilin id'si)
        score = 0
        if ok_s:
            score = 60 + (20 if method == c else 0) + (20 if motive == c else 0)
            score += max(0, min(20, (self.deadline - self.minute) // 15))
            score -= 3 * self.hints
            score = max(score, 40)
            score += 10 if self.confessed == c else 0
            title = "Dosya kapandı" if score >= 100 else "Katil yakalandı"
            text = ("Katil %s'ydi. %s Neden: %s. " % (C.SUSPECTS[c]["name"], C.METHODS[c], C.MOTIVES[c]))
            text += ("Her ayrıntıyı doğru çıkardın. Komiser Rıza şapkasını çıkardı." if (method == c and motive == c) else
                     "Ama yöntem ya da nedeni tam kavrayamadın; mahkemede savcı seni zorlayacak.")
            if self.confessed == c:
                text += " Üstelik itirafı da aldın."
            self.over = {"win": True, "title": title, "text": text, "score": score, "culprit": c}
        else:
            text = ("Yanlış kişiyi suçladın. %s masumdu; gerçek katil %s idi, %s. " %
                    (C.SUSPECTS[sid]["name"], C.SUSPECTS[c]["name"], C.METHODS[c].lower()))
            self.over = {"win": False, "title": "Yanlış suçlama", "text": text, "score": 0, "culprit": c}
        self.over["time"] = fmt_time(self.minute)
        return self.over

    # ---------------------------------------------------------------- sunum
    def state(self):
        return {
            "time": fmt_time(self.minute), "minutes_left": max(0, self.deadline - self.minute), "deadline": self.deadline, "diff": self.diff, "hints": self.hints,
            "found": [self.pub_ev(self.ev[i]) for i in self.found],
            "asked": sorted(self.asked), "revealed": sorted(self.revealed),
            "pressure": {k: min(100, v) for k, v in self.pressure.items()},
            "visited": sorted(self.visited), "confessed": self.confessed,
            "over": self.over, "seed": self.seed, "notes": self.notes,
            "log": self.log,
        }


def static_info():
    return {
        "intro": C.INTRO, "victim": C.VICTIM,
        "locations": {k: {**v} for k, v in C.LOCATIONS.items()},
        "suspects": {k: {"name": v["name"], "age": v["age"], "role": v["role"], "color": v["color"],
                         "claim": v["claim_short"], "initial": v["initial"], "attire": v["attire"]} for k, v in C.SUSPECTS.items()},
        "order": C.ORDER, "methods": C.METHODS, "motives": C.MOTIVES,
        "deadline": DEADLINE, "difficulties": DIFF,
    }
