"""Yapay zekâ sağlayıcıları: Claude, Groq (OpenAI uyumlu), Ollama, çevrimdışı yedek.
Hepsi aynı arayüzü verir: stream(cfg, system, messages) -> metin parçaları üreten generator.
v3: model otomatik algılama (Ollama/Groq/Claude), anlaşılır Türkçe hata mesajları, bozuk sağlayıcıyı kısa süre atlama."""
import json
import re
import time
import requests

TIMEOUT = (6, 90)


class ProviderError(Exception):
    def __init__(self, msg, fatal=False):
        super().__init__(msg)
        self.fatal = fatal          # True: anahtar/kredi/model sorunu; bir süre denenmesin


# ---------------------------------------------------------------- önbellekler
_models = {}        # (sağlayıcı, adres) -> (zaman, [model adları])
_cool = {}          # sağlayıcı -> (bitiş zamanı, mesaj)
_MODEL_TTL = 300


def cooldown(name, secs, msg):
    _cool[name] = (time.time() + secs, msg)


def reset_state():
    _models.clear()
    _cool.clear()


def cooling(name):
    c = _cool.get(name)
    if c and c[0] > time.time():
        return c[1]
    _cool.pop(name, None)
    return None


def friendly(name, status, raw):
    """Ham API hatasını anlaşılır Türkçe'ye çevirir. (mesaj, kalıcı_mı)"""
    low = (raw or "").lower()
    lab = {"claude": "Claude", "groq": "Groq", "ollama": "Ollama"}.get(name, name)
    if "credit balance" in low or "billing" in low:
        return f"{lab}: Anthropic hesabında kredi bitmiş (console.anthropic.com → Plans & Billing'den kredi yükle).", True
    if status in (401, 403) or "invalid x-api-key" in low or "invalid api key" in low or "authentication" in low:
        return f"{lab}: anahtar geçersiz ya da yetkisiz; anahtarı kontrol et.", True
    if status == 429 or "rate limit" in low or "quota" in low:
        return f"{lab}: istek/kota sınırı doldu, birazdan tekrar dene.", False
    if status == 404 and name == "ollama":
        return f"{lab}: model yüklü değil.", False
    if status == 404 or "does not exist" in low or "not found" in low:
        return f"{lab}: model bulunamadı ya da bu anahtarla erişilemiyor.", False
    if status and status >= 500:
        return f"{lab}: sunucu hatası ({status}), sonra tekrar dene.", False
    return f"{lab}: {raw[:160] or 'bilinmeyen hata'}", False


def _sse(resp):
    for raw in resp.iter_lines():
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        if not raw or not raw.startswith("data:"):
            continue
        data = raw[5:].strip()
        if data == "[DONE]":
            return
        try:
            yield json.loads(data)
        except ValueError:
            continue


def _raw_error(r):
    try:
        msg = r.json()
        msg = msg.get("error", msg)
        msg = msg.get("message", msg) if isinstance(msg, dict) else msg
        return str(msg)
    except ValueError:
        return r.text[:200]


def _check(r, name="?"):
    if r.status_code >= 400:
        raw = _raw_error(r)
        msg, fatal = friendly(name, r.status_code, raw)
        e = ProviderError(msg, fatal)
        e.status = r.status_code
        e.raw = raw
        raise e


# ---------------------------------------------------------------- model listeleri
def _list_cached(key, fetch):
    c = _models.get(key)
    if c and time.time() - c[0] < _MODEL_TTL:
        return c[1]
    names = fetch()
    _models[key] = (time.time(), names)
    return names


def ollama_models(cfg):
    def f():
        r = requests.get(cfg["ollama_url"].rstrip("/") + "/api/tags", timeout=(2, 6))
        r.raise_for_status()
        return [m["name"] for m in r.json().get("models", [])]
    return _list_cached(("ollama", cfg["ollama_url"]), f)


def groq_models(cfg):
    def f():
        base = cfg["groq_url"].split("/chat/completions")[0]
        r = requests.get(base + "/models", headers={"Authorization": "Bearer " + cfg["groq_key"]}, timeout=(6, 15))
        _check(r, "groq")
        return [m["id"] for m in r.json().get("data", [])]
    return _list_cached(("groq", cfg["groq_key"][-6:]), f)


def claude_models(cfg):
    def f():
        base = cfg["claude_url"].split("/v1/")[0]
        r = requests.get(base + "/v1/models", headers={"x-api-key": cfg["claude_key"], "anthropic-version": "2023-06-01"}, timeout=(6, 15))
        _check(r, "claude")
        return [m["id"] for m in r.json().get("data", [])]
    return _list_cached(("claude", cfg["claude_key"][-6:]), f)


_OLLAMA_PREF = ["llama3.1", "llama3.2", "llama3.3", "qwen3", "qwen2.5", "gemma3", "gemma2", "mistral", "phi4", "phi3", "deepseek", "llama3"]
_OLLAMA_VISION = ["llava", "vision", "minicpm-v", "moondream", "gemma3", "qwen2.5vl", "qwen2-vl", "bakllava"]
_GROQ_PREF = ["llama-3.3-70b-versatile", "llama-3.1-70b-versatile", "llama-3.1-8b-instant", "llama3-70b-8192", "llama3-8b-8192",
              "gemma2-9b-it", "mixtral-8x7b-32768", "qwen/qwen3-32b", "openai/gpt-oss-120b", "openai/gpt-oss-20b", "moonshotai/kimi-k2-instruct"]
_GROQ_BAD = ("whisper", "guard", "tts", "playai", "distil", "embed", "orpheus")


def _same(a, b):
    a, b = a.lower(), b.lower()
    return a == b or a.split(":")[0] == b.split(":")[0] and (":" not in b or ":" not in a) or a == b + ":latest" or b == a + ":latest"


def pick_ollama(cfg, vision=False):
    inst = ollama_models(cfg)
    if not inst:
        raise ProviderError("Ollama çalışıyor ama hiç model yüklü değil. Terminalde: ollama pull llama3.2", False)
    want = (cfg.get("ollama_vision_model") if vision else cfg.get("ollama_model")) or ""
    for m in inst:
        if want and _same(m, want):
            return m
    if vision:
        for k in _OLLAMA_VISION:
            for m in inst:
                if k in m.lower():
                    return m
        raise ProviderError("Ollama'da görüntü destekleyen model yok (ollama pull llava).", False)
    textm = [m for m in inst if not any(x in m.lower() for x in ("embed", "llava", "vision", "minicpm-v", "moondream"))] or inst
    for k in _OLLAMA_PREF:
        for m in textm:
            if k in m.lower():
                return m
    return textm[0]


def pick_groq(cfg, vision=False):
    want = (cfg.get("groq_vision_model") if vision else cfg.get("groq_model")) or ""
    try:
        avail = groq_models(cfg)
    except (ProviderError, requests.RequestException):
        return want            # liste alınamadıysa ayarlı modeli dene
    if want in avail:
        return want
    if vision:
        for m in avail:
            if "vision" in m or "llama-4" in m or "scout" in m or "maverick" in m:
                return m
        raise ProviderError("Groq hesabında görüntü modeli görünmüyor.", False)
    for m in _GROQ_PREF:
        if m in avail:
            return m
    rest = [m for m in avail if not any(b in m for b in _GROQ_BAD)]
    if rest:
        return rest[0]
    raise ProviderError("Groq hesabında kullanılabilir sohbet modeli görünmüyor.", True)


def pick_claude(cfg):
    want = cfg.get("claude_model") or ""
    try:
        avail = claude_models(cfg)
    except (ProviderError, requests.RequestException):
        return want
    if want in avail or not avail:
        return want
    order = [m for m in avail if "sonnet" in m] or [m for m in avail if "haiku" in m] or avail
    return order[0]


def _with_images_claude(messages, images):
    if not images:
        return messages
    msgs = [dict(m) for m in messages]
    last = msgs[-1]
    blocks = [{"type": "image", "source": {"type": "base64", "media_type": i["mime"], "data": i["b64"]}} for i in images]
    blocks.append({"type": "text", "text": last["content"] if isinstance(last["content"], str) else ""})
    last["content"] = blocks
    return msgs


def claude_stream(cfg, system, messages, images=None):
    if not cfg.get("claude_key"):
        raise ProviderError("Claude anahtarı yok")
    model = cfg["claude_model"]
    body = {"model": model, "max_tokens": 1500 if images else 1024, "system": system,
            "messages": _with_images_claude(messages, images), "stream": True}
    h = {"x-api-key": cfg["claude_key"], "anthropic-version": "2023-06-01",
         "content-type": "application/json"}
    r = requests.post(cfg["claude_url"], json=body, headers=h, stream=True, timeout=TIMEOUT)
    if r.status_code == 404 or (r.status_code == 400 and "model" in _raw_error(r).lower()):
        alt = pick_claude(cfg)      # model adı geçersizse hesaptaki uygun modeli seç
        if alt and alt != model:
            body["model"] = alt
            r = requests.post(cfg["claude_url"], json=body, headers=h, stream=True, timeout=TIMEOUT)
    _check(r, "claude")
    for ev in _sse(r):
        if ev.get("type") == "content_block_delta":
            t = ev.get("delta", {}).get("text")
            if t:
                yield t
        elif ev.get("type") == "error":
            raise ProviderError(str(ev.get("error")))


def groq_stream(cfg, system, messages, images=None):
    if not cfg.get("groq_key"):
        raise ProviderError("Groq anahtarı yok")
    msgs = [dict(m) for m in messages]
    model = pick_groq(cfg, bool(images))
    if images:
        last = msgs[-1]
        last["content"] = [{"type": "text", "text": last["content"]}] + [
            {"type": "image_url", "image_url": {"url": f"data:{i['mime']};base64,{i['b64']}"}} for i in images[:5]]
    body = {"model": model, "stream": True, "max_tokens": 1024,
            "messages": [{"role": "system", "content": system}] + msgs}
    h = {"Authorization": "Bearer " + cfg["groq_key"], "content-type": "application/json"}
    r = requests.post(cfg["groq_url"], json=body, headers=h, stream=True, timeout=TIMEOUT)
    if r.status_code in (400, 404) and not images:      # model sorunu: listeden başka model dene
        _models.pop(("groq", cfg["groq_key"][-6:]), None)
        alt = pick_groq({**cfg, "groq_model": ""})
        if alt and alt != model:
            body["model"] = alt
            r = requests.post(cfg["groq_url"], json=body, headers=h, stream=True, timeout=TIMEOUT)
    _check(r, "groq")
    for ev in _sse(r):
        try:
            t = ev["choices"][0]["delta"].get("content")
        except (KeyError, IndexError):
            t = None
        if t:
            yield t


def ollama_stream(cfg, system, messages, images=None):
    if not cfg.get("ollama_enabled"):
        raise ProviderError("Ollama kapalı")
    msgs = [dict(m) for m in messages]
    try:
        model = pick_ollama(cfg, bool(images))
    except requests.RequestException as e:
        raise ProviderError("Ollama'ya ulaşılamadı (Ollama uygulaması açık mı?)") from e
    if images:
        msgs[-1]["images"] = [i["b64"] for i in images]
    body = {"model": model, "stream": True,
            "messages": [{"role": "system", "content": system}] + msgs}
    try:
        r = requests.post(cfg["ollama_url"].rstrip("/") + "/api/chat", json=body, stream=True,
                          timeout=(2, 120))
    except requests.RequestException as e:
        raise ProviderError("Ollama'ya ulaşılamadı") from e
    _check(r, "ollama")
    for raw in r.iter_lines():
        if not raw:
            continue
        try:
            ev = json.loads(raw)
        except ValueError:
            continue
        t = ev.get("message", {}).get("content")
        if t:
            yield t
        if ev.get("done"):
            return


PROVIDERS = {"claude": claude_stream, "groq": groq_stream, "ollama": ollama_stream}
LABEL = {"claude": "Claude", "groq": "Groq", "ollama": "Ollama", "yerel": "Yerel"}


def order(cfg, text: str):
    """Otomatik seçim: kısa/basit -> Groq, uzun/zor -> Claude; sonra kalanlar; en sonda Ollama.
    Kredisi/anahtarı bozuk olduğu bilinen sağlayıcılar kısa süre atlanır (hepsi bozuksa yine de denenir)."""
    p = cfg.get("provider", "auto")
    avail = [n for n in ("claude", "groq") if cfg.get(n + "_key")]
    if cfg.get("ollama_enabled"):
        avail.append("ollama")
    if p in PROVIDERS:
        names = [p] + [n for n in avail if n != p]
    else:
        hard = len(text) > 160 or any(w in text.lower() for w in
                                      ("kod", "yaz", "açıkla", "analiz", "karşılaştır", "neden", "plan", "özetle"))
        first = ["claude", "groq"] if hard else ["groq", "claude"]
        names = [n for n in first if n in avail] + (["ollama"] if "ollama" in avail else [])
    ok = [n for n in names if not cooling(n)]
    return ok or names


def _fail_text(name, e):
    if isinstance(e, ProviderError):
        return str(e)
    if isinstance(e, requests.ConnectionError):
        return f"{LABEL[name]}: bağlantı kurulamadı" + (" (Ollama açık mı?)" if name == "ollama" else " (internet?)")
    if isinstance(e, requests.Timeout):
        return f"{LABEL[name]}: zaman aşımı"
    return f"{LABEL[name]}: {str(e)[:120]}"


def stream(cfg, system, messages, text, images=None):
    """(sağlayıcı_adı, parça) üretir. Hata olursa sıradakine geçer; ilk parça geldikten sonra geçmez."""
    errors = []
    names = order(cfg, text)
    if images:  # görüntü için en iyi sıra: Claude, Groq (vision), Ollama (llava)
        names = sorted(names, key=lambda n: ["claude", "groq", "ollama"].index(n))
    for name in names:
        started = False
        try:
            for chunk in PROVIDERS[name](cfg, system, messages, images):
                started = True
                yield name, chunk
            if started:
                return
            errors.append(f"{LABEL[name]}: boş yanıt")
        except (ProviderError, requests.RequestException) as e:
            if started:
                yield name, "\n(bağlantı yarıda koptu)"
                return
            msg = _fail_text(name, e)
            errors.append(msg)
            if isinstance(e, ProviderError) and e.fatal:
                cooldown(name, 600, msg)
            elif isinstance(e, requests.ConnectionError) and name == "ollama":
                cooldown(name, 30, msg)
    yield "yerel", "\0ERR:" + " | ".join(errors)


def diagnose(cfg, name):
    """Bağlantı testi: {ok, model, ms, reply, error, hint, models}"""
    t0 = time.time()
    out = {"name": name, "label": LABEL.get(name, name), "ok": False}
    try:
        if name == "claude" and not cfg.get("claude_key"):
            raise ProviderError("Claude: anahtar girilmemiş.")
        if name == "groq" and not cfg.get("groq_key"):
            raise ProviderError("Groq: anahtar girilmemiş.")
        if name == "ollama":
            try:
                out["models"] = ollama_models(cfg)
            except requests.RequestException as e:
                raise ProviderError("Ollama'ya ulaşılamadı. Ollama uygulaması kurulu ve açık mı? (ollama.com)") from e
            out["model"] = pick_ollama(cfg)
        elif name == "groq":
            out["models"] = groq_models(cfg)
            out["model"] = pick_groq(cfg)
        elif name == "claude":
            out["model"] = pick_claude(cfg)
        reply = ""
        for ch in PROVIDERS[name](cfg, "Kısa yanıt ver.", [{"role": "user", "content": "Sadece 'tamam' yaz."}]):
            reply += ch
            if len(reply) > 20:
                break
        out.update(ok=True, reply=reply.strip()[:40])
        _cool.pop(name, None)
    except (ProviderError, requests.RequestException) as e:
        out["error"] = _fail_text(name, e)
        if isinstance(e, ProviderError) and e.fatal:
            cooldown(name, 600, out["error"])
    out["ms"] = int((time.time() - t0) * 1000)
    return out
