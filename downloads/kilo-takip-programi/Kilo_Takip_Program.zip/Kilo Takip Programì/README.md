# FitTrack PRO - Gelişmiş Kilo, Vücut Ölçüm ve AI Beslenme Takip Sistemi

**FitTrack PRO**, kullanıcıların kilo değişimlerini, vücut ölçümlerini, günlük beslenme ve makro değerlerini bütüncül bir şekilde takip etmelerini sağlayan, web tabanlı gelişmiş bir sağlık ve form takip uygulamasıdır. 

Yapay zeka destekli yemek görseli analizi, Mifflin-St Jeor algoritmasına dayalı kişiselleştirilmiş kalori motoru ve U.S. Navy standartlarında vücut yağ oranı hesabı ile kilo verme, kas kazanımı veya mevcut formu koruma hedeflerine ulaşmayı kolaylaştırır.

---

## 🌟 Öne Çıkan Özellikler

### 📸 Yapay Zeka Destekli Yemek Taraması (AI Tabak Analizi)
* **Görsel Yükleme & Kamera:** Öğün tabağınızın fotoğrafını çekerek veya yükleyerek analiz ettirebilirsiniz.
* **Otomatik Makro & Kalori Hesabı:** Yiyecek türü, tahmini porsiyon, kalori, protein, karbonhidrat ve yağ değerlerini otomatik tespit eder.
* **Günlüğe Aktarım:** Analiz edilen tabağı tek tıkla öğün günlüğünüze ekleyebilirsiniz.

### 📊 Detaylı Kilo ve Metrik Takibi
* **Akıllı Hedef Motoru:** Başlangıç kilosu, mevcut kilo ve hedef kilo arasındaki farkı yönlü (Kilo Verme / Kilo Alma) olarak doğru hesaplar.
* **7 Günlük Hareketli Ortalama (Moving Average):** Su ve tuz dalgalanmalarından kaynaklanan anlık kilo değişimlerini yumuşatarak gerçek yağ/kas değişim trendinizi gösterir.
* **Metrik & Vücut Analizleri:**
  * **VKİ (BMI):** Vücut Kitle İndeksi ve ideal kilo aralığı.
  * **BMR & TDEE:** Bazal Metabolizma Hızı ve Günlük Toplam Enerji Harcaması.
  * **U.S. Navy Vücut Yağ Oranı (%):** Bel, boyun ve kalça ölçülerine dayalı yağ oranı tahmini.

### 🥗 Günlük Beslenme ve Makro Yönetimi
* **Öğün Günlüğü:** Kahvaltı, Öğle Yemeği, Akşam Yemeği ve Atıştırmalık bazlı kalori ve makro takibi.
* **Diyete Özel Makro Dağılımı:** Dengeli, Yüksek Protein veya Low-Carb / Keto diyet tiplerine göre özelleştirilebilir günlük makro hedefleri.
* **Hazır Besin Kütüphanesi:** Türk mutfağına uygun yiyecek ve içecek seçenekleri.

### 🤖 Kişisel Koçluk ve Diyet Programları
* **Hedefe Özel Beslenme Planları:** Yağ yakımı, kas kütlesi artırımı veya sağlıklı yaşam hedeflerine yönelik günlük menü önerileri.
* **Akıllı Koç Tavsiyeleri:** Kilo duraklama (plateau) tespiti ve kişiselleştirilmiş diyet ipuçları.

### 📏 Vücut Ölçüm Günlüğü
* Bel, boyun, kalça, göğüs ve pazu ölçümlerini zaman içinde takip edebilme.
* Ölçüm değişimlerini grafiksel olarak izleme.

### 📁 Veri Yönetimi & Güvenlik
* **Tamamen Yerel Depolama (LocalStorage):** Verileriniz tarayıcınızda saklanır, sunucuya gönderilmez.
* **Dışa/İçe Aktarma:** Verilerinizi JSON veya CSV formatında yedekleyebilir veya başka bir cihaza aktarabilirsiniz.

---

## 🛠️ Kullanılan Teknolojiler

* **HTML5 & CSS3:** Modern, responsive ve mobil uyumlu kullanıcı arayüzü (Glassmorphism ve modern dashboard tasarımı).
* **JavaScript (ES6+):** İstemci tarafı veri işleme, hesaplama motorları ve dinamik DOM yönetimi.
* **Chart.js:** Kilo ve vücut ölçüm trendlerini görselleştiren etkileşimli grafikler.
* **FontAwesome:** Kullanıcı dostu arayüz ikonları.

---

## 🚀 Kurulum ve Çalıştırma

Uygulama sunucu kurulumu gerektirmeyen **tek sayfalık bağımsız bir web uygulamasıdır (SPA)**.

1. `index.html` dosyasını bilgisayarınıza indirin.
2. Dosyaya çift tıklayarak herhangi bir modern web tarayıcısında (Chrome, Firefox, Edge, Safari) açın.
3. Profil bilgilerinizi girerek uygulamayı kullanmaya başlayabilirsiniz.

---

## 📖 Kullanım Rehberi

1. **Profil Oluşturma:** Sağ üstteki veya profil sekmesindeki bilgilerinizi (İsim, Yaş, Boy, Aktivite Seviyesi, Diyet Tipi) doldurun ve kaydedin.
2. **Kilo Kaydı Ekleme:** Günlük kilonuzu ve varsa vücut ölçümlerinizi girerek "Kaydet" butonuna basın.
3. **Öğün Ekleme:** 
   * **Manuel:** Öğün seçip besin adını ve porsiyonunu girin.
   * **AI Taraması:** Tabağınızın fotoğrafını yükleyin, analiz tamamlandıktan sonra "Günlüğe Ekle" butonuna tıklayın.
4. **Veri Yedekleme:** Ayarlar/Profil bölümünden verilerinizi istediğiniz zaman `.json` veya `.csv` olarak bilgisayarınıza indirebilirsiniz.
