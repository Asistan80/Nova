\# Kütüphanem - Kişisel Oyun \& Kitap Yönetim Sistemi



Kütüphanem, kişisel kitaplığınızı ve dijital oyun kütüphanenizi tek bir çatı altında toplayan, modern ve karanlık tema arayüzüne sahip bir masaüstü yönetim asistanıdır. Hedeflerinizi belirlemenizi, okuma/oynama durumlarınızı takip etmenizi ve istatistiklerinizi dinamik olarak izlemenizi sağlar.



\## 🌟 Öne Çıkan Özellikler



\*   \*\*Çift Odaklı Takip Paneli:\*\* Hem kitaplarınızı hem de oyunlarınızı tek bir uygulamadan eş zamanlı olarak yönetin.

\*   \*\*Gelişmiş İlerleme Takibi:\*\* Okuduğunuz kitabın sayfa sayısını veya oynadığınız oyunun tamamlanma yüzdesini (`%` ve `Saat` bazında) görsel barlar üzerinden izleyin.

\*   \*\*Yıllık Hedefler:\*\* Kendinize yıllık kitap okuma ve oyun bitirme hedefleri koyun, ilerlemenizi canlı grafiklerle takip edin.

\*   \*\*Ödünç Takibi:\*\* Arkadaşlarınıza verdiğiniz veya aldığınız kitap/oyunların kaydını tutun.

\*   \*\*Günün Alıntısı:\*\* Her açılışta edebiyat dünyasından ilham verici motivasyon sözleri ve kitap alıntıları ile karşılaşın.

\*   \*\*Çalışma Sayacı:\*\* Kitap okurken ya da oyun oynarken harcadığınız zamanı entegre kronometre ile ölçün.



\## 🗂️ Arayüz Modülleri (Sol Menü)



\*   🏠 \*\*Anasayfa (Genel Durum):\*\* Toplam kitap/oyun sayıları, ödünç durumu, istek listesi özetleri ve güncel ilerleme durumlarını içeren ana panel.

\*   📚 \*\*Kitaplarım:\*\* Tüm kitap arşivinizi listelediğiniz, filtrelediğiniz ve yeni kitap eklediğiniz alan.

\*   🎮 \*\*Oyunlarım:\*\* Dijital oyun kütüphanenizin yönetim ve detay ekranı.

\*   ❤️ \*\*İstek Listesi:\*\* Almayı veya okumayı/oynamayı planladığınız içeriklerin listesi.

\*   🤝 \*\*Ödünç Takibi:\*\* Giriş-çıkış yapılan emanet kitap ve oyunların takvimsel takibi.

\*   ✍️ \*\*Alıntı \& Notlar:\*\* Kitaplardan çıkardığınız önemli cümleleri ve kişisel notlarınızı sakladığınız yer.

\*   ⏳ \*\*Aktivite Günlüğü:\*\* Geçmişe dönük hangi gün ne kadar okuma veya oynama yaptığınızın geçmiş kaydı.

\*   📊 \*\*İstatistikler:\*\* Okuma ve oynama alışkanlıklarınıza dair detaylı grafiksel analizler.

\*   ⚙️ \*\*Ayarlar:\*\* Tema, kullanıcı tercihleri ve veri tabanı yapılandırmaları.



\## ⚙️ Sistem Özellikleri



\*   \*\*Modern UI:\*\* Gözü yormayan neon mavi ve mor detaylarla süslenmiş dark mode (karanlık tema) arayüzü.

\*   \*\*Veri Yönetimi:\*\* dynamic sayıcılar ve veri entegrasyonu (Toplam Kitap, Toplam Oyun, Ödünç Verilen ve İstek Listesi sayaçları).



\---

\*Bu modül Murat Apps paketinin bir parçası olarak geliştirilmiştir.\*

