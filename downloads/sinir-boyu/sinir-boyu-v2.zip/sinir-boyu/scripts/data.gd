extends RefCounted
## Sınır Boyu sabit oyun verileri: haritalar, zorluklar, kuleler, düşmanlar, dallar.
## Dengeyi ayarlamak için değerleri burada değiştir.


static func maps() -> Array:
	return [
		{
			"name": "Söğüt Yaylası",
			"desc": "Yeşil yayla. Dengeli yol, bol inşa yeri.",
			"corners": [
				Vector2i(-1, 2), Vector2i(3, 2), Vector2i(3, 8), Vector2i(7, 8), Vector2i(7, 3),
				Vector2i(11, 3), Vector2i(11, 8), Vector2i(14, 8), Vector2i(14, 0),
			],
			"water": [],
			"grass": Color(0.16, 0.27, 0.17), "grass2": Color(0.18, 0.30, 0.19),
			"path": Color(0.60, 0.49, 0.32), "edge": Color(0.36, 0.27, 0.16),
			"tint": Color(1.0, 0.9, 0.6, 0.0),
			"trees": 1.0, "rocks": 0.3, "ambient": "leaves", "seed": 11,
		},
		{
			"name": "Domaniç Geçidi",
			"desc": "Kayalık dağ yolu. Uzun kıvrımlı yol, az yer.",
			"corners": [
				Vector2i(-1, 9), Vector2i(3, 9), Vector2i(3, 5), Vector2i(7, 5), Vector2i(7, 9),
				Vector2i(11, 9), Vector2i(11, 2), Vector2i(8, 2), Vector2i(8, 0),
			],
			"water": [],
			"grass": Color(0.20, 0.24, 0.21), "grass2": Color(0.22, 0.27, 0.23),
			"path": Color(0.52, 0.48, 0.42), "edge": Color(0.28, 0.26, 0.23),
			"tint": Color(0.6, 0.7, 0.9, 0.10),
			"trees": 0.6, "rocks": 0.65, "ambient": "mist", "seed": 23,
		},
		{
			"name": "İznik Ovası",
			"desc": "Göl kıyısı ve alacakaranlık. Su kenarı inşaya kapalı.",
			"corners": [
				Vector2i(-1, 5), Vector2i(2, 5), Vector2i(2, 2), Vector2i(6, 2), Vector2i(6, 8),
				Vector2i(9, 8), Vector2i(9, 4), Vector2i(13, 4), Vector2i(13, 0),
			],
			"water": [Rect2i(10, 6, 5, 4), Rect2i(0, 8, 4, 3)],
			"grass": Color(0.15, 0.25, 0.18), "grass2": Color(0.17, 0.28, 0.20),
			"path": Color(0.68, 0.58, 0.40), "edge": Color(0.40, 0.31, 0.18),
			"tint": Color(0.15, 0.15, 0.45, 0.20),
			"trees": 0.8, "rocks": 0.2, "ambient": "fireflies", "seed": 37,
		},
	]


static func diffs() -> Array:
	return [
		{
			"name": "Çırak", "desc": "Rahat başlangıç, bol altın.",
			"gold": 260, "lives": 25, "hp": 0.9, "growth": 0.08, "speed": 0.95,
			"reward": 1.15, "count": 0.9, "waves": 12, "smult": 0.7,
		},
		{
			"name": "Yiğit", "desc": "Dengeli, ciddi bir sınav.",
			"gold": 200, "lives": 20, "hp": 1.2, "growth": 0.14, "speed": 1.0,
			"reward": 1.0, "count": 1.1, "waves": 15, "smult": 1.0,
		},
		{
			"name": "Gazi", "desc": "Sert düşmanlar, az can, uzun sefer.",
			"gold": 180, "lives": 15, "hp": 1.55, "growth": 0.18, "speed": 1.06,
			"reward": 0.95, "count": 1.25, "waves": 20, "smult": 1.5,
		},
		{
			"name": "Efsane", "desc": "Hata affetmez. Sadece ustalar için.",
			"gold": 160, "lives": 10, "hp": 2.0, "growth": 0.24, "speed": 1.12,
			"reward": 0.9, "count": 1.4, "waves": 25, "smult": 2.2,
		},
	]


static func tower_order() -> Array:
	return ["okcu", "mancinik", "yag", "zincir", "mehter", "sahi"]


static func towers() -> Dictionary:
	return {
		"okcu": {
			"name": "Okçu Kulesi", "short": "Okçu", "cost": 60, "range": 175.0, "damage": 13.0,
			"rate": 0.55, "splash": 0.0, "air": true,
			"color": Color(0.82, 0.63, 0.30), "desc": "Hızlı atış. Havadaki düşmanları da vurur.",
		},
		"mancinik": {
			"name": "Mancınık", "short": "Mancınık", "cost": 125, "range": 240.0, "damage": 42.0,
			"rate": 2.1, "splash": 62.0, "air": false,
			"color": Color(0.55, 0.40, 0.28), "desc": "Yavaş, alan hasarı. Yalnız yerdekileri vurur.",
		},
		"yag": {
			"name": "Kızgın Yağ Kazanı", "short": "Yağ Kazanı", "cost": 95, "range": 115.0, "damage": 34.0,
			"rate": 0.0, "splash": 0.0, "air": false,
			"color": Color(0.85, 0.35, 0.15), "desc": "Yakındakilere sürekli yanık. Zırh işlemez.",
		},
		"zincir": {
			"name": "Zincirli Tuzak", "short": "Zincir", "cost": 75, "range": 135.0, "damage": 4.0,
			"rate": 0.0, "splash": 0.0, "air": false,
			"color": Color(0.55, 0.60, 0.68), "desc": "Yerdeki düşmanları yavaşlatır.",
		},
		"mehter": {
			"name": "Mehter Takımı", "short": "Mehter", "cost": 150, "range": 150.0, "damage": 0.0,
			"rate": 0.0, "splash": 0.0, "air": false,
			"color": Color(0.75, 0.15, 0.18), "desc": "Yakındaki kulelerin atış hızını ve hasarını artırır.",
		},
		"sahi": {
			"name": "Şahi Topu", "short": "Şahi Topu", "cost": 260, "range": 290.0, "damage": 150.0,
			"rate": 3.8, "splash": 80.0, "air": false,
			"color": Color(0.62, 0.45, 0.22), "desc": "Çok yavaş, devasa alan hasarı. Yalnız yerdekileri vurur.",
		},
	}


## Seviye 2 -> 3 yükseltmesinde seçilen dallar
static func branches() -> Dictionary:
	return {
		"okcu": [
			{"name": "Seri Atış", "desc": "Atış hızı çok artar, hasar biraz düşer.", "rate": 0.65, "damage": 0.9},
			{"name": "Zırh Delici", "desc": "Hasar +%50, zırhın yarısını deler.", "damage": 1.5, "pierce": 1.0},
		],
		"mancinik": [
			{"name": "Geniş Alan", "desc": "Patlama alanı +%40.", "splash": 1.4},
			{"name": "Ağır Gülle", "desc": "Hasar +%60, menzil +%10.", "damage": 1.6, "range": 1.1},
		],
		"yag": [
			{"name": "Kaynar Yağ", "desc": "Yanık hasarı +%50.", "damage": 1.5},
			{"name": "Yapışkan Yağ", "desc": "Düşmanları ayrıca yavaşlatır.", "slowadd": 1.0},
		],
		"zincir": [
			{"name": "Buz Zinciri", "desc": "Çok daha güçlü yavaşlatma.", "slowmul": 0.6},
			{"name": "Dikenli Zincir", "desc": "Hasar x6.", "damage": 6.0},
		],
		"mehter": [
			{"name": "Cenk Marşı", "desc": "Atış hızı bonusu +%50 artar.", "buffrate": 1.5},
			{"name": "Savaş Davulu", "desc": "Kulelere ek hasar bonusu verir.", "buffdmg": 0.25},
		],
		"sahi": [
			{"name": "Misket Gülle", "desc": "Alan +%50, hasar -%20.", "splash": 1.5, "damage": 0.8},
			{"name": "Kale Yıkıcı", "desc": "Hasar +%50, zırhın yarısını deler.", "damage": 1.5, "pierce": 1.0},
		],
	}


static func enemy_order() -> Array:
	return ["piyade", "akinci", "muhafiz", "buyucu", "kuzgun", "dev", "devi", "hukumdar"]


static func enemies() -> Dictionary:
	return {
		"piyade": {
			"name": "Karanlık Piyade", "hp": 60.0, "speed": 68.0, "reward": 7, "leak": 1,
			"armor": 0.0, "radius": 13.0, "color": Color(0.38, 0.22, 0.48),
		},
		"akinci": {
			"name": "Kara Akıncı", "hp": 42.0, "speed": 128.0, "reward": 9, "leak": 1,
			"armor": 0.0, "radius": 12.0, "color": Color(0.22, 0.16, 0.32),
		},
		"muhafiz": {
			"name": "Demir Muhafız", "hp": 230.0, "speed": 50.0, "reward": 16, "leak": 2,
			"armor": 4.0, "radius": 16.0, "color": Color(0.42, 0.44, 0.52),
		},
		"buyucu": {
			"name": "Gölge Büyücü", "hp": 95.0, "speed": 62.0, "reward": 14, "leak": 2,
			"armor": 0.0, "radius": 13.0, "color": Color(0.58, 0.22, 0.68),
		},
		"kuzgun": {
			"name": "Gölge Kuzgun", "hp": 55.0, "speed": 105.0, "reward": 10, "leak": 1,
			"armor": 0.0, "radius": 12.0, "color": Color(0.16, 0.18, 0.28), "fly": true,
		},
		"dev": {
			"name": "Taş Dev", "hp": 650.0, "speed": 36.0, "reward": 42, "leak": 5,
			"armor": 2.0, "radius": 24.0, "color": Color(0.38, 0.35, 0.32),
		},
		"devi": {
			"name": "Kuşatma Devi", "hp": 3200.0, "speed": 30.0, "reward": 220, "leak": 12,
			"armor": 6.0, "radius": 34.0, "color": Color(0.30, 0.26, 0.24), "boss": true,
		},
		"hukumdar": {
			"name": "Kara Hükümdar", "hp": 5200.0, "speed": 34.0, "reward": 400, "leak": 20,
			"armor": 5.0, "radius": 30.0, "color": Color(0.20, 0.08, 0.28), "boss": true,
		},
	}


static func wave_names() -> Array:
	return [
		"İlk Akın", "Gölge Sürüsü", "Kara Atlılar", "Demir Yağmuru", "Kuşatma Başlıyor",
		"Kuzgun Bulutu", "Büyücü Çemberi", "Taş Yürüyüşü", "Kızıl Gece", "Karanlığın Çağrısı",
		"Çelik Seli", "Sessiz Ölüm", "Fırtına Ordusu", "Kemik Dalgası", "Son Savunma",
		"Gölgelerin Öfkesi", "Kara Kışlak", "Ateş ve Duman", "Kıyamet Alayı", "Karanlık Zirve",
		"Kızıl Ufuk", "Demir Orman", "Ölüler Geçidi", "Yıkım Yürüyüşü", "Büyük Hesaplaşma",
	]


static func tips() -> Array:
	return [
		"İpucu: Mehter Takımı'nı kulelerin ortasına koy, hepsini güçlendirsin.",
		"İpucu: Gölge Kuzgunlar yalnız Okçu Kuleleri ile vurulur.",
		"İpucu: Zırhlı düşmanlara Kızgın Yağ ya da Zırh Delici Okçu iyi gelir.",
		"İpucu: Zincirli Tuzak, yavaşlattığı düşmanları diğer kulelere daha uzun süre gösterir.",
		"İpucu: Seviye 2 kuleler dal seçerek özelleşir. Dikkatli seç.",
		"İpucu: Ok Yağmurunu boss'lar için sakla.",
		"İpucu: Gölge Büyücüleri önce devir, yoksa herkesi iyileştirirler.",
		"İpucu: Her 5. dalga bir boss gelir. Altın biriktir.",
	]
