extends Node
## Kodla üretilen ses efektleri ve müzik. Dış ses dosyası gerekmez.
## Müzik, açılışta birkaç karede parça parça üretilir; hazır olunca çalmaya başlar.

const RATE := 22050
const MUSIC_RATE := 11025
const POOL := 10
const STEP := 0.3125
const MUSIC_STEPS := 32
const CHUNK := 1500

var sfx_on := true
var music_on := true
var intense := false

var sounds := {}
var recipes := {}
var min_gap := {"shoot": 45, "hit": 40, "stone": 80, "coin": 60, "die": 50, "boom": 70, "click": 30}
var last_play := {}
var players: Array = []
var next_player := 0

var music_player: AudioStreamPlayer
var music_buf := PackedByteArray()
var music_idx := 0
var music_total := 0
var music_ready := false
var music_wanted := false

# Hicaz dizisi (Re): Re, Mib, Fa#, Sol, La, Sib, Do, Re
var scale_hz: Array = [293.66, 311.13, 369.99, 392.0, 440.0, 466.16, 523.25, 587.33]
var melody: Array = [
	0, -1, 1, 0, 2, -1, 1, 0, 3, -1, 2, 1, 0, -1, -1, -1,
	4, -1, 3, 2, 1, -1, 2, 3, 4, -1, 5, 4, 3, -1, 1, 0,
]


func _ready() -> void:
	for i in range(POOL):
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	music_player = AudioStreamPlayer.new()
	music_player.volume_db = -14.0
	add_child(music_player)
	build_sounds()
	music_total = int(float(MUSIC_STEPS) * STEP * float(MUSIC_RATE))
	music_buf.resize(music_total * 2)


func _process(_delta: float) -> void:
	if not music_ready:
		var end_i := mini(music_idx + CHUNK, music_total)
		for i in range(music_idx, end_i):
			var v := music_sample(float(i) / float(MUSIC_RATE))
			music_buf.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 30000.0))
		music_idx = end_i
		if music_idx >= music_total:
			finish_music()
	for k in recipes.keys():
		if not sounds.has(k):
			build_one(String(k))
			break
	var target := -9.5 if intense else -14.0
	music_player.volume_db = lerpf(music_player.volume_db, target, 0.05)


func finish_music() -> void:
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = MUSIC_RATE
	s.stereo = false
	s.data = music_buf
	s.loop_mode = AudioStreamWAV.LOOP_FORWARD
	s.loop_begin = 0
	s.loop_end = music_total
	music_player.stream = s
	music_ready = true
	if music_wanted and music_on:
		music_player.play()


func start_music() -> void:
	music_wanted = true
	if music_ready and music_on and not music_player.playing:
		music_player.play()


func set_music(on: bool) -> void:
	music_on = on
	if on:
		start_music()
	else:
		music_player.stop()


func set_sfx(on: bool) -> void:
	sfx_on = on


func play(sound_name: String, vol_db: float = 0.0, pitch: float = 1.0) -> void:
	if not sfx_on:
		return
	if not sounds.has(sound_name):
		if not recipes.has(sound_name):
			return
		build_one(sound_name)
	var now := Time.get_ticks_msec()
	var gap := int(min_gap.get(sound_name, 0))
	if now - int(last_play.get(sound_name, -10000)) < gap:
		return
	last_play[sound_name] = now
	var p: AudioStreamPlayer = players[next_player]
	next_player = (next_player + 1) % POOL
	p.stream = sounds[sound_name]
	p.volume_db = vol_db
	p.pitch_scale = pitch * randf_range(0.94, 1.06)
	p.play()


# ------------------------------------------------------------ MÜZİK
func kick(st: float) -> float:
	var f := 45.0 + 75.0 * exp(-st * 25.0)
	return sin(TAU * f * st) * exp(-st * 9.0) * 0.75


func snare(st: float) -> float:
	return noise() * exp(-st * 18.0) * 0.30


func hat(st: float) -> float:
	return noise() * exp(-st * 60.0) * 0.14


func reed(f: float, st: float) -> float:
	var env := minf(st * 60.0, 1.0) * exp(-st * 3.0)
	var ff := f * (1.0 + 0.006 * sin(TAU * 5.5 * st))
	var w := sin(TAU * ff * st) + 0.5 * sin(TAU * 2.0 * ff * st) + 0.3 * sin(TAU * 3.0 * ff * st)
	return w * env


func music_sample(t: float) -> float:
	var step_idx := int(t / STEP)
	var st := fposmod(t, STEP)
	var in_bar := step_idx % 8
	var v := 0.0
	if in_bar == 0 or in_bar == 3 or in_bar == 4:
		v += kick(st)
	if in_bar == 2 or in_bar == 6:
		v += snare(st)
	if in_bar % 2 == 1:
		v += hat(st)
	v += 0.10 * sin(TAU * 73.42 * t) + 0.05 * sin(TAU * 110.0 * t)
	var m: int = melody[step_idx % MUSIC_STEPS]
	if m >= 0:
		v += reed(float(scale_hz[m]), st) * 0.16
	return v * 0.8


# ------------------------------------------------------------ SES EFEKTLERİ
func noise() -> float:
	return randf() * 2.0 - 1.0


func synth(dur: float, fn: Callable) -> AudioStreamWAV:
	var n := int(dur * float(RATE))
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in range(n):
		var t := float(i) / float(RATE)
		var v: float = fn.call(t, dur)
		data.encode_s16(i * 2, int(clampf(v, -1.0, 1.0) * 30000.0))
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	s.data = data
	return s


func tone(f: float, t: float) -> float:
	return sin(TAU * f * t)


func reg(sound_name: String, dur: float, fn: Callable) -> void:
	recipes[sound_name] = [dur, fn]


func build_one(sound_name: String) -> void:
	var r: Array = recipes[sound_name]
	sounds[sound_name] = synth(float(r[0]), r[1])


func build_sounds() -> void:
	reg("shoot", 0.12, func(t, _d): return (sin(TAU * (1300.0 * t - 5000.0 * t * t)) * 0.45 + noise() * 0.25) * exp(-t * 32.0))
	reg("stone", 0.28, func(t, _d): return (sin(TAU * (170.0 * t - 250.0 * t * t)) * 0.6 + noise() * 0.12) * exp(-t * 11.0))
	reg("boom", 0.55, func(t, _d): return noise() * exp(-t * 7.0) * 0.6 + sin(TAU * 55.0 * t) * exp(-t * 6.0) * 0.6)
	reg("cannon", 0.8, func(t, _d): return noise() * exp(-t * 5.0) * 0.55 + sin(TAU * (48.0 - 20.0 * t) * t) * exp(-t * 4.0) * 0.8)
	reg("hit", 0.05, func(t, _d): return noise() * exp(-t * 90.0) * 0.4)
	reg("die", 0.14, func(t, _d): return (noise() * 0.3 + sin(TAU * (500.0 - 2500.0 * t) * t) * 0.4) * exp(-t * 20.0))
	reg("coin", 0.22, func(t, _d): return (tone(1320.0, t) * exp(-t * 14.0) + (tone(1760.0, t) * exp(-(t - 0.07) * 14.0) if t > 0.07 else 0.0)) * 0.30)
	reg("build", 0.22, func(t, _d): return (sin(TAU * (130.0 - 150.0 * t) * t) * 0.7 + noise() * 0.15) * exp(-t * 14.0))
	reg("sell", 0.25, func(t, _d): return (tone(880.0, t) * exp(-t * 12.0) + (tone(587.0, t) * exp(-(t - 0.08) * 12.0) if t > 0.08 else 0.0)) * 0.30)
	reg("upgrade", 0.5, func(t, _d): return tone([523.0, 659.0, 784.0, 1047.0][mini(int(t / 0.1), 3)], t) * exp(-fposmod(t, 0.1) * 10.0) * 0.35)
	reg("click", 0.05, func(t, _d): return tone(820.0, t) * exp(-t * 60.0) * 0.30)
	reg("fail", 0.2, func(t, _d): return tone(160.0, t) * exp(-t * 9.0) * 0.45 + tone(150.0, t) * exp(-t * 9.0) * 0.3)
	reg("wave", 0.95, func(t, _d): return (kick(fposmod(t, 0.25)) * 0.9 + noise() * 0.10 * minf(t, 0.5)) * (1.0 - t * 0.35))
	reg("complete", 0.95, func(t, _d): return tone([392.0, 523.0, 659.0, 784.0][mini(int(t / 0.2), 3)], t) * minf(1.0, (1.0 - t) * 3.0) * 0.30)
	reg("leak", 0.45, func(t, _d): return (fposmod(110.0 * t, 1.0) * 2.0 - 1.0) * exp(-t * 6.0) * 0.45)
	reg("horn", 1.3, func(t, _d): return (tone(55.0, t) + 0.6 * tone(82.5, t) + 0.3 * tone(110.0, t)) * minf(t * 4.0, 1.0) * exp(-t * 1.6) * 0.5)
	reg("rain", 0.9, func(t, _d): return noise() * minf(t * 3.0, 1.0) * exp(-t * 2.2) * 0.35)
	reg("win", 1.8, func(t, _d): return tone([392.0, 523.0, 659.0, 784.0, 1047.0, 784.0, 1047.0][mini(int(t / 0.22), 6)], t) * minf(1.0, (1.8 - t) * 2.0) * 0.32)
	reg("lose", 1.5, func(t, _d): return tone([392.0, 349.0, 311.0, 262.0, 196.0][mini(int(t / 0.28), 4)], t) * minf(1.0, (1.5 - t) * 2.0) * 0.35)
