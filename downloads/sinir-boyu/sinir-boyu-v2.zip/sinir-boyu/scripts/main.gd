extends Node2D
## SINIR BOYU (v2)
## Erken Osmanlı uç beyliği temalı kale savunma oyunu (Godot 4).
## Tüm grafikler ve sesler kodla üretilir; dış dosya gerekmez.
## Veriler (harita, zorluk, kule, düşman) scripts/data.gd içinde, sesler scripts/sfx.gd içinde.

const Data = preload("res://scripts/data.gd")
const Sfx = preload("res://scripts/sfx.gd")

# ============================================================== SABİTLER
const TILE := 64
const COLS := 16
const ROWS := 11
const MAP_W := 1024
const SCREEN_W := 1280
const SCREEN_H := 704
const SAVE_PATH := "user://sinir_boyu_kayit.json"

const SELL_RATIO := 0.7
const RAIN_COOLDOWN := 40.0
const RAIN_RADIUS := 120.0
const RAIN_DAMAGE := 150.0
const MAX_PARTICLES := 700
const BANNER_DUR := 3.2

enum State { MENU, PLAYING, OVER, WIN }

# ============================================================== VERİ (data.gd'den)
var maps: Array = []
var diffs: Array = []
var tower_order: Array = []
var tower_defs: Dictionary = {}
var branch_defs: Dictionary = {}
var enemy_order: Array = []
var enemy_defs: Dictionary = {}
var wave_names: Array = []
var tips: Array = []

# ============================================================== DURUM
var state: int = State.MENU

var map_idx := 0
var diff_idx := 1
var endless := false
var cur_map: Dictionary = {}
var cur_diff: Dictionary = {}
var max_wave := 15

var waypoints := PackedVector2Array()
var route_air := PackedVector2Array()
var gate_cell := Vector2i(14, 0)
var path_cells := {}
var blocked_cells := {}
var water_cells := {}
var decor: Array = []
var path_edges: Array = [
	[Vector2i(1, 0), Vector2(1, 0), Vector2(1, 1)],
	[Vector2i(-1, 0), Vector2(0, 0), Vector2(0, 1)],
	[Vector2i(0, 1), Vector2(0, 1), Vector2(1, 1)],
	[Vector2i(0, -1), Vector2(0, 0), Vector2(1, 0)],
]

var towers: Array = []
var enemies: Array = []
var projectiles: Array = []
var effects: Array = []
var particles: Array = []
var rains: Array = []
var spawn_queue: Array = []

var wave := 0
var wave_active := false
var wave_time := 0.0
var gold := 200
var lives := 20
var score := 0
var kills := 0
var game_speed := 1
var paused := false

var selected_type := ""
var selected_tower: Variant = null
var hover_cell := Vector2i(-1, -1)
var mouse_pos := Vector2.ZERO
var rain_cd := 0.0
var rain_armed := false

var time_total := 0.0
var message := ""
var message_t := 0.0
var banner_text := ""
var banner_sub := ""
var banner_t := 0.0
var banner_boss := false
var shake := 0.0
var leak_flash := 0.0

var player_name := "Akıncı"
var scoreboard: Array = []
var best := {}
var wins := 0
var sfx_on := true
var music_on := true
var last_result_text := ""

# ============================================================== UI NESNELERİ
var sfx: Node
var font: Font
var ui: CanvasLayer
var ui_top: CanvasLayer
var panel_root: Control
var lbl_gold: Label
var lbl_lives: Label
var lbl_wave: Label
var lbl_score: Label
var lbl_mapinfo: Label
var tower_buttons := {}
var lbl_info: Label
var btn_upgrade: Button
var btn_sell: Button
var btn_branch_a: Button
var btn_branch_b: Button
var btn_rain: Button
var btn_start: Button
var btn_speed: Button
var btn_pause: Button
var btn_menu: Button
var btn_sfx: Button
var btn_music: Button

var menu_layer: Control
var lbl_best: Label
var lbl_tip: Label
var setup_layer: Control
var map_buttons: Array = []
var diff_buttons: Array = []
var btn_mode: Button
var map_preview: Control
var lbl_map_desc: Label
var lbl_setup_info: Label
var name_edit: LineEdit
var help_layer: Control
var help_text: RichTextLabel
var help_page_buttons: Array = []
var help_pages: Array = []
var score_layer: Control
var score_rows: Array = []
var result_layer: Control
var lbl_result_title: Label
var lbl_result_stats: Label


# ============================================================== BAŞLANGIÇ
func _ready() -> void:
	randomize()
	font = ThemeDB.fallback_font
	maps = Data.maps()
	diffs = Data.diffs()
	tower_order = Data.tower_order()
	tower_defs = Data.towers()
	branch_defs = Data.branches()
	enemy_order = Data.enemy_order()
	enemy_defs = Data.enemies()
	wave_names = Data.wave_names()
	tips = Data.tips()
	sfx = Sfx.new()
	add_child(sfx)
	load_save()
	cur_diff = diffs[diff_idx]
	apply_map(map_idx)
	build_ui()
	sfx.set_sfx(sfx_on)
	sfx.music_on = music_on
	sfx.start_music()
	show_menu()


func cell_center(c: Vector2i) -> Vector2:
	return Vector2(c.x * TILE + TILE * 0.5, c.y * TILE + TILE * 0.5)


func snd(sound_name: String, vol: float = 0.0, pitch: float = 1.0) -> void:
	sfx.play(sound_name, vol, pitch)


func apply_map(i: int) -> void:
	map_idx = i
	cur_map = maps[i]
	var corners: Array = cur_map["corners"]
	waypoints = PackedVector2Array()
	for c in corners:
		waypoints.append(cell_center(c))
	gate_cell = corners[corners.size() - 1]
	route_air = PackedVector2Array([waypoints[0], cell_center(gate_cell)])

	path_cells.clear()
	for k in range(corners.size() - 1):
		var a: Vector2i = corners[k]
		var b: Vector2i = corners[k + 1]
		var step := Vector2i(signi(b.x - a.x), signi(b.y - a.y))
		var cur := a
		while true:
			path_cells[cur] = true
			if cur == b:
				break
			cur += step

	blocked_cells.clear()
	water_cells.clear()
	blocked_cells[Vector2i(gate_cell.x - 1, 0)] = true
	blocked_cells[Vector2i(gate_cell.x + 1, 0)] = true
	var water_list: Array = cur_map["water"]
	for wr in water_list:
		var r: Rect2i = wr
		for yy in range(r.position.y, r.position.y + r.size.y):
			for xx in range(r.position.x, r.position.x + r.size.x):
				var wc := Vector2i(xx, yy)
				water_cells[wc] = true
				blocked_cells[wc] = true

	var rng := RandomNumberGenerator.new()
	rng.seed = int(cur_map["seed"])
	var tree_density := float(cur_map["trees"])
	var rock_ratio := float(cur_map["rocks"])
	decor.clear()
	for cy in range(ROWS):
		for cx in range(COLS):
			var c := Vector2i(cx, cy)
			if path_cells.has(c) or blocked_cells.has(c):
				continue
			var near_path := false
			for dy in range(-1, 2):
				for dx in range(-1, 2):
					if path_cells.has(Vector2i(cx + dx, cy + dy)):
						near_path = true
			var chance := 0.05 if near_path else 0.38 * tree_density
			if rng.randf() < chance:
				blocked_cells[c] = true
				var kind := "rock" if rng.randf() < rock_ratio else "tree"
				decor.append({
					"cell": c, "kind": kind,
					"off": Vector2(rng.randf_range(-8.0, 8.0), rng.randf_range(-6.0, 6.0)),
					"size": rng.randf_range(0.85, 1.15),
				})


# ============================================================== ARAYÜZ YARDIMCILARI
func make_style(bg: Color, border: Color) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_corner_radius_all(6)
	return s


func style_button(b: Button) -> void:
	b.add_theme_stylebox_override("normal", make_style(Color(0.30, 0.22, 0.14), Color(0.62, 0.48, 0.28)))
	b.add_theme_stylebox_override("hover", make_style(Color(0.40, 0.30, 0.18), Color(0.85, 0.68, 0.35)))
	b.add_theme_stylebox_override("pressed", make_style(Color(0.22, 0.16, 0.10), Color(0.85, 0.68, 0.35)))
	b.add_theme_stylebox_override("disabled", make_style(Color(0.18, 0.16, 0.14), Color(0.30, 0.27, 0.22)))
	b.add_theme_color_override("font_color", Color(0.96, 0.90, 0.78))
	b.add_theme_color_override("font_hover_color", Color(1.0, 0.96, 0.85))
	b.add_theme_color_override("font_pressed_color", Color(1.0, 0.96, 0.85))
	b.add_theme_color_override("font_disabled_color", Color(0.55, 0.52, 0.47))


func set_sel_style(b: Button, sel: bool) -> void:
	if sel:
		var hi := make_style(Color(0.48, 0.35, 0.12), Color(1.0, 0.85, 0.40))
		b.add_theme_stylebox_override("normal", hi)
		b.add_theme_stylebox_override("hover", make_style(Color(0.54, 0.40, 0.15), Color(1.0, 0.90, 0.50)))
		b.add_theme_stylebox_override("pressed", hi)
	else:
		style_button(b)


func make_label(parent: Node, text: String, pos: Vector2, size: Vector2, font_size: int, color: Color, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, wrap: bool = false) -> Label:
	var l := Label.new()
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.text = text
	l.position = pos
	l.size = size
	l.horizontal_alignment = align
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)
	return l


func make_button(parent: Node, text: String, pos: Vector2, size: Vector2, cb: Callable, font_size: int = 15) -> Button:
	var b := Button.new()
	b.text = text
	b.position = pos
	b.size = size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font_size)
	style_button(b)
	b.pressed.connect(cb)
	b.pressed.connect(func(): snd("click", -6.0))
	parent.add_child(b)
	return b


func make_overlay(color: Color) -> Control:
	var layer := Control.new()
	layer.size = Vector2(SCREEN_W, SCREEN_H)
	ui_top.add_child(layer)
	var bg := ColorRect.new()
	bg.color = color
	bg.size = Vector2(SCREEN_W, SCREEN_H)
	layer.add_child(bg)
	return layer


# ============================================================== ARAYÜZ KURULUMU
func build_ui() -> void:
	ui = CanvasLayer.new()
	ui.layer = 1
	add_child(ui)
	ui_top = CanvasLayer.new()
	ui_top.layer = 10
	add_child(ui_top)

	var pw := float(SCREEN_W - MAP_W)
	panel_root = Panel.new()
	panel_root.position = Vector2(MAP_W, 0)
	panel_root.size = Vector2(pw, SCREEN_H)
	panel_root.add_theme_stylebox_override("panel", make_style(Color(0.13, 0.10, 0.07), Color(0.45, 0.34, 0.20)))
	ui.add_child(panel_root)

	var gold_col := Color(1.0, 0.85, 0.35)
	var txt_col := Color(0.93, 0.88, 0.78)
	make_label(panel_root, "SINIR BOYU", Vector2(0, 6), Vector2(pw, 30), 24, gold_col, HORIZONTAL_ALIGNMENT_CENTER)
	lbl_gold = make_label(panel_root, "", Vector2(14, 40), Vector2(pw - 28, 20), 16, gold_col)
	lbl_lives = make_label(panel_root, "", Vector2(14, 60), Vector2(pw - 28, 20), 16, Color(1.0, 0.55, 0.50))
	lbl_wave = make_label(panel_root, "", Vector2(14, 80), Vector2(pw - 28, 20), 16, txt_col)
	lbl_score = make_label(panel_root, "", Vector2(14, 100), Vector2(pw - 28, 20), 16, txt_col)
	lbl_mapinfo = make_label(panel_root, "", Vector2(14, 122), Vector2(pw - 28, 16), 11, Color(0.70, 0.62, 0.48))

	make_label(panel_root, "İNŞA", Vector2(14, 142), Vector2(pw - 28, 18), 13, Color(0.70, 0.62, 0.48))
	var idx := 0
	for kind in tower_order:
		var col := idx % 2
		var row := int(floor(idx / 2.0))
		var b := make_button(panel_root, "", Vector2(8 + col * 122, 160 + row * 44), Vector2(118, 40), select_build.bind(kind), 12)
		b.tooltip_text = String(tower_defs[kind]["desc"])
		tower_buttons[kind] = b
		idx += 1

	lbl_info = make_label(panel_root, "", Vector2(12, 294), Vector2(pw - 24, 112), 12, txt_col, HORIZONTAL_ALIGNMENT_LEFT, true)
	btn_upgrade = make_button(panel_root, "Yükselt", Vector2(8, 408), Vector2(118, 46), on_upgrade, 13)
	btn_sell = make_button(panel_root, "Sat", Vector2(130, 408), Vector2(118, 46), on_sell, 13)
	btn_branch_a = make_button(panel_root, "A", Vector2(8, 408), Vector2(118, 46), on_branch.bind(0), 12)
	btn_branch_b = make_button(panel_root, "B", Vector2(130, 408), Vector2(118, 46), on_branch.bind(1), 12)
	btn_rain = make_button(panel_root, "Ok Yağmuru (Q)", Vector2(8, 488), Vector2(pw - 16, 34), on_rain_button, 14)
	btn_start = make_button(panel_root, "Dalgayı Başlat", Vector2(8, 526), Vector2(pw - 16, 42), on_start_wave, 16)
	btn_speed = make_button(panel_root, "Hız: 1x", Vector2(8, 574), Vector2(76, 30), on_speed, 13)
	btn_pause = make_button(panel_root, "Duraklat", Vector2(90, 574), Vector2(76, 30), on_pause, 13)
	btn_menu = make_button(panel_root, "Menü", Vector2(172, 574), Vector2(76, 30), on_menu_button, 13)
	btn_sfx = make_button(panel_root, "Ses: Açık", Vector2(8, 608), Vector2(118, 26), on_sfx_toggle, 12)
	btn_music = make_button(panel_root, "Müzik: Açık", Vector2(130, 608), Vector2(118, 26), on_music_toggle, 12)
	var hint := make_label(panel_root, "1-6 kule | Boşluk dalga | F hız | P duraklat | Q ok yağmuru | U/I yükselt / dal | X sat | M sessiz | Esc ya da sağ tık iptal", Vector2(10, 640), Vector2(pw - 20, 60), 10, Color(0.62, 0.56, 0.45), HORIZONTAL_ALIGNMENT_LEFT, true)

	build_menu()
	build_setup()
	build_help()
	build_scores()
	build_result()


func build_menu() -> void:
	menu_layer = make_overlay(Color(0.05, 0.06, 0.04, 0.90))
	make_label(menu_layer, "SINIR BOYU", Vector2(0, 100), Vector2(SCREEN_W, 84), 74, Color(1.0, 0.82, 0.35), HORIZONTAL_ALIGNMENT_CENTER)
	make_label(menu_layer, "Uç Beyliği Kale Savunması", Vector2(0, 194), Vector2(SCREEN_W, 30), 24, Color(0.85, 0.78, 0.62), HORIZONTAL_ALIGNMENT_CENTER)
	var bx := (SCREEN_W - 360) / 2.0
	make_button(menu_layer, "Savaşa Başla", Vector2(bx, 262), Vector2(360, 54), open_setup, 22)
	make_button(menu_layer, "Skor Tablosu", Vector2(bx, 326), Vector2(360, 54), open_scores, 22)
	make_button(menu_layer, "Nasıl Oynanır", Vector2(bx, 390), Vector2(360, 54), open_help, 22)
	make_button(menu_layer, "Çıkış", Vector2(bx, 454), Vector2(360, 54), on_quit, 22)
	lbl_best = make_label(menu_layer, "", Vector2(0, 540), Vector2(SCREEN_W, 30), 18, Color(0.80, 0.74, 0.60), HORIZONTAL_ALIGNMENT_CENTER)
	lbl_tip = make_label(menu_layer, "", Vector2(0, 590), Vector2(SCREEN_W, 30), 16, Color(0.65, 0.78, 0.55), HORIZONTAL_ALIGNMENT_CENTER)


func build_setup() -> void:
	setup_layer = make_overlay(Color(0.05, 0.05, 0.04, 1.0))
	var cream := Color(0.92, 0.87, 0.76)
	var dim := Color(0.70, 0.62, 0.48)
	make_label(setup_layer, "SEFER HAZIRLIĞI", Vector2(0, 16), Vector2(SCREEN_W, 46), 38, Color(1.0, 0.82, 0.35), HORIZONTAL_ALIGNMENT_CENTER)

	make_label(setup_layer, "HARİTA", Vector2(60, 74), Vector2(300, 22), 15, dim)
	for i in range(maps.size()):
		var b := make_button(setup_layer, "%s\n%s" % [maps[i]["name"], maps[i]["desc"]], Vector2(60, 100 + i * 80), Vector2(380, 72), select_map.bind(i), 14)
		map_buttons.append(b)

	map_preview = Control.new()
	map_preview.position = Vector2(480, 100)
	map_preview.size = Vector2(288, 198)
	map_preview.draw.connect(on_preview_draw)
	setup_layer.add_child(map_preview)
	lbl_map_desc = make_label(setup_layer, "", Vector2(480, 304), Vector2(300, 22), 14, cream)

	make_label(setup_layer, "KOMUTAN ADI", Vector2(840, 74), Vector2(300, 22), 15, dim)
	name_edit = LineEdit.new()
	name_edit.position = Vector2(840, 100)
	name_edit.size = Vector2(380, 40)
	name_edit.max_length = 14
	name_edit.text = player_name
	name_edit.placeholder_text = "Komutan adı"
	name_edit.add_theme_font_size_override("font_size", 20)
	name_edit.text_changed.connect(on_name_changed)
	setup_layer.add_child(name_edit)
	lbl_setup_info = make_label(setup_layer, "", Vector2(840, 156), Vector2(380, 170), 15, cream, HORIZONTAL_ALIGNMENT_LEFT, true)

	make_label(setup_layer, "ZORLUK", Vector2(60, 340), Vector2(300, 22), 15, dim)
	for i in range(diffs.size()):
		var d: Dictionary = diffs[i]
		var txt := "%s\n%s\nAltın %d  Can %d  Dalga %d" % [d["name"], d["desc"], int(d["gold"]), int(d["lives"]), int(d["waves"])]
		var b := make_button(setup_layer, txt, Vector2(60 + i * 293, 366), Vector2(280, 96), select_diff.bind(i), 14)
		diff_buttons.append(b)

	btn_mode = make_button(setup_layer, "", Vector2(60, 482), Vector2(560, 48), on_toggle_endless, 16)
	make_button(setup_layer, "Geri", Vector2(380, 570), Vector2(220, 60), show_menu, 22)
	make_button(setup_layer, "Başla", Vector2(680, 570), Vector2(220, 60), start_game, 24)
	setup_layer.visible = false


func build_help() -> void:
	help_layer = make_overlay(Color(0.06, 0.05, 0.04, 1.0))
	make_label(help_layer, "NASIL OYNANIR", Vector2(0, 16), Vector2(SCREEN_W, 46), 36, Color(1.0, 0.82, 0.35), HORIZONTAL_ALIGNMENT_CENTER)
	var titles: Array = ["Oynanış", "Kuleler", "Düşmanlar", "Kısayollar"]
	for i in range(titles.size()):
		var b := make_button(help_layer, String(titles[i]), Vector2(190 + i * 220, 76), Vector2(210, 40), show_help_page.bind(i), 18)
		help_page_buttons.append(b)
	help_text = RichTextLabel.new()
	help_text.bbcode_enabled = true
	help_text.position = Vector2(90, 130)
	help_text.size = Vector2(1100, 460)
	help_text.scroll_active = true
	help_text.add_theme_font_size_override("normal_font_size", 16)
	help_text.add_theme_font_size_override("bold_font_size", 16)
	help_text.add_theme_color_override("default_color", Color(0.92, 0.87, 0.76))
	help_layer.add_child(help_text)
	make_button(help_layer, "Geri", Vector2((SCREEN_W - 240) / 2.0, 614), Vector2(240, 50), close_help, 20)

	var gold := "[color=#ffd966]"
	var end := "[/color]"
	help_pages = [
		"[b]" + gold + "AMAÇ" + end + "[/b]\nKaranlık ordu yoldan kale kapısına ilerliyor. Kapıya ulaşan her düşman kale canını azaltır. Seçtiğin zorluğun dalga sayısını geçersen zafer kazanırsın. Sonsuz modda zafer yoktur; kale düşene kadar ne kadar dayanabildiğin ölçülür.\n\n"
		+ "[b]" + gold + "OYNANIŞ" + end + "[/b]\n- Sağdaki listeden bir kule seç, haritada boş bir araziye tıkla.\n- Kuleye tıklayınca bilgisini görürsün. 1. seviyeden 2. seviyeye normal yükseltirsin. 2. seviyeden 3. seviyeye geçerken iki daldan birini seçersin.\n- Kuleyi satarsan yatırımının %70'ini geri alırsın.\n- Dalgalar arasında hazırlan. Hazır olunca Boşluk tuşuna ya da Dalgayı Başlat düğmesine bas.\n- Düşman öldürmek ve dalgayı bitirmek altın kazandırır.\n- Her 5. dalgada bir boss gelir.\n- Ok Yağmuru: belirli aralıkla seçtiğin bölgeye büyük hasar verir. Havadakileri de vurur.\n- Gölge Kuzgunlar uçar: yalnız Okçu Kuleleri ve Ok Yağmuru onları vurabilir.",
		"[b]" + gold + "Okçu Kulesi" + end + "[/b]\nHızlı atış. Yerdeki ve havadaki düşmanları vurur. Dallar: Seri Atış ya da Zırh Delici.\n\n"
		+ "[b]" + gold + "Mancınık" + end + "[/b]\nYavaş ama alan hasarı verir, yalnız yerdekileri vurur. Dallar: Geniş Alan ya da Ağır Gülle.\n\n"
		+ "[b]" + gold + "Kızgın Yağ Kazanı" + end + "[/b]\nMenzildeki yerdeki düşmanlara sürekli yanık hasarı verir ve zırhı yok sayar. Dallar: Kaynar Yağ ya da Yapışkan Yağ.\n\n"
		+ "[b]" + gold + "Zincirli Tuzak" + end + "[/b]\nMenzildeki yerdeki düşmanları yavaşlatır. Dallar: Buz Zinciri ya da Dikenli Zincir.\n\n"
		+ "[b]" + gold + "Mehter Takımı" + end + "[/b]\nKendisi saldırmaz; yakındaki kulelerin atış hızını ve hasarını artırır. Birden fazla Mehter üst üste binmez, en güçlüsü geçerli olur. Dallar: Cenk Marşı ya da Savaş Davulu.\n\n"
		+ "[b]" + gold + "Şahi Topu" + end + "[/b]\nÇok yavaş atar ama devasa alan hasarı verir, yalnız yerdekileri vurur. Dallar: Misket Gülle ya da Kale Yıkıcı.",
		"[b]" + gold + "Karanlık Piyade" + end + "[/b]  Sıradan askerler.\n\n"
		+ "[b]" + gold + "Kara Akıncı" + end + "[/b]  Çok hızlı, az canlı.\n\n"
		+ "[b]" + gold + "Demir Muhafız" + end + "[/b]  Zırhlı. Zayıf oklar işlemez; güçlü darbeler, yağ ya da zırh delici kullan.\n\n"
		+ "[b]" + gold + "Gölge Büyücü" + end + "[/b]  Yakınındaki düşmanları iyileştirir. Önce onu devir.\n\n"
		+ "[b]" + gold + "Gölge Kuzgun" + end + "[/b]  Uçar, yolu izlemez, doğrudan kaleye gider. Yalnız Okçu ve Ok Yağmuru vurur.\n\n"
		+ "[b]" + gold + "Taş Dev" + end + "[/b]  Çok canlı ve yavaş. Kapıya vurursa kale ağır zarar görür.\n\n"
		+ "[b]" + gold + "Kuşatma Devi" + end + "[/b]  Boss. Devasa can ve zırh.\n\n"
		+ "[b]" + gold + "Kara Hükümdar" + end + "[/b]  Boss. Düzenli aralıklarla yanına piyade çağırır.",
		"[b]" + gold + "Kule ve araçlar" + end + "[/b]\n1-6: kule seç\nBoşluk: dalgayı başlat\nF: hız (1x / 2x / 3x)\nP: duraklat\nQ: Ok Yağmuru\nU: yükselt (2. seviyede A dalı)\nI: B dalı\nX: kuleyi sat\nM: sesi ve müziği kapat / aç\nEsc ya da sağ tık: seçimi iptal et (seçim yokken duraklatır)\n\n"
		+ "[b]" + gold + "Fare" + end + "[/b]\nSol tık: kule yerleştir, kule seç, Ok Yağmuru hedefle\nSağ tık: seçimi iptal\nDüşmanın üstüne gelirsen canını ve zırhını görürsün.",
	]
	show_help_page(0)
	help_layer.visible = false


func build_scores() -> void:
	score_layer = make_overlay(Color(0.05, 0.05, 0.04, 1.0))
	make_label(score_layer, "SKOR TABLOSU", Vector2(0, 20), Vector2(SCREEN_W, 46), 36, Color(1.0, 0.82, 0.35), HORIZONTAL_ALIGNMENT_CENTER)
	var xs: Array = [100.0, 160.0, 430.0, 600.0, 740.0]
	var ws: Array = [50.0, 260.0, 150.0, 120.0, 440.0]
	var heads: Array = ["#", "Komutan", "Skor", "Dalga", "Harita / Zorluk"]
	for c in range(5):
		make_label(score_layer, String(heads[c]), Vector2(float(xs[c]), 84), Vector2(float(ws[c]), 26), 16, Color(0.70, 0.62, 0.48))
	for r in range(10):
		var row: Array = []
		for c in range(5):
			var align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT
			var l := make_label(score_layer, "", Vector2(float(xs[c]), 120 + r * 40), Vector2(float(ws[c]), 30), 20, Color(0.92, 0.87, 0.76), align)
			row.append(l)
		score_rows.append(row)
	make_button(score_layer, "Geri", Vector2((SCREEN_W - 240) / 2.0, 610), Vector2(240, 54), close_scores, 22)
	score_layer.visible = false


func build_result() -> void:
	result_layer = make_overlay(Color(0.03, 0.03, 0.03, 0.84))
	lbl_result_title = make_label(result_layer, "", Vector2(0, 100), Vector2(SCREEN_W, 90), 72, Color(1.0, 0.82, 0.35), HORIZONTAL_ALIGNMENT_CENTER)
	lbl_result_stats = make_label(result_layer, "", Vector2(0, 210), Vector2(SCREEN_W, 220), 22, Color(0.92, 0.87, 0.76), HORIZONTAL_ALIGNMENT_CENTER)
	var bx := (SCREEN_W - 320) / 2.0
	make_button(result_layer, "Tekrar Oyna", Vector2(bx, 450), Vector2(320, 54), start_game, 22)
	make_button(result_layer, "Skor Tablosu", Vector2(bx, 514), Vector2(320, 54), open_scores, 22)
	make_button(result_layer, "Ana Menü", Vector2(bx, 578), Vector2(320, 54), show_menu, 22)
	result_layer.visible = false


# ============================================================== MENÜ / EKRANLAR
func hide_overlays() -> void:
	menu_layer.visible = false
	setup_layer.visible = false
	help_layer.visible = false
	score_layer.visible = false
	result_layer.visible = false


func show_menu() -> void:
	state = State.MENU
	paused = false
	hide_overlays()
	menu_layer.visible = true
	var top_score := 0
	if scoreboard.size() > 0:
		top_score = int(scoreboard[0]["score"])
	lbl_best.text = "En yüksek skor: %d     Zafer: %d" % [top_score, wins]
	lbl_tip.text = String(tips[randi() % tips.size()])
	sfx.intense = false


func open_setup() -> void:
	hide_overlays()
	setup_layer.visible = true
	refresh_setup()


func open_help() -> void:
	ui_top.move_child(help_layer, -1)
	help_layer.visible = true


func close_help() -> void:
	help_layer.visible = false


func open_scores() -> void:
	refresh_scores()
	ui_top.move_child(score_layer, -1)
	score_layer.visible = true


func close_scores() -> void:
	score_layer.visible = false


func show_help_page(i: int) -> void:
	help_text.text = String(help_pages[i])
	help_text.scroll_to_line(0)
	for k in range(help_page_buttons.size()):
		set_sel_style(help_page_buttons[k], k == i)


func on_quit() -> void:
	get_tree().quit()


func select_map(i: int) -> void:
	map_idx = i
	refresh_setup()


func select_diff(i: int) -> void:
	diff_idx = i
	refresh_setup()


func on_toggle_endless() -> void:
	endless = not endless
	refresh_setup()


func on_name_changed(new_text: String) -> void:
	player_name = new_text


func refresh_setup() -> void:
	for i in range(map_buttons.size()):
		set_sel_style(map_buttons[i], i == map_idx)
	for i in range(diff_buttons.size()):
		set_sel_style(diff_buttons[i], i == diff_idx)
	var d: Dictionary = diffs[diff_idx]
	var m: Dictionary = maps[map_idx]
	btn_mode.text = "Mod: Sonsuz (zafer yok, en çok dalga)" if endless else "Mod: Normal (%d dalga, zafer var)" % int(d["waves"])
	set_sel_style(btn_mode, endless)
	lbl_map_desc.text = String(m["name"])
	var waves_txt := "sonsuz" if endless else str(int(d["waves"]))
	lbl_setup_info.text = "Harita: %s\nZorluk: %s\nDalga: %s\nBaşlangıç altını: %d\nKale canı: %d\nDüşman canı: x%.2f\nSkor çarpanı: x%.1f" % [m["name"], d["name"], waves_txt, int(d["gold"]), int(d["lives"]), float(d["hp"]), float(d["smult"])]
	map_preview.queue_redraw()


func on_preview_draw() -> void:
	var m: Dictionary = maps[map_idx]
	var sc := 0.28
	var pv := map_preview
	pv.draw_rect(Rect2(0, 0, 288, 198), m["grass"])
	var water_list: Array = m["water"]
	for wr in water_list:
		var r: Rect2i = wr
		pv.draw_rect(Rect2(r.position.x * TILE * sc, r.position.y * TILE * sc, r.size.x * TILE * sc, r.size.y * TILE * sc), Color(0.20, 0.40, 0.65))
	var corners: Array = m["corners"]
	var pts := PackedVector2Array()
	for c in corners:
		var cc: Vector2i = c
		pts.append(Vector2(maxf(0.0, (cc.x * TILE + 32) * sc), (cc.y * TILE + 32) * sc))
	pv.draw_polyline(pts, m["path"], 14.0)
	var gate: Vector2i = corners[corners.size() - 1]
	pv.draw_rect(Rect2((gate.x - 1) * TILE * sc, 0, 3 * TILE * sc, 14), Color(0.58, 0.55, 0.50))
	pv.draw_circle(pts[0] + Vector2(6, 0), 9.0, Color(0.55, 0.25, 0.70))
	pv.draw_rect(Rect2(0, 0, 288, 198), Color(0.45, 0.34, 0.20), false, 3.0)


func refresh_scores() -> void:
	for r in range(10):
		var row: Array = score_rows[r]
		if r < scoreboard.size():
			var e: Dictionary = scoreboard[r]
			row[0].text = str(r + 1)
			row[1].text = String(e["name"])
			row[2].text = str(int(e["score"]))
			row[3].text = str(int(e["wave"]))
			row[4].text = String(e["where"])
		else:
			for c in range(5):
				row[c].text = ""


# ============================================================== OYUN AKIŞI
func start_game() -> void:
	hide_overlays()
	name_edit.release_focus()
	if player_name.strip_edges() == "":
		player_name = "Akıncı"
		name_edit.text = player_name
	cur_diff = diffs[diff_idx]
	apply_map(map_idx)
	max_wave = 999999 if endless else int(cur_diff["waves"])
	towers.clear()
	enemies.clear()
	projectiles.clear()
	effects.clear()
	particles.clear()
	rains.clear()
	spawn_queue.clear()
	wave = 0
	wave_active = false
	wave_time = 0.0
	gold = int(cur_diff["gold"])
	lives = int(cur_diff["lives"])
	score = 0
	kills = 0
	game_speed = 1
	paused = false
	selected_type = ""
	selected_tower = null
	rain_cd = 0.0
	rain_armed = false
	shake = 0.0
	leak_flash = 0.0
	banner_t = 0.0
	state = State.PLAYING
	save_all()
	announce("Kaleyi savun! Hazır olunca Boşluk tuşuyla ilk dalgayı başlat.")


func announce(text: String) -> void:
	message = text
	message_t = 3.5


func show_banner(title: String, sub: String, boss: bool) -> void:
	banner_text = title
	banner_sub = sub
	banner_boss = boss
	banner_t = BANNER_DUR


func finish_game(win: bool) -> void:
	state = State.WIN if win else State.OVER
	wave_active = false
	sfx.intense = false
	var reached := wave
	if win:
		add_score(lives * 100)
		wins += 1
	var key := "%d_%d_%d" % [map_idx, diff_idx, 1 if endless else 0]
	var prev: Dictionary = best.get(key, {})
	if score > int(prev.get("score", 0)):
		best[key] = {"score": score, "wave": reached}
	var where := "%s / %s%s" % [cur_map["name"], cur_diff["name"], " (Sonsuz)" if endless else ""]
	scoreboard.append({"name": player_name, "score": score, "wave": reached, "where": where})
	scoreboard.sort_custom(func(a, b): return int(a["score"]) > int(b["score"]))
	if scoreboard.size() > 30:
		scoreboard.resize(30)
	save_all()
	lbl_result_title.text = "ZAFER!" if win else "KALE DÜŞTÜ"
	lbl_result_title.add_theme_color_override("font_color", Color(1.0, 0.82, 0.35) if win else Color(0.90, 0.35, 0.30))
	var wave_txt := "Ulaşılan dalga: %d" % reached if endless else "Ulaşılan dalga: %d / %d" % [reached, max_wave]
	lbl_result_stats.text = "%s\n%s\nKomutan: %s\n%s\nÖldürülen düşman: %d\nSkor: %d" % [cur_map["name"], "Zorluk: " + String(cur_diff["name"]), player_name, wave_txt, kills, score]
	result_layer.visible = true
	snd("win" if win else "lose", -2.0)


func add_score(n: int) -> void:
	score += int(round(float(n) * float(cur_diff["smult"])))


# ============================================================== KAYIT
func load_save() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var data: Variant = JSON.parse_string(f.get_as_text())
	if typeof(data) != TYPE_DICTIONARY:
		return
	wins = int(data.get("wins", 0))
	player_name = String(data.get("name", player_name))
	sfx_on = bool(data.get("sfx", true))
	music_on = bool(data.get("music", true))
	map_idx = clampi(int(data.get("map", 0)), 0, maps.size() - 1)
	diff_idx = clampi(int(data.get("diff", 1)), 0, diffs.size() - 1)
	endless = bool(data.get("endless", false))
	var sc: Variant = data.get("scores", [])
	if typeof(sc) == TYPE_ARRAY:
		scoreboard = sc
	var bs: Variant = data.get("best", {})
	if typeof(bs) == TYPE_DICTIONARY:
		best = bs


func save_all() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify({
		"wins": wins, "name": player_name, "sfx": sfx_on, "music": music_on,
		"map": map_idx, "diff": diff_idx, "endless": endless,
		"scores": scoreboard, "best": best,
	}))


# ============================================================== DÜĞME İŞLEYİCİLERİ
func select_build(kind: String) -> void:
	if state != State.PLAYING:
		return
	rain_armed = false
	selected_tower = null
	selected_type = "" if selected_type == kind else kind


func on_start_wave() -> void:
	if state != State.PLAYING or wave_active or paused:
		return
	if not endless and wave >= max_wave:
		return
	wave += 1
	spawn_queue = build_wave(wave)
	wave_time = 0.0
	wave_active = true
	sfx.intense = true
	var boss := wave % 5 == 0
	show_banner("DALGA %d" % wave, wave_title(wave), boss)
	snd("horn" if boss else "wave", -2.0)


func on_speed() -> void:
	game_speed = game_speed % 3 + 1


func on_pause() -> void:
	if state == State.PLAYING:
		paused = not paused


func on_menu_button() -> void:
	show_menu()


func on_sfx_toggle() -> void:
	sfx_on = not sfx_on
	sfx.set_sfx(sfx_on)
	save_all()


func on_music_toggle() -> void:
	music_on = not music_on
	sfx.set_music(music_on)
	save_all()


func on_mute_all() -> void:
	var on := not (sfx_on or music_on)
	sfx_on = on
	music_on = on
	sfx.set_sfx(sfx_on)
	sfx.set_music(music_on)
	save_all()


func on_rain_button() -> void:
	if state != State.PLAYING or rain_cd > 0.0:
		return
	rain_armed = not rain_armed
	selected_type = ""
	selected_tower = null


func on_upgrade() -> void:
	if selected_tower == null:
		return
	var t: Dictionary = selected_tower
	if int(t["level"]) == 1:
		do_upgrade(t, -1)
	elif int(t["level"]) == 2:
		announce("Dal seç: A (U) ya da B (I)")


func on_branch(bi: int) -> void:
	if selected_tower == null:
		return
	var t: Dictionary = selected_tower
	if int(t["level"]) == 2:
		do_upgrade(t, bi)


func do_upgrade(t: Dictionary, branch: int) -> void:
	var cost := upgrade_cost(t)
	if gold < cost:
		announce("Yeterli altın yok!")
		snd("fail")
		return
	gold -= cost
	t["level"] = int(t["level"]) + 1
	t["invested"] = int(t["invested"]) + cost
	if branch >= 0:
		t["branch"] = branch
	t["pop"] = 0.0
	var tp: Vector2 = t["pos"]
	effects.append({"kind": "boom", "pos": tp, "t": 0.0, "dur": 0.5, "r": 46.0, "color": Color(1.0, 0.9, 0.4)})
	spawn_burst(tp, Color(1.0, 0.88, 0.35), 18, 120.0, 0.7, 3.5, 30.0)
	add_text(tp, "Seviye %d" % int(t["level"]), Color(1.0, 0.9, 0.4))
	snd("upgrade")


func on_sell() -> void:
	if selected_tower == null:
		return
	var t: Dictionary = selected_tower
	var refund := int(float(t["invested"]) * SELL_RATIO)
	gold += refund
	var tp: Vector2 = t["pos"]
	add_text(tp, "+%d" % refund, Color(1.0, 0.85, 0.3))
	spawn_burst(tp, Color(0.8, 0.75, 0.6), 14, 90.0, 0.5, 3.0, 40.0)
	towers.erase(t)
	selected_tower = null
	snd("sell")


# ============================================================== DALGALAR
func scaled(n: int) -> int:
	return mini(int(ceil(float(n) * float(cur_diff["count"]))), 70)


func add_group(q: Array, kind: String, count: int, start: float, gap: float, hp_mult: float) -> void:
	for i in range(count):
		q.append({"t": start + gap * float(i), "kind": kind, "hp_mult": hp_mult})


func wave_title(w: int) -> String:
	if w % 5 == 0:
		return "KUŞATMA DEVİ GELİYOR!" if int(w / 5.0) % 2 == 1 else "KARA HÜKÜMDAR GELİYOR!"
	return String(wave_names[(w - 1) % wave_names.size()])


func build_wave(w: int) -> Array:
	var q: Array = []
	var hp_mult := float(cur_diff["hp"]) * (1.0 + float(cur_diff["growth"]) * float(w - 1))
	add_group(q, "piyade", scaled(5 + w * 2), 0.0, 0.85, hp_mult)
	if w >= 3:
		add_group(q, "akinci", scaled(2 + w), 2.0, 0.70, hp_mult)
	if w >= 5:
		add_group(q, "muhafiz", scaled(w - 3), 4.0, 1.60, hp_mult)
	if w >= 6:
		add_group(q, "kuzgun", scaled(int(w / 2.0)), 3.0, 1.10, hp_mult)
	if w >= 7:
		add_group(q, "buyucu", scaled(int((w - 4) / 2.0)), 6.0, 2.00, hp_mult)
	if w >= 10:
		add_group(q, "dev", scaled(mini(w - 8, 14)), 8.0, 4.00, hp_mult)
	if w % 5 == 0:
		var boss_n := 1 + int(w / 20.0)
		if int(w / 5.0) % 2 == 1:
			add_group(q, "devi", boss_n, 5.0, 8.0, hp_mult)
		else:
			add_group(q, "hukumdar", boss_n, 5.0, 8.0, hp_mult)
	q.sort_custom(func(a, b): return a["t"] < b["t"])
	return q


func preview_text(w: int) -> String:
	var counts := {}
	for s in build_wave(w):
		counts[s["kind"]] = int(counts.get(s["kind"], 0)) + 1
	var parts := PackedStringArray()
	for kind in enemy_order:
		if counts.has(kind):
			parts.append("%s x%d" % [enemy_defs[kind]["name"], counts[kind]])
	return ", ".join(parts)


func make_enemy(kind: String, hp_mult: float, pos: Vector2, wp: int, prog: float) -> Dictionary:
	var d: Dictionary = enemy_defs[kind]
	var hp := float(d["hp"]) * hp_mult
	var flying := bool(d.get("fly", false))
	var route: PackedVector2Array = route_air if flying else waypoints
	return {
		"kind": kind, "pos": pos, "wp": wp, "hp": hp, "max_hp": hp, "hp_mult": hp_mult,
		"speed": float(d["speed"]) * float(cur_diff["speed"]),
		"reward": int(d["reward"]), "leak": int(d["leak"]),
		"armor": float(d["armor"]), "radius": float(d["radius"]), "color": d["color"],
		"route": route, "flying": flying, "boss": bool(d.get("boss", false)),
		"slow": 1.0, "prog": prog, "dir": Vector2.RIGHT, "alive": true,
		"flash": 0.0, "seed": randf() * TAU, "ab_t": 4.0,
	}


func spawn_enemy(kind: String, hp_mult: float) -> void:
	var e := make_enemy(kind, hp_mult, waypoints[0], 1, 0.0)
	enemies.append(e)
	if bool(e["boss"]):
		shake = maxf(shake, 5.0)
		snd("horn", -3.0)


func end_wave() -> void:
	wave_active = false
	sfx.intense = false
	var bonus := int(float(30 + wave * 6) * float(cur_diff["reward"]))
	gold += bonus
	add_score(wave * 100)
	if not endless and wave >= max_wave:
		finish_game(true)
	else:
		show_banner("DALGA %d TAMAMLANDI" % wave, "+%d altın" % bonus, false)
		snd("complete", -3.0)


# ============================================================== KULE İSTATİSTİKLERİ
func bval(t: Dictionary, key: String, default_v: float) -> float:
	var bi := int(t["branch"])
	if bi < 0:
		return default_v
	var arr: Array = branch_defs[t["kind"]]
	if bi >= arr.size():
		return default_v
	var d: Dictionary = arr[bi]
	return float(d.get(key, default_v))


func tower_damage(t: Dictionary) -> float:
	var base := float(tower_defs[t["kind"]]["damage"])
	return base * pow(1.6, int(t["level"]) - 1) * bval(t, "damage", 1.0) * (1.0 + float(t["buff_dmg"]))


func tower_range(t: Dictionary) -> float:
	var base := float(tower_defs[t["kind"]]["range"])
	return base * (1.0 + 0.10 * float(int(t["level"]) - 1)) * bval(t, "range", 1.0)


func tower_rate(t: Dictionary) -> float:
	var base := float(tower_defs[t["kind"]]["rate"])
	return base * pow(0.88, int(t["level"]) - 1) * bval(t, "rate", 1.0) / (1.0 + float(t["buff_rate"]))


func tower_splash(t: Dictionary) -> float:
	var base := float(tower_defs[t["kind"]]["splash"])
	return (base + 8.0 * float(int(t["level"]) - 1)) * bval(t, "splash", 1.0)


func tower_slow(t: Dictionary) -> float:
	var s := (0.60 - 0.10 * float(int(t["level"]) - 1)) * bval(t, "slowmul", 1.0)
	return clampf(s, 0.25, 1.0)


func mehter_rate_bonus(t: Dictionary) -> float:
	return (0.12 + 0.06 * float(int(t["level"]))) * bval(t, "buffrate", 1.0)


func mehter_dmg_bonus(t: Dictionary) -> float:
	return 0.05 * float(int(t["level"])) + bval(t, "buffdmg", 0.0)


func upgrade_cost(t: Dictionary) -> int:
	var base := float(tower_defs[t["kind"]]["cost"])
	return int(base * (0.9 + 0.5 * float(int(t["level"]) - 1)))


func get_tower_at(c: Vector2i) -> Variant:
	for t in towers:
		if t["cell"] == c:
			return t
	return null


func can_build(c: Vector2i) -> bool:
	if c.x < 0 or c.y < 0 or c.x >= COLS or c.y >= ROWS:
		return false
	if path_cells.has(c) or blocked_cells.has(c):
		return false
	return get_tower_at(c) == null


func place_tower(kind: String, c: Vector2i) -> void:
	var cost := int(tower_defs[kind]["cost"])
	gold -= cost
	var t := {
		"kind": kind, "cell": c, "pos": cell_center(c), "level": 1, "branch": -1,
		"cd": 0.2, "invested": cost, "angle": -PI / 2.0, "active": false,
		"pop": 0.0, "recoil": 0.0, "buff_rate": 0.0, "buff_dmg": 0.0, "kills": 0,
	}
	towers.append(t)
	var tp: Vector2 = t["pos"]
	effects.append({"kind": "boom", "pos": tp, "t": 0.0, "dur": 0.35, "r": 34.0, "color": Color(0.9, 0.85, 0.6)})
	spawn_burst(tp + Vector2(0, 18), Color(0.7, 0.62, 0.45), 12, 80.0, 0.5, 3.0, 60.0)
	snd("build")


# ============================================================== GİRDİ
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		var kev0 := event as InputEventKey
		if kev0.pressed and not kev0.echo and kev0.keycode == KEY_M:
			on_mute_all()
			return
	if state != State.PLAYING:
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.pressed:
			if mb.button_index == MOUSE_BUTTON_LEFT:
				handle_click(get_global_mouse_position())
			elif mb.button_index == MOUSE_BUTTON_RIGHT:
				cancel_selection()
	elif event is InputEventKey:
		var kev := event as InputEventKey
		if kev.pressed and not kev.echo:
			handle_key(kev.keycode)


func cancel_selection() -> void:
	selected_type = ""
	selected_tower = null
	rain_armed = false


func handle_key(code: Key) -> void:
	match code:
		KEY_1:
			select_build(String(tower_order[0]))
		KEY_2:
			select_build(String(tower_order[1]))
		KEY_3:
			select_build(String(tower_order[2]))
		KEY_4:
			select_build(String(tower_order[3]))
		KEY_5:
			select_build(String(tower_order[4]))
		KEY_6:
			select_build(String(tower_order[5]))
		KEY_SPACE:
			on_start_wave()
		KEY_P:
			on_pause()
		KEY_F:
			on_speed()
		KEY_Q:
			on_rain_button()
		KEY_U:
			if selected_tower != null and int(selected_tower["level"]) == 2:
				on_branch(0)
			else:
				on_upgrade()
		KEY_I:
			on_branch(1)
		KEY_X:
			on_sell()
		KEY_ESCAPE:
			if selected_type != "" or selected_tower != null or rain_armed:
				cancel_selection()
			else:
				on_pause()


func handle_click(pos: Vector2) -> void:
	if pos.x < 0.0 or pos.x >= MAP_W or pos.y < 0.0 or pos.y >= ROWS * TILE:
		return
	if paused:
		return
	var c := Vector2i(int(pos.x / TILE), int(pos.y / TILE))
	if rain_armed:
		if rain_cd <= 0.0:
			rains.append({"pos": pos, "t": 1.1, "dur": 1.1})
			rain_cd = RAIN_COOLDOWN
			snd("rain")
		rain_armed = false
		return
	var existing: Variant = get_tower_at(c)
	if selected_type != "":
		if existing != null:
			selected_tower = existing
			selected_type = ""
		elif can_build(c):
			var cost := int(tower_defs[selected_type]["cost"])
			if gold >= cost:
				place_tower(selected_type, c)
			else:
				announce("Yeterli altın yok!")
				snd("fail")
		else:
			announce("Buraya inşa edilemez.")
			snd("fail", -4.0)
	else:
		selected_tower = existing


# ============================================================== SİMÜLASYON
func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	time_total += delta
	if message_t > 0.0:
		message_t -= delta
	if banner_t > 0.0:
		banner_t -= delta
	if leak_flash > 0.0:
		leak_flash = maxf(0.0, leak_flash - delta * 2.0)
	if shake > 0.0:
		position = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * shake
		shake = maxf(0.0, shake - 28.0 * delta)
	else:
		position = Vector2.ZERO
	mouse_pos = get_global_mouse_position()
	hover_cell = Vector2i(floori(mouse_pos.x / TILE), floori(mouse_pos.y / TILE))
	if state == State.PLAYING and not paused:
		for i in range(game_speed):
			if state != State.PLAYING:
				break
			sim_step(delta)
	update_ui()
	queue_redraw()


func sim_step(dt: float) -> void:
	if rain_cd > 0.0:
		rain_cd = maxf(0.0, rain_cd - dt)
	if wave_active:
		wave_time += dt
		while spawn_queue.size() > 0 and spawn_queue[0]["t"] <= wave_time:
			var s: Dictionary = spawn_queue.pop_front()
			spawn_enemy(s["kind"], s["hp_mult"])
	update_towers(dt)
	update_enemies(dt)
	update_projectiles(dt)
	update_rains(dt)
	update_effects(dt)
	update_particles(dt)
	cleanup()
	if state != State.PLAYING:
		return
	if wave_active and spawn_queue.is_empty() and enemies.is_empty():
		end_wave()


func spawn_burst(pos: Vector2, color: Color, count: int, speed: float, life: float, size: float, grav: float = 0.0) -> void:
	for i in range(count):
		if particles.size() >= MAX_PARTICLES:
			return
		var a := randf() * TAU
		var sp := speed * randf_range(0.3, 1.0)
		particles.append({
			"pos": pos, "vel": Vector2.from_angle(a) * sp, "life": life * randf_range(0.6, 1.0),
			"max": life, "col": color, "size": size * randf_range(0.7, 1.3), "grav": grav,
		})


func update_particles(dt: float) -> void:
	for i in range(particles.size() - 1, -1, -1):
		var p: Dictionary = particles[i]
		p["life"] = float(p["life"]) - dt
		if float(p["life"]) <= 0.0:
			particles.remove_at(i)
			continue
		var v: Vector2 = p["vel"]
		v.y += float(p["grav"]) * dt
		p["vel"] = v
		p["pos"] = p["pos"] + v * dt


func damage_enemy(e: Dictionary, amount: float, ignore_armor: bool = false, pierce: bool = false, src: Variant = null) -> void:
	if not e["alive"]:
		return
	var dmg := amount
	if not ignore_armor:
		var arm := float(e["armor"])
		if pierce:
			arm *= 0.5
		dmg = maxf(1.0, amount - arm)
	e["hp"] = float(e["hp"]) - dmg
	e["flash"] = 0.08
	if float(e["hp"]) <= 0.0:
		kill_enemy(e, src)


func kill_enemy(e: Dictionary, src: Variant) -> void:
	e["alive"] = false
	kills += 1
	var gain := maxi(1, int(round(float(e["reward"]) * float(cur_diff["reward"]))))
	gold += gain
	add_score(int(e["reward"]) * 10)
	if src != null:
		src["kills"] = int(src["kills"]) + 1
	var ep: Vector2 = e["pos"]
	var ec: Color = e["color"]
	add_text(ep, "+%d" % gain, Color(1.0, 0.85, 0.3))
	if bool(e["boss"]):
		spawn_burst(ep, ec.lightened(0.3), 60, 220.0, 1.0, 5.0, 60.0)
		spawn_burst(ep, Color(1.0, 0.8, 0.3), 30, 160.0, 1.0, 4.0, 80.0)
		effects.append({"kind": "boom", "pos": ep, "t": 0.0, "dur": 0.8, "r": 120.0, "color": Color(1.0, 0.7, 0.3)})
		shake = maxf(shake, 9.0)
		snd("boom")
		announce("%s yenildi! +%d altın" % [enemy_defs[e["kind"]]["name"], gain])
	else:
		spawn_burst(ep, ec.lightened(0.2), 8, 110.0, 0.5, 3.0, 120.0)
		effects.append({"kind": "puff", "pos": ep, "t": 0.0, "dur": 0.4, "r": float(e["radius"]) * 1.6, "color": ec})
	snd("die", -8.0)
	snd("coin", -10.0)


func add_text(pos: Vector2, text: String, color: Color) -> void:
	effects.append({"kind": "text", "pos": pos, "t": 0.0, "dur": 0.9, "text": text, "color": color})


func splash(pos: Vector2, radius: float, amount: float, pierce: bool, src: Variant, hit_air: bool) -> void:
	for e in enemies:
		if not e["alive"]:
			continue
		if bool(e["flying"]) and not hit_air:
			continue
		if pos.distance_to(e["pos"]) <= radius + float(e["radius"]):
			damage_enemy(e, amount, false, pierce, src)
	effects.append({"kind": "boom", "pos": pos, "t": 0.0, "dur": 0.35, "r": radius, "color": Color(1.0, 0.55, 0.15)})
	spawn_burst(pos, Color(1.0, 0.65, 0.25), 10, 140.0, 0.45, 3.5, 100.0)
	spawn_burst(pos, Color(0.35, 0.30, 0.26), 6, 70.0, 0.7, 5.0, -10.0)
	snd("boom", -4.0)


func can_hit(kind: String, e: Dictionary) -> bool:
	if bool(e["flying"]):
		return bool(tower_defs[kind]["air"])
	return true


func find_target(t: Dictionary) -> Variant:
	var best_e: Variant = null
	var best_prog := -1.0
	var r := tower_range(t)
	var tp: Vector2 = t["pos"]
	var kind: String = t["kind"]
	for e in enemies:
		if not e["alive"]:
			continue
		if not can_hit(kind, e):
			continue
		if tp.distance_to(e["pos"]) <= r + float(e["radius"]):
			if float(e["prog"]) > best_prog:
				best_prog = float(e["prog"])
				best_e = e
	return best_e


func update_towers(dt: float) -> void:
	for e in enemies:
		e["slow"] = 1.0
	# Mehter etkileri
	for t in towers:
		t["buff_rate"] = 0.0
		t["buff_dmg"] = 0.0
	for m in towers:
		if m["kind"] != "mehter":
			continue
		var mp: Vector2 = m["pos"]
		var mr := tower_range(m)
		var rb := mehter_rate_bonus(m)
		var db := mehter_dmg_bonus(m)
		for o in towers:
			if o == m or o["kind"] == "mehter":
				continue
			if mp.distance_to(o["pos"]) <= mr:
				o["buff_rate"] = maxf(float(o["buff_rate"]), rb)
				o["buff_dmg"] = maxf(float(o["buff_dmg"]), db)
		if randf() < 2.5 * dt:
			spawn_burst(mp + Vector2(randf_range(-10.0, 10.0), -22.0), Color(1.0, 0.85, 0.35), 1, 30.0, 0.8, 2.5, -30.0)

	for t in towers:
		var kind: String = t["kind"]
		t["pop"] = minf(1.0, float(t["pop"]) + dt * 3.5)
		t["recoil"] = maxf(0.0, float(t["recoil"]) - dt * 6.0)
		if kind == "mehter":
			continue
		var r := tower_range(t)
		var tp: Vector2 = t["pos"]
		if kind == "yag" or kind == "zincir":
			var active := false
			var dps := tower_damage(t) * (1.0 + float(t["buff_rate"]))
			var sticky := kind == "yag" and bval(t, "slowadd", 0.0) > 0.0
			for e in enemies:
				if not e["alive"] or bool(e["flying"]):
					continue
				if tp.distance_to(e["pos"]) <= r + float(e["radius"]):
					active = true
					if kind == "zincir":
						e["slow"] = minf(float(e["slow"]), tower_slow(t))
					elif sticky:
						e["slow"] = minf(float(e["slow"]), 0.7)
					damage_enemy(e, dps * dt, true, false, t)
			t["active"] = active
			if active and kind == "yag" and randf() < 9.0 * dt:
				spawn_burst(tp + Vector2(randf_range(-9.0, 9.0), -4.0), Color(1.0, 0.6, 0.2), 1, 25.0, 0.6, 3.0, -70.0)
		else:
			t["cd"] = float(t["cd"]) - dt
			var target: Variant = find_target(t)
			if target != null:
				t["angle"] = (target["pos"] - tp).angle()
				if float(t["cd"]) <= 0.0:
					fire(t, target)
					t["cd"] = tower_rate(t)


func fire(t: Dictionary, target: Dictionary) -> void:
	var tp: Vector2 = t["pos"]
	var kind: String = t["kind"]
	var ang := float(t["angle"])
	var dirv := Vector2.from_angle(ang)
	var pierce := bval(t, "pierce", 0.0) > 0.0
	t["recoil"] = 1.0
	if kind == "okcu":
		projectiles.append({
			"kind": "ok", "pos": tp + dirv * 18.0, "target": target, "last": target["pos"],
			"speed": 560.0, "damage": tower_damage(t), "splash": 0.0, "done": false,
			"dir": dirv, "total": 1.0, "pierce": pierce, "owner": t,
		})
		spawn_burst(tp + dirv * 22.0, Color(1.0, 0.9, 0.6), 2, 60.0, 0.12, 2.0)
		snd("shoot", -9.0)
	else:
		var speed := 300.0 if kind == "mancinik" else 420.0
		var tpos: Vector2 = target["pos"]
		var dist := tp.distance_to(tpos)
		var tdir: Vector2 = target["dir"]
		var lead: Vector2 = tpos + tdir * float(target["speed"]) * float(target["slow"]) * (dist / speed)
		projectiles.append({
			"kind": "tas" if kind == "mancinik" else "sahi", "pos": tp, "target": null, "last": lead,
			"speed": speed, "damage": tower_damage(t), "splash": tower_splash(t),
			"done": false, "dir": dirv, "total": maxf(1.0, tp.distance_to(lead)),
			"pierce": pierce, "owner": t,
		})
		if kind == "sahi":
			spawn_burst(tp + dirv * 28.0, Color(1.0, 0.7, 0.25), 10, 140.0, 0.3, 4.0)
			spawn_burst(tp + dirv * 28.0, Color(0.5, 0.5, 0.5), 6, 60.0, 0.6, 5.0, -20.0)
			shake = maxf(shake, 2.5)
			snd("cannon", -4.0)
		else:
			snd("stone", -6.0)


func update_enemies(dt: float) -> void:
	# Büyücüler yakındakileri iyileştirir
	for e in enemies:
		if e["alive"] and e["kind"] == "buyucu":
			for o in enemies:
				if o != e and o["alive"] and float(o["hp"]) < float(o["max_hp"]):
					if e["pos"].distance_to(o["pos"]) < 110.0:
						o["hp"] = minf(float(o["max_hp"]), float(o["hp"]) + 9.0 * dt)

	var leaked_total := 0
	var to_spawn: Array = []
	for e in enemies:
		if not e["alive"]:
			continue
		e["flash"] = maxf(0.0, float(e["flash"]) - dt)
		var route: PackedVector2Array = e["route"]
		var remain: float = float(e["speed"]) * float(e["slow"]) * dt
		while remain > 0.0 and int(e["wp"]) < route.size():
			var target: Vector2 = route[int(e["wp"])]
			var to: Vector2 = target - e["pos"]
			var d := to.length()
			if d <= remain:
				e["pos"] = target
				remain -= d
				e["prog"] = float(e["prog"]) + d
				e["wp"] = int(e["wp"]) + 1
			else:
				var dir := to / d
				e["pos"] = e["pos"] + dir * remain
				e["prog"] = float(e["prog"]) + remain
				e["dir"] = dir
				remain = 0.0
		if int(e["wp"]) >= route.size():
			e["alive"] = false
			leaked_total += int(e["leak"])
			effects.append({"kind": "boom", "pos": e["pos"], "t": 0.0, "dur": 0.5, "r": 50.0, "color": Color(1.0, 0.2, 0.2)})
			continue
		# Kara Hükümdar piyade çağırır
		if e["kind"] == "hukumdar":
			e["ab_t"] = float(e["ab_t"]) - dt
			if float(e["ab_t"]) <= 0.0:
				e["ab_t"] = 6.0
				to_spawn.append(e)
	for e in to_spawn:
		var bp: Vector2 = e["pos"]
		for k in range(3):
			var off := Vector2(randf_range(-26.0, 26.0), randf_range(-26.0, 26.0))
			enemies.append(make_enemy("piyade", float(e["hp_mult"]) * 0.7, bp + off, int(e["wp"]), float(e["prog"])))
		spawn_burst(bp, Color(0.6, 0.2, 0.8), 18, 120.0, 0.6, 3.5)
		effects.append({"kind": "boom", "pos": bp, "t": 0.0, "dur": 0.5, "r": 60.0, "color": Color(0.6, 0.2, 0.8)})
		snd("horn", -10.0, 1.4)
	if leaked_total > 0:
		lives = maxi(0, lives - leaked_total)
		leak_flash = 1.0
		shake = maxf(shake, 6.0 + minf(float(leaked_total), 12.0))
		snd("leak")
		announce("Kale kapısı hasar aldı! -%d" % leaked_total)
		if lives <= 0:
			finish_game(false)


func update_projectiles(dt: float) -> void:
	for p in projectiles:
		if p["done"]:
			continue
		var tgt: Variant = p["target"]
		if tgt != null and tgt["alive"]:
			p["last"] = tgt["pos"]
		var to: Vector2 = p["last"] - p["pos"]
		var d := to.length()
		var step: float = float(p["speed"]) * dt
		if d <= step + 4.0:
			if p["kind"] == "ok":
				if tgt != null and tgt["alive"]:
					damage_enemy(tgt, float(p["damage"]), false, bool(p["pierce"]), p["owner"])
					snd("hit", -10.0)
					spawn_burst(p["last"], Color(0.9, 0.8, 0.6), 3, 60.0, 0.2, 2.0)
			else:
				splash(p["last"], float(p["splash"]), float(p["damage"]), bool(p["pierce"]), p["owner"], false)
			p["done"] = true
		else:
			var dir := to / d
			p["dir"] = dir
			p["pos"] = p["pos"] + dir * step
			if p["kind"] != "ok" and randf() < 0.5:
				var trail_col := Color(0.8, 0.8, 0.8) if p["kind"] == "tas" else Color(1.0, 0.6, 0.2)
				spawn_burst(p["pos"], trail_col, 1, 15.0, 0.3, 3.0)


func update_rains(dt: float) -> void:
	for i in range(rains.size() - 1, -1, -1):
		var r: Dictionary = rains[i]
		r["t"] = float(r["t"]) - dt
		if float(r["t"]) <= 0.0:
			splash(r["pos"], RAIN_RADIUS, RAIN_DAMAGE, false, null, true)
			shake = maxf(shake, 4.0)
			rains.remove_at(i)


func update_effects(dt: float) -> void:
	for i in range(effects.size() - 1, -1, -1):
		var fx: Dictionary = effects[i]
		fx["t"] = float(fx["t"]) + dt
		if float(fx["t"]) >= float(fx["dur"]):
			effects.remove_at(i)


func cleanup() -> void:
	for i in range(enemies.size() - 1, -1, -1):
		if not enemies[i]["alive"]:
			enemies.remove_at(i)
	for i in range(projectiles.size() - 1, -1, -1):
		if projectiles[i]["done"]:
			projectiles.remove_at(i)


# ============================================================== ARAYÜZ GÜNCELLEME
func tower_info_text(t: Dictionary) -> String:
	var d: Dictionary = tower_defs[t["kind"]]
	var lvl := int(t["level"])
	var s := "%s  (Seviye %d/3)\n" % [d["name"], lvl]
	if int(t["branch"]) >= 0:
		var arr: Array = branch_defs[t["kind"]]
		var bd: Dictionary = arr[int(t["branch"])]
		s += "Dal: %s\n" % bd["name"]
	match String(t["kind"]):
		"okcu":
			s += "Hasar %d | Menzil %d | Atış %.2f sn\n" % [int(tower_damage(t)), int(tower_range(t)), tower_rate(t)]
		"mancinik", "sahi":
			s += "Hasar %d | Alan %d | Menzil %d\nAtış %.2f sn\n" % [int(tower_damage(t)), int(tower_splash(t)), int(tower_range(t)), tower_rate(t)]
		"yag":
			s += "Yanık %d/sn (zırh işlemez) | Menzil %d\n" % [int(tower_damage(t)), int(tower_range(t))]
		"zincir":
			s += "Yavaşlatma %%%d | Menzil %d\n" % [int((1.0 - tower_slow(t)) * 100.0), int(tower_range(t))]
		"mehter":
			s += "Atış hızı +%%%d | Hasar +%%%d\nMenzil %d\n" % [int(mehter_rate_bonus(t) * 100.0), int(mehter_dmg_bonus(t) * 100.0), int(tower_range(t))]
	if float(t["buff_rate"]) > 0.0 or float(t["buff_dmg"]) > 0.0:
		s += "Mehter desteği aktif\n"
	s += "Öldürülen: %d\n" % int(t["kills"])
	if lvl == 1:
		s += "Yükseltme: %d altın" % upgrade_cost(t)
	elif lvl == 2:
		s += "Dal seç (%d altın): U veya I" % upgrade_cost(t)
	else:
		s += "Azami seviye"
	return s


func type_info_text(kind: String) -> String:
	var d: Dictionary = tower_defs[kind]
	return "%s\n%s\nMenzil: %d   Bedel: %d altın\nHaritada boş araziye tıkla. Sağ tık ile iptal." % [d["name"], d["desc"], int(d["range"]), int(d["cost"])]


func update_ui() -> void:
	lbl_gold.text = "Altın: %d" % gold
	lbl_lives.text = "Kale Canı: %d" % lives
	lbl_wave.text = ("Dalga: %d" % wave) if endless else ("Dalga: %d / %d" % [wave, max_wave])
	lbl_score.text = "Skor: %d" % score
	lbl_mapinfo.text = "%s | %s%s" % [cur_map["name"], cur_diff["name"], " | Sonsuz" if endless else ""]

	for i in range(tower_order.size()):
		var kind: String = tower_order[i]
		var b: Button = tower_buttons[kind]
		var d: Dictionary = tower_defs[kind]
		var mark: String = "> " if selected_type == kind else ""
		b.text = "%s%d %s\n%d altın" % [mark, i + 1, d["short"], int(d["cost"])]
		b.modulate = Color(1, 1, 1, 1) if gold >= int(d["cost"]) else Color(1.0, 0.65, 0.65, 1.0)

	var show_up := false
	var show_branch := false
	var show_sell := false
	if selected_tower != null:
		var t: Dictionary = selected_tower
		lbl_info.text = tower_info_text(t)
		show_sell = true
		var lvl := int(t["level"])
		var cost := upgrade_cost(t)
		btn_sell.text = "Sat (+%d)" % int(float(t["invested"]) * SELL_RATIO)
		if lvl == 1:
			show_up = true
			btn_upgrade.text = "Yükselt (%d)" % cost
			btn_upgrade.disabled = gold < cost
			btn_sell.position = Vector2(130, 408)
			btn_sell.size = Vector2(118, 46)
		elif lvl == 2:
			show_branch = true
			var arr: Array = branch_defs[t["kind"]]
			var da: Dictionary = arr[0]
			var db: Dictionary = arr[1]
			btn_branch_a.text = "A: %s\n(%d)" % [da["name"], cost]
			btn_branch_b.text = "B: %s\n(%d)" % [db["name"], cost]
			btn_branch_a.tooltip_text = String(da["desc"])
			btn_branch_b.tooltip_text = String(db["desc"])
			btn_branch_a.disabled = gold < cost
			btn_branch_b.disabled = gold < cost
			btn_sell.position = Vector2(8, 458)
			btn_sell.size = Vector2(240, 26)
		else:
			show_up = true
			btn_upgrade.text = "Azami"
			btn_upgrade.disabled = true
			btn_sell.position = Vector2(130, 408)
			btn_sell.size = Vector2(118, 46)
	elif selected_type != "":
		lbl_info.text = type_info_text(selected_type)
	else:
		lbl_info.text = "Bir kule seç ya da haritadaki bir kuleye tıkla."
	btn_upgrade.visible = show_up
	btn_branch_a.visible = show_branch
	btn_branch_b.visible = show_branch
	btn_sell.visible = show_sell

	if rain_cd > 0.0:
		btn_rain.text = "Ok Yağmuru (%d sn)" % int(ceil(rain_cd))
		btn_rain.disabled = true
	else:
		btn_rain.disabled = false
		btn_rain.text = "Hedef seç... (Q)" if rain_armed else "Ok Yağmuru (Q)"

	if wave_active:
		btn_start.text = "Dalga sürüyor..."
		btn_start.disabled = true
	elif not endless and wave >= max_wave:
		btn_start.text = "Tüm dalgalar bitti"
		btn_start.disabled = true
	else:
		btn_start.text = "Dalga %d'i Başlat" % (wave + 1)
		btn_start.disabled = false
	btn_speed.text = "Hız: %dx" % game_speed
	btn_pause.text = "Devam" if paused else "Duraklat"
	btn_sfx.text = "Ses: Açık" if sfx_on else "Ses: Kapalı"
	btn_music.text = "Müzik: Açık" if music_on else "Müzik: Kapalı"


# ============================================================== ÇİZİM
func put_text(pos: Vector2, text: String, size: int, color: Color, center: bool = false) -> void:
	var shadow := Color(0, 0, 0, color.a * 0.8)
	if center:
		draw_string(font, pos + Vector2(-499, 1), text, HORIZONTAL_ALIGNMENT_CENTER, 1000, size, shadow)
		draw_string(font, pos + Vector2(-500, 0), text, HORIZONTAL_ALIGNMENT_CENTER, 1000, size, color)
	else:
		draw_string(font, pos + Vector2(1, 1), text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, shadow)
		draw_string(font, pos, text, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)


func _draw() -> void:
	draw_map()
	draw_towers()
	draw_enemies()
	draw_projectiles()
	draw_rains()
	draw_effects()
	draw_particles()
	draw_ambient()
	draw_hover()
	draw_hud_text()


func draw_map() -> void:
	var grass: Color = cur_map["grass"]
	var grass2: Color = cur_map["grass2"]
	var path_col: Color = cur_map["path"]
	var edge_col: Color = cur_map["edge"]
	draw_rect(Rect2(0, 0, MAP_W, SCREEN_H), grass)
	for cy in range(ROWS):
		for cx in range(COLS):
			if (cx + cy) % 2 == 0:
				draw_rect(Rect2(cx * TILE, cy * TILE, TILE, TILE), grass2)

	for key in water_cells.keys():
		var wc: Vector2i = key
		var wo := Vector2(wc.x * TILE, wc.y * TILE)
		draw_rect(Rect2(wo, Vector2(TILE, TILE)), Color(0.16, 0.34, 0.58))
		var shim := 0.5 + 0.5 * sin(time_total * 1.6 + float(wc.x) * 0.9 + float(wc.y) * 1.3)
		draw_line(wo + Vector2(10, 22 + shim * 6.0), wo + Vector2(36, 22 + shim * 6.0), Color(0.55, 0.78, 0.95, 0.35), 2.0)
		draw_line(wo + Vector2(26, 44 - shim * 5.0), wo + Vector2(54, 44 - shim * 5.0), Color(0.55, 0.78, 0.95, 0.30), 2.0)

	for key in path_cells.keys():
		var c: Vector2i = key
		var o := Vector2(c.x * TILE, c.y * TILE)
		draw_rect(Rect2(o, Vector2(TILE, TILE)), path_col)
		var h := absi(c.x * 31 + c.y * 17) % 4
		draw_circle(o + Vector2(14 + h * 10, 20 + h * 8), 3.0, path_col.darkened(0.15))
		draw_circle(o + Vector2(48 - h * 7, 44 - h * 5), 2.5, path_col.lightened(0.10))
		for e in path_edges:
			if not path_cells.has(c + e[0]):
				draw_line(o + e[1] * TILE, o + e[2] * TILE, edge_col, 4.0)

	for dd in decor:
		var dc: Vector2i = dd["cell"]
		var off: Vector2 = dd["off"]
		var p := cell_center(dc) + off
		var sz: float = dd["size"]
		if dd["kind"] == "tree":
			draw_circle(p + Vector2(0, 14), 14.0 * sz, Color(0, 0, 0, 0.18))
			draw_rect(Rect2(p.x - 3, p.y, 6, 16), Color(0.33, 0.22, 0.12))
			draw_circle(p + Vector2(0, -6), 17.0 * sz, Color(0.10, 0.30, 0.14))
			draw_circle(p + Vector2(-6, -12), 11.0 * sz, Color(0.14, 0.38, 0.18))
			draw_circle(p + Vector2(7, -10), 9.0 * sz, Color(0.12, 0.34, 0.16))
		else:
			draw_circle(p + Vector2(0, 8), 14.0 * sz, Color(0, 0, 0, 0.18))
			draw_circle(p, 13.0 * sz, Color(0.45, 0.45, 0.43))
			draw_circle(p + Vector2(-4, -4), 8.0 * sz, Color(0.58, 0.58, 0.55))

	var tint: Color = cur_map["tint"]
	if tint.a > 0.0:
		draw_rect(Rect2(0, 0, MAP_W, SCREEN_H), tint)

	draw_castle()
	draw_portal()


func draw_castle() -> void:
	var gx := gate_cell.x * TILE
	var stone := Color(0.58, 0.55, 0.50)
	var dark := Color(0.34, 0.32, 0.29)
	draw_rect(Rect2(gx - TILE, 10, 3 * TILE, TILE - 16), stone)
	draw_rect(Rect2(gx - TILE, 10, 3 * TILE, TILE - 16), dark, false, 2.0)
	for side in [-1, 1]:
		var r := Rect2(gx + side * TILE + 4, 0, TILE - 8, TILE - 4)
		draw_rect(r, stone)
		draw_rect(r, dark, false, 2.0)
		for i in range(3):
			draw_rect(Rect2(r.position.x + 2 + i * 18, 0, 11, 9), dark)
		draw_rect(Rect2(r.position.x + 22, 20, 8, 14), Color(0.12, 0.10, 0.09))
	var wood := Color(0.27, 0.17, 0.09)
	draw_circle(Vector2(gx + 32, 28), 20.0, wood)
	draw_rect(Rect2(gx + 12, 28, 40, 30), wood)
	draw_line(Vector2(gx + 32, 8), Vector2(gx + 32, 58), Color(0.15, 0.10, 0.06), 2.0)
	draw_line(Vector2(gx + 12, 38), Vector2(gx + 52, 38), Color(0.55, 0.55, 0.58), 2.0)
	for side in [-1, 1]:
		var wave_off := sin(time_total * 3.0 + float(side)) * 1.5
		var fp := Vector2(gx + side * TILE + 18, 4)
		draw_rect(Rect2(fp.x, fp.y + wave_off * 0.3, 28, 15), Color(0.80, 0.10, 0.12))
		draw_circle(fp + Vector2(11, 7.5 + wave_off * 0.3), 4.6, Color(0.96, 0.96, 0.96))
		draw_circle(fp + Vector2(12.6, 7.5 + wave_off * 0.3), 3.9, Color(0.80, 0.10, 0.12))
		draw_circle(fp + Vector2(20, 7.5 + wave_off * 0.3), 1.6, Color(0.96, 0.96, 0.96))


func draw_portal() -> void:
	var start_cell := Vector2i(0, int((waypoints[0].y - TILE * 0.5) / TILE))
	var pc := cell_center(start_cell) + Vector2(-8, 0)
	var pulse := 0.5 + 0.5 * sin(time_total * 3.0)
	draw_circle(pc, 32.0 + pulse * 4.0, Color(0.35, 0.10, 0.45, 0.35))
	draw_circle(pc, 23.0, Color(0.18, 0.04, 0.28, 0.75))
	draw_arc(pc, 27.0, time_total * 2.0, time_total * 2.0 + 4.0, 24, Color(0.80, 0.40, 1.0, 0.85), 3.0)
	draw_arc(pc, 17.0, -time_total * 3.0, -time_total * 3.0 + 3.0, 20, Color(0.95, 0.65, 1.0, 0.7), 2.0)


func draw_range(center: Vector2, r: float, color: Color) -> void:
	draw_circle(center, r, Color(color.r, color.g, color.b, 0.10))
	draw_arc(center, r, 0.0, TAU, 72, Color(color.r, color.g, color.b, 0.75), 2.0)


func draw_towers() -> void:
	for t in towers:
		var p: Vector2 = t["pos"]
		var k := float(t["pop"])
		var s := 0.3 + 0.7 * k + 0.15 * sin(k * PI)
		draw_set_transform(p, 0.0, Vector2(s, s))
		draw_tower_body(t)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	if selected_tower != null:
		var st: Dictionary = selected_tower
		var sp: Vector2 = st["pos"]
		draw_range(sp, tower_range(st), Color(1.0, 1.0, 1.0))
		draw_rect(Rect2(sp - Vector2(28, 28), Vector2(56, 56)), Color(1.0, 0.9, 0.4), false, 3.0)


func draw_tower_body(t: Dictionary) -> void:
	var p := Vector2.ZERO
	var kind: String = t["kind"]
	var ang: float = t["angle"]
	var dirv := Vector2.from_angle(ang)
	var col: Color = tower_defs[kind]["color"]
	var lvl := int(t["level"])
	var rc := float(t["recoil"]) * 5.0
	draw_circle(p + Vector2(0, 4), 27.0, Color(0, 0, 0, 0.25))
	draw_rect(Rect2(p - Vector2(25, 25), Vector2(50, 50)), Color(0.38, 0.36, 0.33))
	draw_rect(Rect2(p - Vector2(25, 25), Vector2(50, 50)), Color(0.22, 0.20, 0.18), false, 2.0)
	match kind:
		"okcu":
			draw_circle(p, 19.0, col)
			draw_arc(p, 19.0, 0.0, TAU, 24, Color(0.35, 0.24, 0.12), 3.0)
			for i in range(4):
				var a := float(i) * PI / 2.0 + PI / 4.0
				draw_rect(Rect2(p + Vector2.from_angle(a) * 17.0 - Vector2(3, 3), Vector2(6, 6)), Color(0.35, 0.24, 0.12))
			draw_line(p - dirv * rc, p + dirv * (22.0 - rc), Color(0.25, 0.16, 0.08), 4.0)
			draw_circle(p + dirv * (22.0 - rc), 3.0, Color(0.9, 0.9, 0.9))
		"mancinik":
			draw_rect(Rect2(p - Vector2(20, 12), Vector2(40, 24)), col)
			draw_rect(Rect2(p - Vector2(20, 12), Vector2(40, 24)), Color(0.28, 0.18, 0.10), false, 2.0)
			draw_line(p - dirv * (16.0 - rc), p + dirv * (22.0 - rc), Color(0.30, 0.20, 0.10), 5.0)
			draw_circle(p + dirv * (22.0 - rc), 6.0, Color(0.55, 0.55, 0.55))
			draw_circle(p, 6.0, Color(0.20, 0.14, 0.08))
		"yag":
			draw_circle(p, 19.0, Color(0.14, 0.12, 0.12))
			draw_arc(p, 19.0, 0.0, TAU, 24, Color(0.45, 0.45, 0.48), 3.0)
			var glow := 0.55 + 0.45 * sin(time_total * 8.0)
			var heat: float = 1.0 if t["active"] else 0.4
			draw_circle(p, 12.0, Color(col.r, col.g, col.b, 0.55 * heat + 0.2 * glow * heat))
			if t["active"]:
				for i in range(3):
					var bp := p + Vector2(-7 + i * 7, -3 - 5.0 * sin(time_total * 6.0 + float(i) * 2.0))
					draw_circle(bp, 2.5, Color(1.0, 0.8, 0.3, 0.9))
		"zincir":
			draw_circle(p, 19.0, Color(0.30, 0.32, 0.36))
			draw_arc(p, 14.0, 0.0, TAU, 16, col, 3.0)
			for i in range(8):
				var a := float(i) * TAU / 8.0
				var inner := p + Vector2.from_angle(a) * 14.0
				var outer := p + Vector2.from_angle(a) * 22.0
				draw_line(inner, outer, Color(0.78, 0.80, 0.85), 3.0)
			if t["active"]:
				var pr := 0.5 + 0.5 * sin(time_total * 6.0)
				draw_arc(p, tower_range(t) * (0.9 + 0.1 * pr), 0.0, TAU, 48, Color(0.7, 0.8, 1.0, 0.25), 2.0)
		"mehter":
			draw_circle(p, 20.0, Color(0.55, 0.10, 0.12))
			draw_arc(p, 20.0, 0.0, TAU, 24, Color(0.95, 0.80, 0.30), 3.0)
			draw_circle(p + Vector2(0, 4), 9.0, Color(0.85, 0.80, 0.70))
			draw_arc(p + Vector2(0, 4), 9.0, 0.0, TAU, 16, Color(0.40, 0.25, 0.10), 2.0)
			var beat := 0.5 + 0.5 * sin(time_total * 7.0)
			draw_line(p + Vector2(0, -16), p + Vector2(0, -34), Color(0.30, 0.20, 0.10), 3.0)
			draw_circle(p + Vector2(0, -34), 5.0, Color(0.95, 0.80, 0.30))
			draw_line(p + Vector2(-3, -30), p + Vector2(-8, -20 + beat * 3.0), Color(0.15, 0.10, 0.08), 2.0)
			draw_line(p + Vector2(3, -30), p + Vector2(8, -20 + beat * 3.0), Color(0.15, 0.10, 0.08), 2.0)
			var pulse := 0.5 + 0.5 * sin(time_total * 3.5)
			draw_arc(p, tower_range(t) * (0.85 + 0.15 * pulse), 0.0, TAU, 56, Color(1.0, 0.8, 0.3, 0.14), 2.0)
		"sahi":
			draw_circle(p + Vector2(-12, 14), 9.0, Color(0.22, 0.16, 0.10))
			draw_circle(p + Vector2(12, 14), 9.0, Color(0.22, 0.16, 0.10))
			draw_line(p - dirv * (12.0 + rc), p + dirv * (24.0 - rc), Color(0.22, 0.17, 0.10), 13.0)
			draw_line(p - dirv * (12.0 + rc), p + dirv * (24.0 - rc), col, 9.0)
			draw_circle(p - dirv * (12.0 + rc), 8.0, Color(0.28, 0.22, 0.14))
			draw_circle(p + dirv * (24.0 - rc), 6.0, Color(0.15, 0.12, 0.09))
			if float(t["recoil"]) > 0.6:
				draw_circle(p + dirv * 30.0, 9.0 * float(t["recoil"]), Color(1.0, 0.7, 0.25, 0.8))
	for i in range(lvl):
		draw_circle(p + Vector2(-8 + i * 8, 21), 3.0, Color(1.0, 0.85, 0.30))
		draw_arc(p + Vector2(-8 + i * 8, 21), 3.0, 0.0, TAU, 8, Color(0.3, 0.2, 0.05), 1.0)
	if int(t["branch"]) >= 0:
		var gem := Color(0.35, 0.65, 1.0) if int(t["branch"]) == 0 else Color(1.0, 0.40, 0.35)
		draw_circle(p + Vector2(19, -19), 5.0, gem)
		draw_arc(p + Vector2(19, -19), 5.0, 0.0, TAU, 10, Color(1, 1, 1, 0.8), 1.5)
	if float(t["buff_rate"]) > 0.0 or float(t["buff_dmg"]) > 0.0:
		draw_arc(p, 27.0, time_total * 2.0, time_total * 2.0 + 1.6, 12, Color(1.0, 0.8, 0.3, 0.85), 3.0)


func draw_enemies() -> void:
	for e in enemies:
		if not e["alive"]:
			continue
		var p: Vector2 = e["pos"]
		var r: float = e["radius"]
		var kind: String = e["kind"]
		var col: Color = e["color"]
		if float(e["flash"]) > 0.0:
			col = col.lerp(Color(1, 1, 1), 0.7)
		var bob := sin(time_total * 9.0 + float(e["seed"])) * 1.5
		var c := p + Vector2(0, bob)
		if bool(e["flying"]):
			draw_circle(p + Vector2(0, 28), r * 0.8, Color(0, 0, 0, 0.22))
		else:
			draw_circle(p + Vector2(0, r * 0.75), r * 0.9, Color(0, 0, 0, 0.28))
		match kind:
			"piyade":
				draw_circle(c, r, col)
				draw_arc(c + Vector2(r * 0.5, 2), r * 0.7, -1.2, 1.2, 8, Color(0.6, 0.55, 0.5), 3.0)
			"akinci":
				draw_circle(c + Vector2(-r * 0.3, r * 0.2), r * 1.05, col)
				draw_circle(c + Vector2(r * 0.55, -r * 0.1), r * 0.6, col.lightened(0.15))
				draw_circle(c + Vector2(0, -r * 0.8), r * 0.55, col.lightened(0.25))
			"muhafiz":
				draw_circle(c, r, col)
				draw_arc(c, r, 0.0, TAU, 20, Color(0.75, 0.77, 0.82), 4.0)
				draw_colored_polygon(PackedVector2Array([c + Vector2(-4, -r + 2), c + Vector2(4, -r + 2), c + Vector2(0, -r - 8)]), Color(0.75, 0.77, 0.82))
			"buyucu":
				var aura := 0.5 + 0.5 * sin(time_total * 4.0 + float(e["seed"]))
				draw_arc(c, 110.0, 0.0, TAU, 48, Color(0.6, 0.9, 0.5, 0.06 + 0.05 * aura), 2.0)
				draw_circle(c, r, col)
				draw_colored_polygon(PackedVector2Array([c + Vector2(-r * 0.8, -r * 0.5), c + Vector2(r * 0.8, -r * 0.5), c + Vector2(0, -r * 2.1)]), col.darkened(0.3))
				draw_circle(c + Vector2(r * 0.9, 0), 4.0, Color(0.6, 1.0, 0.5, 0.9))
			"kuzgun":
				var flap := sin(time_total * 14.0 + float(e["seed"]))
				var wing := col.lightened(0.18)
				draw_line(c, c + Vector2(-r * 2.2, -r * 0.9 * flap), wing, 5.0)
				draw_line(c + Vector2(-r * 2.2, -r * 0.9 * flap), c + Vector2(-r * 1.2, r * 0.6), wing, 3.0)
				draw_line(c, c + Vector2(r * 2.2, -r * 0.9 * flap), wing, 5.0)
				draw_line(c + Vector2(r * 2.2, -r * 0.9 * flap), c + Vector2(r * 1.2, r * 0.6), wing, 3.0)
				draw_circle(c, r * 0.8, col)
				draw_circle(c + Vector2(0, r * 0.7), r * 0.28, Color(0.9, 0.7, 0.2))
			"dev":
				draw_circle(c, r, col)
				draw_circle(c + Vector2(-r * 0.5, -r * 0.5), r * 0.45, col.lightened(0.1))
				draw_circle(c + Vector2(r * 0.55, r * 0.3), r * 0.4, col.darkened(0.15))
				draw_circle(c + Vector2(-r * 0.2, r * 0.6), r * 0.3, col.lightened(0.05))
			"devi":
				var pulse := 0.5 + 0.5 * sin(time_total * 3.0)
				draw_arc(c, r + 6.0 + 3.0 * pulse, 0.0, TAU, 32, Color(1.0, 0.35, 0.2, 0.45), 3.0)
				draw_circle(c, r, col)
				draw_circle(c + Vector2(-r * 0.5, -r * 0.4), r * 0.42, col.lightened(0.08))
				draw_circle(c + Vector2(r * 0.5, r * 0.35), r * 0.36, col.darkened(0.15))
				draw_rect(Rect2(c.x - r * 0.55, c.y - r - 16, r * 1.1, 20), Color(0.33, 0.22, 0.12))
				for i in range(3):
					draw_rect(Rect2(c.x - r * 0.55 + i * r * 0.42, c.y - r - 22, r * 0.26, 8), Color(0.33, 0.22, 0.12))
				draw_arc(c, r, 0.0, TAU, 28, Color(0.55, 0.55, 0.58), 4.0)
			"hukumdar":
				draw_arc(c, r + 10.0, time_total * 2.0, time_total * 2.0 + 2.2, 16, Color(0.75, 0.35, 1.0, 0.85), 4.0)
				draw_arc(c, r + 10.0, time_total * 2.0 + PI, time_total * 2.0 + PI + 2.2, 16, Color(0.75, 0.35, 1.0, 0.85), 4.0)
				draw_circle(c, r, col)
				draw_circle(c + Vector2(0, r * 0.2), r * 0.7, col.lightened(0.12))
				for i in range(5):
					var sx := -r * 0.6 + float(i) * r * 0.3
					var sh := r * 0.5 if i % 2 == 0 else r * 0.3
					draw_line(c + Vector2(sx, -r * 0.8), c + Vector2(sx, -r * 0.8 - sh), Color(0.95, 0.80, 0.30), 3.0)
		var er := maxf(2.0, r * 0.14)
		draw_circle(c + Vector2(-r * 0.32, -r * 0.1), er, Color(1.0, 0.15, 0.1))
		draw_circle(c + Vector2(r * 0.32, -r * 0.1), er, Color(1.0, 0.15, 0.1))
		if float(e["slow"]) < 1.0:
			draw_arc(c, r + 4.0, 0.0, TAU, 20, Color(0.55, 0.80, 1.0, 0.9), 2.0)
		if float(e["hp"]) < float(e["max_hp"]):
			var w := r * 2.0 + 6.0
			var frac := clampf(float(e["hp"]) / float(e["max_hp"]), 0.0, 1.0)
			var bp := Vector2(c.x - w * 0.5, c.y - r - 12.0)
			draw_rect(Rect2(bp, Vector2(w, 5)), Color(0, 0, 0, 0.7))
			draw_rect(Rect2(bp, Vector2(w * frac, 5)), Color(0.35, 0.85, 0.35).lerp(Color(0.9, 0.2, 0.2), 1.0 - frac))


func draw_projectiles() -> void:
	for p in projectiles:
		var pos: Vector2 = p["pos"]
		if p["kind"] == "ok":
			var dv: Vector2 = p["dir"]
			draw_line(pos - dv * 14.0, pos, Color(0.35, 0.22, 0.10), 3.0)
			draw_circle(pos, 2.5, Color(0.92, 0.92, 0.92))
		else:
			var last: Vector2 = p["last"]
			var prog := 1.0 - clampf(pos.distance_to(last) / float(p["total"]), 0.0, 1.0)
			var height := sin(prog * PI) * 55.0
			draw_circle(pos + Vector2(0, 4), 5.0, Color(0, 0, 0, 0.3))
			if p["kind"] == "tas":
				draw_circle(pos - Vector2(0, height), 7.0, Color(0.45, 0.45, 0.45))
				draw_circle(pos - Vector2(2, height + 2), 3.0, Color(0.62, 0.62, 0.62))
			else:
				draw_circle(pos - Vector2(0, height), 11.0, Color(1.0, 0.55, 0.15, 0.35))
				draw_circle(pos - Vector2(0, height), 8.0, Color(0.12, 0.10, 0.09))
				draw_circle(pos - Vector2(2, height + 2), 3.0, Color(0.40, 0.38, 0.35))


func draw_rains() -> void:
	for r in rains:
		var pos: Vector2 = r["pos"]
		var k := 1.0 - clampf(float(r["t"]) / float(r["dur"]), 0.0, 1.0)
		draw_arc(pos, RAIN_RADIUS, 0.0, TAU, 64, Color(1.0, 0.4, 0.2, 0.7), 3.0)
		draw_circle(pos, RAIN_RADIUS, Color(1.0, 0.3, 0.1, 0.08 + 0.12 * k))
		for i in range(14):
			var a := float(i) * 2.399
			var rr := RAIN_RADIUS * sqrt(float(i) / 14.0) * 0.95
			var gp := pos + Vector2.from_angle(a) * rr
			var fall := fposmod(k * 2.0 + float(i) * 0.37, 1.0)
			var tip := gp - Vector2(0, 220.0 * (1.0 - fall))
			draw_line(tip, tip - Vector2(-4, 18), Color(0.35, 0.22, 0.10, 0.9), 2.0)
			draw_circle(tip, 2.0, Color(0.95, 0.95, 0.95))


func draw_effects() -> void:
	for fx in effects:
		var k := clampf(float(fx["t"]) / float(fx["dur"]), 0.0, 1.0)
		var pos: Vector2 = fx["pos"]
		match String(fx["kind"]):
			"boom":
				var c: Color = fx["color"]
				var rad := float(fx["r"]) * (0.35 + 0.65 * k)
				draw_circle(pos, rad, Color(c.r, c.g, c.b, 0.32 * (1.0 - k)))
				draw_arc(pos, rad, 0.0, TAU, 32, Color(c.r, c.g, c.b, 0.85 * (1.0 - k)), 3.0)
			"puff":
				var c2: Color = fx["color"]
				draw_circle(pos, float(fx["r"]) * (0.5 + k), Color(c2.r, c2.g, c2.b, 0.45 * (1.0 - k)))
			"text":
				var c3: Color = fx["color"]
				c3.a = 1.0 - k
				put_text(pos + Vector2(0, -18.0 - 22.0 * k), String(fx["text"]), 16, c3, true)


func draw_particles() -> void:
	for p in particles:
		var k := clampf(float(p["life"]) / float(p["max"]), 0.0, 1.0)
		var c: Color = p["col"]
		draw_circle(p["pos"], float(p["size"]) * (0.4 + 0.6 * k), Color(c.r, c.g, c.b, c.a * k))


func draw_ambient() -> void:
	var kind := String(cur_map["ambient"])
	if kind == "leaves":
		for i in range(14):
			var x := fposmod(float(i) * 131.0 + time_total * (18.0 + float(i % 4) * 6.0), MAP_W + 40.0) - 20.0
			var y := fposmod(float(i) * 97.0 + time_total * (10.0 + float(i % 3) * 5.0) + sin(time_total + float(i)) * 20.0, SCREEN_H)
			draw_circle(Vector2(x, y), 3.0, Color(0.55, 0.72, 0.30, 0.55))
			draw_circle(Vector2(x + 2, y + 1), 2.0, Color(0.45, 0.62, 0.25, 0.55))
	elif kind == "mist":
		for i in range(6):
			var x := fposmod(float(i) * 260.0 + time_total * (8.0 + float(i) * 2.0), MAP_W + 400.0) - 200.0
			draw_circle(Vector2(x, 90.0 + float(i) * 110.0), 130.0, Color(0.85, 0.90, 1.0, 0.035))
	elif kind == "fireflies":
		for i in range(22):
			var bx := fposmod(float(i) * 173.0, MAP_W)
			var by := fposmod(float(i) * 91.0, SCREEN_H)
			var fp := Vector2(bx + sin(time_total * 0.7 + float(i)) * 30.0, by + cos(time_total * 0.9 + float(i) * 1.3) * 20.0)
			var a := 0.35 + 0.65 * (0.5 + 0.5 * sin(time_total * 2.0 + float(i)))
			draw_circle(fp, 5.0, Color(0.85, 1.0, 0.4, 0.12 * a))
			draw_circle(fp, 2.0, Color(0.95, 1.0, 0.55, 0.9 * a))
	if leak_flash > 0.0:
		draw_rect(Rect2(0, 0, MAP_W, SCREEN_H), Color(1.0, 0.1, 0.1, 0.22 * leak_flash))


func draw_hover() -> void:
	if state != State.PLAYING or paused:
		return
	if mouse_pos.x < 0.0 or mouse_pos.x >= MAP_W or mouse_pos.y < 0.0 or mouse_pos.y >= ROWS * TILE:
		return
	if rain_armed:
		draw_arc(mouse_pos, RAIN_RADIUS, 0.0, TAU, 64, Color(1.0, 0.4, 0.2, 0.9), 3.0)
		draw_circle(mouse_pos, RAIN_RADIUS, Color(1.0, 0.3, 0.1, 0.12))
		return
	if selected_type != "":
		var ok := can_build(hover_cell) and gold >= int(tower_defs[selected_type]["cost"])
		var col := Color(0.3, 1.0, 0.4) if ok else Color(1.0, 0.3, 0.3)
		draw_rect(Rect2(hover_cell.x * TILE, hover_cell.y * TILE, TILE, TILE), Color(col.r, col.g, col.b, 0.28))
		if can_build(hover_cell):
			draw_range(cell_center(hover_cell), float(tower_defs[selected_type]["range"]), col)
		return
	var ht: Variant = get_tower_at(hover_cell)
	if ht != null and ht != selected_tower:
		draw_range(ht["pos"], tower_range(ht), Color(0.9, 0.9, 0.9))
	# Düşman bilgisi
	for e in enemies:
		if not e["alive"]:
			continue
		var ep: Vector2 = e["pos"]
		if mouse_pos.distance_to(ep) <= float(e["radius"]) + 8.0:
			var info := "%s\nCan %d / %d   Zırh %d" % [enemy_defs[e["kind"]]["name"], int(float(e["hp"])), int(float(e["max_hp"])), int(float(e["armor"]))]
			var bx := minf(ep.x + 20.0, MAP_W - 190.0)
			var by := maxf(ep.y - 50.0, 4.0)
			draw_rect(Rect2(bx, by, 180, 40), Color(0, 0, 0, 0.75))
			draw_rect(Rect2(bx, by, 180, 40), Color(0.7, 0.55, 0.3), false, 2.0)
			var lines := info.split("\n")
			put_text(Vector2(bx + 8, by + 16), lines[0], 14, Color(1.0, 0.9, 0.6))
			put_text(Vector2(bx + 8, by + 33), lines[1], 12, Color(0.9, 0.9, 0.9))
			break


func draw_hud_text() -> void:
	# Boss can çubuğu
	for e in enemies:
		if e["alive"] and bool(e["boss"]):
			var frac := clampf(float(e["hp"]) / float(e["max_hp"]), 0.0, 1.0)
			draw_rect(Rect2(MAP_W / 2.0 - 202, 8, 404, 24), Color(0, 0, 0, 0.7))
			draw_rect(Rect2(MAP_W / 2.0 - 200, 10, 400.0 * frac, 20), Color(0.75, 0.15, 0.25))
			put_text(Vector2(MAP_W / 2.0, 26), String(enemy_defs[e["kind"]]["name"]), 15, Color(1, 1, 1), true)
			break
	if message_t > 0.0:
		var a := clampf(message_t, 0.0, 1.0)
		put_text(Vector2(MAP_W / 2.0, 60), message, 20, Color(1.0, 0.92, 0.6, a), true)
	if state == State.PLAYING and not wave_active and (endless or wave < max_wave):
		draw_rect(Rect2(0, SCREEN_H - 30, MAP_W, 30), Color(0, 0, 0, 0.55))
		put_text(Vector2(MAP_W / 2.0, SCREEN_H - 10), "Sıradaki dalga: " + preview_text(wave + 1), 14, Color(0.95, 0.90, 0.75), true)
	if state == State.PLAYING and banner_t > 0.0:
		var k := 1.0 - banner_t / BANNER_DUR
		var al := minf(1.0, minf(k * 6.0, (1.0 - k) * 3.0))
		var slide := (1.0 - minf(k * 5.0, 1.0)) * 140.0
		var bar_col := Color(0.35, 0.02, 0.04, 0.6 * al) if banner_boss else Color(0, 0, 0, 0.5 * al)
		draw_rect(Rect2(0, 150, MAP_W, 120), bar_col)
		var title_col := Color(1.0, 0.45, 0.35, al) if banner_boss else Color(1.0, 0.85, 0.35, al)
		put_text(Vector2(MAP_W / 2.0 - slide, 210), banner_text, 54, title_col, true)
		put_text(Vector2(MAP_W / 2.0 + slide, 250), banner_sub, 24, Color(0.95, 0.90, 0.78, al), true)
	if state == State.PLAYING and paused:
		draw_rect(Rect2(0, 0, MAP_W, SCREEN_H), Color(0, 0, 0, 0.45))
		put_text(Vector2(MAP_W / 2.0, SCREEN_H / 2.0), "DURAKLATILDI", 48, Color(1.0, 0.9, 0.5), true)
