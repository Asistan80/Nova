# Sınır Boyu (v2)

Erken Osmanlı uç beyliği temalı, kurgusal karanlık orduya karşı kale savunma oyunu.
Godot 4.2+ (GDScript). Grafikler ve sesler kodla üretilir; dış dosya yoktur.

## Çalıştırma
1. Godot 4.2 veya üstünü aç, "Import" ile `project.godot` dosyasını seç.
2. F5 ile başlat. Müzik açılışta bir iki saniye içinde hazırlanır.

## Yenilikler (v2)
- 4 zorluk: Çırak, Yiğit, Gazi, Efsane + Sonsuz mod
- 3 harita: Söğüt Yaylası, Domaniç Geçidi, İznik Ovası (göl, alacakaranlık)
- 6 kule: Okçu, Mancınık, Kızgın Yağ, Zincirli Tuzak, Mehter Takımı (güçlendirir), Şahi Topu
- Seviye 2 -> 3 geçişinde iki daldan birini seç (U / I)
- Uçan Gölge Kuzgunlar, boss'lar (Kuşatma Devi, Kara Hükümdar), her 5. dalga
- Kodla üretilen ses efektleri ve Hicaz tınılı mehter müziği (M ile kapat)
- Efektler: parçacıklar, ekran sarsıntısı, dalga bannerı, kule animasyonları, ortam efektleri
- Komutan adı ve skor tablosu, düzeltilmiş sayfalı Nasıl Oynanır ekranı

## Kontroller
1-6 kule | Boşluk dalga | F hız | P duraklat | Q ok yağmuru | U/I yükselt / dal | X sat | M sessiz | Esc ya da sağ tık iptal

## Dosyalar
- `scripts/main.gd`: oyun mantığı, çizim, arayüz
- `scripts/data.gd`: haritalar, zorluklar, kuleler, düşmanlar, dallar (dengeyi buradan ayarla)
- `scripts/sfx.gd`: ses ve müzik üretimi
- Kayıt: `user://sinir_boyu_kayit.json`
