// Hikâye grafiği testi: bağlantılar, ulaşılabilirlik, tüm sonlar, sıkışma yok.
const { STORY } = require("../story.js");
const sc = STORY.scenes; let bad = 0; const err = m => { console.log("FAIL", m); bad++; };
for (const [id, s] of Object.entries(sc)) {
  if (!s.art) err(id + " art yok"); if (!s.text) err(id + " metin yok");
  if (!s.ending && !(s.choices && s.choices.length)) err(id + " seçenek yok");
  for (const c of s.choices || []) if (!sc[c.to]) err(id + " -> " + c.to + " yok");
}
// Kapsamlı arama: durum = sahne + eşyalar + bayraklar + görülen sahneler; akıl değeri en yükseği tutulur.
const clone = s => ({ san: s.san, items: new Set(s.items), flags: new Set(s.flags), seen: new Set(s.seen) });
const key = (id, s) => id + "|" + [...s.items].sort() + "|" + [...s.flags].sort() + "|" + [...s.seen].sort();
const best = new Map(), q = [], reached = new Set(), ends = new Map();
const init = { san: 100, items: new Set(), flags: new Set(), seen: new Set() };
function enter(id, s) {            // oyun motorundaki 'show' mantığı
  s = clone(s); const sce = sc[id]; const first = !s.seen.has(id); s.seen.add(id);
  if (first && sce.onEnter) sce.onEnter(s);
  if (sce.scare && sce.scare.san && (first || !sce.scare.once)) s.san = Math.max(0, Math.min(100, s.san + sce.scare.san));
  if (s.san <= 0 && !sce.ending) return enter("e_deli", s);
  return [id, s];
}
function push(id, s) { [id, s] = enter(id, s); const k = key(id, s); if (best.has(k) && best.get(k) >= s.san) return; best.set(k, s.san); q.push([id, s]); }
push(STORY.start, init); let n = 0, stuck = 0;
while (q.length && n++ < 400000) {
  const [id, s] = q.shift(); if (best.get(key(id, s)) > s.san) continue; reached.add(id);
  const sce = sc[id]; if (sce.ending) { if (!ends.has(id) || ends.get(id) < s.san) ends.set(id, s.san); continue; }
  const ok = sce.choices.filter(c => !c.if || c.if(s));
  if (!ok.length) { stuck++; console.log("SIKIŞMA", id); continue; }
  for (const c of ok) { const t = clone(s); if (c.do) c.do(t); if (c.heal) t.san = Math.min(100, t.san + c.heal); if (c.san) t.san = Math.max(0, Math.min(100, t.san + c.san)); push(c.to, t); }
}
for (const id of Object.keys(sc)) if (!reached.has(id)) err("ulaşılamıyor: " + id);
const allEnds = Object.keys(sc).filter(i => sc[i].ending);
for (const e of allEnds) if (!ends.has(e)) err("son görülmedi: " + e);
console.log("durum", best.size, "sahne", Object.keys(sc).length, "sonlar", [...ends].map(([k, v]) => k + "(en iyi akıl " + v + ")").join(", "), "sıkışma", stuck);
console.log(bad ? "HATA " + bad : "TAMAM"); process.exit(bad || stuck ? 1 : 0);
