# Sessiz Konak — metin tabanlı korku oyunu

Kuzyaka Köyü, yağmurlu bir gece. Nine'nin telgrafı: «GEL. SESİME CEVAP VERME.»

## Çalıştırma
`index.html` dosyasına çift tıkla (internet ve kurulum gerekmez). Kulaklık ve karanlık önerilir.

## Özellikler
- 30 sahne, 7 son (iyi, yarım, 5 kötü son); seçimler ve eşyalar sonu belirler
- **Akıl** göstergesi: korkunca düşer; düşük akılda yazı bozulur, fısıltılar ve kalp atışı başlar, 0'da oyun biter
- Eşyalar: demir mil, tuz, muska, anahtar, nazar boncuğu
- Kodla çizilen animasyonlu sahneler, üretilmiş ses (yağmur, drone, vuruş, çığlık) ve ani korkutmalar (yüz, gölge, flaş, kapı vuruşu, ışık sönmesi)
- Otomatik kayıt (Devam et); klavyede 1-9 ile seçim; metne tıklayarak yazıyı hızlandırma

## İpuçları (spoiler)
Kuyudaki ses Nine değil. Üç eşya (tuz, demir mil, muska), mahzen anahtarı ve aynayı kırmak gerekir.

## Dosyalar
`story.js` hikâye · `art.js` resimler · `audio.js` ses · `game.js` motor · `tests/sim.js` hikâye grafiği testi (`node tests/sim.js`)
