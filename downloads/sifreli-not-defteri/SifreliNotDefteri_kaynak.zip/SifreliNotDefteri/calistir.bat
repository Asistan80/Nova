@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Sifreli Not Defteri

set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)
if not defined PY goto :nopython
%PY% --version >nul 2>nul
if errorlevel 1 goto :nopython

if not exist ".venv\Scripts\python.exe" (
    echo Ilk kurulum: sanal ortam olusturuluyor...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
)
set "VPY=%CD%\.venv\Scripts\python.exe"

"%VPY%" -c "import PySide6, cryptography" >nul 2>nul
if errorlevel 1 (
    echo Bagimliliklar kuruluyor, bu sadece ilk seferde yapilir...
    "%VPY%" -m pip install --upgrade pip
    "%VPY%" -m pip install PySide6 cryptography
    if errorlevel 1 goto :fail
)

"%VPY%" main.py
if errorlevel 1 goto :fail
exit /b 0

:nopython
echo [HATA] Python bulunamadi. python.org adresinden Python 3.10 veya ustunu kurun.
pause
exit /b 1

:fail
echo.
echo [HATA] Uygulama baslatilamadi. Yukaridaki mesaji kontrol edin.
pause
exit /b 1
