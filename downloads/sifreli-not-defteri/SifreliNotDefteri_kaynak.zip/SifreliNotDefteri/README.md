# Şifreli Not Defteri

Windows için PySide6 tabanlı, Türkçe arayüzlü, mor-pembe-mavi gradyanlı şifreli masaüstü not defteri.

> **EXE durumu:** Bu pakette hazır bir `.exe` **yoktur**. Kaynak kodu ve EXE oluşturma dosyaları hazırdır;
> EXE'yi Windows'ta `build_exe.bat` ile siz derlersiniz (aşağıya bakın). Derleme, hazırlandığı ortamda
> (Linux) Windows EXE'si üretemediği için gerçek bir `.exe` derlemesi yapılmadı.

## Çalıştırma (kaynaktan)

En kolay yol: **`calistir.bat`** dosyasına çift tıklayın. İlk seferde gerekli paketleri kurar,
sonra uygulamayı açar. (`build_exe.bat` uygulamayı değil, EXE dosyasını derler; bitince EXE'yi otomatik açar.)

Elle çalıştırmak isterseniz:

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

Python 3.10 veya üstü gerekir.

## EXE oluşturma (Windows)

`build_exe.bat` dosyasına çift tıklayın (ya da komut satırında çalıştırın). Betik sırasıyla sanal ortam kurar,
bağımlılıkları yükler, ikonu üretir ve PyInstaller çalıştırır.

| Komut | Çıktı |
|---|---|
| `build_exe.bat` | `dist\SifreliNotDefteri\SifreliNotDefteri.exe` (klasör; daha hızlı açılır, önerilir) |
| `build_exe.bat onefile` | `dist\SifreliNotDefteri.exe` (tek dosya; açılışı biraz yavaştır) |

Not: Yeni derlenmiş, imzasız EXE dosyalarına Windows SmartScreen/antivirüs uyarı verebilir; bu PyInstaller
çıktılarında yaygındır.

## Özellikler

**Parola güvenliği**
- İlk açılışta ana parola belirleme (en az 8 karakter, güç göstergesi, zayıf parola reddi)
- Ana parolayı değiştirme (tüm notlar yeniden şifrelenir)
- Kilit ekranı; art arda yanlış denemelerde artan bekleme süresi
- Ekranı kilitleme (Ctrl+L), hareketsizlikte otomatik kilit (kapalı / 1–30 dk, varsayılan 5 dk),
  isteğe bağlı "simge durumuna küçülünce kilitle"

**Şifreli kayıt**
- Notlar `notlar.snd` dosyasında **AES-256-GCM** ile şifrelenir; anahtar parolanızdan **scrypt** (n=2¹⁵, r=8, p=1)
  ve rastgele tuzla türetilir. Parola hiçbir yere kaydedilmez.
- Atomik yazma (geçici dosya + değiştirme) ve her kayıtta bir önceki sürümün `notlar.snd.bak` kopyası;
  ana dosya bozulursa kilit açılırken yedek dosyadan otomatik açılır.
- Konum: `%APPDATA%\SifreliNotDefteri\NotDefteri\`

**Tarih ve saat**
- Üst şeritte canlı saat ve tarih; her notta oluşturulma ve son düzenleme zamanı

**Not yönetimi**
- Yeni not, otomatik kayıt (yazmayı bıraktıktan ~0,7 sn sonra), düzenleme, silme
- Çöp kutusu: geri yükleme, kalıcı silme, çöpü boşaltma; 30 günden eski silinen notlar otomatik temizlenir
- Boş bırakılan yeni notlar kendiliğinden atılır

**Arama ve sıralama**
- Başlık ve içerikte arama (büyük/küçük harf ve Türkçe karakter farkını yok sayar: "istanbul" → "İstanbul")
- Sıralama: son düzenleme, oluşturulma tarihi, başlık (Türkçe alfabe sırasıyla), her biri iki yönde
- Sabitlenen notlar her zaman listenin başında

**Tasarım**
- Mor-pembe-mavi gradyan arka plan, renkli not kartları (8 renk), açık ve koyu tema (Ctrl+T)

**Dışa aktarma**
- Seçili notu TXT veya Markdown olarak; tüm notları klasöre (ayrı dosyalar) ya da tek dosyaya
- Dışa aktarılan dosyalar şifrelenmez; uygulama bunu işlemden önce uyarır

**Yedekleme**
- Şifreli yedek (`.snbak`): kendi parolasıyla şifrelenir (ana parolayla aynı olabilir)
- Geri yükleme: *Birleştir* (aynı notta son düzenlenen kazanır) veya *Tümünü değiştir*
  (öncesinde `backups\` klasörüne şifreli otomatik kopya alınır)

**Ek kolaylıklar**
- Favoriler, sabitleme, karakter + kelime sayacı (seçili karakter sayısı dahil), sağ tık menüsü
- Yazı boyutu: Ctrl+ / Ctrl- / Ctrl+0 / Ctrl+fare tekerleği
- Parolayı göster/gizle düğmesi, pencere konumu ve ayarların hatırlanması
- Qt standart pencereleri Türkçe

## Klavye kısayolları

| Kısayol | İşlev |
|---|---|
| Ctrl+N | Yeni not |
| Ctrl+S | Şimdi kaydet |
| Ctrl+F | Ara (Esc: aramayı temizle) |
| Ctrl+D | Favori |
| Ctrl+P | Sabitle |
| Ctrl+Del / Del (listede) | Çöp kutusuna taşı |
| Ctrl+L | Ekranı kilitle |
| Ctrl+T | Açık/koyu tema |
| Ctrl++ / Ctrl+- / Ctrl+0 | Yazı boyutu |
| Ctrl+1 / 2 / 3 | Tümü / Favoriler / Çöp |
| Ctrl+E | Seçili notu dışa aktar |
| Ctrl+Shift+B / Ctrl+Shift+O | Yedek oluştur / geri yükle |
| Ctrl+Shift+K | Ana parolayı değiştir |
| F1 | Kısayol listesi |
| Ctrl+Q | Çıkış |

## Güvenlik notları ve sınırlar

- **Parolayı unutursanız notlar kurtarılamaz.** Kurtarma anahtarı ya da arka kapı yoktur.
- Kilitliyken anahtar ve notlar bellekten silinmek üzere bırakılır; Python bellek yönetimi nedeniyle
  bu, belleğin sıfırlandığına dair bir garanti değildir. Kötü amaçlı yazılımın çalıştığı ya da
  cihaza fiziksel erişimin olduğu bir bilgisayarda (ör. keylogger) hiçbir parola koruması yeterli olmaz.
- Başlık/saat/renk gibi tüm not verileri dosyanın içinde şifrelidir; yalnızca dosyanın varlığı ve boyutu
  dışarıdan görülebilir. Tema, yazı boyutu gibi arayüz ayarları şifresiz (Windows kayıt defteri) saklanır.
- Kullandığınız parola ne kadar uzun ve benzersizse koruma o kadar güçlüdür.

## Proje yapısı

```
main.py                    giriş noktası
app/crypto.py              scrypt + AES-256-GCM
app/vault.py               not modeli, şifreli kasa, çöp kutusu, yedek
app/main_window.py         ana pencere, menüler, kısayollar
app/lock_page.py           kilit ekranı / ilk kurulum
app/dialogs.py             parola ve kısayol pencereleri
app/note_list.py           renkli not kartı çizimi
app/theme.py               açık/koyu gradyan stilleri
app/utils.py               tarih, Türkçe arama, parola gücü, dışa aktarma, ikon
tools/make_icon.py         app_icon.ico üretir
tests/smoke_test.py        şifreleme + arayüz duman testi (python tests/smoke_test.py)
build_exe.bat              Windows EXE derleme betiği
SifreliNotDefteri.spec     PyInstaller tanımı
```
