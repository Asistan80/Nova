"""Uygulama ikonunu app_icon.ico (ve app_icon.png) olarak üretir. build_exe.bat tarafından çağrılır."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app.utils import make_app_icon  # noqa: E402

app = QApplication([])
pm = make_app_icon(256)
png_ok = pm.save(os.path.join(ROOT, "app_icon.png"), "PNG")
ico_ok = pm.save(os.path.join(ROOT, "app_icon.ico"), "ICO")
print("PNG:", "ok" if png_ok else "başarısız", "| ICO:", "ok" if ico_ok else "başarısız")
sys.exit(0 if ico_ok else 1)
