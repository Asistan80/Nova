# -*- mode: python ; coding: utf-8 -*-
# PyInstaller tanım dosyası.
#   Klasör çıktısı (varsayılan): SND_ONEFILE=0
#   Tek dosya çıktısı          : SND_ONEFILE=1
import os

onefile = os.environ.get("SND_ONEFILE", "0") == "1"
icon = "app_icon.ico" if os.path.exists("app_icon.ico") else None

a = Analysis(
    ["main.py"],
    pathex=["."],
    binaries=[],
    datas=[],
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "unittest", "pydoc"],
    noarchive=False,
)
pyz = PYZ(a.pure)

if onefile:
    exe = EXE(
        pyz, a.scripts, a.binaries, a.datas, [],
        name="SifreliNotDefteri",
        debug=False, strip=False, upx=False,
        console=False, icon=icon,
    )
else:
    exe = EXE(
        pyz, a.scripts, [],
        exclude_binaries=True,
        name="SifreliNotDefteri",
        debug=False, strip=False, upx=False,
        console=False, icon=icon,
    )
    coll = COLLECT(
        exe, a.binaries, a.datas,
        strip=False, upx=False,
        name="SifreliNotDefteri",
    )
