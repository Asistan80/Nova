@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Sifreli Not Defteri - EXE olusturma

echo ============================================================
echo  Sifreli Not Defteri - EXE olusturma
echo  Normal derleme : build_exe.bat
echo  Tek dosya EXE  : build_exe.bat onefile
echo ============================================================
echo.

set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)
if not defined PY goto :nopython
%PY% --version >nul 2>nul
if errorlevel 1 goto :nopython

if not exist ".venv\Scripts\python.exe" (
    echo [1/4] Sanal ortam olusturuluyor...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
) else (
    echo [1/4] Sanal ortam hazir.
)
set "VPY=%CD%\.venv\Scripts\python.exe"

echo [2/4] Bagimliliklar kuruluyor, bu birkac dakika surebilir...
"%VPY%" -m pip install --upgrade pip
"%VPY%" -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo [3/4] Ikon olusturuluyor...
"%VPY%" tools\make_icon.py
if errorlevel 1 echo [UYARI] Ikon olusturulamadi, EXE varsayilan ikonla derlenecek.

set "SND_ONEFILE=0"
set "EXE=dist\SifreliNotDefteri\SifreliNotDefteri.exe"
if /i "%~1"=="onefile" (
    set "SND_ONEFILE=1"
    set "EXE=dist\SifreliNotDefteri.exe"
)

echo [4/4] PyInstaller ile derleniyor, bu da birkac dakika surebilir...
"%VPY%" -m PyInstaller --noconfirm --clean SifreliNotDefteri.spec
if errorlevel 1 goto :fail
if not exist "%EXE%" goto :fail

echo.
echo ============================================================
echo  TAMAM! EXE hazir:
echo  %CD%\%EXE%
echo ============================================================
echo Uygulama simdi aciliyor...
start "" "%CD%\%EXE%"
echo.
pause
exit /b 0

:nopython
echo.
echo [HATA] Python bulunamadi.
echo https://www.python.org/downloads/ adresinden Python 3.10 veya ustunu kurun.
echo Kurulumda "Add python.exe to PATH" kutusunu isaretleyin.
echo Not: Microsoft Store'un Python kisayolu calismaz, python.org surumunu kurun.
echo.
pause
exit /b 1

:fail
echo.
echo [HATA] Islem basarisiz oldu. Yukaridaki son hata mesajlarini kontrol edin.
echo Bu pencerenin son satirlarini bana gonderirseniz sorunu cozerim.
echo.
pause
exit /b 1
