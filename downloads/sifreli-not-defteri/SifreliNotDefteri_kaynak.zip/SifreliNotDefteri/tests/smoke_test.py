"""Duman testi: şifreleme, kasa, yedek ve (başsız) arayüz akışı.

Çalıştırma:  python tests/smoke_test.py
"""
import json
import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.crypto import CorruptFile, WrongPassword  # noqa: E402
from app.utils import fold, password_strength, render_note, safe_filename, tr_sort_key  # noqa: E402
from app.vault import Vault  # noqa: E402

PW = "Test-Parola-123!"


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)
    print("  ok:", msg)


def test_vault():
    print("[kasa / şifreleme]")
    with tempfile.TemporaryDirectory() as d:
        v = Vault(d)
        check(not v.exists(), "başlangıçta kasa yok")
        v.create(PW)
        n = v.new_note()
        n.title, n.content = "Gizli başlık", "Çok gizli içerik ğüşiöç"
        v.save()
        raw = (Path(d) / "notlar.snd").read_text(encoding="utf-8")
        check("Gizli" not in raw and "içerik" not in raw, "dosyada düz metin yok")
        v.lock()
        check(not v.unlocked and not v.notes, "kilitleme belleği temizler")

        v2 = Vault(d)
        try:
            v2.unlock("yanlis-parola")
            check(False, "yanlış parola reddedilmeli")
        except WrongPassword:
            check(True, "yanlış parola reddedildi")
        v2.unlock(PW)
        check(len(v2.notes) == 1 and v2.notes[n.id].content.startswith("Çok gizli"), "doğru parola notu açar")

        # kurcalama
        p = Path(d) / "notlar.snd"
        doc = json.loads(p.read_text(encoding="utf-8"))
        doc["ct"] = doc["ct"][:-8] + ("AAAAAAAA" if not doc["ct"].endswith("AAAAAAAA") else "BBBBBBBB")
        p.write_text(json.dumps(doc), encoding="utf-8")
        v3 = Vault(d)
        check(v3.unlock(PW) is True, "bozulmuş ana dosya: son yedekten açıldı")
        v3.lock()
        v4 = Vault(d)
        try:
            v4.unlock("yanlis-parola")
            check(False, "bozuk dosyada yanlış parola yine reddedilmeli")
        except WrongPassword:
            check(True, "bozuk dosyada yanlış parola yine reddedildi")

        # çöp kutusu
        v2.save()
        v2.trash(n.id)
        check(v2.counts() == (0, 0, 1), "çöp kutusuna taşıma")
        v2.restore(n.id)
        check(v2.counts()[0] == 1, "geri yükleme")
        v2.trash(n.id)
        v2.notes[n.id].deleted_at -= 31 * 86400
        check(v2.purge_old_trash(30) == 1 and not v2.notes, "30 gün sonra otomatik temizlik")


def test_password_change_and_backup():
    print("[parola değişimi / yedek]")
    with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as out:
        v = Vault(d)
        v.create(PW)
        a = v.new_note(); a.title, a.content = "A", "birinci"
        b = v.new_note(); b.title, b.content = "B", "ikinci"
        v.save()
        try:
            v.change_password("yanlis", "Yeni-Parola-456!")
            check(False, "yanlış mevcut parola reddedilmeli")
        except WrongPassword:
            check(True, "yanlış mevcut parola reddedildi")
        v.change_password(PW, "Yeni-Parola-456!")
        v.lock()
        v = Vault(d)
        try:
            v.unlock(PW)
            check(False, "eski parola artık çalışmamalı")
        except WrongPassword:
            check(True, "eski parola artık çalışmıyor")
        v.unlock("Yeni-Parola-456!")
        check(len(v.notes) == 2, "yeni parola ile notlar açıldı")

        path = Path(out) / "yedek.snbak"
        v.export_backup(path, "Yedek-Parola-789!")
        text = path.read_text(encoding="utf-8")
        check("birinci" not in text, "yedek dosyası şifreli")
        try:
            Vault.read_backup(path, "yanlis")
            check(False, "yedek yanlış parolayla açılmamalı")
        except WrongPassword:
            check(True, "yedek yanlış parolayla açılmadı")
        notes = Vault.read_backup(path, "Yedek-Parola-789!")
        check(len(notes) == 2, "yedek doğru parolayla okundu")

        v.delete_forever(a.id)
        added, updated = v.merge_notes(notes)
        check(added == 1 and updated == 0 and len(v.notes) == 2, "birleştirme eksik notu ekler")
        v.notes[b.id].content = "yerel-yeni"
        v.notes[b.id].modified += 100
        added, updated = v.merge_notes(notes)
        check(v.notes[b.id].content == "yerel-yeni", "birleştirme daha yeni yerel notu korur")
        v.replace_all(notes)
        check(v.notes[b.id].content == "ikinci", "tümünü değiştir yedeği uygular")
        check(any((Path(d) / "backups").glob("oncesi-*.snd")), "değiştirmeden önce otomatik kopya alındı")

        # yedek, kasa dosyası yerine verilirse reddedilmeli
        try:
            Vault.read_backup(Path(d) / "notlar.snd", "Yeni-Parola-456!")
            check(False, "kasa dosyası yedek olarak kabul edilmemeli")
        except CorruptFile:
            check(True, "kasa dosyası yedek olarak kabul edilmedi")


def test_utils():
    print("[yardımcılar]")
    check(fold("İSTANBUL ışık ŞEKER") == fold("istanbul isik seker"), "Türkçe arama katlama")
    check(sorted(["zeytin", "çay", "ayva", "Ilık", "iyi"], key=tr_sort_key)
          == ["ayva", "çay", "Ilık", "iyi", "zeytin"], "Türkçe alfabetik sıralama")
    check(password_strength("12345678")[0] == 0, "yaygın parola çok zayıf")
    check(password_strength("Kuş-Bulut-Dağ-2026!")[0] >= 3, "uzun karışık parola güçlü")
    check(safe_filename('a<b>:c/d?') == "a_b__c_d_", "güvenli dosya adı")
    check(safe_filename("CON") != "CON", "ayrılmış Windows adı")


def test_gui():
    print("[arayüz (offscreen)]")
    from PySide6.QtCore import QCoreApplication, Qt
    from PySide6.QtWidgets import QApplication

    QCoreApplication.setOrganizationName("SND-TEST")
    QCoreApplication.setApplicationName("SmokeTest")
    app = QApplication.instance() or QApplication([])
    from app.main_window import MainWindow

    with tempfile.TemporaryDirectory() as d:
        from PySide6.QtCore import QSettings
        QSettings().clear()
        win = MainWindow(d)
        win.show()
        check(win.lock_page.mode == "setup" and win.stack.currentIndex() == 0, "ilk açılışta parola belirleme")

        win.on_lock_submitted(PW)
        check(win.stack.currentIndex() == 1 and win.vault.unlocked, "kurulumdan sonra uygulama açıldı")

        win.new_note()
        win.title_edit.setText("Alışveriş")
        win.editor.setPlainText("süt\nyumurta\nekmek")
        win._flush(refresh=True)
        n = win._cur()
        check(n.title == "Alışveriş" and "yumurta" in n.content, "otomatik kayıt notu kaydetti")
        check("Karakter: 17" in win.lbl_count.text() and "Kelime: 3" in win.lbl_count.text(), f"karakter sayacı ({win.lbl_count.text()})")

        win.toggle_favorite()
        win.toggle_pin()
        win.set_color(3)
        check(n.favorite and n.pinned and n.color == 3, "favori / sabitle / renk")

        win.new_note()
        win.title_edit.setText("Zebra")
        win.editor.setPlainText("başka bir not")
        win._flush(refresh=True)
        win.search.setText("yumurta")
        check(win.list.count() >= 1, "arama içerik eşleşmesi")
        win.search.setText("ALIŞVERİŞ")
        check(win.list.count() >= 1, "arama büyük/küçük harf duyarsız")
        win.search.setText("")
        win.sort_combo.setCurrentIndex(4)
        titles = [win.vault.notes[win.list.item(i).data(Qt.UserRole)].title for i in range(win.list.count())]
        check(titles[0] == "Alışveriş", f"sabitlenen not başta: {titles}")

        # çöp kutusu
        win.list.setCurrentRow(0)
        win.trash_current()
        check(win.vault.counts()[2] == 1, "not çöp kutusuna taşındı")
        win._set_filter("trash")
        check(win.list.count() == 1, "çöp kutusu görünümünde 1 not")
        win.list.setCurrentRow(0)
        win.restore_current()
        check(win.vault.counts()[2] == 0, "not geri yüklendi")
        win._set_filter("all")

        # kilitle / yanlış parola / aç
        win.lock_now()
        check(win.stack.currentIndex() == 0 and not win.vault.unlocked, "ekran kilitlendi")
        win.on_lock_submitted("yanlış-parola")
        check(not win.vault.unlocked and win.lock_page.error.text() != "", "yanlış parola kilidi açmadı")
        win.on_lock_submitted(PW)
        check(win.vault.unlocked and win.list.count() == 2, "doğru parola kilidi açtı")

        # tema
        win.set_theme("dark")
        check(win.theme == "dark", "koyu tema")
        win.set_theme("light")

        # ekran görüntüleri
        shots = os.environ.get("SND_SHOTS")
        if shots:
            Path(shots).mkdir(parents=True, exist_ok=True)
            win.resize(1200, 780)
            win.list.setCurrentRow(0)
            app.processEvents()
            win.grab().save(str(Path(shots) / "ana_acik.png"))
            win.set_theme("dark")
            app.processEvents()
            win.grab().save(str(Path(shots) / "ana_koyu.png"))
            win.lock_now()
            app.processEvents()
            win.grab().save(str(Path(shots) / "kilit_koyu.png"))
            win.set_theme("light")
            app.processEvents()
            win.grab().save(str(Path(shots) / "kilit_acik.png"))
        win.close()
        QSettings().clear()


if __name__ == "__main__":
    test_vault()
    test_password_change_and_backup()
    test_utils()
    test_gui()
    print("\nTÜM TESTLER GEÇTİ")
