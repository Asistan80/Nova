"""Şifreli Not Defteri — giriş noktası."""
import os
import sys

from PySide6.QtCore import QCoreApplication, QLibraryInfo, QLocale, QStandardPaths, QTranslator
from PySide6.QtWidgets import QApplication

from app import APP_NAME
from app.main_window import MainWindow


def data_directory() -> str:
    override = os.environ.get("SND_DATA_DIR")
    if override:
        return override
    return QStandardPaths.writableLocation(QStandardPaths.AppDataLocation)


def main() -> int:
    QCoreApplication.setOrganizationName("SifreliNotDefteri")
    QCoreApplication.setApplicationName("NotDefteri")
    app = QApplication(sys.argv)
    app.setApplicationDisplayName(APP_NAME)
    QLocale.setDefault(QLocale(QLocale.Turkish, QLocale.Turkey))

    # Qt'nin standart iletişim kutuları (Kes/Kopyala/Yapıştır vb.) Türkçe olsun
    translator = QTranslator()
    if translator.load("qtbase_tr", QLibraryInfo.path(QLibraryInfo.TranslationsPath)):
        app.installTranslator(translator)

    window = MainWindow(data_directory())
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
