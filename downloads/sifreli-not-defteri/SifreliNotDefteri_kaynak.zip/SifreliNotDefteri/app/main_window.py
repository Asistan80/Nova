"""Ana pencere."""
from __future__ import annotations

import time
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QEvent, QSettings, Qt, QTimer
from PySide6.QtGui import (QAction, QActionGroup, QColor, QIcon, QKeySequence, QPixmap,
                           QShortcut)
from PySide6.QtWidgets import (QApplication, QButtonGroup, QComboBox, QFileDialog, QFrame,
                               QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QMainWindow, QMenu, QMessageBox, QPlainTextEdit, QPushButton,
                               QStackedWidget, QVBoxLayout, QWidget)

from . import APP_NAME, __version__
from .crypto import CorruptFile, WrongPassword
from .dialogs import NewPasswordDialog, PasswordPrompt, ShortcutsDialog, ask, info
from .lock_page import LockPage
from .note_list import NoteDelegate
from .theme import build_qss
from .utils import (NOTE_COLORS, fmt_clock, fmt_dt, fold, make_app_icon, note_color_hex,
                    render_many, render_note, safe_filename, tr_sort_key, write_text_file)
from .vault import TRASH_DAYS, Vault

SORTS = [
    ("Son düzenleme (yeni → eski)", "modified", True),
    ("Son düzenleme (eski → yeni)", "modified", False),
    ("Oluşturulma (yeni → eski)", "created", True),
    ("Oluşturulma (eski → yeni)", "created", False),
    ("Başlık (A → Z)", "title", False),
    ("Başlık (Z → A)", "title", True),
]
AUTOLOCK_CHOICES = [(0, "Kapalı"), (1, "1 dakika"), (2, "2 dakika"), (5, "5 dakika"),
                    (10, "10 dakika"), (15, "15 dakika"), (30, "30 dakika")]


class MainWindow(QMainWindow):
    def __init__(self, data_dir: str):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(QIcon(make_app_icon(256)))
        self.resize(1200, 780)
        self.setMinimumSize(920, 620)

        self.settings = QSettings()
        self.vault = Vault(data_dir)
        theme = str(self.settings.value("theme", "light"))
        self.theme = theme if theme in ("light", "dark") else "light"
        self.font_size = max(9, min(28, int(self.settings.value("font_size", 12, type=int))))
        self.autolock_min = int(self.settings.value("autolock_min", 5, type=int))
        self.lock_on_minimize = self.settings.value("lock_on_minimize", False, type=bool)
        self.sort_index = int(self.settings.value("sort_index", 0, type=int))
        if not 0 <= self.sort_index < len(SORTS):
            self.sort_index = 0

        self.current_id: str | None = None
        self.filter = "all"
        self._loading = False
        self._dirty = False
        self._last_activity = time.monotonic()
        self.unlock_actions: list[QAction] = []

        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.setInterval(700)
        self.save_timer.timeout.connect(self._autosave)

        self._build_ui()
        self._build_menus()
        self.apply_theme()
        self._apply_editor_font()

        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self._update_clock)
        self.clock_timer.start(1000)
        self._update_clock()

        self.idle_timer = QTimer(self)
        self.idle_timer.timeout.connect(self._check_idle)
        self.idle_timer.start(5000)
        QApplication.instance().installEventFilter(self)

        geo = self.settings.value("geometry")
        if geo:
            self.restoreGeometry(geo)
        self.show_lock_screen()

    # =================================================================
    #  Arayüz kurulumu
    # =================================================================
    def _build_ui(self):
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        self.lock_page = LockPage()
        self.lock_page.submitted.connect(self.on_lock_submitted)
        self.lock_page.theme_toggle_requested.connect(self.toggle_theme)
        self.stack.addWidget(self.lock_page)

        self.app_page = QWidget()
        self.stack.addWidget(self.app_page)
        root = QVBoxLayout(self.app_page)
        root.setContentsMargins(14, 10, 14, 14)
        root.setSpacing(10)

        # ---- üst şerit -------------------------------------------------
        header = QFrame()
        header.setObjectName("header")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(16, 8, 12, 8)
        icon = QLabel()
        icon.setPixmap(make_app_icon(28).scaledToHeight(28, Qt.SmoothTransformation))
        title = QLabel(APP_NAME)
        title.setObjectName("appTitle")
        self.status = QLabel("")
        self.status.setObjectName("status")
        self.clock = QLabel("")
        self.clock.setObjectName("clock")
        self.theme_btn = QPushButton("🌓")
        self.theme_btn.setToolTip("Açık / koyu tema (Ctrl+T)")
        self.theme_btn.clicked.connect(self.toggle_theme)
        self.lock_btn = QPushButton("🔒 Kilitle")
        self.lock_btn.setToolTip("Ekranı kilitle (Ctrl+L)")
        self.lock_btn.clicked.connect(self.lock_now)
        hl.addWidget(icon)
        hl.addWidget(title)
        hl.addSpacing(18)
        hl.addWidget(self.status, 1)
        hl.addWidget(self.clock)
        hl.addSpacing(10)
        hl.addWidget(self.theme_btn)
        hl.addWidget(self.lock_btn)
        root.addWidget(header)

        body = QHBoxLayout()
        body.setSpacing(12)
        root.addLayout(body, 1)

        # ---- sol panel ------------------------------------------------------
        left = QFrame()
        left.setObjectName("panel")
        left.setFixedWidth(350)
        ll = QVBoxLayout(left)
        ll.setContentsMargins(12, 12, 12, 12)
        ll.setSpacing(8)

        self.search = QLineEdit()
        self.search.setPlaceholderText("🔍 Notlarda ara…  (Ctrl+F)")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._on_search)
        ll.addWidget(self.search)

        self.sort_combo = QComboBox()
        for label, _, _ in SORTS:
            self.sort_combo.addItem("↕ " + label)
        self.sort_combo.setCurrentIndex(self.sort_index)
        self.sort_combo.currentIndexChanged.connect(self._on_sort)
        ll.addWidget(self.sort_combo)

        chips = QHBoxLayout()
        chips.setSpacing(6)
        self.chip_group = QButtonGroup(self)
        self.chip_group.setExclusive(True)
        self.chips: dict[str, QPushButton] = {}
        for key, text in (("all", "Tümü"), ("fav", "⭐ Favoriler"), ("trash", "🗑 Çöp")):
            b = QPushButton(text)
            b.setProperty("chip", True)
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self._set_filter(k))
            self.chip_group.addButton(b)
            chips.addWidget(b)
            self.chips[key] = b
        self.chips["all"].setChecked(True)
        ll.addLayout(chips)

        self.list = QListWidget()
        self.list.setMouseTracking(True)
        self.list.setVerticalScrollMode(QListWidget.ScrollPerPixel)
        self.list.setSelectionMode(QListWidget.SingleSelection)
        self.list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._list_menu)
        self.delegate = NoteDelegate(lambda nid: self.vault.notes.get(nid), self.list)
        self.list.setItemDelegate(self.delegate)
        self.list.currentItemChanged.connect(self._on_current_changed)
        ll.addWidget(self.list, 1)
        QShortcut(QKeySequence(Qt.Key_Delete), self.list, activated=self._delete_key,
                  context=Qt.WidgetShortcut)

        self.empty_hint = QLabel("")
        self.empty_hint.setObjectName("emptyHint")
        self.empty_hint.setAlignment(Qt.AlignCenter)
        self.empty_hint.setWordWrap(True)
        ll.addWidget(self.empty_hint)

        self.new_btn = QPushButton("＋  Yeni not")
        self.new_btn.setObjectName("primary")
        self.new_btn.setCursor(Qt.PointingHandCursor)
        self.new_btn.clicked.connect(self.new_note)
        ll.addWidget(self.new_btn)
        self.empty_trash_btn = QPushButton("🗑  Çöp kutusunu boşalt")
        self.empty_trash_btn.setObjectName("danger")
        self.empty_trash_btn.clicked.connect(self.empty_trash)
        ll.addWidget(self.empty_trash_btn)
        body.addWidget(left)

        # ---- sağ panel ----------------------------------------------------------
        right = QFrame()
        right.setObjectName("panel")
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        self.right_stack = QStackedWidget()
        rl.addWidget(self.right_stack)

        placeholder = QLabel("📝\n\nBir not seçin ya da yeni bir not oluşturun\n(Ctrl+N)")
        placeholder.setObjectName("placeholder")
        placeholder.setAlignment(Qt.AlignCenter)
        self.right_stack.addWidget(placeholder)

        editor_page = QWidget()
        el = QVBoxLayout(editor_page)
        el.setContentsMargins(18, 14, 18, 12)
        el.setSpacing(8)

        self.title_edit = QLineEdit()
        self.title_edit.setObjectName("titleEdit")
        self.title_edit.setPlaceholderText("Başlık")
        self.title_edit.setMaxLength(200)
        self.title_edit.textChanged.connect(self._on_edited)
        el.addWidget(self.title_edit)

        tools = QHBoxLayout()
        tools.setSpacing(6)
        self.btn_fav = self._tool_button("☆ Favori", "Favorilere ekle / çıkar (Ctrl+D)",
                                         self.toggle_favorite)
        self.btn_pin = self._tool_button("📌 Sabitle", "Listenin başına sabitle (Ctrl+P)",
                                         self.toggle_pin)
        self.btn_color = QPushButton("🎨 Renk")
        self.btn_color.setToolTip("Not rengini seç")
        self.color_menu = QMenu(self)
        self._fill_color_menu(self.color_menu)
        self.btn_color.setMenu(self.color_menu)
        self.btn_trash = self._tool_button("🗑 Sil", "Çöp kutusuna taşı (Ctrl+Del)",
                                           self.trash_current)
        self.btn_restore = self._tool_button("♻ Geri yükle", "Notu çöp kutusundan geri al",
                                             self.restore_current)
        self.btn_purge = self._tool_button("✖ Kalıcı sil", "Notu tamamen sil",
                                           self.purge_current)
        self.btn_purge.setObjectName("danger")
        for b in (self.btn_fav, self.btn_pin, self.btn_color, self.btn_trash, self.btn_restore,
                  self.btn_purge):
            tools.addWidget(b)
        tools.addStretch(1)
        el.addLayout(tools)

        self.editor = QPlainTextEdit()
        self.editor.setObjectName("editor")
        self.editor.setPlaceholderText("Notunuzu buraya yazın… Değişiklikler otomatik kaydedilir.")
        self.editor.textChanged.connect(self._on_edited)
        self.editor.selectionChanged.connect(self._update_counter)
        self.editor.installEventFilter(self)
        el.addWidget(self.editor, 1)

        foot = QHBoxLayout()
        self.lbl_created = QLabel("")
        self.lbl_modified = QLabel("")
        self.lbl_count = QLabel("")
        self.lbl_save = QLabel("")
        for lab in (self.lbl_created, self.lbl_modified, self.lbl_count, self.lbl_save):
            lab.setObjectName("muted")
        foot.addWidget(self.lbl_created)
        foot.addSpacing(14)
        foot.addWidget(self.lbl_modified)
        foot.addStretch(1)
        foot.addWidget(self.lbl_count)
        foot.addSpacing(14)
        foot.addWidget(self.lbl_save)
        el.addLayout(foot)
        self.right_stack.addWidget(editor_page)
        body.addWidget(right, 1)

    def _tool_button(self, text, tip, slot) -> QPushButton:
        b = QPushButton(text)
        b.setToolTip(tip)
        b.setProperty("tool", True)
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(lambda _=False: slot())
        return b

    def _fill_color_menu(self, menu: QMenu):
        menu.clear()
        for i, (name, light, dark) in enumerate(NOTE_COLORS):
            pm = QPixmap(16, 16)
            pm.fill(QColor(light))
            act = menu.addAction(QIcon(pm), name)
            act.triggered.connect(lambda _=False, idx=i: self.set_color(idx))

    # ---- menüler -------------------------------------------------------------
    def _act(self, menu, text, slot, shortcut=None, *, checkable=False, needs_unlock=True):
        a = QAction(text, self)
        if shortcut:
            if isinstance(shortcut, (list, tuple)):
                a.setShortcuts([QKeySequence(s) for s in shortcut])
            else:
                a.setShortcut(QKeySequence(shortcut))
        a.setShortcutContext(Qt.WindowShortcut)
        a.setCheckable(checkable)
        a.triggered.connect(lambda _=False: slot())
        menu.addAction(a)
        self.addAction(a)
        if needs_unlock:
            self.unlock_actions.append(a)
        return a

    def _build_menus(self):
        mb = self.menuBar()

        m = mb.addMenu("&Dosya")
        self._act(m, "Yeni not", self.new_note, "Ctrl+N")
        self._act(m, "Şimdi kaydet", self.save_now, "Ctrl+S")
        m.addSeparator()
        ex = m.addMenu("Dışa aktar")
        self._act(ex, "Seçili notu dışa aktar (TXT / Markdown)…", self.export_selected, "Ctrl+E")
        self._act(ex, "Tüm notları klasöre aktar (ayrı dosyalar)…", self.export_all_folder)
        self._act(ex, "Tüm notları tek dosyaya aktar…", self.export_all_single)
        bk = m.addMenu("Yedekleme")
        self._act(bk, "Şifreli yedek oluştur…", self.backup_create, "Ctrl+Shift+B")
        self._act(bk, "Yedeği geri yükle…", self.backup_restore, "Ctrl+Shift+O")
        m.addSeparator()
        self._act(m, "Ekranı kilitle", self.lock_now, "Ctrl+L")
        self._act(m, "Çıkış", self.close, "Ctrl+Q", needs_unlock=False)

        m = mb.addMenu("D&üzen")
        self._act(m, "Notlarda ara", self.focus_search, "Ctrl+F")
        self._act(m, "Favorilere ekle / çıkar", self.toggle_favorite, "Ctrl+D")
        self._act(m, "Sabitle / sabitlemeyi kaldır", self.toggle_pin, "Ctrl+P")
        cm = m.addMenu("Not rengi")
        self._fill_color_menu(cm)
        self._act(m, "Notu çöp kutusuna taşı", self.trash_current, "Ctrl+Del")

        m = mb.addMenu("&Görünüm")
        grp = QActionGroup(self)
        grp.setExclusive(True)
        self.act_light = self._act(m, "Açık tema", lambda: self.set_theme("light"),
                                   checkable=True, needs_unlock=False)
        self.act_dark = self._act(m, "Koyu tema", lambda: self.set_theme("dark"),
                                  checkable=True, needs_unlock=False)
        grp.addAction(self.act_light)
        grp.addAction(self.act_dark)
        self._sync_theme_actions()
        self._act(m, "Temayı değiştir", self.toggle_theme, "Ctrl+T", needs_unlock=False)
        m.addSeparator()
        self._act(m, "Yazıyı büyüt", lambda: self.zoom(1), ["Ctrl++", "Ctrl+="])
        self._act(m, "Yazıyı küçült", lambda: self.zoom(-1), "Ctrl+-")
        self._act(m, "Yazı boyutunu sıfırla", lambda: self.zoom(0), "Ctrl+0")
        m.addSeparator()
        self._act(m, "Tüm notlar", lambda: self._set_filter("all"), "Ctrl+1")
        self._act(m, "Favoriler", lambda: self._set_filter("fav"), "Ctrl+2")
        self._act(m, "Çöp kutusu", lambda: self._set_filter("trash"), "Ctrl+3")

        m = mb.addMenu("G&üvenlik")
        self._act(m, "Ana parolayı değiştir…", self.change_password, "Ctrl+Shift+K")
        al = m.addMenu("Otomatik kilit (hareketsizlik)")
        agrp = QActionGroup(self)
        agrp.setExclusive(True)
        self._autolock_actions = {}
        for minutes, label in AUTOLOCK_CHOICES:
            a = self._act(al, label, lambda mm=minutes: self.set_autolock(mm), checkable=True)
            agrp.addAction(a)
            a.setChecked(minutes == self.autolock_min)
            self._autolock_actions[minutes] = a
        self.act_min_lock = self._act(m, "Simge durumuna küçülünce kilitle",
                                      self.toggle_lock_on_minimize, checkable=True)
        self.act_min_lock.setChecked(self.lock_on_minimize)

        m = mb.addMenu("&Yardım")
        self._act(m, "Klavye kısayolları", self.show_shortcuts, "F1", needs_unlock=False)
        self._act(m, "Hakkında", self.show_about, needs_unlock=False)

    # =================================================================
    #  Tema / görünüm
    # =================================================================
    def apply_theme(self):
        QApplication.instance().setStyleSheet(build_qss(self.theme))
        self.delegate.theme = self.theme
        self.list.viewport().update()

    def _sync_theme_actions(self):
        self.act_light.setChecked(self.theme == "light")
        self.act_dark.setChecked(self.theme == "dark")

    def set_theme(self, theme: str):
        self.theme = theme
        self.settings.setValue("theme", theme)
        self.apply_theme()
        self._sync_theme_actions()

    def toggle_theme(self):
        self.set_theme("dark" if self.theme == "light" else "light")

    def zoom(self, delta: int):
        self.font_size = 12 if delta == 0 else max(9, min(28, self.font_size + delta))
        self.settings.setValue("font_size", self.font_size)
        self._apply_editor_font()

    def _apply_editor_font(self):
        f = self.editor.font()
        f.setPointSize(self.font_size)
        self.editor.setFont(f)

    def _update_clock(self):
        self.clock.setText("🕒 " + fmt_clock())

    def flash(self, text: str, ms: int = 3500):
        self.status.setText(text)
        QTimer.singleShot(ms, lambda: self.status.setText("") if self.status.text() == text else None)

    # =================================================================
    #  Kilit ekranı / parola
    # =================================================================
    def show_lock_screen(self):
        mode = "unlock" if self.vault.exists() else "setup"
        self.lock_page.set_mode(mode)
        self.stack.setCurrentIndex(0)
        self._set_unlocked_ui(False)

    def _set_unlocked_ui(self, flag: bool):
        for a in self.unlock_actions:
            a.setEnabled(flag)

    def on_lock_submitted(self, password: str):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            if self.lock_page.mode == "setup":
                self.vault.create(password)
                used_bak = False
            else:
                used_bak = self.vault.unlock(password)
        except WrongPassword:
            QApplication.restoreOverrideCursor()
            self.lock_page.fail("Parola yanlış. Lütfen tekrar deneyin.")
            return
        except CorruptFile as exc:
            QApplication.restoreOverrideCursor()
            self.lock_page.fail(f"Not dosyası okunamadı: {exc}")
            return
        except OSError as exc:
            QApplication.restoreOverrideCursor()
            self.lock_page.fail(f"Dosya hatası: {exc}")
            return
        QApplication.restoreOverrideCursor()
        self.lock_page.reset()
        self._after_unlock(used_bak)

    def _after_unlock(self, used_bak: bool = False):
        purged = self.vault.purge_old_trash(TRASH_DAYS)
        if purged:
            self.vault.save()
        self.current_id = None
        self.filter = "all"
        self.chips["all"].setChecked(True)
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        self._last_activity = time.monotonic()
        self._set_unlocked_ui(True)
        self.stack.setCurrentIndex(1)
        self.refresh_list()
        self._show_note(None)
        if used_bak:
            self.flash("⚠ Ana dosya bozuktu; son yedekten açıldı.", 8000)
        elif purged:
            self.flash(f"{purged} eski not çöp kutusundan temizlendi.")

    def lock_now(self):
        if not self.vault.unlocked:
            return
        self.save_timer.stop()
        self._flush()
        self._discard_if_empty(self.current_id)
        for _ in range(5):  # açık diyalog varsa kapat
            w = QApplication.activeModalWidget()
            if w is None:
                break
            w.close()
        self.vault.lock()
        self._loading = True
        self.title_edit.clear()
        self.editor.clear()
        self.list.clear()
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        self._loading = False
        self.current_id = None
        self._dirty = False
        self.show_lock_screen()

    def change_password(self):
        if not self.vault.unlocked:
            return
        dlg = NewPasswordDialog(self, "Ana parolayı değiştir",
                                "Mevcut parolanızı ve yeni parolanızı girin. Tüm notlarınız "
                                "yeni parolayla yeniden şifrelenir.",
                                ask_current=True, ok_text="Parolayı değiştir")
        if dlg.exec() != dlg.Accepted or not self.vault.unlocked:
            return
        self._flush()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self.vault.change_password(dlg.current_password(), dlg.new_password())
        except WrongPassword:
            QApplication.restoreOverrideCursor()
            info(self, "Parola değiştirilemedi", "Mevcut parola yanlış.", QMessageBox.Warning)
            return
        finally:
            QApplication.restoreOverrideCursor()
        info(self, "Parola değiştirildi", "Ana parolanız güncellendi. Eski parolayla alınmış "
             "şifreli yedek dosyalarınız eski parolayla açılmaya devam eder.")

    # ---- otomatik kilit -----------------------------------------------------------
    def set_autolock(self, minutes: int):
        self.autolock_min = minutes
        self.settings.setValue("autolock_min", minutes)
        self.flash("Otomatik kilit kapatıldı." if minutes == 0
                   else f"Otomatik kilit: {minutes} dakika hareketsizlik.")

    def toggle_lock_on_minimize(self):
        self.lock_on_minimize = self.act_min_lock.isChecked()
        self.settings.setValue("lock_on_minimize", self.lock_on_minimize)

    def _check_idle(self):
        if (self.vault.unlocked and self.autolock_min > 0
                and time.monotonic() - self._last_activity > self.autolock_min * 60):
            self.lock_now()

    def eventFilter(self, obj, ev):  # noqa: N802
        t = ev.type()
        if t in (QEvent.MouseMove, QEvent.MouseButtonPress, QEvent.KeyPress, QEvent.Wheel):
            self._last_activity = time.monotonic()
            if t == QEvent.Wheel and obj is self.editor.viewport():
                pass
        if (obj is self.editor and t == QEvent.Wheel
                and QApplication.keyboardModifiers() & Qt.ControlModifier):
            self.zoom(1 if ev.angleDelta().y() > 0 else -1)
            return True
        return False

    def changeEvent(self, ev):  # noqa: N802
        if (ev.type() == QEvent.WindowStateChange and self.lock_on_minimize
                and self.isMinimized() and self.vault.unlocked):
            QTimer.singleShot(0, self.lock_now)
        super().changeEvent(ev)

    # =================================================================
    #  Liste
    # =================================================================
    def _cur(self):
        return self.vault.notes.get(self.current_id) if self.current_id else None

    def _visible_notes(self):
        q = fold(self.search.text().strip())
        out = []
        for n in self.vault.notes.values():
            in_trash = n.deleted_at is not None
            if self.filter == "trash":
                ok = in_trash
            elif in_trash:
                ok = False
            elif self.filter == "fav":
                ok = n.favorite
            else:
                ok = True
            if not ok:
                continue
            if q and n.id != self.current_id:
                if q not in fold(n.title) and q not in fold(n.content):
                    continue
            out.append(n)
        _, key, rev = SORTS[self.sort_index]
        if key == "title":
            out.sort(key=lambda n: tr_sort_key(n.title or "zzzz"), reverse=rev)
        elif key == "created":
            out.sort(key=lambda n: n.created, reverse=rev)
        else:
            out.sort(key=lambda n: n.modified, reverse=rev)
        if self.filter != "trash":
            out.sort(key=lambda n: not n.pinned)  # kararlı sıralama: sabitlenenler başa
        else:
            out.sort(key=lambda n: n.deleted_at or 0, reverse=True)
        return out

    def refresh_list(self):
        if not self.vault.unlocked:
            return
        notes = self._visible_notes()
        self.delegate.trash_mode = self.filter == "trash"
        self.list.blockSignals(True)
        self.list.clear()
        sel_item = None
        for n in notes:
            it = QListWidgetItem()
            it.setData(Qt.UserRole, n.id)
            self.list.addItem(it)
            if n.id == self.current_id:
                sel_item = it
        if sel_item is not None:
            self.list.setCurrentItem(sel_item)
            self.list.scrollToItem(sel_item)
        self.list.blockSignals(False)
        self.list.viewport().update()
        if sel_item is None and self.current_id is not None:
            self._show_note(None)
        self._update_counts(len(notes))

    def _update_counts(self, shown: int):
        total, fav, trash = self.vault.counts()
        self.chips["all"].setText(f"Tümü ({total})")
        self.chips["fav"].setText(f"⭐ Favoriler ({fav})")
        self.chips["trash"].setText(f"🗑 Çöp ({trash})")
        trash_view = self.filter == "trash"
        self.new_btn.setVisible(not trash_view)
        self.empty_trash_btn.setVisible(trash_view and trash > 0)
        if shown:
            self.empty_hint.setText("")
            self.empty_hint.hide()
        else:
            if self.search.text().strip():
                text = "Aramanızla eşleşen not bulunamadı."
            elif trash_view:
                text = f"Çöp kutusu boş.\nSilinen notlar {TRASH_DAYS} gün sonra kalıcı silinir."
            elif self.filter == "fav":
                text = "Henüz favori not yok.\n⭐ simgesiyle bir notu favorilere ekleyin."
            else:
                text = "Henüz not yok.\n“Yeni not” ile başlayın (Ctrl+N)."
            self.empty_hint.setText(text)
            self.empty_hint.show()

    def _on_search(self, _text=None):
        self.refresh_list()

    def _on_sort(self, idx: int):
        self.sort_index = idx
        self.settings.setValue("sort_index", idx)
        self.refresh_list()

    def _set_filter(self, key: str):
        if not self.vault.unlocked:
            return
        self._flush()
        self._discard_if_empty(self.current_id)
        self.filter = key
        self.chips[key].setChecked(True)
        self.refresh_list()

    def focus_search(self):
        self.search.setFocus()
        self.search.selectAll()

    def keyPressEvent(self, ev):  # noqa: N802
        if ev.key() == Qt.Key_Escape and self.search.hasFocus():
            self.search.clear()
            return
        super().keyPressEvent(ev)

    def _on_current_changed(self, cur: QListWidgetItem | None, prev):
        self.save_timer.stop()
        self._flush(refresh=False)
        self._discard_if_empty(self.current_id)
        nid = cur.data(Qt.UserRole) if cur is not None else None
        self._show_note(nid)
        QTimer.singleShot(0, self.refresh_list)

    def _list_menu(self, pos):
        it = self.list.itemAt(pos)
        if it is None:
            return
        self.list.setCurrentItem(it)
        m = QMenu(self)
        if self.filter == "trash":
            m.addAction("♻ Geri yükle", self.restore_current)
            m.addAction("✖ Kalıcı sil", self.purge_current)
        else:
            n = self._cur()
            m.addAction("★ Favoriden çıkar" if n and n.favorite else "☆ Favorilere ekle",
                        self.toggle_favorite)
            m.addAction("📌 Sabitlemeyi kaldır" if n and n.pinned else "📌 Sabitle",
                        self.toggle_pin)
            cm = m.addMenu("🎨 Renk")
            self._fill_color_menu(cm)
            m.addSeparator()
            m.addAction("🗑 Çöp kutusuna taşı", self.trash_current)
        m.exec(self.list.viewport().mapToGlobal(pos))

    def _delete_key(self):
        if self.filter == "trash":
            self.purge_current()
        else:
            self.trash_current()

    # =================================================================
    #  Editör
    # =================================================================
    def _show_note(self, nid: str | None):
        self._loading = True
        n = self.vault.notes.get(nid) if nid else None
        if n is None:
            self.current_id = None
            self.title_edit.clear()
            self.editor.clear()
            self.right_stack.setCurrentIndex(0)
        else:
            self.current_id = n.id
            self.title_edit.setText(n.title)
            self.editor.setPlainText(n.content)
            trashed = n.deleted_at is not None
            self.title_edit.setReadOnly(trashed)
            self.editor.setReadOnly(trashed)
            self.right_stack.setCurrentIndex(1)
            self._update_toolbar(n)
            self._update_footer(n)
        self._loading = False
        self._dirty = False
        self.lbl_save.setText("")
        self._update_counter()

    def _update_toolbar(self, n):
        trashed = n.deleted_at is not None
        for b in (self.btn_fav, self.btn_pin, self.btn_color, self.btn_trash):
            b.setVisible(not trashed)
        self.btn_restore.setVisible(trashed)
        self.btn_purge.setVisible(trashed)
        self.btn_fav.setText("★ Favoride" if n.favorite else "☆ Favori")
        self.btn_fav.setChecked(n.favorite)
        self.btn_pin.setText("📌 Sabitli" if n.pinned else "📌 Sabitle")
        self.btn_pin.setChecked(n.pinned)

    def _update_footer(self, n):
        self.lbl_created.setText(f"Oluşturulma: {fmt_dt(n.created)}")
        if n.deleted_at:
            self.lbl_modified.setText(f"Silinme: {fmt_dt(n.deleted_at)}")
        else:
            self.lbl_modified.setText(f"Son düzenleme: {fmt_dt(n.modified)}")

    def _update_counter(self):
        text = self.editor.toPlainText()
        chars = len(text)
        words = len(text.split())
        sel = len(self.editor.textCursor().selectedText())
        extra = f"  ·  seçili: {sel:,}".replace(",", ".") if sel else ""
        self.lbl_count.setText(
            f"Karakter: {chars:,}  ·  Kelime: {words:,}{extra}".replace(",", "."))

    def _on_edited(self, *_):
        if self._loading:
            return
        self._update_counter()
        n = self._cur()
        if n is None or n.deleted_at is not None:
            return
        self._dirty = True
        self.lbl_save.setText("✎ Kaydediliyor…")
        self.save_timer.start()

    def _autosave(self):
        if self._dirty:
            self._save_current(refresh=True)

    def _flush(self, refresh: bool = False):
        if self._dirty and self.current_id and self.vault.unlocked:
            self._save_current(refresh=refresh)

    def _save_current(self, refresh: bool = True):
        n = self._cur()
        if n is None or n.deleted_at is not None or not self.vault.unlocked:
            self._dirty = False
            return
        n.title = self.title_edit.text()
        n.content = self.editor.toPlainText()
        n.modified = time.time()
        self.vault.save()
        self._dirty = False
        self._update_footer(n)
        self.lbl_save.setText("✓ Kaydedildi")
        if refresh:
            self.refresh_list()

    def save_now(self):
        if not self.vault.unlocked:
            return
        self.save_timer.stop()
        self._flush(refresh=True)
        self.lbl_save.setText("✓ Kaydedildi")
        self.flash("Kaydedildi.")

    def _discard_if_empty(self, nid: str | None) -> bool:
        n = self.vault.notes.get(nid) if nid else None
        if (n is not None and n.deleted_at is None and not n.title.strip()
                and not n.content.strip() and not self._dirty):
            del self.vault.notes[nid]
            self.vault.save()
            return True
        return False

    # =================================================================
    #  Not işlemleri
    # =================================================================
    def new_note(self):
        if not self.vault.unlocked:
            return
        self.save_timer.stop()
        self._flush()
        self._discard_if_empty(self.current_id)
        if self.filter != "all":
            self.filter = "all"
            self.chips["all"].setChecked(True)
        if self.search.text():
            self.search.blockSignals(True)
            self.search.clear()
            self.search.blockSignals(False)
        n = self.vault.new_note()
        self.vault.save()
        self.current_id = n.id
        self.refresh_list()
        self._show_note(n.id)
        self.title_edit.setFocus()

    def _mutate(self, fn, message: str | None = None, keep_current: bool = True):
        """Seçili notu değiştir, kaydet, listeyi yenile."""
        n = self._cur()
        if n is None or not self.vault.unlocked:
            return
        self.save_timer.stop()
        self._flush()
        fn(n)
        self.vault.save()
        if not keep_current:
            self.current_id = None
        self.refresh_list()
        if keep_current:
            cur = self._cur()
            if cur is not None:
                self._update_toolbar(cur)
                self._update_footer(cur)
        else:
            self._show_note(None)
        if message:
            self.flash(message)

    def toggle_favorite(self):
        n = self._cur()
        if n is None or n.deleted_at is not None:
            return
        def fn(note):
            note.favorite = not note.favorite
        if self.filter == "fav" and n.favorite:
            self._mutate(fn, "Favorilerden çıkarıldı.", keep_current=False)
        else:
            self._mutate(fn, "Favorilere eklendi." if not n.favorite else "Favorilerden çıkarıldı.")

    def toggle_pin(self):
        n = self._cur()
        if n is None or n.deleted_at is not None:
            return
        def fn(note):
            note.pinned = not note.pinned
        self._mutate(fn, "Not sabitlendi." if not n.pinned else "Sabitleme kaldırıldı.")

    def set_color(self, idx: int):
        n = self._cur()
        if n is None or n.deleted_at is not None:
            return
        def fn(note):
            note.color = idx
        self._mutate(fn)

    def trash_current(self):
        n = self._cur()
        if n is None or n.deleted_at is not None:
            return
        def fn(note):
            note.deleted_at = time.time()
        self._mutate(fn, "Not çöp kutusuna taşındı.", keep_current=False)

    def restore_current(self):
        n = self._cur()
        if n is None or n.deleted_at is None:
            return
        def fn(note):
            note.deleted_at = None
        self._mutate(fn, "Not geri yüklendi.", keep_current=False)

    def purge_current(self):
        n = self._cur()
        if n is None or n.deleted_at is None:
            return
        if not ask(self, "Kalıcı olarak sil",
                   "Bu not kalıcı olarak silinecek ve geri getirilemeyecek. Devam edilsin mi?",
                   yes="Kalıcı sil", no="Vazgeç", danger=True) or not self.vault.unlocked:
            return
        nid = n.id
        self.vault.delete_forever(nid)
        self.vault.save()
        self.current_id = None
        self.refresh_list()
        self._show_note(None)
        self.flash("Not kalıcı olarak silindi.")

    def empty_trash(self):
        count = len(self.vault.trashed())
        if not count:
            return
        if not ask(self, "Çöp kutusunu boşalt",
                   f"Çöp kutusundaki {count} not kalıcı olarak silinecek. Devam edilsin mi?",
                   yes="Boşalt", no="Vazgeç", danger=True) or not self.vault.unlocked:
            return
        self.vault.empty_trash()
        self.vault.save()
        self.current_id = None
        self.refresh_list()
        self._show_note(None)
        self.flash("Çöp kutusu boşaltıldı.")

    # =================================================================
    #  Dışa aktarma
    # =================================================================
    def _confirm_plain_export(self) -> bool:
        return ask(self, "Dışa aktarma uyarısı",
                   "Dışa aktarılan dosyalar ŞİFRELENMEZ; herkes okuyabilir.\n"
                   "Şifreli bir kopya için “Yedekleme” menüsünü kullanın.\n\nDevam edilsin mi?",
                   yes="Devam et", no="Vazgeç", danger=True)

    def _export_notes(self):
        return [n for n in self._visible_all() if n.deleted_at is None]

    def _visible_all(self):
        return sorted(self.vault.notes.values(), key=lambda n: n.created)

    def export_selected(self):
        n = self._cur()
        if n is None or not self.vault.unlocked:
            info(self, "Dışa aktar", "Önce dışa aktarmak istediğiniz notu seçin.")
            return
        self._flush()
        if not self._confirm_plain_export() or not self.vault.unlocked:
            return
        default = safe_filename(n.title.strip() or "not")
        path, flt = QFileDialog.getSaveFileName(
            self, "Notu dışa aktar", str(Path.home() / f"{default}.txt"),
            "Metin dosyası (*.txt);;Markdown (*.md)")
        if not path or not self.vault.unlocked:
            return
        fmt = "md" if path.lower().endswith(".md") or "Markdown" in flt and not path.lower().endswith(".txt") else "txt"
        if not path.lower().endswith((".txt", ".md")):
            path += f".{fmt}"
        try:
            write_text_file(path, render_note(n, fmt), fmt)
        except OSError as exc:
            info(self, "Dışa aktarma başarısız", str(exc), QMessageBox.Warning)
            return
        self.flash("Not dışa aktarıldı.")

    def _ask_format(self) -> str | None:
        box = QMessageBox(QMessageBox.Question, "Biçim seçin", "Hangi biçimde dışa aktarılsın?",
                          QMessageBox.NoButton, self)
        b_txt = box.addButton("TXT", QMessageBox.AcceptRole)
        b_md = box.addButton("Markdown", QMessageBox.AcceptRole)
        box.addButton("Vazgeç", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is b_txt:
            return "txt"
        if box.clickedButton() is b_md:
            return "md"
        return None

    def export_all_folder(self):
        if not self.vault.unlocked:
            return
        self._flush()
        notes = self._export_notes()
        if not notes:
            info(self, "Dışa aktar", "Dışa aktarılacak not yok.")
            return
        if not self._confirm_plain_export():
            return
        fmt = self._ask_format()
        if not fmt or not self.vault.unlocked:
            return
        folder = QFileDialog.getExistingDirectory(self, "Klasör seçin", str(Path.home()))
        if not folder or not self.vault.unlocked:
            return
        used: set[str] = set()
        try:
            for n in notes:
                base = safe_filename(n.title.strip() or "Başlıksız not")
                name, i = base, 2
                while name.lower() in used or (Path(folder) / f"{name}.{fmt}").exists():
                    name = f"{base} ({i})"
                    i += 1
                used.add(name.lower())
                write_text_file(Path(folder) / f"{name}.{fmt}", render_note(n, fmt), fmt)
        except OSError as exc:
            info(self, "Dışa aktarma başarısız", str(exc), QMessageBox.Warning)
            return
        self.flash(f"{len(notes)} not dışa aktarıldı.")

    def export_all_single(self):
        if not self.vault.unlocked:
            return
        self._flush()
        notes = self._export_notes()
        if not notes:
            info(self, "Dışa aktar", "Dışa aktarılacak not yok.")
            return
        if not self._confirm_plain_export() or not self.vault.unlocked:
            return
        path, flt = QFileDialog.getSaveFileName(
            self, "Tüm notları dışa aktar", str(Path.home() / "tum-notlar.md"),
            "Markdown (*.md);;Metin dosyası (*.txt)")
        if not path or not self.vault.unlocked:
            return
        fmt = "txt" if path.lower().endswith(".txt") else "md"
        if not path.lower().endswith((".txt", ".md")):
            path += f".{fmt}"
        try:
            write_text_file(path, render_many(notes, fmt), fmt)
        except OSError as exc:
            info(self, "Dışa aktarma başarısız", str(exc), QMessageBox.Warning)
            return
        self.flash(f"{len(notes)} not tek dosyaya aktarıldı.")

    # =================================================================
    #  Yedekleme
    # =================================================================
    def backup_create(self):
        if not self.vault.unlocked:
            return
        self._flush()
        dlg = NewPasswordDialog(
            self, "Şifreli yedek oluştur",
            "Yedek dosyası bu parolayla şifrelenir. Ana parolanızı da kullanabilirsiniz; "
            "yedeği geri yüklerken bu parola gerekir.", ok_text="Yedeği oluştur")
        if dlg.exec() != dlg.Accepted or not self.vault.unlocked:
            return
        default = Path.home() / datetime.now().strftime("notlar-yedek-%Y%m%d-%H%M.snbak")
        path, _ = QFileDialog.getSaveFileName(self, "Yedeği kaydet", str(default),
                                              "Şifreli yedek (*.snbak)")
        if not path or not self.vault.unlocked:
            return
        if not path.lower().endswith(".snbak"):
            path += ".snbak"
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self.vault.export_backup(path, dlg.new_password())
        except OSError as exc:
            QApplication.restoreOverrideCursor()
            info(self, "Yedekleme başarısız", str(exc), QMessageBox.Warning)
            return
        QApplication.restoreOverrideCursor()
        self.flash("Şifreli yedek oluşturuldu.")
        info(self, "Yedek hazır", f"Şifreli yedek kaydedildi:\n{path}")

    def backup_restore(self):
        if not self.vault.unlocked:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Yedeği seç", str(Path.home()),
                                              "Şifreli yedek (*.snbak);;Tüm dosyalar (*)")
        if not path or not self.vault.unlocked:
            return
        prompt = PasswordPrompt(self, "Yedeği aç", "Bu yedeği oluştururken kullandığınız "
                                "parolayı girin.", ok_text="Yedeği aç")
        if prompt.exec() != prompt.Accepted or not self.vault.unlocked:
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            notes = self.vault.read_backup(path, prompt.password())
        except WrongPassword:
            QApplication.restoreOverrideCursor()
            info(self, "Geri yüklenemedi", "Parola yanlış ya da yedek dosyası bozulmuş.",
                 QMessageBox.Warning)
            return
        except CorruptFile as exc:
            QApplication.restoreOverrideCursor()
            info(self, "Geri yüklenemedi", str(exc), QMessageBox.Warning)
            return
        QApplication.restoreOverrideCursor()
        if not self.vault.unlocked:
            return

        box = QMessageBox(QMessageBox.Question, "Geri yükleme yöntemi",
                          f"Yedekte {len(notes)} not var.\n\n"
                          "• Birleştir: mevcut notlar korunur, yedekteki yeni/daha güncel notlar eklenir.\n"
                          "• Tümünü değiştir: mevcut notların yerine yedek gelir "
                          "(öncesinde şifreli otomatik kopya alınır).",
                          QMessageBox.NoButton, self)
        b_merge = box.addButton("Birleştir", QMessageBox.AcceptRole)
        b_replace = box.addButton("Tümünü değiştir", QMessageBox.DestructiveRole)
        box.addButton("Vazgeç", QMessageBox.RejectRole)
        box.exec()
        clicked = box.clickedButton()
        if clicked not in (b_merge, b_replace) or not self.vault.unlocked:
            return
        self.save_timer.stop()
        self._flush()
        if clicked is b_merge:
            added, updated = self.vault.merge_notes(notes)
            msg = f"{added} not eklendi, {updated} not güncellendi."
        else:
            self.vault.replace_all(notes)
            msg = f"{len(notes)} not geri yüklendi."
        self.vault.save()
        self.current_id = None
        self.refresh_list()
        self._show_note(None)
        self.flash(msg)
        info(self, "Geri yükleme tamamlandı", msg)

    # =================================================================
    #  Yardım
    # =================================================================
    def show_shortcuts(self):
        ShortcutsDialog(self).exec()

    def show_about(self):
        info(self, "Hakkında",
             f"<b>{APP_NAME}</b> sürüm {__version__}<br><br>"
             "Notlarınız bilgisayarınızda <b>AES-256-GCM</b> ile şifrelenerek saklanır; "
             "anahtar, ana parolanızdan <b>scrypt</b> ile türetilir.<br>"
             "Parola hiçbir yere kaydedilmez — unutulursa notlar kurtarılamaz.")

    # =================================================================
    #  Kapanış
    # =================================================================
    def closeEvent(self, ev):  # noqa: N802
        try:
            if self.vault.unlocked:
                self.save_timer.stop()
                self._flush()
                self._discard_if_empty(self.current_id)
            self.settings.setValue("geometry", self.saveGeometry())
            self.vault.lock()
        finally:
            ev.accept()
