"""Yardımcı işlevler: tarih biçimi, Türkçe arama, parola gücü, dışa aktarma metinleri, uygulama ikonu."""
from __future__ import annotations

import math
import re
from datetime import datetime

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (QBrush, QColor, QLinearGradient, QPainter, QPainterPath, QPen,
                           QPixmap)

TR_MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos",
             "Eylül", "Ekim", "Kasım", "Aralık"]
TR_DAYS = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]

NOTE_COLORS = [  # (ad, açık tema, koyu tema)
    ("Sarı", "#fff3b0", "#6b5a12"),
    ("Pembe", "#ffd1e8", "#7a2457"),
    ("Mor", "#e3d4ff", "#4a2a8a"),
    ("Mavi", "#cfe6ff", "#1f4a7d"),
    ("Turkuaz", "#c8f3ef", "#136a66"),
    ("Yeşil", "#d4f5cf", "#2c6a2a"),
    ("Turuncu", "#ffdcc2", "#8a4a14"),
    ("Gri", "#e9e7f0", "#3c3a50"),
]


def note_color_hex(index: int, theme: str) -> str:
    name, light, dark = NOTE_COLORS[index % len(NOTE_COLORS)]
    return light if theme == "light" else dark


def fmt_dt(ts: float | None) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts).strftime("%d.%m.%Y %H:%M:%S")


def fmt_short(ts: float | None) -> str:
    if not ts:
        return "—"
    return datetime.fromtimestamp(ts).strftime("%d.%m.%Y %H:%M")


def fmt_clock(now: datetime | None = None) -> str:
    now = now or datetime.now()
    return (f"{TR_DAYS[now.weekday()]}, {now.day} {TR_MONTHS[now.month - 1]} {now.year}"
            f"  ·  {now:%H:%M:%S}")


# ---- Türkçe arama / sıralama -----------------------------------------
_FOLD_MAP = str.maketrans({"ı": "i", "ş": "s", "ğ": "g", "ü": "u", "ö": "o", "ç": "c",
                           "â": "a", "î": "i", "û": "u"})


def fold(text: str) -> str:
    """Büyük/küçük harf ve Türkçe karakter farkını yok sayan arama biçimi."""
    text = text.replace("İ", "i").replace("I", "ı").lower()
    return text.translate(_FOLD_MAP)


_TR_ALPHA = "abcçdefgğhıijklmnoöprsştuüvyz"
_TR_ORDER = {ch: i for i, ch in enumerate(_TR_ALPHA)}


def tr_sort_key(text: str):
    text = text.replace("İ", "i").replace("I", "ı").lower().strip()
    return tuple(_TR_ORDER.get(ch, 100 + ord(ch)) for ch in text)


# ---- parola gücü --------------------------------------------------------
_COMMON = {"12345678", "123456789", "1234567890", "password", "parola123", "qwerty123",
           "11111111", "iloveyou", "sifre123", "password1", "parolam123", "12341234"}


def password_strength(pw: str) -> tuple[int, str]:
    """(0-4, etiket)"""
    if not pw:
        return 0, ""
    if pw.lower() in _COMMON:
        return 0, "Çok zayıf"
    pool = 0
    if any(c.islower() for c in pw):
        pool += 29
    if any(c.isupper() for c in pw):
        pool += 29
    if any(c.isdigit() for c in pw):
        pool += 10
    if any(not c.isalnum() for c in pw):
        pool += 33
    pool = max(pool, 1)
    uniq = len(set(pw)) / len(pw)
    bits = len(pw) * math.log2(pool) * (0.4 + 0.6 * uniq)
    if bits < 30:
        return 0, "Çok zayıf"
    if bits < 45:
        return 1, "Zayıf"
    if bits < 65:
        return 2, "Orta"
    if bits < 85:
        return 3, "Güçlü"
    return 4, "Çok güçlü"


# ---- dışa aktarma ----------------------------------------------------------
_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
             *(f"LPT{i}" for i in range(1, 10))}


def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    name = name[:80].strip(" .") or "not"
    if name.upper() in _RESERVED:
        name += "_"
    return name


def render_note(note, fmt: str) -> str:
    title = note.title.strip() or "Başlıksız not"
    created, modified = fmt_dt(note.created), fmt_dt(note.modified)
    if fmt == "md":
        return (f"# {title}\n\n*Oluşturulma: {created} · Son düzenleme: {modified}*\n\n"
                f"{note.content}\n")
    return (f"{title}\n{'=' * len(title)}\nOluşturulma: {created}\n"
            f"Son düzenleme: {modified}\n\n{note.content}\n")


def render_many(notes, fmt: str) -> str:
    sep = "\n\n---\n\n" if fmt == "md" else "\n\n" + "-" * 60 + "\n\n"
    return sep.join(render_note(n, fmt).rstrip("\n") for n in notes) + "\n"


def write_text_file(path, text: str, fmt: str):
    enc = "utf-8-sig" if fmt == "txt" else "utf-8"
    with open(path, "w", encoding=enc, newline="\n") as fh:
        fh.write(text)


# ---- uygulama ikonu (dosyasız, kodla çizilir) --------------------------------
def make_app_icon(size: int = 256) -> QPixmap:
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, True)
    s = float(size)
    bg = QLinearGradient(0, 0, s, s)
    bg.setColorAt(0.0, QColor("#8b5cf6"))
    bg.setColorAt(0.55, QColor("#ec4899"))
    bg.setColorAt(1.0, QColor("#3b82f6"))
    path = QPainterPath()
    path.addRoundedRect(QRectF(s * 0.04, s * 0.04, s * 0.92, s * 0.92), s * 0.22, s * 0.22)
    p.fillPath(path, QBrush(bg))
    # defter sayfası
    page = QRectF(s * 0.22, s * 0.16, s * 0.56, s * 0.68)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(255, 255, 255, 235))
    p.drawRoundedRect(page, s * 0.06, s * 0.06)
    # satırlar
    p.setPen(QPen(QColor(139, 92, 246, 120), max(1.0, s * 0.012)))
    for i in range(3):
        y = s * (0.30 + i * 0.07)
        p.drawLine(QPointF(s * 0.29, y), QPointF(s * 0.71, y))
    # kilit
    body = QRectF(s * 0.38, s * 0.55, s * 0.24, s * 0.20)
    p.setPen(QPen(QColor("#7c3aed"), s * 0.03, Qt.SolidLine, Qt.RoundCap))
    p.setBrush(Qt.NoBrush)
    shackle = QPainterPath()
    shackle.moveTo(s * 0.42, s * 0.55)
    shackle.lineTo(s * 0.42, s * 0.50)
    shackle.arcTo(QRectF(s * 0.42, s * 0.42, s * 0.16, s * 0.16), 180, -180)
    shackle.lineTo(s * 0.58, s * 0.55)
    p.drawPath(shackle)
    p.setPen(Qt.NoPen)
    p.setBrush(QColor("#7c3aed"))
    p.drawRoundedRect(body, s * 0.03, s * 0.03)
    p.setBrush(QColor("white"))
    p.drawEllipse(QPointF(s * 0.50, s * 0.63), s * 0.022, s * 0.022)
    p.end()
    return pm
