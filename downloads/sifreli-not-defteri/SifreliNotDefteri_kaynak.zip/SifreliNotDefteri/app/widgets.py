"""Ortak küçük bileşenler: parola alanı, parola gücü çubuğu."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QLineEdit, QProgressBar, QToolButton,
                               QVBoxLayout, QWidget)

from .utils import password_strength

STRENGTH_COLORS = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#10b981"]
STRENGTH_WIDTH = [12, 32, 58, 82, 100]


class PasswordField(QWidget):
    textChanged = Signal(str)
    returnPressed = Signal()

    def __init__(self, placeholder: str = "", parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        self.edit = QLineEdit()
        self.edit.setEchoMode(QLineEdit.Password)
        self.edit.setPlaceholderText(placeholder)
        self.btn = QToolButton()
        self.btn.setObjectName("eye")
        self.btn.setText("👁")
        self.btn.setCheckable(True)
        self.btn.setCursor(Qt.PointingHandCursor)
        self.btn.setToolTip("Parolayı göster / gizle")
        self.btn.setFocusPolicy(Qt.NoFocus)
        self.btn.toggled.connect(self._toggle)
        lay.addWidget(self.edit, 1)
        lay.addWidget(self.btn)
        self.edit.textChanged.connect(self.textChanged)
        self.edit.returnPressed.connect(self.returnPressed)

    def _toggle(self, shown: bool):
        self.edit.setEchoMode(QLineEdit.Normal if shown else QLineEdit.Password)

    def text(self) -> str:
        return self.edit.text()

    def clear(self):
        self.edit.clear()
        self.btn.setChecked(False)

    def setFocus(self, *args):  # noqa: N802
        self.edit.setFocus(*args)


class StrengthBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(4)
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setTextVisible(False)
        self.label = QLabel("")
        self.label.setObjectName("muted")
        lay.addWidget(self.bar)
        lay.addWidget(self.label)
        self.update_for("")

    def update_for(self, pw: str):
        if not pw:
            self.bar.setValue(0)
            self.label.setText("Parola gücü: —")
            return
        score, text = password_strength(pw)
        color = STRENGTH_COLORS[score]
        self.bar.setValue(STRENGTH_WIDTH[score])
        self.bar.setStyleSheet(
            f"QProgressBar::chunk {{ background: {color}; border-radius: 4px; }}")
        self.label.setText(f"Parola gücü: {text}")
