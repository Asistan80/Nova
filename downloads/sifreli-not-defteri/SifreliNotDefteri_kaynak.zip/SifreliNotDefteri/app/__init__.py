"""Şifreli Not Defteri."""

__version__ = "1.0.0"
APP_NAME = "Şifreli Not Defteri"
