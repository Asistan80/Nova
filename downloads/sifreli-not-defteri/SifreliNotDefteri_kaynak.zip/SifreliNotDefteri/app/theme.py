"""Açık/koyu tema stilleri (mor-pembe-mavi gradyan)."""
from __future__ import annotations

PALETTES = {
    "light": dict(
        text="#231d3d", sub="#625c87", panel="rgba(255,255,255,0.88)", input="#ffffff",
        border="rgba(124,58,237,0.28)", btn="rgba(124,58,237,0.10)", btn_hover="rgba(124,58,237,0.22)",
        dialog="#f6f3ff", popup="#ffffff", g0="#8b5cf6", g1="#ec4899", g2="#3b82f6",
        accent="#7c3aed", scroll="rgba(124,58,237,0.38)", sel="rgba(124,58,237,0.30)",
        disabled_bg="rgba(120,110,160,0.18)", disabled_fg="#8f89ad",
    ),
    "dark": dict(
        text="#efeaff", sub="#b3a9d9", panel="rgba(22,16,46,0.88)", input="#2a2152",
        border="rgba(196,181,253,0.28)", btn="rgba(196,181,253,0.12)", btn_hover="rgba(196,181,253,0.24)",
        dialog="#1a1433", popup="#241b48", g0="#4c1d95", g1="#9d174d", g2="#1e40af",
        accent="#c4b5fd", scroll="rgba(196,181,253,0.40)", sel="rgba(196,181,253,0.30)",
        disabled_bg="rgba(196,181,253,0.10)", disabled_fg="#7d739f",
    ),
}


def accent_color(theme: str) -> str:
    return PALETTES[theme]["accent"]


def build_qss(theme: str) -> str:
    p = PALETTES[theme]
    grad_diag = (f"qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {p['g0']}, "
                 f"stop:0.5 {p['g1']}, stop:1 {p['g2']})")
    grad_btn = ("qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #8b5cf6, stop:0.5 #ec4899, "
                "stop:1 #3b82f6)")
    grad_btn_hover = ("qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #9d75f8, stop:0.5 #f063a8, "
                      "stop:1 #5b96f8)")
    return f"""
* {{
    font-family: "Segoe UI", "Noto Sans", "Helvetica Neue", Arial, sans-serif;
    font-size: 13px; color: {p['text']};
}}
QMainWindow {{ background: {grad_diag}; }}
QStackedWidget {{ background: transparent; }}
QDialog, QMessageBox {{ background: {p['dialog']}; }}
QToolTip {{ background: {p['popup']}; color: {p['text']}; border: 1px solid {p['border']}; padding: 4px 8px; }}

QFrame#panel, QFrame#header, QFrame#lockCard {{
    background: {p['panel']}; border: 1px solid {p['border']}; border-radius: 16px;
}}
QFrame#header {{ border-radius: 14px; }}
QLabel {{ background: transparent; }}
QLabel#muted {{ color: {p['sub']}; font-size: 12px; }}
QLabel#error {{ color: #ef4444; font-weight: 600; }}
QLabel#warn {{ color: {p['sub']}; font-size: 12px; }}
QLabel#appTitle {{ font-size: 17px; font-weight: 700; color: {p['accent']}; }}
QLabel#clock {{ font-size: 14px; font-weight: 600; }}
QLabel#status {{ color: {p['sub']}; font-size: 12px; }}
QLabel#lockTitle {{ font-size: 26px; font-weight: 800; color: {p['accent']}; }}
QLabel#placeholder {{ font-size: 16px; color: {p['sub']}; }}
QLabel#emptyHint {{ color: {p['sub']}; font-size: 13px; }}

QLineEdit, QPlainTextEdit, QComboBox, QSpinBox {{
    background: {p['input']}; border: 1px solid {p['border']}; border-radius: 10px;
    padding: 7px 10px; selection-background-color: {p['sel']}; selection-color: {p['text']};
}}
QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus {{ border: 1px solid {p['accent']}; }}
QLineEdit#titleEdit {{
    font-size: 21px; font-weight: 700; background: transparent; border: none;
    border-bottom: 2px solid {p['border']}; border-radius: 0; padding: 6px 4px;
}}
QLineEdit#titleEdit:focus {{ border-bottom: 2px solid {p['accent']}; }}
QPlainTextEdit#editor {{ border-radius: 12px; padding: 10px 12px; }}
QComboBox QAbstractItemView {{
    background: {p['popup']}; border: 1px solid {p['border']};
    selection-background-color: {p['sel']}; selection-color: {p['text']}; outline: 0;
}}

QPushButton, QToolButton {{
    background: {p['btn']}; border: 1px solid {p['border']}; border-radius: 10px;
    padding: 7px 14px;
}}
QPushButton:hover, QToolButton:hover {{ background: {p['btn_hover']}; }}
QPushButton:disabled, QToolButton:disabled {{
    background: {p['disabled_bg']}; color: {p['disabled_fg']};
}}
QPushButton#primary {{
    background: {grad_btn}; color: white; border: none; font-weight: 700; padding: 10px 18px;
}}
QPushButton#primary:hover {{ background: {grad_btn_hover}; }}
QPushButton#primary:disabled {{ background: {p['disabled_bg']}; color: {p['disabled_fg']}; }}
QPushButton#danger {{ color: #ef4444; }}
QPushButton[chip="true"] {{ padding: 6px 10px; border-radius: 14px; }}
QPushButton[chip="true"]:checked {{ background: {grad_btn}; color: white; border: none; font-weight: 700; }}
QPushButton[tool="true"]:checked {{ background: {p['btn_hover']}; border: 1px solid {p['accent']}; }}
QPushButton::menu-indicator {{ width: 0px; }}
QToolButton#eye {{ padding: 6px 9px; }}

QListWidget {{ background: transparent; border: none; outline: 0; }}
QProgressBar {{ background: {p['btn']}; border: none; border-radius: 4px; max-height: 8px; min-height: 8px; }}

QScrollBar:vertical {{ background: transparent; width: 11px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {p['scroll']}; border-radius: 4px; min-height: 30px; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{ background: transparent; height: 11px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {p['scroll']}; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}

QMenuBar {{ background: rgba(0,0,0,0.14); }}
QMenuBar::item {{ background: transparent; color: white; padding: 6px 12px; border-radius: 8px; }}
QMenuBar::item:selected {{ background: rgba(255,255,255,0.28); }}
QMenuBar::item:disabled {{ color: rgba(255,255,255,0.55); }}
QMenu {{ background: {p['popup']}; border: 1px solid {p['border']}; border-radius: 10px; padding: 6px; }}
QMenu::item {{ padding: 7px 26px 7px 14px; border-radius: 6px; }}
QMenu::item:selected {{ background: {p['sel']}; }}
QMenu::item:disabled {{ color: {p['disabled_fg']}; }}
QMenu::separator {{ height: 1px; background: {p['border']}; margin: 5px 8px; }}
"""
