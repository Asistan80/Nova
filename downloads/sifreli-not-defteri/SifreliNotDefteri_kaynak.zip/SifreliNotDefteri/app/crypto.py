"""Şifreleme katmanı.

- Anahtar türetme : scrypt (n=2^15, r=8, p=1) + rastgele 16 baytlık tuz
- Şifreleme       : AES-256-GCM (kimlik doğrulamalı); başlık bilgisi AAD olarak bağlanır
- Parola hiçbir yere kaydedilmez; yalnızca açık olduğu sürece türetilmiş anahtar bellekte tutulur.
"""
from __future__ import annotations

import base64
import json
import os
import unicodedata

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = "SND1"
KDF_N = 2 ** 15
KDF_R = 8
KDF_P = 1
SALT_LEN = 16
NONCE_LEN = 12


class CryptoError(Exception):
    pass


class WrongPassword(CryptoError):
    """Parola yanlış (ya da veri kurcalanmış)."""


class CorruptFile(CryptoError):
    """Dosya biçimi geçersiz / bozuk."""


def _b64e(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def _b64d(text: str) -> bytes:
    return base64.b64decode(text.encode("ascii"), validate=True)


def _pw_bytes(password: str) -> bytes:
    return unicodedata.normalize("NFKC", password).encode("utf-8")


def new_kdf_params() -> dict:
    return {
        "name": "scrypt",
        "n": KDF_N,
        "r": KDF_R,
        "p": KDF_P,
        "salt": _b64e(os.urandom(SALT_LEN)),
    }


def derive_key(password: str, kdf: dict) -> bytes:
    try:
        if kdf.get("name") != "scrypt":
            raise CorruptFile("Bilinmeyen anahtar türetme yöntemi.")
        salt = _b64d(kdf["salt"])
        n, r, p = int(kdf["n"]), int(kdf["r"]), int(kdf["p"])
    except CorruptFile:
        raise
    except Exception as exc:  # noqa: BLE001
        raise CorruptFile("Anahtar türetme bilgisi okunamadı.") from exc
    # Kurcalanmış dosyalarla aşırı bellek/CPU tüketimini engelle
    if not (2 <= n <= 2 ** 18 and 1 <= r <= 16 and 1 <= p <= 4 and len(salt) >= 8):
        raise CorruptFile("Anahtar türetme parametreleri geçersiz.")
    try:
        return Scrypt(salt=salt, length=32, n=n, r=r, p=p).derive(_pw_bytes(password))
    except ValueError as exc:
        raise CorruptFile("Anahtar türetme parametreleri geçersiz.") from exc


def _aad(kind: str, kdf: dict) -> bytes:
    header = {"magic": MAGIC, "kind": kind, "kdf": kdf}
    return json.dumps(header, sort_keys=True, separators=(",", ":")).encode("utf-8")


def encrypt_document(key: bytes, kdf: dict, plaintext: bytes, kind: str = "vault") -> dict:
    nonce = os.urandom(NONCE_LEN)
    ct = AESGCM(key).encrypt(nonce, plaintext, _aad(kind, kdf))
    return {
        "magic": MAGIC,
        "kind": kind,
        "kdf": kdf,
        "nonce": _b64e(nonce),
        "ct": _b64e(ct),
    }


def decrypt_document(doc: dict, *, password: str | None = None, key: bytes | None = None,
                     kind: str = "vault") -> tuple[bytes, bytes, dict]:
    """(düz_metin, anahtar, kdf) döndürür."""
    try:
        if doc.get("magic") != MAGIC or doc.get("kind") != kind:
            raise CorruptFile("Bu dosya beklenen türde değil.")
        kdf = doc["kdf"]
        nonce = _b64d(doc["nonce"])
        ct = _b64d(doc["ct"])
    except CorruptFile:
        raise
    except Exception as exc:  # noqa: BLE001
        raise CorruptFile("Dosya biçimi geçersiz.") from exc
    if key is None:
        if password is None:
            raise ValueError("parola ya da anahtar gerekli")
        key = derive_key(password, kdf)
    try:
        plain = AESGCM(key).decrypt(nonce, ct, _aad(kind, kdf))
    except InvalidTag as exc:
        raise WrongPassword("Parola yanlış ya da dosya bozulmuş.") from exc
    return plain, key, kdf
