"""Not listesi için kart biçiminde çizim yapan delegate."""
from __future__ import annotations

from PySide6.QtCore import QRectF, QSize, Qt
from PySide6.QtGui import (QBrush, QColor, QLinearGradient, QPainter, QPainterPath, QPen)
from PySide6.QtWidgets import QStyle, QStyledItemDelegate

from .theme import accent_color
from .utils import fmt_short, note_color_hex


class NoteDelegate(QStyledItemDelegate):
    CARD_HEIGHT = 100

    def __init__(self, lookup, parent=None):
        super().__init__(parent)
        self.lookup = lookup  # id -> Note
        self.theme = "light"
        self.trash_mode = False

    def sizeHint(self, option, index):  # noqa: N802
        return QSize(option.rect.width(), self.CARD_HEIGHT)

    def paint(self, painter: QPainter, option, index):
        note = self.lookup(index.data(Qt.UserRole))
        if note is None:
            return
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        rect = QRectF(option.rect).adjusted(6, 4, -6, -4)
        light = self.theme == "light"

        base = QColor(note_color_hex(note.color, self.theme))
        grad = QLinearGradient(rect.topLeft(), rect.bottomRight())
        grad.setColorAt(0.0, base.lighter(110 if light else 128))
        grad.setColorAt(1.0, base)
        path = QPainterPath()
        path.addRoundedRect(rect, 14, 14)
        painter.fillPath(path, QBrush(grad))

        selected = bool(option.state & QStyle.State_Selected)
        hovered = bool(option.state & QStyle.State_MouseOver)
        accent = QColor(accent_color(self.theme))
        if selected:
            pen = QPen(accent, 3)
        elif hovered:
            pen = QPen(QColor(accent.red(), accent.green(), accent.blue(), 150), 2)
        else:
            pen = QPen(QColor(0, 0, 0, 38 if light else 70), 1)
        painter.setPen(pen)
        painter.drawPath(path)

        fg = QColor("#2a2540") if light else QColor("#f5f3ff")
        sub = QColor(fg)
        sub.setAlpha(165)
        x, w = rect.left() + 14, rect.width() - 28

        badges = ("📌" if note.pinned else "") + ("⭐" if note.favorite else "")
        badge_w = 0.0
        if badges:
            f = option.font
            f.setPointSizeF(10)
            painter.setFont(f)
            badge_w = painter.fontMetrics().horizontalAdvance(badges) + 6
            painter.setPen(fg)
            painter.drawText(QRectF(rect.right() - 14 - badge_w, rect.top() + 9, badge_w, 22),
                             Qt.AlignRight | Qt.AlignVCenter, badges)

        title_font = option.font
        title_font.setPointSizeF(11)
        title_font.setBold(True)
        painter.setFont(title_font)
        title = note.title.strip()
        painter.setPen(fg if title else sub)
        shown = painter.fontMetrics().elidedText(title or "Başlıksız not", Qt.ElideRight,
                                                 int(w - badge_w))
        painter.drawText(QRectF(x, rect.top() + 9, w - badge_w, 22),
                         Qt.AlignLeft | Qt.AlignVCenter, shown)

        body_font = option.font
        body_font.setBold(False)
        body_font.setPointSizeF(9.5)
        painter.setFont(body_font)
        painter.setPen(sub)
        snippet = " ".join(note.content.split())[:150] or "Boş not"
        body_rect = QRectF(x, rect.top() + 34, w, 36)
        painter.setClipRect(body_rect)
        painter.drawText(body_rect, Qt.TextWordWrap | Qt.AlignTop | Qt.AlignLeft, snippet)
        painter.setClipping(False)

        date_font = option.font
        date_font.setPointSizeF(8.5)
        date_font.setBold(False)
        painter.setFont(date_font)
        if self.trash_mode and note.deleted_at:
            stamp = f"Silinme: {fmt_short(note.deleted_at)}"
        else:
            stamp = f"Son düzenleme: {fmt_short(note.modified)}"
        painter.setPen(sub)
        painter.drawText(QRectF(x, rect.bottom() - 24, w, 18), Qt.AlignLeft | Qt.AlignVCenter,
                         stamp)
        painter.restore()
