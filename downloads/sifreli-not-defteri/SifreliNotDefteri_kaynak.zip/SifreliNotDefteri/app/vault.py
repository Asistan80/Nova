"""Not veri modeli ve şifreli kasa (vault)."""
from __future__ import annotations

import hmac
import json
import os
import shutil
import time
import uuid
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Optional

from .crypto import (CorruptFile, WrongPassword, decrypt_document, derive_key,
                     encrypt_document, new_kdf_params)

TRASH_DAYS = 30


@dataclass
class Note:
    id: str
    title: str = ""
    content: str = ""
    color: int = 0
    created: float = field(default_factory=time.time)
    modified: float = field(default_factory=time.time)
    favorite: bool = False
    pinned: bool = False
    deleted_at: Optional[float] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Note":
        names = {f.name for f in fields(cls)}
        clean = {k: v for k, v in data.items() if k in names}
        clean.setdefault("id", uuid.uuid4().hex)
        return cls(**clean)


class Vault:
    FILE = "notlar.snd"
    BAK = "notlar.snd.bak"

    def __init__(self, directory):
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.file = self.dir / self.FILE
        self.bak = self.dir / self.BAK
        self._key: bytes | None = None
        self._kdf: dict | None = None
        self.notes: dict[str, Note] = {}

    # ---- durum -----------------------------------------------------
    @property
    def unlocked(self) -> bool:
        return self._key is not None

    def exists(self) -> bool:
        return self.file.exists() or self.bak.exists()

    def _require(self):
        if not self.unlocked:
            raise RuntimeError("Kasa kilitli.")

    # ---- oluşturma / açma / kilitleme -------------------------------
    def create(self, password: str):
        self._kdf = new_kdf_params()
        self._key = derive_key(password, self._kdf)
        self.notes = {}
        self.save(make_bak=False)

    def unlock(self, password: str) -> bool:
        """Kasayı açar. Ana dosya bozuksa yedek dosyayı dener; yedek kullanıldıysa True döner."""
        last_error: Exception | None = None
        wrong_password = False
        for path, is_bak in ((self.file, False), (self.bak, True)):
            if not path.exists():
                continue
            try:
                doc = json.loads(path.read_text(encoding="utf-8"))
                plain, key, kdf = decrypt_document(doc, password=password)
                data = json.loads(plain.decode("utf-8"))
                notes = [Note.from_dict(d) for d in data.get("notes", [])]
            except WrongPassword:
                # Parola yanlış olabilir ya da ana dosya bozulmuş olabilir; yedek dosyayı da dene.
                wrong_password = True
                continue
            except (CorruptFile, ValueError, OSError, KeyError, TypeError) as exc:
                last_error = exc
                continue
            self._key, self._kdf = key, kdf
            self.notes = {n.id: n for n in notes}
            return is_bak
        if wrong_password:
            raise WrongPassword("Parola yanlış.")
        raise CorruptFile(str(last_error) if last_error else "Not dosyası bulunamadı.")

    def lock(self):
        self._key = None
        self._kdf = None
        self.notes = {}

    # ---- kaydetme ---------------------------------------------------
    def _serialize(self) -> bytes:
        payload = {"version": 1, "notes": [asdict(n) for n in self.notes.values()]}
        return json.dumps(payload, ensure_ascii=False).encode("utf-8")

    @staticmethod
    def _atomic_write(path: Path, data: bytes, keep_copy: Path | None = None):
        tmp = path.with_name(path.name + ".tmp")
        with open(tmp, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        if keep_copy is not None and path.exists():
            shutil.copy2(path, keep_copy)
        os.replace(tmp, path)

    def save(self, make_bak: bool = True):
        self._require()
        doc = encrypt_document(self._key, self._kdf, self._serialize())
        data = json.dumps(doc).encode("utf-8")
        self._atomic_write(self.file, data, self.bak if make_bak else None)

    # ---- parola değiştirme -------------------------------------------
    def change_password(self, old: str, new: str):
        self._require()
        check = derive_key(old, self._kdf)
        if not hmac.compare_digest(check, self._key):
            raise WrongPassword("Mevcut parola yanlış.")
        self._kdf = new_kdf_params()
        self._key = derive_key(new, self._kdf)
        self.save(make_bak=False)
        try:  # eski parolayla şifreli yedek kalmasın
            self.bak.unlink()
        except FileNotFoundError:
            pass

    # ---- not işlemleri -----------------------------------------------
    def new_note(self, color: int | None = None) -> Note:
        self._require()
        if color is None:
            color = len([n for n in self.notes.values() if n.deleted_at is None]) % 8
        note = Note(id=uuid.uuid4().hex, color=color)
        self.notes[note.id] = note
        return note

    def trash(self, nid: str):
        n = self.notes.get(nid)
        if n:
            n.deleted_at = time.time()

    def restore(self, nid: str):
        n = self.notes.get(nid)
        if n:
            n.deleted_at = None

    def delete_forever(self, nid: str):
        self.notes.pop(nid, None)

    def trashed(self) -> list[Note]:
        return [n for n in self.notes.values() if n.deleted_at is not None]

    def empty_trash(self) -> int:
        ids = [n.id for n in self.trashed()]
        for i in ids:
            del self.notes[i]
        return len(ids)

    def purge_old_trash(self, days: int = TRASH_DAYS) -> int:
        limit = time.time() - days * 86400
        ids = [n.id for n in self.trashed() if n.deleted_at < limit]
        for i in ids:
            del self.notes[i]
        return len(ids)

    def counts(self) -> tuple[int, int, int]:
        alive = [n for n in self.notes.values() if n.deleted_at is None]
        return len(alive), sum(1 for n in alive if n.favorite), len(self.trashed())

    # ---- şifreli yedek -------------------------------------------------
    def export_backup(self, path, password: str):
        self._require()
        kdf = new_kdf_params()
        key = derive_key(password, kdf)
        payload = {"version": 1, "exported": time.time(),
                   "notes": [asdict(n) for n in self.notes.values()]}
        doc = encrypt_document(key, kdf, json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                               kind="backup")
        self._atomic_write(Path(path), json.dumps(doc).encode("utf-8"))

    @staticmethod
    def read_backup(path, password: str) -> list[Note]:
        try:
            doc = json.loads(Path(path).read_text(encoding="utf-8"))
        except (ValueError, OSError) as exc:
            raise CorruptFile("Yedek dosyası okunamadı.") from exc
        plain, _, _ = decrypt_document(doc, password=password, kind="backup")
        try:
            data = json.loads(plain.decode("utf-8"))
            return [Note.from_dict(d) for d in data.get("notes", [])]
        except (ValueError, TypeError, KeyError) as exc:
            raise CorruptFile("Yedek içeriği geçersiz.") from exc

    def merge_notes(self, notes: list[Note]) -> tuple[int, int]:
        """Aynı kimlikli notlarda son düzenlenen kazanır. (eklenen, güncellenen) döner."""
        self._require()
        added = updated = 0
        for n in notes:
            cur = self.notes.get(n.id)
            if cur is None:
                self.notes[n.id] = n
                added += 1
            elif n.modified > cur.modified:
                self.notes[n.id] = n
                updated += 1
        return added, updated

    def snapshot(self) -> Path | None:
        """Mevcut şifreli kasanın bir kopyasını backups/ klasörüne alır."""
        if not self.file.exists():
            return None
        folder = self.dir / "backups"
        folder.mkdir(exist_ok=True)
        target = folder / time.strftime("oncesi-%Y%m%d-%H%M%S.snd")
        shutil.copy2(self.file, target)
        return target

    def replace_all(self, notes: list[Note]):
        self._require()
        self.snapshot()
        self.notes = {n.id: n for n in notes}
