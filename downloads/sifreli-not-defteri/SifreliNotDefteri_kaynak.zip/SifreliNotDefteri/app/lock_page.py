"""Kilit ekranı: ilk açılışta parola belirleme, sonraki açılışlarda kilit açma."""
from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget)

from .dialogs import MIN_PASSWORD
from .utils import make_app_icon, password_strength
from .widgets import PasswordField, StrengthBar


class LockPage(QWidget):
    submitted = Signal(str)
    theme_toggle_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.mode = "unlock"
        self._attempts = 0
        self._cooldown = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 20, 20, 20)
        outer.addStretch(1)
        row = QHBoxLayout()
        row.addStretch(1)
        self.card = QFrame()
        self.card.setObjectName("lockCard")
        self.card.setFixedWidth(450)
        row.addWidget(self.card)
        row.addStretch(1)
        outer.addLayout(row)
        outer.addStretch(1)

        lay = QVBoxLayout(self.card)
        lay.setContentsMargins(38, 30, 38, 24)
        lay.setSpacing(12)

        icon = QLabel()
        icon.setPixmap(make_app_icon(96))
        icon.setAlignment(Qt.AlignCenter)
        lay.addWidget(icon)
        title = QLabel("Şifreli Not Defteri")
        title.setObjectName("lockTitle")
        title.setAlignment(Qt.AlignCenter)
        lay.addWidget(title)
        self.subtitle = QLabel("")
        self.subtitle.setObjectName("muted")
        self.subtitle.setAlignment(Qt.AlignCenter)
        self.subtitle.setWordWrap(True)
        lay.addWidget(self.subtitle)
        lay.addSpacing(6)

        self.pw = PasswordField("Parola")
        self.pw.returnPressed.connect(self._enter_pressed)
        lay.addWidget(self.pw)
        self.confirm = PasswordField("Parola (tekrar)")
        self.confirm.returnPressed.connect(self._submit)
        lay.addWidget(self.confirm)
        self.strength = StrengthBar()
        self.pw.textChanged.connect(self.strength.update_for)
        lay.addWidget(self.strength)
        self.warn = QLabel("⚠ Parolanızı unutursanız notlarınız kurtarılamaz. "
                           "Parola hiçbir yere kaydedilmez.")
        self.warn.setObjectName("warn")
        self.warn.setWordWrap(True)
        lay.addWidget(self.warn)

        self.error = QLabel("")
        self.error.setObjectName("error")
        self.error.setAlignment(Qt.AlignCenter)
        self.error.setWordWrap(True)
        lay.addWidget(self.error)

        self.btn = QPushButton("")
        self.btn.setObjectName("primary")
        self.btn.setCursor(Qt.PointingHandCursor)
        self.btn.clicked.connect(self._submit)
        lay.addWidget(self.btn)

        bottom = QHBoxLayout()
        self.theme_btn = QPushButton("🌓 Tema")
        self.theme_btn.setToolTip("Açık / koyu tema (Ctrl+T)")
        self.theme_btn.clicked.connect(self.theme_toggle_requested)
        bottom.addStretch(1)
        bottom.addWidget(self.theme_btn)
        bottom.addStretch(1)
        lay.addLayout(bottom)

        self.set_mode("unlock")

    # ---- durum -------------------------------------------------------
    def set_mode(self, mode: str):
        self.mode = mode
        setup = mode == "setup"
        self.confirm.setVisible(setup)
        self.strength.setVisible(setup)
        self.warn.setVisible(setup)
        self.pw.edit.setPlaceholderText(
            f"Yeni ana parola (en az {MIN_PASSWORD} karakter)" if setup else "Parola")
        self.subtitle.setText(
            "İlk kurulum: notlarınızı korumak için bir ana parola belirleyin."
            if setup else "Notlarınızın kilidini açmak için parolanızı girin.")
        self.btn.setText("Parolayı belirle ve başla" if setup else "🔓 Kilidi aç")
        self.reset()

    def reset(self):
        self.pw.clear()
        self.confirm.clear()
        self.error.setText("")
        self._attempts = 0
        self._cooldown = 0
        self._timer.stop()
        self.btn.setEnabled(True)
        self.btn.setText("Parolayı belirle ve başla" if self.mode == "setup" else "🔓 Kilidi aç")
        self.pw.setFocus()

    def _enter_pressed(self):
        if self.mode == "setup":
            self.confirm.setFocus()
        else:
            self._submit()

    def _submit(self):
        if self._cooldown > 0:
            return
        pw = self.pw.text()
        if self.mode == "setup":
            if len(pw) < MIN_PASSWORD:
                self.error.setText(f"Parola en az {MIN_PASSWORD} karakter olmalı.")
                return
            if pw != self.confirm.text():
                self.error.setText("Parolalar eşleşmiyor.")
                return
            if password_strength(pw)[0] == 0:
                self.error.setText("Parola çok zayıf; daha uzun ve karışık bir parola seçin.")
                return
        elif not pw:
            self.error.setText("Parolayı girin.")
            return
        self.error.setText("")
        self.submitted.emit(pw)

    # ---- hata / bekleme ---------------------------------------------------
    def fail(self, message: str):
        self._attempts += 1
        self.error.setText(message)
        self.pw.clear()
        self.pw.setFocus()
        if self._attempts >= 3:
            self._cooldown = min(30, 2 ** (self._attempts - 2))
            self.btn.setEnabled(False)
            self._update_cooldown_text()
            self._timer.start(1000)

    def _update_cooldown_text(self):
        self.btn.setText(f"Tekrar denemek için bekleyin ({self._cooldown})")

    def _tick(self):
        self._cooldown -= 1
        if self._cooldown <= 0:
            self._timer.stop()
            self.btn.setEnabled(True)
            self.btn.setText("🔓 Kilidi aç")
            self.pw.setFocus()
        else:
            self._update_cooldown_text()
