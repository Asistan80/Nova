"""Diyaloglar: parola sorma, yeni/değiştirilen parola, kısayol listesi."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog, QFormLayout, QHBoxLayout, QLabel, QMessageBox,
                               QPushButton, QVBoxLayout)

from .utils import password_strength
from .widgets import PasswordField, StrengthBar

MIN_PASSWORD = 8


def ask(parent, title: str, text: str, yes: str = "Evet", no: str = "Hayır",
        danger: bool = False) -> bool:
    box = QMessageBox(QMessageBox.Warning if danger else QMessageBox.Question, title, text,
                      QMessageBox.NoButton, parent)
    yes_btn = box.addButton(yes, QMessageBox.AcceptRole)
    box.addButton(no, QMessageBox.RejectRole)
    box.setDefaultButton(box.buttons()[-1])
    box.exec()
    return box.clickedButton() is yes_btn


def info(parent, title: str, text: str, icon=QMessageBox.Information):
    box = QMessageBox(icon, title, text, QMessageBox.NoButton, parent)
    box.addButton("Tamam", QMessageBox.AcceptRole)
    box.exec()


class _BaseDialog(QDialog):
    def __init__(self, parent, title: str, width: int = 420):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(width)
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(22, 20, 22, 18)
        self.root.setSpacing(12)

    def add_buttons(self, ok_text: str = "Tamam"):
        row = QHBoxLayout()
        row.addStretch(1)
        cancel = QPushButton("İptal")
        cancel.clicked.connect(self.reject)
        self.ok_btn = QPushButton(ok_text)
        self.ok_btn.setObjectName("primary")
        self.ok_btn.setDefault(True)
        self.ok_btn.clicked.connect(self._try_accept)
        row.addWidget(cancel)
        row.addWidget(self.ok_btn)
        self.root.addLayout(row)

    def _try_accept(self):
        self.accept()


class PasswordPrompt(_BaseDialog):
    def __init__(self, parent, title: str, text: str, ok_text: str = "Tamam"):
        super().__init__(parent, title)
        label = QLabel(text)
        label.setWordWrap(True)
        self.root.addWidget(label)
        self.field = PasswordField("Parola")
        self.field.returnPressed.connect(self._try_accept)
        self.root.addWidget(self.field)
        self.error = QLabel("")
        self.error.setObjectName("error")
        self.root.addWidget(self.error)
        self.add_buttons(ok_text)
        self.field.setFocus()

    def _try_accept(self):
        if not self.field.text():
            self.error.setText("Parola boş olamaz.")
            return
        self.accept()

    def password(self) -> str:
        return self.field.text()


class NewPasswordDialog(_BaseDialog):
    """Yeni parola belirleme; ask_current=True ise mevcut parolayı da ister."""

    def __init__(self, parent, title: str, intro: str, ask_current: bool = False,
                 ok_text: str = "Tamam"):
        super().__init__(parent, title, 440)
        intro_label = QLabel(intro)
        intro_label.setWordWrap(True)
        self.root.addWidget(intro_label)
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignLeft)
        form.setSpacing(10)
        self.cur = PasswordField("Mevcut parola") if ask_current else None
        self.new = PasswordField(f"Yeni parola (en az {MIN_PASSWORD} karakter)")
        self.confirm = PasswordField("Yeni parola (tekrar)")
        if self.cur:
            form.addRow("Mevcut parola:", self.cur)
        form.addRow("Yeni parola:", self.new)
        form.addRow("Tekrar:", self.confirm)
        self.root.addLayout(form)
        self.strength = StrengthBar()
        self.new.textChanged.connect(self.strength.update_for)
        self.root.addWidget(self.strength)
        warn = QLabel("⚠ Parolayı unutursanız verileriniz kurtarılamaz.")
        warn.setObjectName("warn")
        self.root.addWidget(warn)
        self.error = QLabel("")
        self.error.setObjectName("error")
        self.root.addWidget(self.error)
        self.confirm.returnPressed.connect(self._try_accept)
        self.add_buttons(ok_text)
        (self.cur or self.new).setFocus()

    def _try_accept(self):
        if self.cur and not self.cur.text():
            self.error.setText("Mevcut parolayı girin.")
            return
        pw = self.new.text()
        if len(pw) < MIN_PASSWORD:
            self.error.setText(f"Parola en az {MIN_PASSWORD} karakter olmalı.")
            return
        if pw != self.confirm.text():
            self.error.setText("Parolalar eşleşmiyor.")
            return
        if password_strength(pw)[0] == 0:
            self.error.setText("Parola çok zayıf; daha uzun ve karışık bir parola seçin.")
            return
        self.accept()

    def current_password(self) -> str:
        return self.cur.text() if self.cur else ""

    def new_password(self) -> str:
        return self.new.text()


SHORTCUTS = [
    ("Ctrl+N", "Yeni not"),
    ("Ctrl+S", "Şimdi kaydet"),
    ("Ctrl+F", "Notlarda ara"),
    ("Esc", "Aramayı temizle (arama kutusundayken)"),
    ("Ctrl+D", "Favorilere ekle / çıkar"),
    ("Ctrl+P", "Notu sabitle / sabitlemeyi kaldır"),
    ("Ctrl+Del  /  Del (listede)", "Notu çöp kutusuna taşı"),
    ("Ctrl+L", "Ekranı kilitle"),
    ("Ctrl+T", "Açık / koyu temayı değiştir"),
    ("Ctrl++  /  Ctrl+-  /  Ctrl+0", "Yazıyı büyüt / küçült / sıfırla"),
    ("Ctrl+1 / Ctrl+2 / Ctrl+3", "Tümü / Favoriler / Çöp kutusu görünümü"),
    ("Ctrl+E", "Seçili notu dışa aktar (TXT / Markdown)"),
    ("Ctrl+Shift+B", "Şifreli yedek oluştur"),
    ("Ctrl+Shift+O", "Yedeği geri yükle"),
    ("Ctrl+Shift+K", "Ana parolayı değiştir"),
    ("F1", "Bu kısayol listesi"),
    ("Ctrl+Q", "Çıkış"),
]


class ShortcutsDialog(_BaseDialog):
    def __init__(self, parent):
        super().__init__(parent, "Klavye kısayolları", 480)
        rows = "".join(
            f"<tr><td style='padding:4px 18px 4px 0;'><b>{k}</b></td><td>{v}</td></tr>"
            for k, v in SHORTCUTS)
        label = QLabel(f"<table>{rows}</table>")
        label.setTextFormat(Qt.RichText)
        self.root.addWidget(label)
        row = QHBoxLayout()
        row.addStretch(1)
        close = QPushButton("Kapat")
        close.setObjectName("primary")
        close.clicked.connect(self.accept)
        row.addWidget(close)
        self.root.addLayout(row)
