KADİM DESTE  (Godot 4.3)
========================
Türk mitolojisi temalı, her yolculukta değişen kart tabanlı roguelike (Slay the Spire tarzı).

NASIL OYNANIR
  - 3 kahraman: Alp (güç/blok), Kam (zehir/ruhlar/yok etme), Mergen (ucuz kartlar/çoklu atış)
  - 3 perde (Bozkır, Demir Dağ, Tamu): harita, elit düşmanlar ve patron
  - Savaş: kart tıkla -> oynanır (hedef gerekiyorsa düşmana tıkla). Boşluk: turu bitir. Sağ tık/Esc: iptal
  - Düşmanın üstündeki simge niyetini gösterir (üzerine gel: ayrıntı). Durum simgelerinin üzerine gel: açıklama
  - Ödül: altın, kart, iksir, elitlerde relik, patronda relik seçimi
  - Kamp ateşi (dinlen/yükselt), pazar (kart/relik/iksir/kart silme), 10 farklı olay
  - 3 zorluk: Normal, Zor, Kâbus (birini bitirince sıradaki açılır)
  - Harita ekranında otomatik kayıt (Ana menü > Devam Et)
  - Ses ve müzik çalışma anında üretilir

WEB SÜRÜMÜ
  index.html'i doğrudan açmak çalışmaz. Web_Calistir.bat (Python gerekir) ya da klasörde:
  python -m http.server 8000  yazıp http://localhost:8000
