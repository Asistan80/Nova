\# Nexus Hub - Kütüphane \& Oyun Odası



Nexus Hub, kişisel kitaplığınızı ve dijital oyun kütüphanenizi eğlenceli bir oyunlaştırma (gamification) mekanizmasıyla bir araya getiren modern, web tabanlı bir yönetim arayüzüdür. Kullanıcıların okuma ve oynama alışkanlıklarını seviye atlama, rozet kazanma ve dinamik sayaçlar eşliğinde takip etmelerini sağlar.



\## 🌟 Öne Çıkan Özellikler



\*   \*\*Oyunlaştırılmış Takip Sistemi:\*\* Okudukça ve oynadıkça XP (Deneyim Puanı) kazanın, seviye (Level) atlayın ve "Kitap Kurdu" gibi özel rozetler koleksiyonunuza eklensin.

\*   \*\*Ne Okusam / Ne Oynasam? (Rastgele Seçim):\*\* Kararsız kaldığınız anlarda kütüphanenizden rastgele kitap veya oyun seçen şans çarkı mekanizması.

\*   \*\*Odaklanma Zamanlayıcısı (Pomodoro Timer):\*\* Okuma ve oyun seanslarınızı optimize etmek için 25 Dk, 50 Dk veya 5 Dk Mola seçeneklerine sahip entegre zamanlayıcı.

\*   \*\*Yıllık Okuma Hedefi:\*\* Yıl bitmeden okumayı hedeflediğiniz kitap sayısını belirleyin ve yüzde bazlı ilerleme grafiğiyle takip edin.

\*   \*\*Alıntılar Köşesi:\*\* Edebi eserlerden ilham verici sözleri görüntüleyin ve "Başka Bir Alıntı Gör" butonu ile dinamik olarak değiştirin.

\*   \*\*Hızlı Ekleme Paneli:\*\* Sağ üst köşede yer alan butonlar sayesinde hızlıca Tekli/Toplu Kitap ve Tekli/Toplu Oyun girişleri yapın.



\## 🗂️ Arayüz Modülleri (Sol Menü)



\*   🏠 \*\*Anasayfa:\*\* Seviye durumu, son okunan/eklenen içerikler, zamanlayıcı ve hedeflerin yer aldığı ana kontrol merkezi.

\*   📚 \*\*Kitaplığım:\*\* Detaylı kitap arşivi ve yönetim alanı.

\*   🎮 \*\*Oyun Odası:\*\* Dijital oyun kütüphanesinin listelendiği ve takip edildiği özel bölüm.

\*   🤝 \*\*Ödünç Takip Odası:\*\* Emanet verilen veya alınan kitap/oyunların kayıt merkezi.

\*   📊 \*\*İstatistikler:\*\* Okuma ve oynama verilerinin grafiksel analizleri.

\*   ❤️ \*\*İstek Listesi \& Bütçe:\*\* Alınması planlanan içeriklerin finansal takibiyle birlikte listelenmesi.

\*   🧩 \*\*Bulmaca Sayfası:\*\* Eğlenceli vakit geçirmek için entegre edilmiş mini oyun/bulmaca alanı.

\*   🔐 \*\*Güvenli Notlar:\*\* Kişisel verilerin ve özel notların saklandığı korumalı modül.

\*   ☕ \*\*Cozy Cafe \& AI:\*\* Çalışırken veya okuma yaparken eşlik edecek atmosferik içerikler ve yapay zeka entegrasyonu.

\*   ⚙️ \*\*Ayarlar:\*\* Genel sistem ve arayüz yapılandırmaları.

\*   💾 \*\*Bulut Yedekle:\*\* Verilerin güvenle saklanması için bulut senkronizasyon altyapısı.



\## 🛠️ Teknolojiler



\*   \*\*Frontend:\*\* HTML5, CSS3 (Modern Koyu Tema \& Neon Esintileri), JavaScript (Dinamik sayaçlar, rastgele seçim işlevleri ve zamanlayıcı yönetimi)



\---

\*Bu proje Murat tarafından kişisel gelişim ve eğlence yönetim ihtiyaçları doğrultusunda geliştirilmiştir.\*

