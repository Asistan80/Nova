nw.Window.open('index.html', {}, function(win) {
  win.maximize();

  var menubar = new nw.Menu({ type: 'menubar' });

  // 🔹 Dosya Menüsü
  var fileMenu = new nw.Menu();
  fileMenu.append(new nw.MenuItem({
    label: 'Yeni Dosya',
    key: 'N',
    modifiers: 'ctrl',
    click: function() {
      document.body.innerHTML = "<h2>Yeni dosya oluşturuldu!</h2>";
    }
  }));
  fileMenu.append(new nw.MenuItem({
    label: 'Aç (CSV/TXT)',
    click: function() {
      var input = document.createElement('input');
      input.type = 'file';
      input.accept = ".txt,.csv";
      input.onchange = e => {
        var file = e.target.files[0];
        var reader = new FileReader();
        reader.onload = function() {
          if (file.name.endsWith(".csv")) {
            var rows = reader.result.split("\n").map(r => r.split(","));
            var html = "<table border='1' style='width:100%;border-collapse:collapse'>";
            rows.forEach(row => {
              html += "<tr>" + row.map(cell => "<td>"+cell+"</td>").join("") + "</tr>";
            });
            html += "</table>";
            document.body.innerHTML = html;
          } else {
            document.body.innerHTML = "<pre>"+reader.result+"</pre>";
          }
        };
        reader.readAsText(file);
      };
      input.click();
    }
  }));
  fileMenu.append(new nw.MenuItem({
    label: 'Kaydet (TXT)',
    key: 'S',
    modifiers: 'ctrl',
    click: function() {
      var blob = new Blob(["Bu bir örnek veridir"], { type: "text/plain;charset=utf-8" });
      saveAs(blob, "veri.txt");
    }
  }));
  fileMenu.append(new nw.MenuItem({
    label: 'Dışa Aktar (JSON)',
    click: function() {
      var data = { isim: "MuBiKu", uygulama: "NW.js", tarih: new Date().toLocaleString() };
      var blob = new Blob([JSON.stringify(data)], { type: "application/json;charset=utf-8" });
      saveAs(blob, "veri.json");
    }
  }));
  fileMenu.append(new nw.MenuItem({
    label: 'Dışa Aktar (CSV)',
    click: function() {
      var csv = "isim,uygulama,tarih\nMuBiKu,NW.js,"+new Date().toLocaleString();
      var blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      saveAs(blob, "veri.csv");
    }
  }));
  fileMenu.append(new nw.MenuItem({ type: 'separator' }));
  fileMenu.append(new nw.MenuItem({
    label: 'Çıkış',
    key: 'Q',
    modifiers: 'ctrl',
    click: function() {
      nw.App.quit();
    }
  }));

  // 🔹 Tema/Görünüm Menüsü
  var themeMenu = new nw.Menu();
  themeMenu.append(new nw.MenuItem({ label: 'Kırmızı', click: () => document.body.style.background = "red" }));
  themeMenu.append(new nw.MenuItem({ label: 'Yeşil', click: () => document.body.style.background = "green" }));
  themeMenu.append(new nw.MenuItem({ label: 'Mavi', click: () => document.body.style.background = "blue" }));
  themeMenu.append(new nw.MenuItem({ label: 'Gradyan 1', click: () => document.body.style.background = "linear-gradient(to right, purple, orange)" }));
  themeMenu.append(new nw.MenuItem({ label: 'Gradyan 2', click: () => document.body.style.background = "linear-gradient(to bottom, lightblue, white)" }));
  themeMenu.append(new nw.MenuItem({ label: 'Dark Mode', click: () => document.body.style.background = "black", click: () => document.body.style.color = "white" }));

  // 🔹 Bildirim Menüsü
  var notifyMenu = new nw.Menu();
  notifyMenu.append(new nw.MenuItem({
    label: 'Bildirim Göster',
    click: () => {
      new Notification('Merhaba MuBiKu!', {
        body: 'Uygulaman bildirim gönderebiliyor 🎉'
      });
    }
  }));

  // 🔹 Ayarlar Menüsü (İleri Özellik)
  var settingsMenu = new nw.Menu();
  settingsMenu.append(new nw.MenuItem({
    label: 'Pencereyi Sabitle',
    click: () => win.setResizable(false)
  }));
  settingsMenu.append(new nw.MenuItem({
    label: 'Pencereyi Serbest Bırak',
    click: () => win.setResizable(true)
  }));

  // 🔹 Yardım Menüsü
  var helpMenu = new nw.Menu();
  helpMenu.append(new nw.MenuItem({
    label: 'Hakkında',
    click: function() {
      alert('Bu uygulama MuBiKu tarafından NW.js ile yapılmıştır!');
    }
  }));

  // 🔹 Sürpriz Özellikler 🎁
  var surpriseMenu = new nw.Menu();
  surpriseMenu.append(new nw.MenuItem({
    label: 'Rastgele Tema',
    click: () => {
      const colors = ["red","green","blue","yellow","purple","orange","pink"];
      document.body.style.background = colors[Math.floor(Math.random()*colors.length)];
    }
  }));
  surpriseMenu.append(new nw.MenuItem({
    label: 'Saat Göster',
    click: () => {
      alert("Şu anki saat: " + new Date().toLocaleTimeString());
    }
  }));

  // Menülere ekleme
  menubar.append(new nw.MenuItem({ label: 'Dosya', submenu: fileMenu }));
  menubar.append(new nw.MenuItem({ label: 'Tema', submenu: themeMenu }));
  menubar.append(new nw.MenuItem({ label: 'Bildirim', submenu: notifyMenu }));
  menubar.append(new nw.MenuItem({ label: 'Ayarlar', submenu: settingsMenu }));
  menubar.append(new nw.MenuItem({ label: 'Yardım', submenu: helpMenu }));
  menubar.append(new nw.MenuItem({ label: 'Sürpriz', submenu: surpriseMenu }));

  win.menu = menubar;
});
