# Pazarcı — İkinci El Dükkânı (v0.2)
Windows: windows/Pazarci.exe • Tarayıcı: web/ içinde web_baslat.bat

## v0.2 yenilikleri
- 30 eşya (12'den), hepsi 3B modelli
- 8 müşteri tipi, her birinin görünümü ve pazarlık huyu farklı: Cimri, Koleksiyoncu, Tüccar, Yaşlı Hanım, Öğrenci, Turist, Şüpheli Tip (çalıntı mal riski!), Müşteri
- Dükkân büyütme: 4 seviye, daha geniş oda, daha çok raf ve sergi masası; zemin (parke/karo/mermer) ve duvar rengi; dekorlar: halı, bitki, tablolar, kedi, plak çalar, neon, avize
- Akşam açık artırması (3 rakip alıcıya karşı)
- Koleksiyon defteri (kategoriyi tamamla = ödül), 14 başarım
- Stok sekmesi: toptancıya satış
- Sesler (kapı zili, kasa, tokmak...)
